﻿namespace CivilMasterData.Models.Logs
{
    public static class Comparer
    {
        public static bool AreEqual(string a, string b)
        {
            if (string.IsNullOrEmpty(a))
            {
                return string.IsNullOrEmpty(b);
            }
            else if (string.IsNullOrEmpty(b))
            {
                return string.IsNullOrEmpty(a);
            }
            else
            {
                string a1 = a.ToUpper();
                string b1 = b.ToUpper();
                return string.Equals(a1, b1);
            }
        }

        public static bool AreEqual(double? a, double? b, double tolerance)
        {
            if ((a == null || !a.HasValue) && (a == null || !a.HasValue))
                return true;

            if (a == null || !a.HasValue)
                return false;
            if (b == null || !b.HasValue)
                return false;

            return System.Math.Abs(a.Value - b.Value) < tolerance;
        }
    }
}
