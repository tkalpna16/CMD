﻿using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using System;
using System.Collections.Generic;

namespace CivilMasterData.Models.Logs
{
    public class ForgeLog
    {
        #region Members
        public MESSAGE_CODES MessageCode { get; set; }
        public string Description { get; set; }
        public string Unit { get; set; }
        public string CA { get; set; }
        public string CWA { get; set; }
        public string Lot { get; set; }
        public string SubDiscipline { get; set; }
        public string WP { get; set; }
        public string ObjectCode { get; set; }
        public string MaterialWorkGroup { get; set; }
        public string TagType { get; set; }
        public string MainItemTag { get; set; }
        public string FileName { get; set; }
        public string ItemTag { get; set; }
        public string GetError
        {
            get { return MessageCode.ToString(); }
        }
        #endregion

        #region Constructor
        public ForgeLog()
        {
        }
        public ForgeLog(MESSAGE_CODES messageCode, string description)
        {
            this.MessageCode = messageCode;
            this.Description = description;
        }
        #endregion

        #region Other methods
        public MISSING_MAINITEMS GetMISSING_MAINITEMS(int projectId, USERS user)
        {
            if (MessageCode != MESSAGE_CODES.MODEL_CONNECTOR_MAIN_ITEM_NOT_FOUND)
                return null;
            MISSING_MAINITEMS item = new MISSING_MAINITEMS();
            item.ProjectID = projectId;
            item.Unit = Unit;
            item.CA = CA;
            item.CWA = CWA;
            item.SubDiscipline = SubDiscipline;
            item.WP = WP;
            item.ObjectCode = ObjectCode;
            item.MaterialWorkGroup = MaterialWorkGroup;
            item.TagType = TagType;
            item.MainItemTag = MainItemTag;
            item.Lot = Lot;
            item.Filename = FileName;
            item.Created = 0;

            // Set User and Date
            item.UserID = user.USERID;
            item.CreationDate = DateTime.UtcNow;
            item.LastModified = DateTime.UtcNow;
            return item;
        }
        #endregion

        #region Comparer
        public static bool operator ==(ForgeLog msg1, ForgeLog msg2)
        {
            return Object.Equals(msg1, msg2);
        }

        public static bool operator !=(ForgeLog msg1, ForgeLog msg2)
        {
            return !Object.Equals(msg1, msg2);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            ForgeLog msg = (ForgeLog)obj;
            return (this.MessageCode == msg.MessageCode && Comparer.AreEqual(Unit, msg.Unit) &&
                Comparer.AreEqual(Description, msg.Description) &&
                Comparer.AreEqual(CA, msg.CA) &&
                Comparer.AreEqual(CWA, msg.CWA) &&
                Comparer.AreEqual(Lot, msg.Lot) &&
                Comparer.AreEqual(SubDiscipline, msg.SubDiscipline) &&
                Comparer.AreEqual(WP, msg.WP) &&
                Comparer.AreEqual(ObjectCode, msg.ObjectCode) &&
                Comparer.AreEqual(MaterialWorkGroup, msg.MaterialWorkGroup) &&
                Comparer.AreEqual(TagType, msg.TagType) &&
                Comparer.AreEqual(MainItemTag, msg.MainItemTag));
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        #endregion
    }
}
