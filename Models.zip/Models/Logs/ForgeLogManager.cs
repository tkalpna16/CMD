﻿using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Logs
{
    /// <summary>
    /// A class for managing logs
    /// </summary>
    public static class ForgeLogManager
    {
        #region Private members
        public static List<ForgeLog> Logs;
        #endregion

        #region Access members
        /// <summary>
        /// Total logs
        /// </summary>
        public static int Count { get { return Logs != null ? Logs.Count : 0; } }
        /// <summary>
        /// Is Empty
        /// </summary>
        public static bool Empty { get { return Logs != null ? Logs.Count == 0 : true; } }
        #endregion

        #region Other function
        /// <summary>
        /// Clear logs
        /// </summary>
        public static void Clear()
        {
            Logs = new List<ForgeLog>();
        }

        /// <summary>
        /// Add a log
        /// </summary>
        /// <param name="log"></param>
        public static void AddLog(ForgeLog log)
        {
            if (log == null)
                return;
            bool found = false;
            if (Logs == null)
                Logs = new List<ForgeLog>();
            foreach (ForgeLog l in Logs)
                if (l == log)
                {
                    found = true;
                    break;
                }
            if (!found)
                Logs.Add(log);
        }

        public static void AddLog(MESSAGE_CODES messageCode, string description)
        {
            ForgeLog log = new ForgeLog(messageCode, description);
            AddLog(log);
        }
        #endregion

        #region Output function
        /// <summary>
        /// Output override
        /// </summary>
        /// <returns></returns>
        public static string ExportString()
        {
            string output = string.Empty;
            foreach (ForgeLog log in Logs)
                output += log.ToString();
            return output;
        }
        public static string ExportJson()
        {
            return JsonConvert.SerializeObject(Logs);
        }

        public static List<string> GetFiles()
        {
            List<string> files = new List<string>();
            if (Logs != null)
                   files = Logs.Select(l => l.FileName).Distinct().ToList();
            return files;
        }

        /// <summary>
        /// List of Files where CMD_Checker Parameter is not defined
        /// </summary>
        /// <returns></returns>
        public static List<string> GetIncorrectFiles()
        {
            List<string> files = new List<string>();
            if (Logs != null)
                files = Logs.Where(l => l.MessageCode == MESSAGE_CODES.MODEL_CONNECTOR_CMD_CHECKER_NULL).Select(l => l.FileName).Distinct().ToList();
            return files;
        }
        #endregion
    }
}
