﻿using System.Collections.Generic;

namespace CivilMasterData.Models.Logs
{
    public class ExcelLogManager
    {
        public List<ExcelLog> Logs { get; set; }
        public string Result { get; set; }

        public ExcelLogManager()
        {
            Logs = new List<ExcelLog>();
        }

        public void AddLog(int rowId, int columnId, string note)
        {
            ExcelLog log = new ExcelLog();
            log.RowNumber = rowId;
            if (columnId > 0)
                log.ColumnName = columnId.ToString();
            log.Note = note;
            Logs.Add(log);
        }
    }
}
