﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Logs
{
    public class ExcelLog
    {
        public int RowNumber { get; set; }
        public string ColumnName { get; set; }
        public string Note { get; set; }
    }
}
