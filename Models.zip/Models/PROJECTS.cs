﻿/* ----- Tecnimont Civil MasterData @2020 ------*/
/* ---------------------------------------------*/
/* ---------------------------------------------*/
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CivilMasterData.Models.Users;
/* ---------------------------------------------*/
/* ---------------------------------------------*/
/* ---------------------------------------------*/

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class PROJECTS
    {
        [Key]
        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("CODE")]
        [Display(Name = "Project Code")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "Project cannot be longer than 256 characters.")]
        public string Code { get; set; }

        [Column("TITLE")]
        [Display(Name = "Project Title")]
        [StringLength(256, MinimumLength = 0, ErrorMessage = "Unit cannot be longer than 256 characters.")]
        public string Title { get; set; }

        [Column("DLPROJECTCODE")]
        [Display(Name = "DL Project Code")]
        [StringLength(256, MinimumLength = 0, ErrorMessage = "Unit cannot be longer than 256 characters.")]
        public string DLProjectCode { get; set; }

        [Column("NOTES")]
        [Display(Name = "Notes")]
        [StringLength(256, MinimumLength = 0, ErrorMessage = "Unit cannot be longer than 256 characters.")]
        public string Notes { get; set; }

        [Column("STARTDATE")]
        [Display(Name = "Project Start Date")]
        public DateTime? StartDate { get; set; }

        [Column("ENDDATE")]
        [Display(Name = "Project End Date")]
        public DateTime? EndDate { get; set; }

        [Column("ITEMPROCESSING")]
        [Display(Name = "ITEMPROCESSING")]
        public int? ITEMPROCESSING { get; set; }

        [Column("LASTUPDATEFROMFORGE")]
        [Display(Name = "LASTUPDATEFROMFORGE")]
        public DateTime? LASTUPDATEFROMFORGE { get; set; }

        [Column("LASTUPDATEUSERID")]
        [Display(Name = "LASTUPDATEUSERID")]
        public int? LASTUPDATEUSERID { get; set; }

        public USERS LASTUPDATEUSER{ get; set; }

        [Column("PROCESSINGUSERID")]
        [Display(Name = "PROCESSINGUSERID")]
        public int? PROCESSINGUSERID { get; set; }

        public USERS PROCESSINGUSER { get; set; }

        [Column("COMMONAREA")]
        [Display(Name = "CommonArea")]
        public string CommonArea { get; set; }

        [NotMapped]
        public string GetForgeUpdateInfo
        {
            get
            {
                string info = string.Empty;
                if (LASTUPDATEFROMFORGE != null && LASTUPDATEFROMFORGE.HasValue)
                    info += "Last update on " + LASTUPDATEFROMFORGE.Value.ToShortDateString();
                return info;
            }
        }

        [NotMapped]
        public string GetCompleteDescription
        {
            get
            {
                string info = Code;
                if (!string.IsNullOrEmpty(Title))
                    info += "-" + Title;
                return info;
            }
        }
    }
}
