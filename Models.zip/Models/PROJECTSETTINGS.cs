﻿using CivilMasterData.Models.BIM360.Parameters;
using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using UnitsNet;

namespace CivilMasterData.Models
{
    public class PROJECTSETTINGS
    {
        [Key]
        [Column("PROJECTSETTINGID")]
        [Display(Name = "PROJECTSETTINGID")]
        public int ProjectSettingID { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS PROJECTS { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("CWA")]
        [Display(Name = "CWA")]
        [StringLength(64, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string CWA { get; set; }

        [Column("SUBAREA")]
        [Display(Name = "SUBAREA")]
        [StringLength(64, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string SUBAREA { get; set; }

        [Column("BALANCE")]
        [Display(Name = "BALANCE")]
        [StringLength(64, MinimumLength = 1, ErrorMessage = "BALANCE cannot be longer than 32 characters.")]
        public string BALANCE { get; set; }

        [Column("DRAWINGNUMBER")]
        [Display(Name = "DRAWING NUMBER")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DRAWINGNUMBER cannot be longer than 32 characters.")]
        public string DRAWINGNUMBER { get; set; }

        [Column("DRAWINGDESCITEMS")]
        [Display(Name = "Drw Desc. for Items")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DRAWINGNUMBER cannot be longer than 32 characters.")]
        public string DRAWINGDESCITEMS { get; set; }

        [Column("DRAWINGDESCAREA")]
        [Display(Name = "Drw Desc. for Area/Balance")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DRAWINGNUMBER cannot be longer than 32 characters.")]
        public string DRAWINGDESCAREA { get; set; }

        [Column("DRAWINGDESCCOMMON")]
        [Display(Name = "Drw Desc. for Common Docs")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DRAWINGNUMBER cannot be longer than 32 characters.")]
        public string DRAWINGDESCCOMMON { get; set; }

        [Column("DRAWINGCWADIGIT")]
        [Display(Name = "CWA Digits")]
        [StringLength(256, MinimumLength = 3, ErrorMessage = "Digit between 3 and 256 characters.")]
        public string DRAWINGCWADIGIT { get; set; }

        [Column("DRAWINGOBJECTDIGIT")]
        [Display(Name = "Object digits")]
        [StringLength(256, MinimumLength = 3, ErrorMessage = "Digit between 3 and 256 characters.")]
        public string DRAWINGOBJECTDIGIT { get; set; }

        [Column("DRAWINGSEQDIGIT")]
        [Display(Name = "Sequence digits")]
        [StringLength(256, MinimumLength = 2, ErrorMessage = "Digit between 3 and 256 characters.")]
        public string DRAWINGSEQDIGIT { get; set; }

        [Column("BIM360PARAMETERS")]
        [Display(Name = "BIM360 Model Parameters")]
        public string BIM360PARAMETERS { get; set; }

        [Column("ELEVATIONCONCRETEUNIT")]
        [Display(Name = "Elevation Concrete Unit")]
        public string ELEVATIONCONCRETEUNIT { get; set; }

        [Column("FOUNDATIONCONCRETEUNIT")]
        [Display(Name = "Foundation Concrete Unit")]
        public string FOUNDATIONCONCRETEUNIT { get; set; }

        [Column("PAVINGUNIT")]
        [Display(Name = "Paving Unit")]
        public string PAVINGUNIT { get; set; }

        [Column("PILESUNIT")]
        [Display(Name = "Piles Unit")]
        public string PILESUNIT { get; set; }

        [Column("UNDERGROUNDPIPEUNIT")]
        [Display(Name = "Underground Pipe Unit")]
        public string UNDERGROUNDPIPEUNIT { get; set; }

        [Column("UNDERGROUNDPITUNIT")]
        [Display(Name = "Underground Pit Unit")]
        public string UNDERGROUNDPITUNIT { get; set; }

        [Column("STEELUNIT")]
        [Display(Name = "Steel Unit")]
        public string STEELUNIT { get; set; }

        [Column("CONCRETESLABUNIT")]
        [Display(Name = "Concrete Slab Unit")]
        public string CONCRETESLABUNIT { get; set; }

        [Column("DRAWING_MAX_NDOCS")]
        [Display(Name = "Unit Area Max Automatic Docs")]
        public int DRAWING_MAX_NDOCS { get; set; }

        [Column("DRAWING_MAX_MANUAL_NDOCS")]
        [Display(Name = "Unit Area Max Manual Docs")]
        public int DRAWING_MAX_MANUAL_NDOCS { get; set; }

        [Column("DRAWING_MAX_FOR_TYPE")]
        [Display(Name = "Max Automatic Drawing for Doc Type")]
        public int DRAWING_MAX_FOR_TYPE { get; set; }

        public List<string> VolumeUnits
        {
            get
            {
                List<string> volumes = new List<string>();
                volumes.Add(UnitsNet.Units.VolumeUnit.CubicMeter.ToString());
                volumes.Add(UnitsNet.Units.VolumeUnit.CubicCentimeter.ToString());
                volumes.Add(UnitsNet.Units.VolumeUnit.CubicInch.ToString());
                volumes.Add(UnitsNet.Units.VolumeUnit.CubicFoot.ToString());
                volumes.Add(UnitsNet.Units.VolumeUnit.CubicYard.ToString());
                return volumes;
            }
        }

        public List<string> LengthsUnits
        {
            get
            {
                List<string> lenghts = new List<string>();
                lenghts.Add(UnitsNet.Units.LengthUnit.Meter.ToString());
                lenghts.Add(UnitsNet.Units.LengthUnit.Centimeter.ToString());
                lenghts.Add(UnitsNet.Units.LengthUnit.Kilometer.ToString());
                lenghts.Add(UnitsNet.Units.LengthUnit.Inch.ToString());
                lenghts.Add(UnitsNet.Units.LengthUnit.Foot.ToString());
                return lenghts;
            }
        }

        public List<string> WeigthsUnits
        {
            get
            {
                List<string> weights = new List<string>();
                weights.Add(UnitsNet.Units.MassUnit.Tonne.ToString());
                weights.Add(UnitsNet.Units.MassUnit.Kilogram.ToString());
                weights.Add(UnitsNet.Units.MassUnit.Kilopound.ToString());
                weights.Add(UnitsNet.Units.MassUnit.Pound.ToString());
                return weights;
            }
        }

        public PROJECTSETTINGS() { }

        public PROJECTSETTINGS(PROJECTSETTINGS settings, int projectId)
        {
            this.ProjectID = projectId;
            this.CWA = settings.CWA;
            this.SUBAREA = settings.SUBAREA;
            this.BALANCE = settings.BALANCE;
            this.DRAWINGNUMBER = settings.DRAWINGNUMBER;
            this.DRAWINGCWADIGIT = settings.DRAWINGCWADIGIT;
            this.DRAWINGOBJECTDIGIT = settings.DRAWINGOBJECTDIGIT;
            this.DRAWINGSEQDIGIT = settings.DRAWINGSEQDIGIT;
            this.DRAWINGDESCAREA = settings.DRAWINGDESCAREA;
            this.DRAWINGDESCCOMMON = settings.DRAWINGDESCCOMMON;
            this.DRAWINGDESCITEMS = settings.DRAWINGDESCITEMS;
            this.BIM360PARAMETERS = settings.BIM360PARAMETERS;

            this.ELEVATIONCONCRETEUNIT = settings.ELEVATIONCONCRETEUNIT;
            this.FOUNDATIONCONCRETEUNIT = settings.FOUNDATIONCONCRETEUNIT;
            this.PAVINGUNIT = settings.PAVINGUNIT;
            this.PILESUNIT = settings.PILESUNIT;
            this.UNDERGROUNDPIPEUNIT = settings.UNDERGROUNDPIPEUNIT;
            this.UNDERGROUNDPITUNIT = settings.UNDERGROUNDPITUNIT;
            this.STEELUNIT = settings.STEELUNIT;
            this.CONCRETESLABUNIT = settings.CONCRETESLABUNIT;

            this.DRAWING_MAX_NDOCS = settings.DRAWING_MAX_NDOCS;
            this.DRAWING_MAX_MANUAL_NDOCS = settings.DRAWING_MAX_MANUAL_NDOCS;
            this.DRAWING_MAX_FOR_TYPE = settings.DRAWING_MAX_FOR_TYPE;
        }

        public List<string> GetBim360Parameters()
        {
            return ParsingUtils.ParseString(BIM360PARAMETERS);
        }

        public string GetBalanceMainItemTag(string area)
        {
            return area + "-" + BALANCE;
        }

    }
}
