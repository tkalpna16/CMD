﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// MISSING_MAINITEMS From Forge
    /// </summary>
    public class MISSING_MAINITEMS
    {
        [Key]
        [Column("MainItemID")]
        [Display(Name = "MainItemID")]
        public int MainItemID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int? ProjectID { get; set; }

        public PROJECTS PROJECTS { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("CA")]
        [Display(Name = "CA")]
        public string CA { get; set; }

        [Column("CWA")]
        [Display(Name = "CWA")]
        public string CWA { get; set; }

        [Column("SubDiscipline")]
        [Display(Name = "SubDiscipline")]
        public string SubDiscipline { get; set; }

        [Column("WP")]
        [Display(Name = "WP")]
        public string WP { get; set; }

        [Column("ObjectCode")]
        [Display(Name = "ObjectCode")]
        public string ObjectCode { get; set; }

        [Column("MaterialWorkGroup")]
        [Display(Name = "MaterialWorkGroup")]
        public string MaterialWorkGroup { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("MainItemTag")]
        [Display(Name = "MainItemTag")]
        public string MainItemTag { get; set; }

        [Column("Created")]
        [Display(Name = "Created")]
        public int? Created { get; set; }

        [Column("Filename")]
        [Display(Name = "Filename")]
        public string Filename { get; set; }

        [Column("Lot")]
        [Display(Name = "Lot")]
        public string Lot { get; set; }
    }
}
