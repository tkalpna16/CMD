﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class MAINITEMPARAMETERCATEGORIES
    {
        [Key]
        [Column("CategoriesID")]
        [Display(Name = "CategoriesID")]
        public int CategoriesID { get; set; }

        [Column("CATEGORIESNAME")]
        [Display(Name = "CATEGORIESNAME")]
        public string CATEGORIESNAME { get; set; }
    }
}
