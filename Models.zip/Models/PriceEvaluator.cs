﻿using CivilMasterData.Models.PriceList;
using System.Collections.Generic;

namespace CivilMasterData.Models
{
    public class PriceEvaluator
    {
        public PROJECTS Project { get; set; }

        public List<PBS> PBS { get; set; }

        public List<PBS> SelectedPBS { get; set; }

        public List<BOOLEANOPERATORS> BOOLEANOPERATORS { get; set; }

        public List<COMPARISONTYPES> COMPARISONTYPES { get; set; }

        public List<PRICECONDITIONTYPES> PRICECONDITIONTYPES { get; set; }

        public List<PRICECONDITIONS> PRICECONDITIONS { get; set; }

        public List<PRICECODES> PRICECODES { get; set; }

        public List<PRICECODEDEFINITIONS> PRICECODEDEFINITIONS { get; set; }

        public List<PRICEFAMILIESVALUES> PRICEFAMILIESVALUES { get; set; }

        public List<MAINITEMS> MAINITEMS { get; set; }

        public List<SECONDARY_ITEM> SECONDARY_ITEM { get; set; }

        public List<SECONDARY_ITEM_QUANTITY> SECONDARY_ITEM_QUANTITY { get; set; }

        public List<TAGTYPES> TagTypes { get; set; }

        public List<TAGTYPES> SelectedTagTypes { get; set; }
    }
}
