﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class MAIN_ITEM_QTY_REV
    {
        [Key]
        [Column("QtyId")]
        [Display(Name = "QtyId")]
        public int QtyId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int? MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("MTO_Rev")]
        [Display(Name = "MTO_Rev")]
        public int? MTO_Rev { get; set; }

        [Column("RevId")]
        [Display(Name = "RevId")]
        public int? RevId { get; set; }

        [Column("QTY")]
        [Display(Name = "QTY")]
        public double? QTY { get; set; }
    }
}
