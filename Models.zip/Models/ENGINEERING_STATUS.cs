﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class ENGINEERING_STATUS
    {
        [Key]
        [Column("StatusID")]
        [Display(Name = "StatusID")]
        public int StatusID { get; set; }

        [Column("MainCode")]
        [Display(Name = "MainCode")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string MainCode { get; set; }

        [Column("RevCode")]
        [Display(Name = "RevCode")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string RevCode { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string Description { get; set; }
    }
}
