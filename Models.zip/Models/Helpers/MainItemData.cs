﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Helpers
{
    public class MainItemData
    {
        public string Description { get; set; }
        public string Area { get; set; }
        public string WP { get; set; }
        public string ObjectCode { get; set; }
        public string Material { get; set; }
        public string TagType { get; set; }
        public string TagClient { get; set; }
        public string TagDescription { get; set; }
        public string Lot { get; set; }
        
    }
}
