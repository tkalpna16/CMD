﻿using System.Collections.Generic;

namespace CivilMasterData.Models.Helpers
{
    public class DocumentResult
    {
        public List<int> Documents { get; set; }
        public string Message { get; set; }
        public bool Valid { get; set; }
    }
}
