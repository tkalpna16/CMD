﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class MAINITEMPARAMETERVALUES
    {
        [Key]
        [Column("VALUEID")]
        [Display(Name = "VALUEID")]
        public int ValueID { get; set; }

        [Column("MAINITEMSID")]
        [Display(Name = "MAINITEMSID")]
        public int MainItemsID { get; set; }

        public MAINITEMS MainItems { get; set; }

        [Column("MAINITEMPARAMETERSID")]
        [Display(Name = "MAINITEMPARAMETERSID")]
        public int MainItemParametersID { get; set; }

        public MAINITEMPARAMETERS MainItemParameters { get; set; }
        
        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("PARAMETERTEXT")]
        [Display(Name = "PARAMETERTEXT")]
        public string PARAMETERTEXT { get; set; }

        [Column("PARAMETERDATE")]
        [Display(Name = "PARAMETERDATE")]
        public DateTime? PARAMETERDATE { get; set; }

        [Column("PARAMETERDOUBLE")]
        [Display(Name = "PARAMETERDOUBLE")]
        public double? PARAMETERDOUBLE { get; set; }
    }
}
