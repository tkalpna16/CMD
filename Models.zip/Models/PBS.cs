﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class PBS
    {
        [Key]
        [Column("PBSID")]
        [Display(Name = "PBSID")]
        public int PBSID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string Unit { get; set; }

        [Column("AREA")]
        [Display(Name = "Area name")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "Area cannot be longer than 32 characters.")]
        public string Area { get; set; }

        [Column("AREA_DESCRIPTION")]
        [Display(Name = "Area desc")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "Area description cannot be longer than 256 characters.")]
        public string AreaDescription { get; set; }

        [Column("DAS")]
        [Display(Name = "Discipline Sub-Area")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "DAS [Discipline Sub-Area] cannot be longer than 32 characters.")]
        public string DAS { get; set; }

        [Column("CWA")]
        [Display(Name = "CWA")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "CWA cannot be longer than 32 characters.")]
        public string CWA { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("AREAVALUE")]
        [Display(Name = "Area [m2]")]
        public double AreaValue { get; set; }

        [NotMapped]
        public bool AutoCWA { get; set; }

        [NotMapped]
        public bool AutoDAS { get; set; }

        public void UpdateValues(PROJECTSETTINGS pROJECTSETTINGS, USERS uSERS)
        {
            if (pROJECTSETTINGS == null)
                return;

            if (AutoCWA)
            {
                string value = pROJECTSETTINGS.CWA + CWA;
                value = ReplaceValues(value);
                this.CWA = value;
            }
            if (AutoDAS)
            {
                string value = pROJECTSETTINGS.SUBAREA + DAS;
                value = ReplaceValues(value);
                this.DAS = value;
            }

            if (uSERS != null)
                this.UserID = uSERS.USERID;
        }

        private string ReplaceValues(string value)
        {
            if (string.IsNullOrEmpty(value))
                return value;

            var bindingFlags = BindingFlags.Instance |
                BindingFlags.NonPublic |
                 BindingFlags.Public;
            var fieldNames = typeof(PBS).GetProperties()
                            .Select(field => field.Name)
                            .ToList();
            var fieldValues = this.GetType()
                                 .GetProperties(bindingFlags)
                                 .Select(field => field.GetValue(this))
                                 .ToList();

            for (int i = 0; i < fieldNames.Count; i++)
            {
                string name = fieldNames[i];
                var obj = fieldValues[i];
                string valueField = obj == null ? string.Empty : fieldValues[i].ToString();
                string identified = AppCostants.GetSubstitutionString(name);
                value = value.Replace(identified, valueField);
                identified = identified.ToLowerInvariant();
                value = value.Replace(identified, valueField);
                identified = identified.ToUpperInvariant();
                value = value.Replace(identified, valueField);
            }
            return value;
        }
    }
}
