﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class MAIN_ITEM_MANUAL_QTY_REV
    {
        [Key]
        [Column("QtyId")]
        [Display(Name = "QtyId")]
        public int QtyId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int? MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("RevId")]
        [Display(Name = "RevId")]
        public int? RevId { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("QTY_BUDGET")]
        [Display(Name = "QTY_BUDGET")]
        public double? QTY_BUDGET { get; set; }

        [Column("QTY_WR")]
        [Display(Name = "QTY_WR")]
        public double? QTY_WR { get; set; }

        [Column("MANUAL_QTY_HOLD")]
        [Display(Name = "MANUAL_QTY_HOLD")]
        public double? MANUAL_QTY_HOLD { get; set; }

        [Column("QTY_REINF")]
        [Display(Name = "QTY_REINF")]
        public double? QTY_REINF { get; set; }

        [Column("QTY_IFR")]
        [Display(Name = "QTY_IFR")]
        public double? QTY_IFR { get; set; }

        [Column("QTY_IFC")]
        [Display(Name = "QTY_IFC")]
        public double? QTY_IFC { get; set; }

        [Column("QTY_ACC")]
        [Display(Name = "QTY_ACC")]
        public double? QTY_ACC { get; set; }

        [Column("QTY_NEXT_CE")]
        [Display(Name = "QTY_NEXT_CE")]
        public double? QTY_NEXT_CE { get; set; }

        [Column("CONNECTION_INDICENCE")]
        [Display(Name = "CONNECTION_INDICENCE")]
        public double? CONNECTION_INDICENCE { get; set; }

        [Column("AI_VOLUME_LAST_ISSUE")]
        [Display(Name = "AI_VOLUME_LAST_ISSUE")]
        public double? AI_VOLUME_LAST_ISSUE { get; set; }

        #region Constuctor
        public MAIN_ITEM_MANUAL_QTY_REV() { }
        public MAIN_ITEM_MANUAL_QTY_REV(MAIN_ITEM_QUANTITY qty, USERS user)
        {
            this.MainItemId = qty.MainItemId;
            this.QTY_BUDGET = qty.QTY_BUDGET;
            this.QTY_WR = qty.QTY_WR;
            this.QTY_IFR = qty.QTY_IFR;
            this.QTY_IFC = qty.QTY_IFC;
            this.QTY_ACC = qty.QTY_ACC;
            this.QTY_NEXT_CE = qty.QTY_NEXT_CE;
            this.MANUAL_QTY_HOLD = qty.MANUAL_QTY_HOLD;
            this.QTY_REINF = qty.QTY_REINF;
            this.CONNECTION_INDICENCE = qty.CONNECTION_INDICENCE;
            this.AI_VOLUME_LAST_ISSUE = qty.AI_VOLUME_LAST_ISSUE;
            
            this.USERS = user;
            this.UserID = user.USERID;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
        }
        #endregion
    }
}
