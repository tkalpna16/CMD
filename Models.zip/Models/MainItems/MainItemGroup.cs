﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.MainItems
{
    public class MainItemGroup
    {
        public string MainItemTag { get; set; }
        public string MainItemDescritpion { get; set; }
        public string TagClient { get; set; }
        public string TagDescription { get; set; }
        public string EquipmentTag { get; set; }
        public string EquipmentLayout { get; set; }

        public string Unit { get; set; }
        public string Area { get; set; }

        public string AssociatedTagTypes { get; set; }
        public double Length { get; set; }
        public double Width { get; set; }
        public double ConcreteHeight { get; set; }
        public int ConcreteLevels { get; set; }
        public double SteelHeight { get; set; }
        public int SteelLevels { get; set; }

        public string Parameter1Value { get; set; }
        public string Parameter2Value { get; set; }
        public string Parameter3Value { get; set; }
        public string Parameter4Value { get; set; }
        public string Parameter5Value { get; set; }
        public string Parameter6Value { get; set; }
        public string Parameter7Value { get; set; }
        public string Parameter8Value { get; set; }
        public string Parameter9Value { get; set; }
        public string Parameter10Value { get; set; }

        public IMPORTANCESTATUS IMPORTANCESTATUS { get; set; }

        public string ImportanceName
        {
            get { return IMPORTANCESTATUS != null ? IMPORTANCESTATUS.Description : null; }
        }

        public List<IMPORTANCESTATUS> ImportanceStatusList { get; set; }

        public double Footprint
        {
            get { return Length * Width; }
        }
        public double ConcreteVolume
        {
            get { return Footprint * ConcreteHeight; }
        }
        public double SteelVolume
        {
            get { return Footprint * SteelHeight; }
        }

        public int Modules { get; set; }

        public bool IsEquipmentTag { get; set; }
        public bool IsPipeRackStructuresTag { get; set; }

        public static MainItemGroup GetMainItemGroup(List<MAINITEMS> mainItems)
        {
            if (mainItems == null || mainItems.Count == 0)
                return null;
            List<string> tags = mainItems.Select(m => m.MainItemTag).Distinct().ToList();
            if (tags.Count > 1)
                return null;

            MainItemGroup mainItemGroup = new MainItemGroup();
            mainItemGroup.MainItemTag = tags[0];
            try
            {
                mainItemGroup.IsEquipmentTag = mainItems[0].IsEquipmentTag;
                mainItemGroup.IsPipeRackStructuresTag = mainItems[0].IsPipeRack;
            }
            catch
            {

            }

            mainItemGroup.Unit = mainItems.Select(m => m.PBS.Unit).FirstOrDefault();
            mainItemGroup.Area = mainItems.Select(m => m.PBS.Area).FirstOrDefault();
            mainItemGroup.MainItemDescritpion = mainItems.Select(m => m.UserDescription).FirstOrDefault();
            mainItemGroup.TagClient = mainItems.Select(m => m.TagClient).FirstOrDefault();
            mainItemGroup.TagDescription = mainItems.Select(m => m.TagDescription).FirstOrDefault();
            mainItemGroup.EquipmentTag = mainItems.Select(m => m.EquipmentTag).FirstOrDefault();
            mainItemGroup.EquipmentLayout = mainItems.Select(m => m.EquipmentLayout).FirstOrDefault();
            List<string> tagTypes = mainItems.Select(m => m.TAGTYPES.Code).Distinct().ToList();
            mainItemGroup.AssociatedTagTypes = string.Empty;
            if (tagTypes != null)
            {
                for (int i = 0; i < tagTypes.Count; i++)
                {
                    mainItemGroup.AssociatedTagTypes += tagTypes[i];
                    if (i < (tagTypes.Count - 1))
                        mainItemGroup.AssociatedTagTypes += "-";
                }
            }
            mainItemGroup.Length = mainItems[0].Length != null ? mainItems[0].Length.Value : 0.0;
            mainItemGroup.Width = mainItems[0].Width != null ? mainItems[0].Width.Value : 0.0;
            mainItemGroup.ConcreteHeight = mainItems[0].ConcreteHeight != null ? mainItems[0].ConcreteHeight.Value : 0.0;
            mainItemGroup.ConcreteLevels = mainItems[0].ConcreteLevels != null ? mainItems[0].ConcreteLevels.Value : 0;
            mainItemGroup.SteelHeight = mainItems[0].SteelHeight != null ? mainItems[0].SteelHeight.Value : 0.0;
            mainItemGroup.SteelLevels = mainItems[0].SteelLevels != null ? mainItems[0].SteelLevels.Value : 0;

            mainItemGroup.Modules = mainItems[0].MODULES != null ? mainItems[0].MODULES.Value : 0;
            mainItemGroup.IMPORTANCESTATUS = mainItems[0].IMPORTANCESTATUS;

            return mainItemGroup;
        }
    }
}
