﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Users
{
    public class TecnimontClaimsTransformer : IClaimsTransformation
    {
        private readonly USERSContext _context;

        public TecnimontClaimsTransformer(USERSContext context)
        {
            _context = context;
        }

        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var identity = principal.Identity;
            var userName = identity.Name;
            var user = _context.USERS.Where(u => u.USERNAME.ToUpperInvariant() == userName.ToUpperInvariant()).FirstOrDefault();
            if (user != null)
                ((ClaimsIdentity)principal.Identity).AddClaim(new Claim(Roles.ROLE, user.ACCESS_LEVEL));
            return Task.FromResult(principal);
        }
    }
}
