﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Users
{
    public class USERS
    {
        [Key]
        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? USERID { get; set; }

        [Column("USERNAME")]
        [Display(Name = "Username")]
        public string USERNAME { get; set; }

        [Column("PASSWORD")]
        [Display(Name = "Password")]
        public string PASSWORD { get; set; }

        [Column("FIRST_NAME")]
        [Display(Name = "First name")]
        public string FIRST_NAME { get; set; }

        [Column("LAST_NAME")]
        [Display(Name = "Last name")]
        public string LAST_NAME { get; set; }

        [Column("EMAIL")]
        [Display(Name = "Email")]
        public string EMAIL { get; set; }

        [Column("PHONE")]
        [Display(Name = "Phone")]
        public string PHONE { get; set; }

        [Column("ACCESS_LEVEL")]
        [Display(Name = "Access level")]
        public string ACCESS_LEVEL { get; set; }

        [Column("READ_ONLY")]
        [Display(Name = "READ_ONLY")]
        public string READ_ONLY { get; set; }

        [Column("WRITE_ACCESS")]
        [Display(Name = "WRITE_ACCESS")]
        public string WRITE_ACCESS { get; set; }


        [Column("DISABLED")]
        [Display(Name = "DISABLED")]
        public int? DISABLED { get; set; }


        [NotMapped]
        public string IdentityUserName
        {
            get { return USERNAME; }
        }

        [NotMapped]
        public string GetCompleteName
        {
            get { return FIRST_NAME + " " + LAST_NAME; }
        }

        [NotMapped]
        public List<string> AvailableRoles
        {
            get { return Roles.AvailableRoles(); }
        }

        [NotMapped]
        public bool IsDisabled
        {
            get { return DISABLED != null && DISABLED.HasValue && DISABLED.Value > 0; }
        }
    }
}
