﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Users
{
    public class PROJECTUSERS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int? ID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "PROJECTID")]
        public int? ProjectID { get; set; }

        public PROJECTS PROJECTS { get; set; }


        [NotMapped]
        public static List<USERS> AvailabeUsers { get; set; }

        public static bool CanAccessProject(int userId, List<PROJECTUSERS> projectUsers)
        {
            if (projectUsers == null || projectUsers.Count == 0)
                return false;
            var user = projectUsers.Where(u => u.UserID == userId).FirstOrDefault();
            return user != null;
        }
    }
}
