﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Users
{
    public class ACTIVEUSERS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int? ID { get; set; }

        [Column("USERNAME")]
        [Display(Name = "USERNAME")]
        public string Username { get; set; }

        [Column("LOGINDATE")]
        [Display(Name = "LOGINDATE")]
        public DateTime? LoginDate { get; set; }
    }
}
