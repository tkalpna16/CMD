﻿using System.Collections.Generic;

namespace CivilMasterData.Models.Users
{
    public static class Roles
    {
        public const string ROLE = "Role";
        public const string ADMIN = "Admin";
        public const string DISCIPLINE_LEADER = "Discipline Leader";
        public const string SPECIALIST = "Specialist";
        public const string QUANTITY_SPECIALIST = "Quantity Specialist";

        public static List<string> AvailableRoles()
        {
            List<string> roles = new List<string>();
            roles.Add(ADMIN);
            roles.Add(DISCIPLINE_LEADER);
            roles.Add(SPECIALIST);
            roles.Add(QUANTITY_SPECIALIST);
            return roles;
        }
    }
}
