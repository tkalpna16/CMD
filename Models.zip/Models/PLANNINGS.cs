﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class PLANNINGS
    {
        [Key]
        [Column("PlanningId")]
        [Display(Name = "PlanningId")]
        public int PlanningId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "Main Item")]
        public int? MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [NotMapped]
        public string DateLastModify
        {
            get
            {
                if (LastModified != null && LastModified.HasValue)
                    return LastModified.Value.ToString("yyyy/MM/dd");
                return string.Empty;
            }
        }

        [NotMapped]
        public string LastModifyUser
        {
            get
            {
                return USERS != null ? USERS.IdentityUserName : string.Empty;
            }
        }

        [Column("DATE_INPUT_FORE")]
        [Display(Name = "DATE INPUT FORECAST")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? DATE_INPUT_FORE { get; set; }

        [NotMapped]
        public string DateInputForeGUI
        {
            get
            {
                if (DATE_INPUT_FORE == null)
                    return null;
                string val = DATE_INPUT_FORE.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFR_CHECK_FORE")]
        [Display(Name = "DATE IFR QUALITY CHECK FORECAST")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFR_CHECK_FORE { get; set; }

        [NotMapped]
        public string DateIfrCheckForeGUI
        {
            get
            {
                if (DATE_IFR_CHECK_FORE == null)
                    return null;
                string val = DATE_IFR_CHECK_FORE.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [Column("DATE_IFR_CHECK_ACTUAL")]
        [Display(Name = "DATE IFR QUALITY CHECK ACTUAL")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFR_CHECK_ACTUAL { get; set; }

        [NotMapped]
        public string DateIfrCheckActualGUI
        {
            get
            {
                if (DATE_IFR_CHECK_ACTUAL == null)
                    return null;
                string val = DATE_IFR_CHECK_ACTUAL.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFR_FORE")]
        [Display(Name = "DATE IFR FORECAST")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFR_FORE { get; set; }

        [NotMapped]
        public string DateIfrForeGUI
        {
            get
            {
                if (DATE_IFR_FORE == null)
                    return null;
                string val = DATE_IFR_FORE.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [Column("DATE_IFR_ACTUAL")]
        [Display(Name = "DATE IFR ACTUAL")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFR_ACTUAL { get; set; }
        [NotMapped]
        public string DateIfrActualGUI
        {
            get
            {
                if (DATE_IFR_ACTUAL == null)
                    return null;
                string val = DATE_IFR_ACTUAL.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [Column("DATE_IFC_CHECK_FORE")]
        [Display(Name = "DATE IFC QUALITY CHECK FORECAST")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFC_CHECK_FORE { get; set; }
        [NotMapped]
        public string DateIfcCheckForeGUI
        {
            get
            {
                if (DATE_IFC_CHECK_FORE == null)
                    return null;
                string val = DATE_IFC_CHECK_FORE.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFC_CHECK_ACTUAL")]
        [Display(Name = "DATE IFC QUALITY CHECK ACTUAL")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFC_CHECK_ACTUAL { get; set; }
        [NotMapped]
        public string DateIfcCheckActualGUI
        {
            get
            {
                if (DATE_IFC_CHECK_ACTUAL == null)
                    return null;
                string val = DATE_IFC_CHECK_ACTUAL.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFC_FORE")]
        [Display(Name = "DATE IFC FORECAST")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFC_FORE { get; set; }
        [NotMapped]
        public string DateIfcForeGUI
        {
            get
            {
                if (DATE_IFC_FORE == null)
                    return null;
                string val = DATE_IFC_FORE.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFC_ACTUAL")]
        [Display(Name = "DATE IFC ACTUAL")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFC_ACTUAL { get; set; }
        [NotMapped]
        public string DateIfcActualGUI
        {
            get
            {
                if (DATE_IFC_ACTUAL == null)
                    return null;
                string val = DATE_IFC_ACTUAL.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFR_BASE_LEV3")]
        [Display(Name = "DATE IFR BASELINE (LEV3)")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFR_BASE_LEV3 { get; set; }
        [NotMapped]
        public string DateIfrBaseLev3GUI
        {
            get
            {
                if (DATE_IFR_BASE_LEV3 == null)
                    return null;
                string val = DATE_IFR_BASE_LEV3.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [Column("DATE_IFR_BASE_ENG")]
        [Display(Name = "DATE IFR BASELINE (ENG)")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFR_BASE_ENG { get; set; }
        [NotMapped]
        public string DateIfrBaseEngGUI
        {
            get
            {
                if (DATE_IFR_BASE_ENG == null)
                    return null;
                string val = DATE_IFR_BASE_ENG.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [Column("DATE_IFC_BASE_LEV3")]
        [Display(Name = "DATE IFC BASELINE (LEV3)")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFC_BASE_LEV3 { get; set; }
        [NotMapped]
        public string DateIfcBaseLev3GUI
        {
            get
            {
                if (DATE_IFC_BASE_LEV3 == null)
                    return null;
                string val = DATE_IFC_BASE_LEV3.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("DATE_IFC_BASE_ENG")]
        [Display(Name = "DATE IFC BASELINE (ENG)")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFC_BASE_ENG { get; set; }
        [NotMapped]
        public string DateIfcBaseEngGUI
        {
            get
            {
                if (DATE_IFC_BASE_ENG == null)
                    return null;
                string val = DATE_IFC_BASE_ENG.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [NotMapped]
        public string GetHoldStatus
        {
            get
            {
                if (MAINITEMS != null)
                {
                    if (MAINITEMS.HOLDS != null && MAINITEMS.HOLDS.Count > 0)
                    {
                        foreach (var hold in MAINITEMS.HOLDS)
                            if (hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                return MainItemsCostants.HOLD_OPEN;
                        return MainItemsCostants.HOLD_CLOSED;
                    }
                }
                return null;
            }
        }

        [NotMapped]
        public MAIN_ITEM_QUANTITY ITEM_QUANTITY { get; set; }

        [NotMapped]
        public string DayToNextIssue
        {
            get
            {
                if (MAINITEMS != null)
                {
                    if (MAINITEMS.IsDeleted)
                        return "N.A.";
                    if (MAINITEMS.IsReplaced)
                        return "N.A.";
                }
                DateTime now = DateTime.UtcNow;
                now = new DateTime(now.Year, now.Month, now.Day, 0, 0, 0);
                if (DATE_IFC_ACTUAL != null && DATE_IFC_ACTUAL.HasValue)
                    return "N.A.";

                // If two forecast dates are there (IFR/IFC) but no actual dates are registered yet, 
                // the values of this shall be set on IFR date
                if (DATE_IFC_FORE != null && DATE_IFC_FORE.HasValue && DATE_IFR_FORE != null && DATE_IFR_FORE.HasValue 
                    && (DATE_IFR_ACTUAL == null || !DATE_IFR_ACTUAL.HasValue))
                {
                    return (DATE_IFR_FORE.Value - now).TotalDays.ToString();
                }
                if (DATE_IFC_FORE != null && DATE_IFC_FORE.HasValue)
                {
                    return (DATE_IFC_FORE.Value - now).TotalDays.ToString();
                }
                else
                {
                    if (DATE_IFR_FORE != null && DATE_IFR_FORE.HasValue)
                        return (DATE_IFR_FORE.Value - now).TotalDays.ToString();
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Empty constructor
        /// </summary>
        public PLANNINGS() { }

        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="pLANNINGS"></param>
        public PLANNINGS(PLANNINGS pLANNINGS)
        {
            if (pLANNINGS.MainItemId.HasValue)
                this.MainItemId = pLANNINGS.MainItemId.Value;
            UserID = pLANNINGS.UserID;
            CreationDate = pLANNINGS.CreationDate;
            LastModified = pLANNINGS.LastModified;

            DATE_INPUT_FORE = pLANNINGS.DATE_INPUT_FORE;
            DATE_IFR_CHECK_FORE = pLANNINGS.DATE_IFR_CHECK_FORE;
            DATE_IFR_CHECK_ACTUAL = pLANNINGS.DATE_IFR_CHECK_ACTUAL;
            DATE_IFR_FORE = pLANNINGS.DATE_IFR_FORE;
            DATE_IFR_ACTUAL = pLANNINGS.DATE_IFR_ACTUAL;
            DATE_IFC_CHECK_FORE = pLANNINGS.DATE_IFC_CHECK_FORE;
            DATE_IFC_CHECK_ACTUAL = pLANNINGS.DATE_IFC_CHECK_ACTUAL;
            DATE_IFC_FORE = pLANNINGS.DATE_IFC_FORE;
            DATE_IFC_ACTUAL = pLANNINGS.DATE_IFC_ACTUAL;

            DATE_IFR_BASE_LEV3 = pLANNINGS.DATE_IFR_BASE_LEV3;
            DATE_IFR_BASE_ENG = pLANNINGS.DATE_IFR_BASE_ENG;
            DATE_IFC_BASE_LEV3 = pLANNINGS.DATE_IFC_BASE_LEV3;
            DATE_IFC_BASE_ENG = pLANNINGS.DATE_IFC_BASE_ENG;
        }

        public bool UpdateDate()
        {
            bool updated = false;
            //if (DATE_ACT_INT != null && DATE_ACT_INT.HasValue && DATE_FORE_INT != null && DATE_FORE_INT.HasValue)
            //{
            //    if (DATE_ACT_INT.Value < DATE_FORE_INT.Value)
            //    {
            //        DATE_FORE_INT = DATE_ACT_INT.Value;
            //        updated = true;
            //    }
            //}
            //if (DATE_ACT_IFR != null && DATE_ACT_IFR.HasValue && DATE_FORE_IFR != null && DATE_FORE_IFR.HasValue)
            //{
            //    if (DATE_ACT_IFR.Value < DATE_FORE_IFR.Value)
            //    {
            //        DATE_FORE_IFR = DATE_ACT_IFR.Value;
            //        updated = true;
            //    }
            //}
            //if (DATE_ACT_IFC != null && DATE_ACT_IFC.HasValue && DATE_FORE_IFC != null && DATE_FORE_IFC.HasValue)
            //{
            //    if (DATE_ACT_IFC.Value < DATE_FORE_IFC.Value)
            //    {
            //        DATE_FORE_IFC = DATE_ACT_IFC.Value;
            //        updated = true;
            //    }
            //}

            return updated;
        }

        public static List<string> GetDates1()
        {
            List<string> dates = new List<string>();
            dates.Add(MainItemsCostants.DATE_IFC_FORE);
            dates.Add(MainItemsCostants.DATE_IFC_CHECK_FORE);
            dates.Add(MainItemsCostants.DATE_IFR_FORE);
            dates.Add(MainItemsCostants.DATE_IFR_CHECK_FORE);
            dates.Add(MainItemsCostants.DATE_INP_FORE);
            return dates;
        }

        public static List<string> GetDates2()
        {
            List<string> dates = new List<string>();
            dates.Add(MainItemsCostants.DATE_IFC_FORE);
            dates.Add(MainItemsCostants.DATE_IFC_CHECK_FORE);
            dates.Add(MainItemsCostants.DATE_IFR_FORE);
            dates.Add(MainItemsCostants.DATE_IFR_CHECK_FORE);
            dates.Add(MainItemsCostants.DATE_INP_FORE);

            dates.Add(MainItemsCostants.DATE_IFC_CHECK_ACTUAL);
            dates.Add(MainItemsCostants.DATE_IFR_CHECK_ACTUAL);
            dates.Add(MainItemsCostants.DATE_IFR_BASE_LEV3);
            dates.Add(MainItemsCostants.DATE_IFR_BASE_ENG);
            dates.Add(MainItemsCostants.DATE_IFC_BASE_LEV3);
            dates.Add(MainItemsCostants.DATE_IFC_BASE_ENG);

            dates.Add(MainItemsCostants.DATE_IFR_ACT);
            dates.Add(MainItemsCostants.DATE_IFC_ACT);
            return dates;
        }

        /// <summary>
        /// Only text parameters
        /// </summary>
        [NotMapped]
        public List<MAINITEMPARAMETERVALUES> MAINITEMDATEVALUES { get; set; }

        #region Parameters

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter1
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 0)
                    return MAINITEMDATEVALUES[0].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter1GUI
        {
            get
            {
                DateTime? param = GetParameter1;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter2
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 1)
                    return MAINITEMDATEVALUES[1].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter2GUI
        {
            get
            {
                DateTime? param = GetParameter2;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter3
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 2)
                    return MAINITEMDATEVALUES[2].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter3GUI
        {
            get
            {
                DateTime? param = GetParameter3;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter4
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 4)
                    return MAINITEMDATEVALUES[4].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter4GUI
        {
            get
            {
                DateTime? param = GetParameter4;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter5
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 5)
                    return MAINITEMDATEVALUES[4].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter5GUI
        {
            get
            {
                DateTime? param = GetParameter5;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter6
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 6)
                    return MAINITEMDATEVALUES[5].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter6GUI
        {
            get
            {
                DateTime? param = GetParameter6;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter7
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 7)
                    return MAINITEMDATEVALUES[6].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter7GUI
        {
            get
            {
                DateTime? param = GetParameter7;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter8
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 8)
                    return MAINITEMDATEVALUES[7].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter8GUI
        {
            get
            {
                DateTime? param = GetParameter8;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter9
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 9)
                    return MAINITEMDATEVALUES[8].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter9GUI
        {
            get
            {
                DateTime? param = GetParameter1;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [NotMapped]
        [DataType(DataType.Date)]
        public DateTime? GetParameter10
        {
            get
            {
                if (MAINITEMDATEVALUES != null && MAINITEMDATEVALUES.Count > 10)
                    return MAINITEMDATEVALUES[9].PARAMETERDATE;
                return null;
            }
        }
        [NotMapped]
        public string DateParameter10GUI
        {
            get
            {
                DateTime? param = GetParameter10;
                if (param == null)
                    return null;
                string val = param.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }
        #endregion
    }
}
