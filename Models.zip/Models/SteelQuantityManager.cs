﻿using CivilMasterData.Models.Steel;
using System.Collections.Generic;

namespace CivilMasterData.Models
{
    public class SteelQuantityManager
    {
        public List<PBS> PBS { get; set; }

        public List<MAINITEMS> MainItems { get; set; }

        public PROJECTS Project { get; set; }

        public List<STEEL_ESTIMATED_QUANTITIES> STEEL_ESTIMATED_QUANTITIES { get; set; }

        public List<STEEL_QUANTITIES> STEEL_QUANTITIES { get; set; }

        public List<COMMODITYCODES> COMMODITYCODES { get; set; }
    }
}
