﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class OBJECTCODES
    {
        [Key]
        [Column("CODEID")]
        [Display(Name = "CodeID")]
        public int CodeID { get; set; }

        [Column("CODE")]
        [Display(Name = "Code")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "GroupDescription cannot be longer than 32 characters.")]
        public string Code { get; set; }

        [Column("CODEDESCRIPTION")]
        [Display(Name = "Description")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "GroupDescription cannot be longer than 32 characters.")]
        public string CodeDescription { get; set; }

        [Column("DISCIPLINECODE")]
        [Display(Name = "Discipline Code")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineCode cannot be longer than 32 characters.")]
        public string DisciplineCode { get; set; }

        [Column("SUBDISCIPLINECODE")]
        [Display(Name = "Sub-Discipline Code")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "SubDisciplineCode cannot be longer than 32 characters.")]
        public string SubDisciplineCode { get; set; }

        [Column("DISCIPLINENAME")]
        [Display(Name = "Discipline Name")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineOwner cannot be longer than 32 characters.")]
        public string DisciplineName { get; set; }

        [Column("SUBDISCIPLINENAME")]
        [Display(Name = "Sub-Discipline Name")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineOwner cannot be longer than 32 characters.")]
        public string SubDisciplineName { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "Last Modified")]
        public DateTime? LastModified { get; set; }

        [Column("BEHAVIOUR")]
        [Display(Name = "Behaviour")]
        public string Behaviour { get; set; }

        public OBJECTCODES() { }

        public OBJECTCODES Copy(int projectId, USERS user)
        {
            OBJECTCODES newCode = new OBJECTCODES();
            newCode.Code = this.Code;
            newCode.CodeDescription = this.CodeDescription;
            newCode.DisciplineCode = this.DisciplineCode;
            newCode.SubDisciplineCode = this.SubDisciplineCode;
            newCode.DisciplineName = this.DisciplineName;
            newCode.SubDisciplineName = this.SubDisciplineName;
            newCode.ProjectID = projectId;
            newCode.UserID = user.USERID.Value;
            newCode.CreationDate = DateTime.UtcNow;
            newCode.LastModified = DateTime.UtcNow;
            newCode.Behaviour = this.Behaviour;
            return newCode;
        }

        public bool SupportCode(string codeToCheck)
        {
            if (codeToCheck == this.Code)
                return true;
            if (!string.IsNullOrEmpty(Behaviour))
                if (codeToCheck == Behaviour)
                    return true;
            return false;
        }
    }
}
