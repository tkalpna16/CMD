﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class ItemListCreation
    {
        public List<MAINITEMS> MainItems { get; set; }
        public List<MAINITEMS> SelectedMainItems { get; set; }

        public List<TAGTYPES> TagTypes { get; set; }

        public List<TAGTYPES> SelectedTagTypes { get; set; }

        public List<MATERIALWORKGROUPS> Materials { get; set; }

        public List<OBJECTCODES> ObjectCodes { get; set; }

        public List<OBJECTCODES> SelectedObjectCodes { get; set; }

        public PROJECTS Project { get; set; }

        public List<PBS> PBS { get; set; }

        public List<PBS> SelectedPBS { get; set; }

        public List<WORKINGPACKAGES> WORKINGPACKAGES { get; set; }
    }
}
