﻿using CivilMasterData.Models.Costants;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class TAGTYPES
    {
        [Key]
        [Column("TagTypeID")]
        [Display(Name = "TagTypeID")]
        public int TagTypeID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string Description { get; set; }

        [Column("VALIDFORMAINITEMS")]
        [Display(Name = "VALIDFORMAINITEMS")]
        public int VALIDFORMAINITEMS { get; set; }

        [Column("Code")]
        [Display(Name = "Code")]
        public string Code { get; set; }


        public static string QtyUnits(PROJECTSETTINGS PROJECTSETTINGS, int TagTypeID)
        {
            string units = string.Empty;
            if (PROJECTSETTINGS == null)
                return string.Empty;
            if (TagTypeID == DatabaseCostants.TagType_Foundation_ID)
            {
                units = PROJECTSETTINGS.FOUNDATIONCONCRETEUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_Elevation_ID)
            {
                units = PROJECTSETTINGS.ELEVATIONCONCRETEUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_Paving_ID)
            {
                units = PROJECTSETTINGS.PAVINGUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_Pile_ID)
            {
                units = PROJECTSETTINGS.PILESUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_UndergroundPipe_ID)
            {
                units = PROJECTSETTINGS.UNDERGROUNDPIPEUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_Steel_ID)
            {
                units = PROJECTSETTINGS.STEELUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_Ground_Slab_Concrete_ID)
            {
                units = PROJECTSETTINGS.CONCRETESLABUNIT;
            }
            else if (TagTypeID == DatabaseCostants.TagType_UndergroundPit_ID)
            {
                units = "Count";
            }
            return units;
        }

        public static string QtyUnitsShort(PROJECTSETTINGS PROJECTSETTINGS, int TagTypeID)
        {
            string units = string.Empty;
            if (PROJECTSETTINGS == null)
                return string.Empty;
            if (TagTypeID == DatabaseCostants.TagType_Foundation_ID)
            {
                units = "m\xB3";
            }
            else if (TagTypeID == DatabaseCostants.TagType_Elevation_ID)
            {
                units = "m\xB3";
            }
            else if (TagTypeID == DatabaseCostants.TagType_Paving_ID)
            {
                units = "m\xB3";
            }
            else if (TagTypeID == DatabaseCostants.TagType_Pile_ID)
            {
                units = "m";
            }
            else if (TagTypeID == DatabaseCostants.TagType_UndergroundPipe_ID)
            {
                units = "m";
            }
            else if (TagTypeID == DatabaseCostants.TagType_Steel_ID)
            {
                units = "tons";
            }
            else if (TagTypeID == DatabaseCostants.TagType_Ground_Slab_Concrete_ID)
            {
                units = "m\xB2";
            }
            else if (TagTypeID == DatabaseCostants.TagType_UndergroundPit_ID)
            {
                units = "Count";
            }
            return units;
        }
    }
}
