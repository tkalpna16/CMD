﻿using CivilMasterData.Models.Quantities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class QuantityManager
    {
        public List<MAINITEMS> MainItems { get; set; }

        public List<TAGTYPES> TagTypes { get; set; }

        public PROJECTS Project { get; set; }

        public List<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }

        public List<PROPOSEDQUANTITY> PROPOSEDQUANTITIES { get; set; }

        public List<QuantityCEData> QuantityCEData { get; set; }
    }
}
