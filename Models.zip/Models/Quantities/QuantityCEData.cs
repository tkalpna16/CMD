﻿namespace CivilMasterData.Models.Quantities
{
    public class QuantityCEData
    {
        public string MainItemTag { get; set; }
        public string TagTypeDescription { get; set; }
        public string Lot { get; set; }
        public double QtyCE1 { get; set; }
        public double QtyCE2 { get; set; }
        public double DeltaCE { get; set; }
    }
}
