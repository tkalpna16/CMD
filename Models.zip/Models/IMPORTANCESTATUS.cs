﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class IMPORTANCESTATUS
    {
        [Key]
        [Column("StatusID")]
        [Display(Name = "StatusID")]
        public int StatusID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("FoundationCoefficient")]
        [Display(Name = "FoundationCoefficient")]
        public double FoundationCoefficient { get; set; }

        [Column("ElevationCoefficient")]
        [Display(Name = "ElevationCoefficient")]
        public double ElevationCoefficient { get; set; }
    }
}
