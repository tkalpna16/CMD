﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class MAIN_ITEM_QUANTITY_CE
    {
        [Key]
        [Column("QuantityId")]
        [Display(Name = "QuantityId")]
        public int QuantityId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("QTY_CE")]
        [Display(Name = "QTY_CE")]
        public double? QTY_CE { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("RevId")]
        [Display(Name = "RevId")]
        public int? RevId { get; set; }

    }
}
