﻿using Autodesk.Forge.Model;
using CivilMasterData.Controllers.Support;
using CivilMasterData.Models.BIM360.Database;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360
{
    public class ForgeModel
    {
        #region Private members
        public string modelName { get; set; }
        public string lastVersion { get; set; }
        public List<ForgeItem> items { get; set; }
        #endregion

        #region Constructor
        public ForgeModel() { }
        public ForgeModel(string modelName, string lastVersion)
        {
            this.modelName = modelName;
            this.lastVersion = string.Empty;
            items = null;
        }
        #endregion

        #region Members methods
        public async Task<List<ForgeItem>> ReadForgeItemsAsync(
            string urn, 
            string token, 
            bool saveToDatabase,
            string connectionString,
            string procedureInserForgeItem,
            string procedureFilename,
            string procedureObjectId,
            string procedurePropertyName,
            string procedurePropertyValue)
        {
            items = new List<ForgeItem>();
            try
            {
                // Read metadata
                var client = new RestClient(ForgeAPI.FORGE_BASE_URL);
                var request = new RestRequest(ForgeAPI.GetBaseUrlMetadata(urn), Method.GET);
                request.AddHeader("Authorization", "Bearer " + token);
                var cancellationTokenSource = new CancellationTokenSource();
                var restResponse = await client.ExecuteAsync(request, cancellationTokenSource.Token);
                if (restResponse.ResponseStatus != ResponseStatus.Completed)
                    return null;
                var jsonMetadata = restResponse.Content;
                if (String.IsNullOrEmpty(jsonMetadata))
                    return null;
                var metadataViews = JsonConvert.DeserializeObject<Autodesk.Forge.Model.Metadata>(jsonMetadata);
                if (metadataViews == null || metadataViews.Data == null || metadataViews.Data.Metadata == null || metadataViews.Data.Metadata.Count == 0)
                    return null;
                var viewGuid = metadataViews.Data.Metadata[0].Guid;

                // Access Properties
                request = new RestRequest(ForgeAPI.GetBaseUrlProperties(urn, viewGuid), Method.GET);
                request.AddHeader("Authorization", "Bearer " + token);
                restResponse = await client.ExecuteAsync(request, cancellationTokenSource.Token);
                if (restResponse.ResponseStatus != ResponseStatus.Completed)
                    return null;

                var jsonProperties = restResponse.Content;
                if (String.IsNullOrEmpty(jsonMetadata))
                    return null;
                var metadataProperties = JsonConvert.DeserializeObject<Autodesk.Forge.Model.Metadata>(jsonProperties);
                if (metadataProperties == null || metadataProperties.Data == null || metadataProperties.Data.Collection == null)
                    return null;
                
                List<MetadataCollection> metadataCollections = metadataProperties.Data.Collection;

                foreach (MetadataCollection metadataCollection in metadataCollections)
                {
                    ForgeItem item = ForgeItem.GetItem(metadataCollection, modelName);
                    if (item != null)
                        items.Add(item);
                }
                
                if (saveToDatabase)
                    OracleUtils.SaveForgeItems(items, connectionString, procedureInserForgeItem,
                        procedureFilename, procedureObjectId, procedurePropertyName,
                        procedurePropertyValue);
            }
            catch
            {
            }

            return items;
        }
        #endregion
    }
}
