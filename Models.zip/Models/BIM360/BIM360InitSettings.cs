﻿namespace CivilMasterData.Models.BIM360
{
    public class BIM360InitSettings
    {
        public string ForgeClientId { get; set; }
        public string ForgeSecret { get; set; }
        public string HubName { get; set; }
        public string RootFolderName { get; set; }
        public string FirstLevelFolderName { get; set; }
        public string SecondLevelFolderName { get; set; }
    }
}
