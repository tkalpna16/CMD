﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.BIM360
{
    public class BIM360FILES
    {
        [Key]
        [Column("FILESID")]
        [Display(Name = "FILESID")]
        public int FILESID { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "PROJECTID")]
        public int PROJECTID { get; set; }

        public PROJECTS PROJECT { get; set; }

        [Column("FILENAME")]
        [Display(Name = "FILENAME")]
        public string FILENAME { get; set; }

        [Column("FILEVERSION")]
        [Display(Name = "FILEVERSION")]
        public string FILEVERSION { get; set; }

        [Column("FILEDATE")]
        [Display(Name = "FILEDATE")]
        public DateTime FILEDATE { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        public BIM360FILES() { }
         
        public BIM360FILES(BIM360FILES bim360File, USERS user)
        {
            this.PROJECTID = bim360File.PROJECTID;
            this.FILENAME = bim360File.FILENAME;
            this.FILEVERSION = bim360File.FILEVERSION;
            this.FILEDATE = bim360File.FILEDATE;
            this.UserID = user.USERID;
            this.CreationDate = DateTime.UtcNow;
        }

        public bool IsEqual(BIM360FILES files)
        {
            bool equal = this.PROJECTID == files.PROJECTID;
            equal &= this.FILENAME == files.FILENAME;
            equal &= this.FILEVERSION == files.FILEVERSION;
            return equal;
        }
    }
}
