﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360
{
    public class Property
    {
        public string CategoryName { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
