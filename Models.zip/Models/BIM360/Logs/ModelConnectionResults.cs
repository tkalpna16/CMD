﻿using CivilMasterData.Models.Logs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Logs
{
    public static class ModelConnectionResults
    {
        public static List<MainItemData> MainItemData { get; set; } // Not existing items
        public static List<MAINITEMS> ProcessedMainItems { get; set; } // Processed items

        public static List<BIM360PARAMETERS> Parameters { get; set; } // List of project settings parameters

        public static List<BIM360FILEREVISIONS> FileRevisions { get; set; }

        public static List<BIM360INCORRECTFILES> IncorrectFiles { get; set; }

        public static List<BIM360ITEMSTATUS> ItemStatusList { get; set; }

        public static bool IsProcessedEmpty
        {
            get
            {
                return ProcessedMainItems == null || ProcessedMainItems.Count == 0;
            }
        }

        public static bool IsNotExistingEmpty
        {
            get
            {
                return MainItemData == null || MainItemData.Count == 0;
            }
        }

        public static bool IsParametersEmpty
        {
            get
            {
                return Parameters == null || Parameters.Count == 0;
            }
        }

        public static bool FileRevisionsEmpty
        {
            get
            {
                return FileRevisions == null || FileRevisions.Count == 0;
            }
        }

        public static bool IsIncorrectFilesEmpty
        {
            get
            {
                return IncorrectFiles == null || IncorrectFiles.Count == 0;
            }
        }

        public static bool IsItemStatusEmpty
        {
            get
            {
                return ItemStatusList == null || ItemStatusList.Count == 0;
            }
        }

        public static void AddItemStatus(BIM360ITEMSTATUS itemStatus)
        {
            if (ItemStatusList == null)
                ItemStatusList = new List<BIM360ITEMSTATUS>();
            bool exist = ContainItemStatus(itemStatus);
            if (!exist)
                ItemStatusList.Add(itemStatus);
        }

        private static bool ContainItemStatus(BIM360ITEMSTATUS itemStatus)
        {
            if (IsItemStatusEmpty)
                return false;
            if (itemStatus == null)
                return true;
            foreach (BIM360ITEMSTATUS currentItem in ItemStatusList)
                if (currentItem.MainItemTag == itemStatus.MainItemTag && currentItem.TagType == itemStatus.TagType &&
                    currentItem.Lot == itemStatus.Lot)
                    return true;
            return false;
        }

        public static void AddProcessedMainItem(MAINITEMS mainItem)
        {
            if (ProcessedMainItems == null)
                ProcessedMainItems = new List<MAINITEMS>();
            bool exist = ContainMainItem(mainItem);
            if (!exist)
                ProcessedMainItems.Add(mainItem);
        }

        public static void AddNotFoundMainItem(MainItemData mainItemData)
        {
            if (MainItemData == null)
                MainItemData = new List<MainItemData>();
            bool exist = ContainMainData(mainItemData);
            if (!exist)
                MainItemData.Add(mainItemData);
        }

        public static void AddParameterValue(BIM360PARAMETERS bIM360PARAMETERS)
        {
            if (Parameters == null)
                Parameters = new List<BIM360PARAMETERS>();
            if (bIM360PARAMETERS == null)
                return;
            Parameters.Add(bIM360PARAMETERS);
        }

        public static void AddFileRevision(BIM360FILEREVISIONS bIM360FILEREVISIONS)
        {
            if (FileRevisions == null)
                FileRevisions = new List<BIM360FILEREVISIONS>();
            if (bIM360FILEREVISIONS == null)
                return;
            foreach (var file in FileRevisions)
                if (file.ModelName == bIM360FILEREVISIONS.ModelName)
                    return;
            FileRevisions.Add(bIM360FILEREVISIONS);
        }

        private static bool ContainMainItem(MAINITEMS mainItem)
        {
            if (IsProcessedEmpty)
                return false;
            if (mainItem == null)
                return true;
            foreach (MAINITEMS currentItem in ProcessedMainItems)
                if (currentItem.MainItemID == mainItem.MainItemID)
                    return true;
            return false;
        }

        private static bool ContainMainData(MainItemData mainItemData)
        {
            if (IsNotExistingEmpty)
                return false;
            if (mainItemData == null || !mainItemData.IsValid())
                return true;
            foreach (MainItemData currentItem in MainItemData)
            {
                bool equal = currentItem.MainItemTag.ToLowerInvariant() == mainItemData.MainItemTag.ToLowerInvariant();
                equal &= currentItem.TagType.ToLowerInvariant() == mainItemData.TagType.ToLowerInvariant();
                equal &= currentItem.Lot.ToLowerInvariant() == mainItemData.Lot.ToLowerInvariant();
                if (equal)
                    return true;
            }
            return false;
        }

        public static void UpdateBIM360Revisions(List<BIM360FILEREVISIONS> bIM360FILEREVISIONs)
        {
            if (!FileRevisionsEmpty)
            {
                foreach (var revision in FileRevisions)
                {
                    int id = GetRevision(revision.ModelName, bIM360FILEREVISIONs);
                    revision.ID = id + 1;
                }
            }
        }

        private static int GetRevision(string modelName, List<BIM360FILEREVISIONS> bIM360FILEREVISIONs)
        {
            if (bIM360FILEREVISIONs == null || bIM360FILEREVISIONs.Count == 0)
                return 1;
            int id = 0;
            foreach (var revision in bIM360FILEREVISIONs)
                if (revision.ModelName == modelName && revision.Version > id)
                    id = revision.Version;
            id++;
            return id;
        }

        public static void UpdateIncorrectFiles(List<BIM360FILES> bim360Files, int projectId)
        {
            IncorrectFiles = new List<BIM360INCORRECTFILES>();
            List<string> incorrectFiles = ForgeLogManager.GetIncorrectFiles();
            if (incorrectFiles != null)
            {
                foreach (string file in incorrectFiles)
                {
                    string date = string.Empty;
                    if (bim360Files != null)
                    {
                        foreach(BIM360FILES files in bim360Files)
                            if (files.FILENAME == file)
                            {
                                date = files.FILEDATE.ToString("d");
                                break;
                            }
                    }
                    if (!string.IsNullOrEmpty(date))
                    {
                        BIM360INCORRECTFILES bIM360INCORRECTFILES = new BIM360INCORRECTFILES();
                        bIM360INCORRECTFILES.ModelName = file;
                        bIM360INCORRECTFILES.ProjectID = projectId;
                        bIM360INCORRECTFILES.Version = date;
                        IncorrectFiles.Add(bIM360INCORRECTFILES);
                    }
                }
            }
        }

        /// <summary>
        /// Get the list of items in the database not processed
        /// </summary>
        /// <param name="databaseMainItems"></param>
        /// <returns></returns>
        public static List<MAINITEMS> GetNotProcessedMainItems(List<MAINITEMS> databaseMainItems)
        {
            if (IsProcessedEmpty)
                return null;

            List<MAINITEMS> notProcessedItems = new List<MAINITEMS>();
            foreach(MAINITEMS dbItem in databaseMainItems)
            {
                if (dbItem.IsBalance || dbItem.IsReplaced || dbItem.IsDeleted)
                    continue;
                bool found = false;
                foreach(MAINITEMS item in ProcessedMainItems)
                {
                    if (item.MainItemID == dbItem.MainItemID)
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                    notProcessedItems.Add(dbItem);
            }

            return notProcessedItems;
        }

        public static void Reset()
        {
            MainItemData = new List<MainItemData>();
            ProcessedMainItems = new List<MAINITEMS>();
            Parameters = new List<BIM360PARAMETERS>();
            FileRevisions = new List<BIM360FILEREVISIONS>();
            IncorrectFiles = new List<BIM360INCORRECTFILES>();
            ItemStatusList = new List<BIM360ITEMSTATUS>();
        }
    }

    // Main Items not Existing in the model
    public class MainItemData
    {
        public string MainItemTag { get; set; }
        public string TagType { get; set; }
        public string Lot { get; set; }
        public string ModelName { get; set; }

        public bool IsValid()
        {
            return !string.IsNullOrEmpty(MainItemTag) && !string.IsNullOrEmpty(TagType) && !string.IsNullOrEmpty(Lot);
        }
    }
}
