﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Formulas
{
    public class Log
    {
        #region Members
        /// <summary>
        /// First level of description
        /// </summary>
        public string Description_1 { get; private set; }
        /// <summary>
        /// Second level of description
        /// </summary>
        public string Description_2 { get; private set; }
        /// <summary>
        /// Additiona notes
        /// </summary>
        public string Notes { get; private set; }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="description_1"></param>
        /// <param name="description_2"></param>
        /// <param name="notes"></param>
        public Log(string description_1, string description_2 = "",
            string notes = "")
        {
            this.Description_1 = description_1;
            this.Description_2 = description_2;
            this.Notes = notes;
        }
        #endregion

        #region Comparer
        public static bool operator ==(Log msg1, Log msg2)
        {
            return Object.Equals(msg1, msg2);
        }

        public static bool operator !=(Log msg1, Log msg2)
        {
            return !Object.Equals(msg1, msg2);
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            Log msg = (Log)obj;
            return this.Description_1 == msg.Description_1 &&
                this.Description_2 == msg.Description_2 &&
                this.Notes == msg.Notes;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        #endregion
    }
}
