﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Formulas
{
    public static class LogManager
    {
        #region Private members
        public static List<Log> Logs;
        #endregion

        #region Access members
        /// <summary>
        /// Total logs
        /// </summary>
        public static int Count { get { return Logs != null ? Logs.Count : 0; } }
        /// <summary>
        /// Is Empty
        /// </summary>
        public static bool Empty { get { return Logs != null ? Logs.Count == 0 : true; } }
        #endregion

        #region Other function
        /// <summary>
        /// Clear logs
        /// </summary>
        public static void Clear()
        {
            Logs = new List<Log>();
        }

        /// <summary>
        /// Add a log
        /// </summary>
        /// <param name="log"></param>
        public static void AddLog(Log log)
        {
            if (log == null)
                return;
            bool found = false;
            foreach (Log l in Logs)
                if (l == log)
                {
                    found = true;
                    break;
                }
            if (!found)
                Logs.Add(log);
        }

        public static void AddLog(string description_1, string description_2 = "",
            string notes = "")
        {
            Log log = new Log(description_1, description_2, notes);
            LogManager.AddLog(log);
        }
        #endregion

        #region Output function
        /// <summary>
        /// Output override
        /// </summary>
        /// <returns></returns>
        public static string ExportString()
        {
            string output = string.Empty;
            foreach (Log log in Logs)
                output += log.ToString();
            return output;
        }
        #endregion
    }
}
