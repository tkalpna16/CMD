﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.BIM360
{
    public class BIM360PARAMETERS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("ModelName")]
        [Display(Name = "ModelName")]
        public string ModelName { get; set; }

        [Column("ForgeItemName")]
        [Display(Name = "ForgeItemName")]
        public string ForgeItemName { get; set; }

        [Column("ItemName")]
        [Display(Name = "ItemName")]
        public string ItemName { get; set; }

        [Column("ParameterName")]
        [Display(Name = "ParameterName")]
        public string ParameterName { get; set; }

        [Column("ParameterValue")]
        [Display(Name = "ParameterValue")]
        public string ParameterValue { get; set; }
    }
}
