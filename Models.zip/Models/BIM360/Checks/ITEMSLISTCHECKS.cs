﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.BIM360
{
    public class ITEMSLISTCHECKS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("MainItemID")]
        [Display(Name = "MainItemID")]
        public int? MainItemID { get; set; }

        public MAINITEMS MainItem { get; set; }

        [Column("ModelName")]
        [Display(Name = "ModelName")]
        public string ModelName { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

    }
}
