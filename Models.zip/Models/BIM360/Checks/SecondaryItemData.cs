﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Checks
{
    public class SecondaryItemData
    {
        public string ModelName { get; set; }
        public string ModelItemName { get; set; }
        
        public List<ItemAttribute> Attributes { get; set; }


        public static List<SecondaryItemData> ParseSecondaryItems(
            List<SecondaryItem> secondaryItems,
            List<BIM360PARAMETERS> parameters, List<string> parameterNames)
        {
            return null;
            //if (secondaryItems == null)
            //    return null;
            //if (parameters == null)
            //    return null;
            //if (parameterNames == null || parameterNames.Count == 0)
            //    return null;

            //List<SecondaryItemData> secItemData = new List<SecondaryItemData>();

            //if (secondaryItems != null)
            //{
            //    foreach(SecondaryItem secItem in secondaryItems)
            //    {
            //        SecondaryItemData secondaryItemData = new SecondaryItemData();
            //        secondaryItemData.ModelItemName = secItem.GetItemTag;

            //        var currentParameters = parameters.Where(p => p.ForgeItemName == secItem).ToList();
            //        foreach(string parameterName in parameterNames)
            //        {
            //            BIM360PARAMETERS currentParam = parameters.Where(p => p.ForgeItemName == secItem &&
            //                p.ParameterName == parameterName).FirstOrDefault();
            //            if (currentParam != null)
            //            {
            //                ItemAttribute itemAttribute = new ItemAttribute();
            //                itemAttribute.Name = parameterName;
            //                itemAttribute.Value = currentParam.ParameterValue;
            //            }
            //        }
            //    }
            //}
            
        }
    }

    public class ItemAttribute
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
