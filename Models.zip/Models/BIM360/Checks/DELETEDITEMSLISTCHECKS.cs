﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.BIM360
{
    public class DELETEDITEMSLISTCHECKS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("MainItemTag")]
        [Display(Name = "MainItemTag")]
        public string MainItemTag { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("Lot")]
        [Display(Name = "Lot")]
        public string Lot { get; set; }

        [Column("ModelName")]
        [Display(Name = "ModelName")]
        public string ModelName { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("STATUS")]
        [Display(Name = "Status")]
        public string Status { get; set; }
    }
}
