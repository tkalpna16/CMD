﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using UnitsNet;
using UnitsNet.Units;

namespace CivilMasterData.Models.BIM360
{
    public class BIM360ITEMSTATUS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("ModelName")]
        [Display(Name = "ModelName")]
        public string ModelName { get; set; }

        [Column("MainItemTag")]
        [Display(Name = "MainItemTag")]
        public string MainItemTag { get; set; }

        [Column("MatchItem")]
        [Display(Name = "MatchItem")]
        public string MatchItem { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("Lot")]
        [Display(Name = "Lot")]
        public string Lot { get; set; }

        [Column("Qty")]
        [Display(Name = "Qty")]
        public double Qty { get; set; }

        [Column("Hold")]
        [Display(Name = "Hold")]
        public bool Hold { get; set; }

        [Column("QtyHold")]
        [Display(Name = "QtyHold")]
        public double QtyHold { get; set; }

        [Column("Status")]
        [Display(Name = "Status")]
        public string Status { get; set; }

        [Column("ModelDate")]
        [Display(Name = "ModelDate")]
        public string ModelDate { get; set; }

        [Column("ActualDate")]
        [Display(Name = "ActualDate")]
        public string ActualDate { get; set; }

        [Column("COUNT")]
        [Display(Name = "COUNT")]
        public int? COUNT { get; set; }

        [Column("ObjectCode")]
        [Display(Name = "ObjectCode")]
        public string ObjectCode { get; set; }

        [Column("Material")]
        [Display(Name = "Material")]
        public string Material { get; set; }

        [Column("WP")]
        [Display(Name = "WP")]
        public string WP { get; set; }

        [Column("CWA")]
        [Display(Name = "CWA")]
        public string CWA { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("CA")]
        [Display(Name = "CA")]
        public string CA { get; set; }

        [Column("DAS")]
        [Display(Name = "DAS")]
        public string DAS { get; set; }

        [Column("SyncDate")]
        [Display(Name = "SyncDate")]
        public string SyncDate { get; set; }

        [NotMapped]
        public PROJECTSETTINGS PROJECTSETTINGS { get; set; }

        public bool EqualQty(BIM360ITEMSTATUS item)
        {
            if (item == null)
                return false;
            bool equal = DoubleExtension.AlmostEqualsWithAbsTolerance(item.Qty, this.Qty, 0.001);
            equal &= DoubleExtension.AlmostEqualsWithAbsTolerance(item.QtyHold, this.QtyHold, 0.001);
            return equal;
        }

        [NotMapped]
        public double QtyRounded
        {
            get 
            { 
                if (string.IsNullOrEmpty(TagType))
                    return System.Math.Round(Qty, 1);
                if (TagType.Contains("Pipe") || TagType.Contains("Paving") || TagType.Contains("Pit"))
                    return System.Math.Round(Qty, 3);
                return System.Math.Round(Qty, 1);
            }
        }

        [NotMapped]
        public double QtyHoldRounded
        {
            get 
            {
                if (string.IsNullOrEmpty(TagType))
                    return System.Math.Round(QtyHold, 1);
                if (TagType.Contains("Pipe") || TagType.Contains("Paving") || TagType.Contains("Pit"))
                    return System.Math.Round(QtyHold, 3);
                return System.Math.Round(QtyHold, 1);
            }
        }

        [NotMapped]
        public double GetQtyRounded
        {
            get
            {
                if (TagType == DatabaseCostants.TagType_Foundation_Name)
                {
                    Volume volume = new Volume(QtyRounded, VolumeUnit.CubicMeter);
                    var units = Volume.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.FOUNDATIONCONCRETEUNIT)
                            return System.Math.Round(volume.ToUnit(unit).Value, 1);
                    }
                    return QtyRounded;
                }
                else if (TagType == DatabaseCostants.TagType_Elevation_Name)
                {
                    Volume volume = new Volume(QtyRounded, VolumeUnit.CubicMeter);
                    var units = Volume.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.ELEVATIONCONCRETEUNIT)
                            return System.Math.Round(volume.ToUnit(unit).Value, 1);
                    }
                    return QtyRounded;
                }
                else if (TagType == DatabaseCostants.TagType_Paving_Name)
                {
                    Volume volume = new Volume(QtyRounded, VolumeUnit.CubicMeter);
                    var units = Volume.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.PAVINGUNIT)
                            return System.Math.Round(volume.ToUnit(unit).Value, 3);
                    }
                    return QtyRounded;
                }
                else if (TagType == DatabaseCostants.TagType_Pile_Name)
                {
                    Length length = new Length(QtyRounded, LengthUnit.Meter);
                    var units = UnitsNet.Length.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.PILESUNIT)
                            return System.Math.Round(length.ToUnit(unit).Value, 1);
                    }
                    return QtyRounded;
                }
                else if (TagType == DatabaseCostants.TagType_UndergroundPipe_Name)
                {
                    Length length = new Length(QtyRounded, LengthUnit.Meter);
                    var units = UnitsNet.Length.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.UNDERGROUNDPIPEUNIT)
                            return System.Math.Round(length.ToUnit(unit).Value, 3);
                    }
                    return QtyRounded;
                }
                else if (TagType == DatabaseCostants.TagType_Steel_Name)
                {
                    Mass mass = new Mass(QtyRounded, MassUnit.Kilogram);
                    var units = UnitsNet.Mass.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.STEELUNIT)
                            return System.Math.Round(mass.ToUnit(unit).Value, 1);
                    }
                }
                else if (TagType == DatabaseCostants.TagType_Ground_Slab_Concrete_Name)
                {
                    Volume volume = new Volume(QtyRounded, VolumeUnit.CubicMeter);
                    var units = Volume.Units;
                    foreach (var unit in units)
                    {
                        if (unit.ToString() == PROJECTSETTINGS.CONCRETESLABUNIT)
                            return System.Math.Round(volume.ToUnit(unit).Value, 1);
                    }
                    return QtyRounded;
                }
                return QtyRounded;
            }
        }
    }
}
