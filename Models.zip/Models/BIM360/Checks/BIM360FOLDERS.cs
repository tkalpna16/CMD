﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.BIM360
{
    public class BIM360FOLDERS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("FolderName")]
        [Display(Name = "FolderName")]
        public string FolderName { get; set; }

        [Column("Filter")]
        [Display(Name = "Filter")]
        public string Filter { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("Version")]
        [Display(Name = "Version")]
        public int Version { get; set; }
    }
}
