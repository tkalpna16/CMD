﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Checks
{
    public class BIM360ItemCostants
    {
        public static string ITEM_ALREADY_PRESENT = "Already present";
        public static string ITEM_NEW_MATCH = "New Match";
        public static string ITEM_NO_MATCH = "No Match";

        public static string ITEM_QTY_UPDATE = "Up to date";
        public static string ITEM_QTY_MODIFIED = "Modified";
    }
}
