﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360
{
    public class BIM360ItemAttribute
    {
        public string ModelName { get; set; }
        public string ItemName { get; set; }

        public List<string> AttributesValues { get; set; }
    }
}
