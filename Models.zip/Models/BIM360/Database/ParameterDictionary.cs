﻿using CivilMasterData.Models.BIM360.Parameters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Database
{
    public class ParameterDictionary
    {
        public List<Parameter> Parameters { get; set; }

        public ParameterDictionary() { }

        public ParameterDictionary(ParameterDictionary parameterDictionary, bool resetValues)
        {
            if (parameterDictionary.Parameters != null)
            {
                this.Parameters = new List<Parameter>();
                foreach (Parameter parameter in parameterDictionary.Parameters)
                    this.Parameters.Add(new Parameter(parameter, resetValues));
            }
            else
                this.Parameters = null;
        }

        #region Methods
        public Parameter GetParameterByForgeName(string parameterName)
        {
            if (String.IsNullOrEmpty(parameterName))
                return null;
            Parameter parameter = null;
            if (Parameters != null)
            {
                foreach (Parameter p in Parameters)
                    if (p.ForgeName == parameterName)
                    {
                        parameter = p;
                        break;
                    }
            }
            return parameter;
        }
        public Parameter GetParameterByOracleName(string parameterName)
        {
            if (String.IsNullOrEmpty(parameterName))
                return null;
            Parameter parameter = null;
            if (Parameters != null)
            {
                foreach(Parameter p in Parameters)
                    if (p.OracleDatabaseName == parameterName)
                    {
                        parameter = p;
                        break;
                    }
            }
            return parameter;
        }
        #endregion

        #region Override
        public override string ToString()
        {
            string value = string.Empty;
            string lfcr = "\r\n";
            int counter = 1;
            if (Parameters != null)
            {
                foreach (Parameter item in Parameters)
                {
                    if (item.StorageType == StorageType.STRING)
                        value += counter.ToString() + lfcr;
                    counter++;
                }
            }
            return value;
        }
        #endregion
    }
}
