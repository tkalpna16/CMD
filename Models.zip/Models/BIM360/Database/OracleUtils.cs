﻿using CivilMasterData.Data;
using CivilMasterData.Models.BIM360.Checks;
using CivilMasterData.Models.BIM360.Formulas;
using CivilMasterData.Models.BIM360.Logs;
using CivilMasterData.Models.BIM360.Parameters;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Logs;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.EntityFrameworkCore;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CivilMasterData.Models.BIM360.Database
{
    public static class OracleUtils
    {
        public static bool SaveForgeItems(List<ForgeItem> forgeItems, 
            string connectionString,
            string procedureInserForgeItem,
            string procedureFilename,
            string procedureObjectId,
            string procedurePropertyName,
            string procedurePropertyValue)
        {
            bool found = !String.IsNullOrEmpty(connectionString);
            if (!found)
                return found;
            if (forgeItems == null || forgeItems.Count == 0)
                return false;

            bool correct = true;
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                conn.Open();
                try
                {
                    // Add Items
                    foreach(ForgeItem forgeItem in forgeItems)
                    {
                        // Add parameters
                        foreach (Property prop in forgeItem.Properties)
                        {
                            // Create a Command object to call Get_Employee_Info procedure.
                            OracleCommand cmd = new OracleCommand(procedureInserForgeItem, conn);

                            // Command Type is StoredProcedure
                            cmd.CommandType = System.Data.CommandType.StoredProcedure;

                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(procedureFilename, OracleDbType.Char).Value = forgeItem.ModelName;
                            cmd.Parameters.Add(procedureObjectId, OracleDbType.Int32).Value = forgeItem.Objectid;
                            cmd.Parameters.Add(procedurePropertyName, OracleDbType.Char).Value = prop.Name;
                            cmd.Parameters.Add(procedurePropertyValue, OracleDbType.Char).Value = prop.Value;

                            // Execute procedure.
                            int result = cmd.ExecuteNonQuery();
                            correct &= result == -1;
                        }
                    }
                }
                catch
                {

                }
                finally
                {
                    conn.Close();
                    conn.Dispose();
                }
            }

            return found;
        }

        public static bool SaveSecondaryItems(OracleConnection conn,
            USERS user,
            int projectId,
            List<SecondaryItem> secondaryItems,
            List<string> itemTagsToProcess,
            MODELCONNECTORContext _context,
            PROJECTSETTINGS pROJECTSETTINGS,
            ref List<string> modelsNotProcessed,
            bool saveToDB = false)
        {
            if (secondaryItems == null || secondaryItems.Count == 0)
                return true;

            // Get all main items of the project
            var mainItemsList = _context.MAINITEMS.Include(m => m.PBS).Include(m => m.TAGTYPES).Include(m => m.LOTS)
                .Where(m => m.PBS.ProjectID == projectId).ToList();
            List<MAINITEMS> processedMainItems = new List<MAINITEMS>();

            modelsNotProcessed = new List<string>();

            bool correct = true;
            List<string> secondaryItemTagAdded = new List<string>();
            string itemTag = string.Empty;
            string mainItemTag = string.Empty;
            string mainItemLot = string.Empty;
            string familyName = string.Empty;
            string unit = string.Empty;
            string area = string.Empty;
            string cwa = string.Empty;
            string subDiscipline = string.Empty;
            string wp = string.Empty;
            string objectCode = string.Empty;
            string materialGroup = string.Empty;
            string materialGroup2 = string.Empty;
            OBJECTCODES objCode = null;
            MATERIALWORKGROUPS matWorkGroup = null;

            // Init User Parameter
            Parameter userParameter = new Parameter(DatabaseCostants.Oracle_ParameterNameUserId, DatabaseCostants.Oracle_ParameterNameUserId, StorageType.INTEGER, UnitType.NUMBER, false);
            userParameter.Set(user.USERID.Value);

            // Init Main Item Id Parameter
            Parameter mainItemIdParameter = new Parameter(DatabaseCostants.Oracle_ParameterNameMainItemId, DatabaseCostants.Oracle_ParameterNameMainItemId, StorageType.INTEGER, UnitType.NUMBER, false);

            // Init List of Parameters
            List<string> parametersToCheck = pROJECTSETTINGS.GetBim360Parameters();

            // Add Items
            bool createMainItems = false;
            bool foundCMDChecker = false;
            foreach (SecondaryItem item in secondaryItems)
            {
                // Process Parameters
                if (!string.IsNullOrEmpty(item.GetItemTag) || 
                    item.TagType == DatabaseCostants.TagType_UndergroundPipe_ID
                    || item.TagType == DatabaseCostants.TagType_Paving_ID 
                    || item.TagType == DatabaseCostants.TagType_UndergroundPit_ID)
                {
                    if (parametersToCheck != null && parametersToCheck.Count > 0)
                    {
                        string modelName = item.ModelName;
                        string itemName = item.GetForgeName;
                        foreach (string parameter in parametersToCheck)
                        {
                            BIM360PARAMETERS bIM360PARAMETERS = new BIM360PARAMETERS();
                            bIM360PARAMETERS.ProjectID = projectId;
                            bIM360PARAMETERS.ModelName = modelName;
                            bIM360PARAMETERS.ItemName = itemName;
                            bIM360PARAMETERS.ForgeItemName = item.GetForgeTextValue("Name");
                            bIM360PARAMETERS.ParameterName = parameter;
                            bIM360PARAMETERS.ParameterValue = item.GetForgeTextValue(parameter);
                            ModelConnectionResults.AddParameterValue(bIM360PARAMETERS);
                        }
                    }
                }

                // File Revisions
                if (!string.IsNullOrEmpty(item.ModelName))
                {
                    BIM360FILEREVISIONS bIM360FILEREVISIONS = new BIM360FILEREVISIONS();
                    bIM360FILEREVISIONS.ModelName = item.ModelName;
                    bIM360FILEREVISIONS.ProjectID = projectId;
                    bIM360FILEREVISIONS.UserID = user.USERID;
                    bIM360FILEREVISIONS.CreationDate = DateTime.UtcNow;
                    ModelConnectionResults.AddFileRevision(bIM360FILEREVISIONS);
                }

                if (!item.ProcessedQty)
                    continue;
                try
                {
                    // CMD Checker Control
                    string cmdCheckerValue = item.GetForgeTextValue(DatabaseCostants.Forge_ParameterName_CMD_Checker);
                    if (!string.IsNullOrEmpty(cmdCheckerValue))
                        foundCMDChecker = true;

                    itemTag = item.GetItemTag;
                    if (item.TagType != DatabaseCostants.TagType_UndergroundPipe_ID &&
                        item.TagType != DatabaseCostants.TagType_Paving_ID &&
                        item.TagType != DatabaseCostants.TagType_UndergroundPit_ID)
                    {
                        if (string.IsNullOrEmpty(itemTag))
                        {
                            ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_ITEM_TAG_NULL, itemTag);
                            forgeLog.FileName = item.ModelName;
                            forgeLog.ItemTag = item.GetItemTag + "-" + item.Objectid.ToString();
                            ForgeLogManager.AddLog(forgeLog);
                            continue;
                        }
                    }

                    // Init Unit
                    unit = item.GetTextValue(DatabaseCostants.Forge_ParameterName_Unit);
                    if (string.IsNullOrEmpty(unit) && item.TagType != DatabaseCostants.TagType_Steel_ID)
                    {
                        ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_UNIT_NULL, itemTag);
                        forgeLog.FileName = item.ModelName;
                        forgeLog.ItemTag = item.GetItemTag;
                        ForgeLogManager.AddLog(forgeLog);
                        continue;
                    }

                    // Init Area
                    area = item.GetTextValue(DatabaseCostants.Forge_ParameterName_AreaCode);
                    if (string.IsNullOrEmpty(area) && item.TagType != DatabaseCostants.TagType_Steel_ID)
                    {
                        ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_AREA_NULL, itemTag);
                        forgeLog.FileName = item.ModelName;
                        forgeLog.ItemTag = item.GetItemTag;
                        ForgeLogManager.AddLog(forgeLog);
                        continue;
                    }

                    cwa = item.GetTextValue(DatabaseCostants.Forge_ParameterName_CWA);
                    subDiscipline = item.GetTextValue(DatabaseCostants.Forge_ParameterName_SubDiscipline);

                    wp = item.GetTextValue(DatabaseCostants.Forge_ParameterName_WP);
                    objectCode = item.GetTextValue(DatabaseCostants.Forge_ParameterName_ObjectCode);
                    materialGroup = item.GetTextValue(DatabaseCostants.Forge_ParameterName_MaterialGroup);
                    materialGroup2 = item.GetTextValue(DatabaseCostants.Forge_ParameterName_MaterialGroup2);

                    objCode = _context.OBJECTCODES.Where(o => o.Code == objectCode).FirstOrDefault();
                    if (objCode == null && item.TagType != DatabaseCostants.TagType_Steel_ID &&
                        item.TagType != DatabaseCostants.TagType_UndergroundPipe_ID &&
                        item.TagType != DatabaseCostants.TagType_Paving_ID &&
                        item.TagType != DatabaseCostants.TagType_UndergroundPit_ID)
                    {
                        ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_OBJECT_CODE_NOT_FOUND, itemTag);
                        forgeLog.FileName = item.ModelName;
                        forgeLog.ItemTag = item.GetItemTag;
                        ForgeLogManager.AddLog(forgeLog);
                        continue;
                    }
                    matWorkGroup = _context.MATERIALWORKGROUPS.Where(o => o.GroupCode == materialGroup).FirstOrDefault();
                    if (matWorkGroup == null)
                        matWorkGroup = _context.MATERIALWORKGROUPS.Where(o => o.GroupCode == materialGroup2).FirstOrDefault();
                    if (matWorkGroup == null && item.TagType != DatabaseCostants.TagType_Steel_ID)
                    {
                        ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_MATERIAL_WORK_GROUP_NOT_FOUND, itemTag);
                        forgeLog.FileName = item.ModelName;
                        forgeLog.ItemTag = item.GetItemTag;
                        ForgeLogManager.AddLog(forgeLog);
                        continue;
                    }

                    if (!secondaryItemTagAdded.Contains(itemTag) 
                        || item.TagType == DatabaseCostants.TagType_UndergroundPipe_ID
                        || item.TagType == DatabaseCostants.TagType_Paving_ID
                        || item.TagType == DatabaseCostants.TagType_UndergroundPit_ID)
                    {
                        if (itemTagsToProcess != null && itemTagsToProcess.Count > 0)
                        {
                            if (!itemTagsToProcess.Contains(itemTag))
                                continue;
                            createMainItems = true;
                        }

                        // Search Main Item
                        mainItemTag = item.GetTextValue(DatabaseCostants.Forge_ParameterName_MainItemTag);
                        if (string.IsNullOrEmpty(mainItemTag))
                        {
                            ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_ITEM_MAIN_ITEM_NULL, itemTag);
                            forgeLog.FileName = item.ModelName;
                            forgeLog.ItemTag = item.GetItemTag;
                            ForgeLogManager.AddLog(forgeLog);
                            continue;
                        }

                        mainItemLot = item.GetTextValue(DatabaseCostants.Forge_ParameterName_Lot);
                        if (string.IsNullOrEmpty(mainItemLot)) // Set default to A
                            mainItemLot = DatabaseCostants.DefaultLot;

                        var mainItem = mainItemsList.Where(m => m.MainItemTag == mainItemTag && m.TagTypeID == item.TagType
                            && m.LOTS.NAME == mainItemLot).FirstOrDefault();
                        if (mainItem == null)
                        {
                            if (!createMainItems)
                            {
                                // Init Log
                                ForgeLog forgeLog = new ForgeLog();
                                forgeLog.MessageCode = MESSAGE_CODES.MODEL_CONNECTOR_MAIN_ITEM_NOT_FOUND;
                                forgeLog.Unit = unit;
                                forgeLog.CA = area;
                                forgeLog.CWA = cwa;
                                forgeLog.Lot = mainItemLot;
                                forgeLog.SubDiscipline = subDiscipline;
                                forgeLog.WP = wp;
                                forgeLog.ObjectCode = objectCode;
                                if (!string.IsNullOrEmpty(materialGroup))
                                    forgeLog.MaterialWorkGroup = materialGroup;
                                else
                                    forgeLog.MaterialWorkGroup = materialGroup2;
                                forgeLog.TagType = _context.TAGTYPES.Where(t => t.TagTypeID == item.TagType).FirstOrDefault().Description;
                                forgeLog.MainItemTag = mainItemTag;
                                forgeLog.FileName = item.ModelName;
                                forgeLog.ItemTag = item.GetItemTag;
                                forgeLog.FileName = item.ModelName;

                                ForgeLogManager.AddLog(forgeLog);
                                modelsNotProcessed.Add(item.ModelName);

                                // Add to not found items
                                MainItemData mainItemData = new MainItemData();
                                mainItemData.MainItemTag = mainItemTag;
                                mainItemData.TagType = forgeLog.TagType;
                                mainItemData.Lot = mainItemLot;
                                mainItemData.ModelName = item.ModelName;

                                ModelConnectionResults.AddNotFoundMainItem(mainItemData);

                                // Add main item status
                                BIM360ITEMSTATUS itemStatus = new BIM360ITEMSTATUS();
                                itemStatus.ModelName = item.ModelName;
                                itemStatus.TagType = forgeLog.TagType;
                                itemStatus.MainItemTag = mainItemTag;
                                itemStatus.Lot = mainItemLot;
                                itemStatus.ProjectID = projectId;
                                itemStatus.MatchItem = BIM360ItemCostants.ITEM_NO_MATCH;
                                itemStatus.Status = string.Empty;
                                itemStatus.ObjectCode = objectCode;
                                if (!string.IsNullOrEmpty(materialGroup))
                                    itemStatus.Material = materialGroup;
                                else
                                    itemStatus.Material = materialGroup2;
                                itemStatus.WP = wp;
                                itemStatus.CWA = cwa;
                                itemStatus.Unit = unit;
                                itemStatus.DAS = subDiscipline;
                                itemStatus.CA = cwa;
                                itemStatus.SyncDate = DateTime.UtcNow.ToString("yyyy-MM-dd");
                                ModelConnectionResults.AddItemStatus(itemStatus);
                            }
                            continue;
                        }
                        else if (mainItem.IsDeleted || mainItem.IsReplaced)
                        {
                            // Add main item status
                            BIM360ITEMSTATUS itemStatus = new BIM360ITEMSTATUS();
                            itemStatus.ModelName = item.ModelName;
                            itemStatus.TagType = _context.TAGTYPES.Where(t => t.TagTypeID == item.TagType).FirstOrDefault().Description;
                            itemStatus.MainItemTag = mainItemTag;
                            itemStatus.Lot = mainItemLot;
                            itemStatus.ProjectID = projectId;
                            itemStatus.MatchItem = BIM360ItemCostants.ITEM_NO_MATCH;
                            itemStatus.Status = string.Empty;
                            itemStatus.ObjectCode = objectCode;
                            itemStatus.Material = materialGroup;
                            itemStatus.WP = wp;
                            itemStatus.CWA = cwa;
                            itemStatus.Unit = unit;
                            itemStatus.DAS = subDiscipline;
                            itemStatus.CA = cwa;
                            itemStatus.SyncDate = DateTime.UtcNow.ToString("yyyy-MM-dd");
                            ModelConnectionResults.AddItemStatus(itemStatus);
                            continue;
                        }

                        // Add main item to model connector results
                        mainItem.ModelName = item.ModelName;
                        ModelConnectionResults.AddProcessedMainItem(mainItem);

                        secondaryItemTagAdded.Add(itemTag);
                        string value = item.ParameterDictionary.ToString();

                        // Set lot
                        item.LotName = mainItem.LOTS.NAME;

                        if (saveToDB)
                        {
                            // Create a Command object to call procedure.
                            OracleCommand cmd = new OracleCommand(DatabaseCostants.Oracle_ProcedureSaveSecName, conn);

                            // Command Type is StoredProcedure
                            cmd.CommandType = System.Data.CommandType.StoredProcedure;

                            cmd.Parameters.Clear();
                            value = string.Empty;

                            // Add Base Parameter
                            mainItemIdParameter.Set(mainItem.MainItemID);
                            mainItemIdParameter.AddToCommand(cmd, ref value);
                            userParameter.AddToCommand(cmd, ref value);


                            // Add Parameter from Forge Properties
                            foreach (Parameter parameter in item.ParameterDictionary.Parameters)
                            {
                                if (parameter.ForgeName == DatabaseCostants.Forge_ParameterName_MainItemTag) // Exclude Main Tag Added as Id
                                    continue;
                                else
                                {
                                    if (!string.IsNullOrEmpty(parameter.OracleProcedureName))
                                        parameter.AddToCommand(cmd, ref value);
                                }
                            }

                            // Execute procedure.
                            int result = cmd.ExecuteNonQuery();
                            correct &= result == -1;
                        }

                        // Add main item to processed
                        processedMainItems.Add(mainItem);
                    }
                }
                catch (Exception ex)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                    correct = false;
                }
            }

            if (!foundCMDChecker && secondaryItems != null && secondaryItems.Count > 0)
            {
                ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MODEL_CONNECTOR_CMD_CHECKER_NULL, string.Empty);
                forgeLog.FileName = secondaryItems[0].ModelName;
                forgeLog.ItemTag = string.Empty;
                ForgeLogManager.AddLog(forgeLog);
            }

            // Get not found items
            List<int> processedIds = processedMainItems.Select(m => m.MainItemID).Distinct().ToList();
            List<MAINITEMS> notProcessedMainItems = mainItemsList.Where(m => !processedIds.Contains(m.MainItemID) 
                && m.BALANCE.Value < 1 && m.ConsiderForBIM360).ToList();
            if (notProcessedMainItems != null)
            {
                foreach(MAINITEMS mainItem in notProcessedMainItems)
                {
                    ForgeLog forgeLog = new ForgeLog();
                    forgeLog.MessageCode = MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_MAIN_ITEM_NOT_PROCESSED;
                    forgeLog.TagType = mainItem.TAGTYPES.Description;
                    forgeLog.MainItemTag = mainItem.MainItemTag;
                    forgeLog.Lot = mainItem.LOTS.NAME;
                    ForgeLogManager.AddLog(forgeLog);
                }
            }

            return correct;
        }


        public static bool AddMissingMainItems(MODELCONNECTORContext _context, USERS user, int projectId)
        {
            bool valid = true;
            if (ForgeLogManager.Logs != null)
            {
                bool added = false;
                foreach(ForgeLog log in ForgeLogManager.Logs)
                {
                    MISSING_MAINITEMS item = log.GetMISSING_MAINITEMS(projectId, user);
                    if (item != null)
                    {
                        var itemInDb = _context.MISSING_MAINITEMS.Where(i => i.ProjectID == projectId &&
                            i.MainItemTag == item.MainItemTag && i.TagType == item.TagType
                            && i.Lot == item.Lot).FirstOrDefault();
                        if (itemInDb == null)
                        {
                            _context.MISSING_MAINITEMS.Add(item);
                            added = true;
                        }
                    }
                }
                if (added)
                {
                    int result = _context.SaveChanges();
                    valid &= result > 0;
                }
            }
            return valid;
        }

        public static bool SetMainItemsToBeDeleted(MODELCONNECTORContext _context, USERS user, int projectId)
        {
            bool valid = true;
            if (ForgeLogManager.Logs != null)
            {
                var logs = ForgeLogManager.Logs.Where(l => l.MessageCode == MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_MAIN_ITEM_NOT_PROCESSED).ToList();
                if (logs != null)
                {
                    foreach (ForgeLog log in logs)
                    {
                        var itemInDb = _context.MAINITEMS.
                            Include(i => i.PBS).
                            Include(i => i.LOTS).
                            Include(i => i.TAGTYPES).
                            Where(i => i.PBS.ProjectID == projectId &&i.MainItemTag == log.MainItemTag && i.TAGTYPES.Description == log.TagType && i.LOTS.NAME == log.Lot).
                            FirstOrDefault();
                        if (itemInDb != null)
                            _context.MAINITEMS_TO_BE_DELETED.Add(itemInDb);
                    }
                }
            }
            return valid;
        }

        public static List<double> GetQuantity(string mainItemTagToCalculate, int tagType, string lot,
            List<SecondaryItem> secondaryItems)
        {
            double qty = 0.0;
            double qtyHold = 0.0;
            List<int> idComputed = new List<int>();

            if (secondaryItems != null)
            {
                List<SecondaryItem> itemsWithQty = secondaryItems.Where(s => s.ProcessedQty).ToList();

                foreach (SecondaryItem secItem in itemsWithQty)
                {
                    if (idComputed.Contains(secItem.Objectid))
                        continue;
                    idComputed.Add(secItem.Objectid);

                    // Check if main item is not present in database
                    string mainItemTag = secItem.GetMainItemTag;
                    if (String.IsNullOrEmpty(mainItemTag))
                    {
                        LogManager.AddLog(new Log(mainItemTag, secItem.ModelName, secItem.GetItemTag));
                        continue;
                    }

                    if (mainItemTagToCalculate == mainItemTag && tagType  == secItem.TagType)
                    {
                        bool valid = false;
                        string itemLot = secItem.GetLotName;
                        if (string.IsNullOrEmpty(lot) && string.IsNullOrEmpty(itemLot))
                            valid = true;
                        else if (lot == itemLot)
                            valid = true;
                        else if (lot == DatabaseCostants.DefaultLot && string.IsNullOrEmpty(itemLot))
                            valid = true;
                        if (valid)
                        {
                            qty += secItem.GetQty;
                            if (tagType == DatabaseCostants.TagType_Steel_ID)
                            {
                                if (secItem.IsHoldSteel)
                                    qtyHold += secItem.GetQty;
                            }
                            else
                            {
                                if (secItem.IsHold)
                                    qtyHold += secItem.GetQty;
                            }
                        }
                    }
                }
            }

            List<double> quantities = new List<double>();
            quantities.Add(qty);
            quantities.Add(qtyHold);
            return quantities;
        }

        public static bool UpdateQuantities(
            List<MAINITEMS> mAINITEMs,
            List<ENGINEERING_STATUS> statusList,
            List<SecondaryItem> secondaryItems,
            USERS user)
        {
            bool valid = true;
            LogManager.Clear();

            if (secondaryItems != null)
            {
                List<SecondaryItem> itemsWithQty = secondaryItems.Where(s => s.ProcessedQty).ToList();

                ComputedQtyType computedQtyType = null;
                MAINITEMS mainItem = null;
                List<ComputedQtyType> computedItems = new List<ComputedQtyType>();
                List<Tuple<int,string>> idComputed = new List<Tuple<int, string>>();
                using (OracleConnection conn = new OracleConnection(DatabaseCostants.Oracle_ConnectionString))
                {
                    conn.Open();
                    try
                    {
                        foreach (SecondaryItem secItem in itemsWithQty)
                        {
                            var itemComputed = idComputed.Where(a => a.Item1 == secItem.Objectid && a.Item2 == secItem.ModelName).FirstOrDefault();
                            if (itemComputed != null)
                                continue;
                            idComputed.Add(new Tuple<int, string>(secItem.Objectid, secItem.ModelName));

                            // Check if main item is not present in database
                            string mainItemTag = secItem.GetMainItemTag;
                            if (String.IsNullOrEmpty(mainItemTag))
                            {
                                LogManager.AddLog(new Log(mainItemTag, secItem.ModelName, secItem.GetItemTag));
                                continue;
                            }

                            mainItem = mAINITEMs.Where(m => m.MainItemTag == mainItemTag && m.TagTypeID == secItem.TagType
                                     && m.LOTS.NAME == secItem.LotName).FirstOrDefault();

                            if (mainItem == null)
                            {
                                LogManager.AddLog(new Log(mainItemTag, secItem.ModelName, secItem.GetItemTag));
                                continue;
                            }

                            // Now Calculate Qty
                            double qty = 0.0;
                            double qtyHold = 0.0;
                            var filteredQty = itemsWithQty.Where(m => m.GetMainItemTag == mainItemTag && m.TagType == secItem.TagType
                                 && (m.LotName == secItem.LotName)).ToList();

                            bool addCount = mainItem.TagTypeID == DatabaseCostants.TagType_Pile_ID;
                            int count = 0;

                            if (filteredQty != null)
                            {
                                foreach (SecondaryItem secItemToAdd in filteredQty)
                                {
                                    idComputed.Add(new Tuple<int, string>(secItem.Objectid, secItem.ModelName));
                                    qty += secItemToAdd.GetQty;

                                    if (mainItem.TagTypeID == DatabaseCostants.TagType_Steel_ID)
                                    {
                                        if (secItemToAdd.IsHoldSteel)
                                            qtyHold += secItemToAdd.GetQty;
                                    }
                                    else
                                    {
                                        if (secItemToAdd.IsHold)
                                            qtyHold += secItemToAdd.GetQty;
                                    }
                                }
                                count = filteredQty.Count;
                            }
                            else
                                continue;

                            try
                            {
                                OracleCommand cmd = new OracleCommand(DatabaseCostants.Oracle_ProcedureNameMTORev, conn);

                                // Command Type is StoredProcedure
                                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                                cmd.Parameters.Clear();
                                cmd.Parameters.Add(DatabaseCostants.Oracle_ParameterNameMainItemId, OracleDbType.Int32).Value = mainItem.MainItemID;
                                cmd.Parameters.Add(DatabaseCostants.Oracle_EngStatusId, OracleDbType.Int32).Value = 1;
                                cmd.Parameters.Add(DatabaseCostants.Oracle_ModelStatusId, OracleDbType.Int32).Value = 2;
                                cmd.Parameters.Add(DatabaseCostants.Oracle_Qty, OracleDbType.Double).Value = qty;
                                cmd.Parameters.Add(DatabaseCostants.Oracle_ParameterNameUserId, OracleDbType.Int32).Value = user.USERID;
                                cmd.Parameters.Add(DatabaseCostants.Oracle_Qty_Hold, OracleDbType.Double).Value = qtyHold;

                                // Execute procedure.
                                int result = cmd.ExecuteNonQuery();
                                valid &= result == -1;

                                // Add main item status
                                BIM360ITEMSTATUS itemStatus = new BIM360ITEMSTATUS();
                                itemStatus.ModelName = secItem.ModelName;
                                itemStatus.TagType = mainItem.TAGTYPES.Description;
                                itemStatus.MainItemTag = mainItemTag;
                                itemStatus.Lot = mainItem.LOTS.NAME;
                                itemStatus.ProjectID = mainItem.PBS.ProjectID;
                                itemStatus.MatchItem = BIM360ItemCostants.ITEM_NEW_MATCH;
                                itemStatus.Status = BIM360ItemCostants.ITEM_QTY_UPDATE;
                                itemStatus.Qty = qty;
                                itemStatus.Hold = qtyHold > 0.0;
                                itemStatus.QtyHold = qtyHold;
                                itemStatus.SyncDate = DateTime.UtcNow.ToString("yyyy-MM-dd");
                                if (addCount)
                                    itemStatus.COUNT = count;

                                ModelConnectionResults.AddItemStatus(itemStatus);
                            }
                            catch (Exception ex)
                            {
                                ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MAIN_ITEM_QTY_NOT_UPDATED, mainItem.MainItemTag);
                                forgeLog.Description = ex.Message;
                                ForgeLogManager.AddLog(forgeLog);
                            }


                            //ENGINEERING_STATUS status = secItem.GetEngineeringStatus(statusList);
                            //if (status != null)
                            //{
                            //    computedQtyType = secItem.GetComputedQty();
                            //    if (computedQtyType.IsAlreadyPresent(computedItems))
                            //        continue;
                            //    computedItems.Add(computedQtyType);

                            //    // Now Calculate Qty
                            //    ComputedQtyType computedQtyTypeToAdd = null;
                            //    double qty = 0.0;
                            //    double qtyHold = 0.0;

                            //    var filteredQty = itemsWithQty.Where(m => m.GetMainItemTag == mainItemTag && m.TagType == secItem.TagType
                            //         && (m.LotId == secItem.LotId || m.LotId == -1)).ToList();

                            //    var item = filteredQty.Where(f => f.GetForgeName == "Foundation Slab:GSJ001:3802644").FirstOrDefault();
                            //    if (item != null)
                            //    {
                            //        var a = item.IsHold;
                            //    }

                            //    if (filteredQty != null)
                            //    {
                            //        foreach (SecondaryItem secItemToAdd in filteredQty)
                            //        {
                            //            computedQtyTypeToAdd = secItemToAdd.GetComputedQty();
                            //            if (computedQtyTypeToAdd == null)
                            //                continue;
                            //            if (computedQtyTypeToAdd == computedQtyType)
                            //            {
                            //                idComputed.Add(secItemToAdd.Objectid);
                            //                qty += secItemToAdd.GetQty;

                            //                if (secItemToAdd.IsHold)
                            //                    qtyHold += secItemToAdd.GetQty;
                            //            }
                            //        }
                            //    }
                            //    else
                            //        continue;

                            //    try
                            //    {
                            //        OracleCommand cmd = new OracleCommand(DatabaseCostants.Oracle_ProcedureNameMTORev, conn);

                            //        // Command Type is StoredProcedure
                            //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

                            //        cmd.Parameters.Clear();
                            //        cmd.Parameters.Add(DatabaseCostants.Oracle_ParameterNameMainItemId, OracleDbType.Int32).Value = mainItem.MainItemID;
                            //        cmd.Parameters.Add(DatabaseCostants.Oracle_EngStatusId, OracleDbType.Int32).Value = status.StatusID;
                            //        cmd.Parameters.Add(DatabaseCostants.Oracle_ModelStatusId, OracleDbType.Int32).Value = 2;
                            //        cmd.Parameters.Add(DatabaseCostants.Oracle_Qty, OracleDbType.Double).Value = qty;
                            //        cmd.Parameters.Add(DatabaseCostants.Oracle_ParameterNameUserId, OracleDbType.Int32).Value = user.USERID;
                            //        cmd.Parameters.Add(DatabaseCostants.Oracle_Qty_Hold, OracleDbType.Double).Value = qtyHold;

                            //        // Execute procedure.
                            //        int result = cmd.ExecuteNonQuery();
                            //        valid &= result == -1;

                            //        // Add main item status
                            //        BIM360ITEMSTATUS itemStatus = new BIM360ITEMSTATUS();
                            //        itemStatus.ModelName = secItem.ModelName;
                            //        itemStatus.TagType = mainItem.TAGTYPES.Description;
                            //        itemStatus.MainItemTag = mainItemTag;
                            //        itemStatus.Lot = mainItem.LOTS.NAME;
                            //        itemStatus.ProjectID = mainItem.PBS.ProjectID;
                            //        itemStatus.MatchItem = BIM360ItemCostants.ITEM_NEW_MATCH;
                            //        itemStatus.Status = BIM360ItemCostants.ITEM_QTY_UPDATE;
                            //        itemStatus.Qty = qty;
                            //        itemStatus.Hold = qtyHold > 0.0;
                            //        itemStatus.QtyHold = qtyHold;

                            //        ModelConnectionResults.AddItemStatus(itemStatus);
                            //    }
                            //    catch (Exception ex)
                            //    {
                            //        ForgeLog forgeLog = new ForgeLog(MESSAGE_CODES.MAIN_ITEM_QTY_NOT_UPDATED, mainItem.MainItemTag);
                            //        forgeLog.Description = ex.Message;
                            //        ForgeLogManager.AddLog(forgeLog);
                            //    }
                            //}
                            //else
                            //    continue;
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.Print(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
            }

            return valid;
        }
    }
}
