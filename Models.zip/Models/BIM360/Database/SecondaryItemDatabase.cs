﻿using CivilMasterData.Data;
using CivilMasterData.Models.BIM360.Formulas;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Logs;
using CivilMasterData.Models.Users;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Database
{
    public class SecondaryItemDatabase
    {
        #region Private members
        public string FileName { get; set; }
        List<SecondaryItem> items;
        #endregion

        #region Access members
        public List<SecondaryItem> Items
        {
            get { return items; }
        }
        #endregion

        #region Constructor
        public SecondaryItemDatabase(List<ForgeItem> forgeItemList, 
            ParameterDictionary parameterDictionary, 
            FamilyFormulaDictionary familyFormulaDictionary,
            bool parallel = true)
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            items = new List<SecondaryItem>();
            SecondaryItem item = null;

            if (parallel)
            {
                ConcurrentBag<SecondaryItem> bagItems = new ConcurrentBag<SecondaryItem>();
                if (forgeItemList != null)
                {
                    Parallel.ForEach(forgeItemList, forgeItem =>
                    {
                        item = SecondaryItem.Parse(forgeItem, parameterDictionary, familyFormulaDictionary);
                        if (item != null)
                        {
                            item.ModelName = forgeItem.ModelName;
                            bagItems.Add(item);
                        }
                    });
                }
                items = bagItems.ToList();
            }
            else
            {
                if (forgeItemList != null)
                {
                    foreach(ForgeItem currentItem in forgeItemList)
                    {
                        item = SecondaryItem.Parse(currentItem, parameterDictionary, familyFormulaDictionary);
                        if (item != null)
                        {
                            item.ModelName = currentItem.ModelName;
                            items.Add(item);
                        }
                    };
                }
            }
            stopWatch.Stop();
            Debug.Print("Parsing items " + stopWatch.Elapsed.TotalSeconds.ToString());
        }
        #endregion

        #region Oracle methods
        public void SaveToDatabase(
            List<MAINITEMS> mainItems,
            List<ENGINEERING_STATUS> statusList,
            int projectId,
            USERS user,
            List<string> itemTags,
            MODELCONNECTORContext _context,
            PROJECTSETTINGS pROJECTSETTINGS,
            ref List<string> modelsNotProcessed)
        {
            LogManager.Clear();
            ForgeLogManager.Clear();
            if (items != null)
            {
                using (OracleConnection conn = new OracleConnection(DatabaseCostants.Oracle_ConnectionString))
                {
                    conn.Open();
                    OracleTransaction oracleTransaction = conn.BeginTransaction();
                    try
                    {
                        Stopwatch stopWatch = new Stopwatch();
                        stopWatch.Start();
                        bool valid = OracleUtils.SaveSecondaryItems(conn, 
                            user, 
                            projectId,
                            items,
                            itemTags,
                            _context,
                            pROJECTSETTINGS,
                            ref modelsNotProcessed);
                        stopWatch.Stop();
                        Debug.Print("Read items " + stopWatch.Elapsed.TotalSeconds.ToString());

                        stopWatch.Start();
                        valid &= OracleUtils.AddMissingMainItems(_context, user, projectId);
                        //valid &= OracleUtils.SetMainItemsToBeDeleted(_context, user, projectId);
                        stopWatch.Stop();
                        Debug.Print("Adding missing items " + stopWatch.Elapsed.TotalSeconds.ToString());

                        stopWatch.Start();
                        valid &= OracleUtils.UpdateQuantities(mainItems, statusList, items, user);
                        Debug.Print("Adding missing items " + stopWatch.Elapsed.TotalSeconds.ToString());

                        if (valid)
                            oracleTransaction.Commit();
                        else
                            oracleTransaction.Rollback();
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.Print(ex.Message);
                        oracleTransaction.Rollback();
                    }
                    finally
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
            }
        }
        #endregion

        #region Override
        public override string ToString()
        {
            string value = string.Empty;
            string lfcr = "\r\n";
            if (items != null)
            {
                foreach (SecondaryItem item in items)
                    value += item.GetFamilyName + lfcr;
            }
            return value;
        }
        #endregion
    }
}
