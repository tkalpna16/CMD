﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Database
{
    public class ComputedQtyType
    {
        public string MainItemTag { get; set; }
        public int TagType { get; set; }
        public string EngStatus { get; set; }

        public ComputedQtyType() { }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            ComputedQtyType computedQty = (ComputedQtyType)obj;
            if (computedQty == null)
                return false;
            if (MainItemTag == computedQty.MainItemTag && EngStatus == computedQty.EngStatus && TagType == computedQty.TagType)
                return true;
            else
                return false;
        }

        public static bool operator ==(ComputedQtyType lhs, ComputedQtyType rhs)
        {
            return lhs.Equals(rhs);
        }
        public static bool operator !=(ComputedQtyType lhs, ComputedQtyType rhs)
        {
            return !lhs.Equals(rhs);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }

        public bool IsAlreadyPresent(List<ComputedQtyType> computedQties)
        {
            if (computedQties == null || computedQties.Count == 0)
                return false;
            foreach (ComputedQtyType c in computedQties)
                if (c == this)
                    return true;
            return false;
        }
    }
}
