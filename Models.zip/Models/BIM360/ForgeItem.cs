﻿using Autodesk.Forge.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360
{
    public class ForgeItem
    {
        public string ModelName { get; set; }
        public int? Objectid { get; set; }
        public string Name { get; set; }
        public List<Property> Properties { get; set; }

        public static ForgeItem GetItem(MetadataCollection metadataCollection, string modelName)
        {
            if (metadataCollection == null)
                return null;
            ForgeItem item = new ForgeItem();
            item.ModelName = modelName;
            item.Name = metadataCollection.Name;
            item.Objectid = metadataCollection.Objectid;
            item.Properties = new List<Property>();

            // Add model name
            Property property = new Property();
            property.Name = "name";
            property.Value = item.Name;
            item.Properties.Add(property);
            if (metadataCollection.Properties != null)
            {
                JToken jProperty = (JToken) metadataCollection.Properties;
                List<JToken> categories = jProperty.Children().ToList<JToken>();
                string category = string.Empty;
                string name = string.Empty;
                string value = string.Empty;
                if (categories != null)
                {
                    foreach (JToken jToken in categories)
                    {
                        JProperty parentProp = (JProperty)jToken;
                        if (parentProp != null)
                        {
                            category = parentProp.Name;  // "Info"
                            List<JToken> properties = jToken.Children().ToList<JToken>();
                            if (properties != null)
                            {
                                foreach (JToken jTokenProp in properties)
                                {
                                    List<JToken> parameters = jTokenProp.Children().ToList<JToken>();
                                    if (parameters != null)
                                    {
                                        foreach (JToken jTokenParam in parameters)
                                        {
                                            JProperty propParam = (JProperty)jTokenParam;
                                            if (propParam != null)
                                            {
                                                name = propParam.Name;
                                                value = propParam.Value.ToString();
                                                if (!String.IsNullOrEmpty(name))
                                                {
                                                    property = new Property();
                                                    property.Name = name;
                                                    property.Value = value;
                                                    property.CategoryName = category;
                                                    item.Properties.Add(property);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return item;
        }

        public static T GetValue<T>(JToken jToken, string key, T defaultValue = default(T))
        {
            dynamic ret = jToken[key];
            if (ret == null) return defaultValue;
            if (ret is JObject) return JsonConvert.DeserializeObject<T>(ret.ToString());
            return (T)ret;
        }
    }
}
