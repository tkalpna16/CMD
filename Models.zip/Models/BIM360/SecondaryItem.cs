﻿using CivilMasterData.Models.BIM360.Database;
using CivilMasterData.Models.BIM360.Formulas;
using CivilMasterData.Models.BIM360.Parameters;
using CivilMasterData.Models.Costants;
using org.mariuszgromada.math.mxparser;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CivilMasterData.Models.BIM360
{
    public class SecondaryItem
    {
        public int Objectid { get; set; }
        public string ModelName { get; set; }
        public ParameterDictionary ParameterDictionary { get; set; }
        public bool ProcessedQty { get; set; }
        public int TagType { get; set; }
        public string LotName { get; set; }

        #region Access members
        public string GetFamilyName
        {
            get
            {
                string value = GetTextValue(DatabaseCostants.Forge_ParameterName_FamilyName);
                if (!String.IsNullOrEmpty(value))
                {
                    string[] values = value.Split(' ');
                    if (values != null && values.Length > 0)
                        return values[0];
                    else
                        return string.Empty;
                }
                return value;
            }
        }
        public string GetLotName
        {
            get
            {
                string value = GetForgeTextValue(DatabaseCostants.Forge_ParameterName_Lot);
                return value;
            }
        }
        public string GetItemTag
        {
            get
            {
                // In case of steel the Item Tag is equal to the model name
                if (TagType != DatabaseCostants.TagType_Steel_ID)
                {
                    string value = GetTextValue(DatabaseCostants.Forge_ParameterName_ItemTag);
                    return value;
                }
                else
                {
                    return ModelName;
                }
            }
        }

        public bool IsHold
        {
            get
            {
                string value = GetForgeTextValue(DatabaseCostants.Forge_ParameterName_Hold);
                if (!string.IsNullOrEmpty(value))
                    value = value.ToLowerInvariant();
                return value == "yes" || value == "true" || value == "1";
            }
        }
        public bool IsHoldSteel
        {
            get
            {
                string value = GetForgeTextValue(DatabaseCostants.Forge_ParameterName_Hold_Steel);
                if (!string.IsNullOrEmpty(value))
                    value = value.ToLowerInvariant();
                return value == "yes" || value == "true" || value == "1";
            }
        }
        public string GetForgeName
        {
            get
            {
                string value = GetTextValue(DatabaseCostants.Forge_ParameterName_ForgeItemName);
                return value;
            }
        }
        public string GetMainItemTag
        {
            get
            {
                string value = GetTextValue(DatabaseCostants.Forge_ParameterName_MainItemTag);
                return value;
            }
        }
        public string GetEngineeringStatusStr
        {
            get
            {
                string value = GetTextValue(DatabaseCostants.Forge_ParameterName_EngineeringStatus);
                return value;
            }
        }
        public ENGINEERING_STATUS GetEngineeringStatus(List<ENGINEERING_STATUS> statusList)
        {
            string value = GetEngineeringStatusStr;
            if (!String.IsNullOrEmpty(value))
            {
                foreach (ENGINEERING_STATUS status in statusList)
                    if (status.MainCode != null && status.MainCode.ToUpper() == value.ToUpper())
                        return status;
            }
            // Return Budget Phase when not defined
            var statusCurrent = statusList.Where(s => s.StatusID == 1).FirstOrDefault();
            return statusCurrent;
        }
        public double GetQty
        {
            get
            {
                double qty = 0.0;
                if (ProcessedQty)
                {
                    Parameter parameter = ParameterDictionary.GetParameterByForgeName(DatabaseCostants.Forge_ParameterName_QTY);
                    if (parameter != null)
                        qty = parameter.ValueDouble;
                }
                return qty;
            }
        }
        #endregion

        public static SecondaryItem Parse(ForgeItem forgeItem, ParameterDictionary parameterDictionary, 
            FamilyFormulaDictionary familyFormulaDictionary)
        {
            SecondaryItem item = new SecondaryItem();
            if (forgeItem == null || !forgeItem.Objectid.HasValue)
                return null;

            item.Objectid = forgeItem.Objectid.Value;
            item.ModelName = forgeItem.ModelName;
            item.ParameterDictionary = new ParameterDictionary(parameterDictionary, true);
            bool valid = item.InitParameterList(forgeItem.Properties);
            if (!valid)
                item = null;
            item.UpdateTagType();
            item.UpdateQuantity(familyFormulaDictionary);
            return item;
        }

        #region Parameters methods
        private bool InitParameterList(List<Property> properties)
        {
            if (properties == null)
                return false;
            List<string> compiledParameters = new List<string>();
            if (ParameterDictionary.Parameters != null)
            {
                foreach (Parameter parameter in ParameterDictionary.Parameters)
                {
                    parameter.InitValueFromForge(properties);
                }

            }
            return true;
        }
        public string GetTextValue(string parameterName)
        {
            if (ParameterDictionary.Parameters != null)
            {
                foreach (Parameter parameter in ParameterDictionary.Parameters)
                    if (parameter.OracleDatabaseName == parameterName)
                        return parameter.AsValueString();
            }
            return String.Empty;
        }
        public string GetForgeTextValue(string parameterName)
        {
            if (ParameterDictionary.Parameters != null)
            {
                foreach (Parameter parameter in ParameterDictionary.Parameters)
                    if (parameter.ForgeName == parameterName)
                        return parameter.AsValueString();
            }
            return String.Empty;
        }
        #endregion

        #region Values
        private void UpdateTagType()
        {
            this.TagType = -1;
            this.LotName = string.Empty;

            Parameter lv02ObjectCodeParam = ParameterDictionary.GetParameterByForgeName(DatabaseCostants.Forge_ParameterName_Lv02ObjectCode);
            Parameter materialParam = ParameterDictionary.GetParameterByForgeName(DatabaseCostants.Forge_ParameterName_Material);
            Parameter tagTypeParam = ParameterDictionary.GetParameterByForgeName(DatabaseCostants.Forge_ParameterName_TagType);
            Parameter lotParam = ParameterDictionary.GetParameterByForgeName(DatabaseCostants.Forge_ParameterName_Lot);

            if (lotParam != null)
            {
                this.LotName = lotParam.ValueString;
            }
            if (string.IsNullOrEmpty(this.LotName))
                this.LotName = DatabaseCostants.DefaultLot;

            if (!string.IsNullOrEmpty(ModelName) && ModelName.Contains("AI"))
            {
                this.TagType = DatabaseCostants.TagType_Steel_ID;
                return;
            }
            if (lv02ObjectCodeParam != null && lv02ObjectCodeParam.ValueString == "PL")
            {
                this.TagType = DatabaseCostants.TagType_Pile_ID;
                return;
            }
            if (materialParam != null && !string.IsNullOrEmpty(materialParam.ValueString))
            {
                if (materialParam.ValueString == DatabaseCostants.TagType_Foundation_Name)
                {
                    this.TagType = DatabaseCostants.TagType_Foundation_ID;
                    return;
                }
                else if (materialParam.ValueString == DatabaseCostants.TagType_Elevation_Name)
                {
                    this.TagType = DatabaseCostants.TagType_Elevation_ID;
                    return;
                }
                else if (materialParam.ValueString == DatabaseCostants.TagType_Ground_Slab_Concrete_Name)
                {
                    this.TagType = DatabaseCostants.TagType_Ground_Slab_Concrete_ID;
                    return;
                }
            }
            if (tagTypeParam != null && !string.IsNullOrEmpty(tagTypeParam.ValueString))
            {
                if (tagTypeParam.ValueString == DatabaseCostants.TagType_UndergroundPit_Name)
                {
                    this.TagType = DatabaseCostants.TagType_UndergroundPit_ID;
                    return;
                }
                else if (tagTypeParam.ValueString == DatabaseCostants.TagType_UndergroundPipe_Name)
                {
                    this.TagType = DatabaseCostants.TagType_UndergroundPipe_ID;
                    return;
                }
                else if (tagTypeParam.ValueString == DatabaseCostants.TagType_Paving_Name)
                {
                    this.TagType = DatabaseCostants.TagType_Paving_ID;
                    return;
                }
            }
        }
        private void UpdateQuantity(FamilyFormulaDictionary familyFormulaDictionary)
        {
            string familyName = GetFamilyName;
            if (this.TagType <= 0)
                return;

            ProcessedQty = false;
            if (!string.IsNullOrEmpty(familyName) && familyFormulaDictionary.FamilyFormulas != null)
            {
                if (String.IsNullOrEmpty(familyName))
                    return;
                List<FamilyFormula> formulalist = familyFormulaDictionary.FamilyFormulas.Where(f => familyName.Contains(f.FamilyName)
                    && f.TagType == this.TagType).ToList();
                if (formulalist == null || formulalist.Count == 0)
                {
                    // Try using ALL filter
                    formulalist = familyFormulaDictionary.FamilyFormulas.Where(f => f.FamilyName == AppCostants.ALL_FAMILY_FILTER
                        && f.TagType == this.TagType).ToList();
                }
                if (formulalist != null)
                {
                    foreach (FamilyFormula formula in formulalist)
                    {
                        double qty = this.EvaluateQty(formula);
                        Parameter parameter = ParameterDictionary.GetParameterByForgeName(DatabaseCostants.Forge_ParameterName_QTY);
                        if (parameter != null)
                        {
                            parameter.Set(qty);
                            ProcessedQty = true;
                        }
                        //this.TagType = formula.TagType;
                        break;
                    }
                }
            }
            
        }
        private double EvaluateQty(FamilyFormula familyFormula)
        {
            double qty = 0.0;
            string model = this.ModelName;

            List<Argument> arguments = new List<Argument>();
            Argument argument = null;
            if (arguments != null && ParameterDictionary.Parameters != null)
            {
                foreach (Parameter parameter in ParameterDictionary.Parameters)
                {
                    switch(parameter.StorageType)
                    {
                        case StorageType.DOUBLE:
                        case StorageType.INTEGER:
                            argument = parameter.GetArgument;
                            if (argument != null && familyFormula.Formula.Contains(parameter.OracleDatabaseName))
                                arguments.Add(argument);
                            break;
                    }
                }
            }
            Expression e = new Expression(familyFormula.Formula, arguments.ToArray());
            qty = e.calculate();
            if (double.IsNaN(qty))
                qty = 0.0;
            return qty;
        }
        public MAINITEMS FoundMainTag(List<MAINITEMS> mAINITEMs)
        {
            string mainTag = this.GetMainItemTag;
            if (mAINITEMs != null && !String.IsNullOrEmpty(mainTag))
            {
                foreach (MAINITEMS item in mAINITEMs)
                    if (item.MainItemTag.ToUpper() == mainTag.ToUpper())
                        return item;
            }
            return null;
        }
        public ComputedQtyType GetComputedQty()
        {
            ComputedQtyType computedQtyType = new ComputedQtyType();
            computedQtyType.MainItemTag = this.GetMainItemTag;
            computedQtyType.EngStatus = this.GetEngineeringStatusStr;
            computedQtyType.TagType = this.TagType;
            return computedQtyType;
        }
        #endregion
    }
}
