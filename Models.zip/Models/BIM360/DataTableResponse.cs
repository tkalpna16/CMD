﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360
{
    public class DataTableResponse
    {
        public long recordsTotal { get; set; }
        public object[] data { get; set; }
        public string error { get; set; }
    }
}
