﻿namespace CivilMasterData.Models.BIM360
{
    public class FileVersion
    {
        public string version { get; set; }
        public string date { get; set; }
        public string username { get; set; }
        public string urn { get; set; }

        public FileVersion() { }
    }
}
