﻿namespace CivilMasterData.Models.BIM360.Formulas
{
    public class FamilyFormula
    {
        #region Private members
        public string FamilyName { get; set; }
        public string Formula { get; set; }
        public int TagType { get; set; }
        #endregion

        #region Constructor
        public FamilyFormula(string family, string formula, int tagType)
        {
            this.FamilyName = family;
            this.Formula = formula;
            this.TagType = tagType;
        }
        #endregion
    }
}
