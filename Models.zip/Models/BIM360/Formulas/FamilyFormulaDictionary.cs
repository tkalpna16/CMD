﻿using System.Collections.Generic;

namespace CivilMasterData.Models.BIM360.Formulas
{
    public class FamilyFormulaDictionary
    {
        public List<FamilyFormula> FamilyFormulas { get; set; }

        public FamilyFormulaDictionary() { }
    }
}
