﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using org.mariuszgromada.math.mxparser;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using UnitsNet;

namespace CivilMasterData.Models.BIM360.Parameters
{
    public class Parameter
    {
        #region Private members
        public string CategoryName { get; set; }
        public string ForgeName { get; set; }
        public string OracleDatabaseName { get; set; }
        public string OracleProcedureName { get; set; }
        public string ValueString { get; set; }
        public double ValueDouble { get; set; }
        public int ValueInt { get; set; }
        public bool UseInFormula { get; set; }
        public StorageType StorageType { get; set; }
        public UnitType UnitType { get; set; }
        public bool ReadFromForge { get; set; }
        #endregion

        #region Access members
        [JsonIgnore]
        public Argument GetArgument
        {
            get
            {
                if (UseInFormula && StorageType == StorageType.DOUBLE)
                {
                    string value = ForgeName.Replace(" ", "") + " = " + ValueDouble.ToString();
                    Argument argument = new Argument(value);
                    return argument;
                }
                else if (UseInFormula && StorageType == StorageType.INTEGER)
                {
                    string value = ForgeName.Replace(" ", "") + " = " + ValueInt.ToString();
                    Argument argument = new Argument(value);
                    return argument;
                }
                return null;
            }
        }
        #endregion

        #region Constructor
        protected Parameter() { }
        public Parameter(string forgeName, string oracleProcedureName, 
            StorageType storageType, UnitType unitType, bool useInFormula, bool readFromForge = true,
            string oracleDatabaseName = "")
        {
            this.ForgeName = forgeName;
            if (String.IsNullOrEmpty(oracleDatabaseName))
                this.OracleDatabaseName = this.ForgeName;
            else
                this.OracleDatabaseName = oracleDatabaseName;
            this.OracleProcedureName = oracleProcedureName;
            this.StorageType = storageType;
            this.UnitType = unitType;
            this.UseInFormula = useInFormula;
            this.ReadFromForge = readFromForge;
            this.ValueString = string.Empty;
            this.ValueDouble = 0.0;
            this.ValueInt = 0;
        }
        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="parameter"></param>
        public Parameter(Parameter parameter, bool resetValues)
        {
            this.CategoryName = parameter.CategoryName;
            this.OracleProcedureName = parameter.OracleProcedureName;
            this.OracleDatabaseName = parameter.OracleDatabaseName;
            this.ForgeName = parameter.ForgeName;
            if (resetValues)
            {
                this.ValueString = string.Empty;
                this.ValueDouble = 0.0;
                this.ValueInt = 0;
            }
            else
            {
                this.ValueString = parameter.ValueString;
                this.ValueDouble = parameter.ValueDouble;
                this.ValueInt = parameter.ValueInt;
            }
            this.UseInFormula = parameter.UseInFormula;
            this.StorageType = parameter.StorageType;
            this.UnitType = parameter.UnitType;
            this.ReadFromForge = parameter.ReadFromForge;
        }
        #endregion

        #region Values
        public bool InitValueFromForge(List<Property> properties)
        {
            bool found = false;
            if (properties != null)
            {
                foreach (Property property in properties)
                {
                    if (string.IsNullOrEmpty(CategoryName))
                    {
                        if (property.Name == ForgeName)
                        {
                            // Set value
                            switch (StorageType)
                            {
                                case StorageType.STRING:
                                    this.ValueString = property.Value;
                                    found = true;
                                    break;
                                case StorageType.INTEGER:
                                    ParseIntValue(property.Value);
                                    found = true;
                                    break;
                                case StorageType.DOUBLE:
                                    ParseDoubleValue(property.Value);
                                    found = true;
                                    break;
                            }
                        }
                    }
                    else
                    {
                        if (property.Name == ForgeName && property.CategoryName == CategoryName)
                        {
                            // Set value
                            switch (StorageType)
                            {
                                case StorageType.STRING:
                                    this.ValueString = property.Value;
                                    found = true;
                                    break;
                                case StorageType.INTEGER:
                                    ParseIntValue(property.Value);
                                    found = true;
                                    break;
                                case StorageType.DOUBLE:
                                    ParseDoubleValue(property.Value);
                                    found = true;
                                    break;
                            }
                        }
                    }
                    if (found)
                        break;
                }
            }
            return found;
        }
        private void ParseIntValue(string valueStr)
        {
            int value = 0;
            int.TryParse(valueStr, out value);
            this.ValueInt = value;
        }
        
        private void ParseDoubleValue(string valueStr)
        {
            double value = 0.0;
            if (!String.IsNullOrEmpty(valueStr))
            {
                try
                {
                    string valueToParse = valueStr.Replace(" ", String.Empty);
                    switch (UnitType)
                    {
                        case UnitType.NUMBER:
                            double.TryParse(valueToParse, out value);
                            break;
                        case UnitType.LENGTH:
                            Length length = Length.Parse(valueToParse);
                            if (length != null)
                                value = length.Meters;
                            break;
                        case UnitType.AREA:
                            Area area = Area.Parse(valueToParse);
                            if (area != null)
                                value = area.SquareMeters;
                            break;
                        case UnitType.VOLUME:
                            Volume volume = Volume.Parse(valueToParse);
                            if (volume != null)
                                value = volume.CubicMeters;
                            break;
                        case UnitType.WEIGHT:
                            Mass mass = Mass.Parse(valueToParse);
                            if (mass != null)
                                value = mass.Kilograms;
                            break;
                        case UnitType.SLOPE_PERCENT:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    string a = ex.Message;
                }
            }
            this.ValueDouble = value;
        }
        public string AsValueString()
        {
            if (StorageType == StorageType.STRING)
                return ValueString;
            else if(StorageType == StorageType.INTEGER)
                return ValueInt.ToString();
            else if (StorageType == StorageType.DOUBLE)
                return ValueDouble.ToString();
            return string.Empty;
        }
        public string AsValueString2()
        {
            if (StorageType == StorageType.STRING)
                return ValueString;            //return "'"+ ValueString + "'";
            else if (StorageType == StorageType.INTEGER)
                return ValueInt.ToString();
            else if (StorageType == StorageType.DOUBLE)
                return ValueDouble.ToString();
            return null;
        }
        public string AsString()
        {
            if (StorageType == StorageType.STRING)
                return ValueString;
            else
                return string.Empty;
        }
        public int AsInteger()
        {
            if (StorageType == StorageType.INTEGER)
                return ValueInt;
            else
                return -1;
        }
        public double AsDouble()
        {
            if (StorageType == StorageType.DOUBLE)
                return ValueDouble;
            else
                return 0.0;
        }
        public bool Set(string val)
        {
            if (StorageType == StorageType.STRING)
            {
                this.ValueString = val;
                return true;
            }
            else
                return false;
        }
        public bool Set(int val)
        {
            if (StorageType == StorageType.INTEGER)
            {
                this.ValueInt = val;
                return true;
            }
            else
                return false;
        }
        public bool Set(double val)
        {
            if (StorageType == StorageType.DOUBLE)
            {
                this.ValueDouble = val;
                return true;
            }
            else
                return false;
        }
        #endregion

        #region Oracle methods
        public void AddToCommand(OracleCommand oracleCommand, ref string a)
        {
            OracleDbType oracleDbType = GetOracleStorageType();
            string value = AsValueString2();
            oracleCommand.Parameters.Add(OracleProcedureName, oracleDbType).Value = value;
            a += value + ",";
        }
        private OracleDbType GetOracleStorageType()
        {
            OracleDbType oracleStorageType = OracleDbType.Varchar2;
            switch (StorageType)
            {
                case StorageType.DOUBLE:
                    oracleStorageType = OracleDbType.Double;
                    break;
                case StorageType.INTEGER:
                    oracleStorageType = OracleDbType.Int32;
                    break;
                default:
                    break;
            }
            return oracleStorageType;
        }
        #endregion
    }
}
