﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Parameters
{
    public enum StorageType
    {
        NONE = 0,
        STRING = 1,
        INTEGER = 2,
        DOUBLE = 3
    }
}
