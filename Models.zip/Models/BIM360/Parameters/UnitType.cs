﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.BIM360.Parameters
{
    public enum UnitType
    {
        NONE = 0,
        NUMBER = 1,
        LENGTH = 2,
        AREA = 3,
        VOLUME = 4,
        WEIGHT = 5,
        SLOPE_PERCENT = 6
    }
}
