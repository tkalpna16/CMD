﻿using System.Collections.Generic;

namespace CivilMasterData.Models.BIM360.Parameters
{
    public class ParsingUtils
    {
        public const char SEPARATOR = ';';

        public static List<string> ParseString(string searchString)
        {
            List<string> valueList = new List<string>();
            if (!string.IsNullOrWhiteSpace(searchString))
            {
                string[] values = searchString.Split(new char[] { SEPARATOR });
                if (values != null)
                {
                    foreach (string s in values)
                    {
                        if (!string.IsNullOrEmpty(s))
                            valueList.Add(s);
                    }
                }
            }
            return valueList;
        }
    }
}
