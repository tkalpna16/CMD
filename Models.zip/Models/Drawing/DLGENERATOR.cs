﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Drawing
{
    public class DLGENERATOR
    {
        public PROJECTS Project { get; set; }
        public List<PBS> Pbs { get; set; }
        public List<MAINITEMS> MainItems { get; set; }
        public List<MAINITEMDRAWINGS> MainItemDrawings { get; set; }
        public List<DRAWINGS> Drawings { get; set; }
        public List<PBSDRAWINGS> PBSDrawings { get; set; }

        public List<DOCUMENTSETTINGS> DocumentSettings { get; set; }
        public List<DRAWINGSCALES> DrawingScales { get; set; }
        public List<DRAWINGSIZES> DrawingSizes { get; set; }

        public List<MAINITEMDRAWINGS> Piles { get; set; }
        public List<MAINITEMDRAWINGS> FoundationElevations { get; set; }
        public List<MAINITEMDRAWINGS> PilesAndFoundationBalance { get; set; }

        public List<MAINITEMDRAWINGS> PilesFoundationElevationConcrete { get; set; }
        public List<MAINITEMDRAWINGS> Steel { get; set; }
    }
}
