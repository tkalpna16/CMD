﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class DOCUMENTSETTINGS
    {
        [Key]
        [Column("SettingID")]
        [Display(Name = "SettingID")]
        public int SettingID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("TypeID")]
        [Display(Name = "TypeID")]
        public int? TypeID { get; set; }

        public DOCUMENTTYPES DOCUMENTTYPE { get; set; }

        [Column("NUMBEROFDOCUMENTS")]
        [Display(Name = "NUMBEROFDOCUMENTS")]
        public int? NUMBEROFDOCUMENTS { get; set; }

        [Column("ScaleID")]
        [Display(Name = "ScaleID")]
        public int? ScaleID { get; set; }

        public DRAWINGSCALES Scale { get; set; }

        [Column("DwgSizeID")]
        [Display(Name = "DwgSizeID")]
        public int? DwgSizeID { get; set; }

        public DRAWINGSIZES DwgSize { get; set; }

        public DOCUMENTSETTINGS() { }

        public DOCUMENTSETTINGS(int projectId, int userId, int documentType, int scaleId, int dwgSizeId)
        {
            this.ProjectID = projectId;
            this.UserID = userId;
            this.TypeID = documentType;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
            this.NUMBEROFDOCUMENTS = 0;
            this.ScaleID = scaleId;
            this.DwgSizeID = dwgSizeId;
        }
    }
}
