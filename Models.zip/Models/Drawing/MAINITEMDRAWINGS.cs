﻿using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing
{
    public class MAINITEMDRAWINGS
    {
        [Key]
        [Column("ItemDrawingID")]
        [Display(Name = "ItemDrawingID")]
        public int ItemDrawingID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("MainItemID")]
        [Display(Name = "MainItemID")]
        public int? MainItemID { get; set; }

        public MAINITEMS MAINITEM { get; set; }

        [Column("AADANumDocs")]
        [Display(Name = "AADANumDocs")]
        public int? AADANumDocs { get; set; }

        [NotMapped]
        public int? AADAAutomaticNumDocs { get; set; }

        [Column("AADAFactor")]
        [Display(Name = "AADAFactor")]
        public double? AADAFactor { get; set; }

        #region AADC
        [Column("AADCNumDocs")]
        [Display(Name = "AADANumDocs")]
        public int? AADCNumDocs { get; set; }

        [NotMapped]
        public int? AADCAutomaticNumDocs { get; set; }
        #endregion


        [Column("AADCNumDocsFoundationPlan")]
        [Display(Name = "AADCNumDocsFoundationPlan")]
        public int? AADCNumDocsFoundationPlan { get; set; }

        [Column("AADCNumDocsFoundationBBS")]
        [Display(Name = "AADCNumDocsFoundationBBS")]
        public int? AADCNumDocsFoundationBBS { get; set; }

        [Column("AADCNumDocsElevationBBS")]
        [Display(Name = "AADCNumDocsElevationBBS")]
        public int? AADCNumDocsElevationBBS { get; set; }

        [Column("AADCFoundationPlanNumDocs")]
        [Display(Name = "AADCFoundationPlanNumDocs")]
        public int? AADCFoundationPlanNumDocs { get; set; }

        [Column("AADCFoundationPlanArea")]
        [Display(Name = "AADCFoundationPlanArea")]
        public double? AADCFoundationPlanArea { get; set; }

        [Column("AADCPipeFoundationFactor")]
        [Display(Name = "AADCPipeFoundationFactor")]
        public double? AADCPipeFoundationFactor { get; set; }

        [Column("AADCPipeElevationFactor")]
        [Display(Name = "AADCPipeElevationFactor")]
        public double? AADCPipeElevationFactor { get; set; }

        [Column("AADCPipeFloor")]
        [Display(Name = "AADCPipeFloor")]
        public int? AADCPipeFloor { get; set; }

        [Column("AADCEquipmentFoundationFactor")]
        [Display(Name = "AADCEquipmentFoundationFactor")]
        public double? AADCEquipmentFoundationFactor { get; set; }

        [Column("AADCEquipmentElevationFactor")]
        [Display(Name = "AADCEquipmentElevationFactor")]
        public double? AADCEquipmentElevationFactor { get; set; }

        [Column("AADCEquipmentFloor")]
        [Display(Name = "AADCEquipmentFloor")]
        public int? AADCEquipmentFloor { get; set; }

        [Column("AADCBuildingFoundationFactor")]
        [Display(Name = "AADCBuildingFoundationFactor")]
        public double? AADCBuildingFoundationFactor { get; set; }

        [Column("AADCBuildingElevationFactor")]
        [Display(Name = "AADCBuildingElevationFactor")]
        public double? AADCBuildingElevationFactor { get; set; }

        [Column("AADCBuildingFloor")]
        [Display(Name = "AADCBuildingFloor")]
        public double? AADCBuildingFloor { get; set; }

        [Column("AADCBasinFoundationFactor")]
        [Display(Name = "AADCBasinFoundationFactor")]
        public double? AADCBasinFoundationFactor { get; set; }

        [Column("AADCNumDocsOthersFoundation")]
        [Display(Name = "AADCNumDocsOthersFoundation")]
        public int? AADCNumDocsOthersFoundation { get; set; }

        [Column("AADCNumDocsOthersElevation")]
        [Display(Name = "AADCNumDocsOthersElevation")]
        public int? AADCNumDocsOthersElevation { get; set; }

        [Column("AACSNumDocs")]
        [Display(Name = "AACSNumDocs")]
        public int? AACSNumDocs { get; set; }

        [Column("AIDUNumDocs")]
        [Display(Name = "AIDUNumDocs")]
        public int? AIDUNumDocs { get; set; }

        [Column("AICSNumDocs")]
        [Display(Name = "AICSNumDocs")]
        public int? AICSNumDocs { get; set; }

        [Column("AIDUPipeFactorDocs")]
        [Display(Name = "AIDUPipeFactorDocs")]
        public double? AIDUPipeFactorDocs { get; set; }

        [Column("AIDUPipeFloors")]
        [Display(Name = "AIDUPipeFloors")]
        public double? AIDUPipeFloors { get; set; }

        [Column("AIDUPipeModules")]
        [Display(Name = "AIDUPipeModules")]
        public double? AIDUPipeModules { get; set; }

        [Column("AIDUProcessArea")]
        [Display(Name = "AIDUProcessArea")]
        public double? AIDUProcessArea { get; set; }

        [Column("AIDUProcessFloor")]
        [Display(Name = "AIDUProcessFloor")]
        public double? AIDUProcessFloor { get; set; }

        [Column("AIDUShelterFactor")]
        [Display(Name = "AIDUShelterFactor")]
        public double? AIDUShelterFactor { get; set; }

        [Column("AIDUShelterFloor")]
        [Display(Name = "AIDUShelterFloor")]
        public double? AIDUShelterFloor { get; set; }

        [Column("AIDUPipeSupportNumDocs")]
        [Display(Name = "AIDUPipeSupportNumDocs")]
        public int? AIDUPipeSupportNumDocs { get; set; }

        [Column("AIDUOthersNumDocs")]
        [Display(Name = "AIDUOthersNumDocs")]
        public int? AIDUOthersNumDocs { get; set; }

        [Column("AIDANumDocs")]
        [Display(Name = "AIDANumDocs")]
        public int? AIDANumDocs { get; set; }

        [Column("AQDANumDocs")]
        [Display(Name = "AQDANumDocs")]
        public int? AQDANumDocs { get; set; }

        [Column("AQDAArea")]
        [Display(Name = "AQDAArea")]
        public double? AQDAArea { get; set; }


        [NotMapped]
        public AACSSETTINGS AACSSETTINGS { get; set; }
        [NotMapped]
        public AADASETTINGS AADASETTINGS { get; set; }
        [NotMapped]
        public AICSSETTINGS AICSSETTINGS { get; set; }

        [NotMapped]
        public int CalculateAutomaticAACSDrawings
        {
            get
            {
                if (AACSSETTINGS != null && AACSSETTINGS.MinimumDrawing != null && AACSSETTINGS.MinimumDrawing.HasValue)
                    return AACSSETTINGS.MinimumDrawing.Value;
                return 0;
            }
        }

        [NotMapped]
        public PROJECTSETTINGS PROJECTSETTINGS { get; set; }

        [NotMapped]
        public int CalculateAutomaticAADADrawings
        {
            get
            {
                double area = MAINITEM.PBS.AreaValue;
                int drawingNum = 0;
                if (AADASETTINGS != null && AADASETTINGS.ReferenceArea > 0)
                {
                    if (area == 0.0)
                    {
                        drawingNum = 0;
                    }
                    else if (area > 0.0 && area <= 1.0)
                    {
                        drawingNum = 1;
                    }
                    else
                    {
                        drawingNum = (int)Math.Ceiling(area / AADASETTINGS.ReferenceArea.Value);
                        drawingNum = Math.Max(drawingNum, AADASETTINGS.MinimumDrawing.Value);
                    }
                    if (PROJECTSETTINGS != null)
                    {
                        int maxDrawing = PROJECTSETTINGS.DRAWING_MAX_NDOCS;
                        if (drawingNum > maxDrawing)
                            drawingNum = maxDrawing;
                    }
                }
                return drawingNum;
            }
        }

        [NotMapped]
        public int CalculateAutomaticAICSDrawings
        {
            get
            {
                if (AICSSETTINGS != null && AICSSETTINGS.MinimumDrawing != null && AICSSETTINGS.MinimumDrawing.HasValue)
                    return AICSSETTINGS.MinimumDrawing.Value;
                return 0;
            }
        }

        public int CalculateDrawing(string tcmCode)
        {
            int num = 0;
            if (tcmCode == "AA-CS")
            {
                num = CalculateAutomaticAACSDrawings;
                if (MustBeProcessed(AACSNumDocs))
                    num = AACSNumDocs.Value;
            }
            else if (tcmCode == "AA-DA")
            {
                num = CalculateAutomaticAADADrawings;
                if (MustBeProcessed(AADANumDocs))
                    num = AADANumDocs.Value;
            }
            else if (tcmCode == "AA-DC")
            {
                num = MAINITEM.TotalDocuments;
                if (MustBeProcessed(AADCNumDocs))
                    num = AADCNumDocs.Value;
            }
            else if (tcmCode == "AI-CS")
            {
                num = CalculateAutomaticAICSDrawings;
                if (MustBeProcessed(AICSNumDocs))
                    num = AICSNumDocs.Value;
            }
            else if (tcmCode == "AI-DU")
            {
                num = MAINITEM.TotalDocuments;
                if (MustBeProcessed(AIDUNumDocs))
                    num = AIDUNumDocs.Value;
            }
            if (PROJECTSETTINGS != null)
            {
                int maxDrawing = PROJECTSETTINGS.DRAWING_MAX_NDOCS;
                if (num > maxDrawing)
                    num = maxDrawing;
            }
            return num;
        }

        private bool MustBeProcessed(int? value)
        {
            return value != null && value.HasValue;
        }

        [NotMapped]
        public int AACSNumDocsRevision { get; set; }

        [NotMapped]
        public int AADANumDocsRevision { get; set; }

        [NotMapped]
        public int AADCNumDocsRevision { get; set; }

        [NotMapped]
        public int AICSNumDocsRevision { get; set; }

        [NotMapped]
        public int AIDUNumDocsRevision { get; set; }
    }
}
