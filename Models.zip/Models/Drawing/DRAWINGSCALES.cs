﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;

namespace CivilMasterData.Models
{
    /// <summary>
    /// DRAWINGSCALES
    /// </summary>
    public class DRAWINGSCALES
    {
        [Key]
        [Column("ScaleID")]
        [Display(Name = "ScaleID")]
        public int ScaleID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("VALUE")]
        [Display(Name = "VALUE")]
        public double? VALUE { get; set; }
    }
}
