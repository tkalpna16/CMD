﻿using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing
{
    public class PBSDRAWINGS
    {
        [Key]
        [Column("PbsDrawingID")]
        [Display(Name = "PbsDrawingID")]
        public int PbsDrawingID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("PBSID")]
        [Display(Name = "PBSID")]
        public int? PBSID { get; set; }

        public PBS PBS { get; set; }

        [Column("AQDANumDocs")]
        [Display(Name = "AQDANumDocs")]
        public int? AQDANumDocs { get; set; }

        [Column("AQDAArea")]
        [Display(Name = "AQDAArea")]
        public double? AQDAArea { get; set; }

        [Column("APDANumDocs")]
        [Display(Name = "APDANumDocs")]
        public int? APDANumDocs { get; set; }

        [Column("APDAArea")]
        [Display(Name = "APDAArea")]
        public double? APDAArea { get; set; }

        [Column("ARDANumDocs")]
        [Display(Name = "ARDANumDocs")]
        public int? ARDANumDocs { get; set; }

        [Column("ARDAArea")]
        [Display(Name = "ARDAArea")]
        public double? ARDAArea { get; set; }

        [NotMapped]
        public APDASETTINGS APDASETTINGS { get; set; }
        [NotMapped]
        public AQDASETTINGS AQDASETTINGS { get; set; }
        [NotMapped]
        public ARDASETTINGS ARDASETTINGS { get; set; }

        [NotMapped]
        public PROJECTSETTINGS PROJECTSETTINGS { get; set; }

        [NotMapped]
        public int CalculateAutomaticAPDADrawings
        {
            get
            {
                double area = PBS.AreaValue;
                int drawingNum = 0;
                if (APDASETTINGS != null && APDASETTINGS.ReferenceArea > 0)
                {
                    if (area == 0.0)
                    {
                        drawingNum = 0;
                    }
                    else if (area > 0.0 && area <= 1.0)
                    {
                        drawingNum = 1;
                    }
                    else
                    {
                        drawingNum = (int)Math.Ceiling(area / APDASETTINGS.ReferenceArea.Value);
                        drawingNum = Math.Max(drawingNum, APDASETTINGS.MinimumDrawing.Value);
                    }
                }
                if (PROJECTSETTINGS != null)
                {
                    int maxDrawing = PROJECTSETTINGS.DRAWING_MAX_NDOCS;
                    if (drawingNum > maxDrawing)
                        drawingNum = maxDrawing;
                }
                return drawingNum;
            }
        }

        [NotMapped]
        public int CalculateAutomaticAQDADrawings
        {
            get
            {
                double area = PBS.AreaValue;
                int drawingNum = 0;
                if (AQDASETTINGS != null && AQDASETTINGS.ReferenceArea > 0)
                {
                    if (area == 0.0)
                    {
                        drawingNum = 0;
                    }
                    else if (area > 0.0 && area <= 1.0)
                    {
                        drawingNum = 1;
                    }
                    else
                    {
                        drawingNum = (int)Math.Ceiling(area / AQDASETTINGS.ReferenceArea.Value);
                        drawingNum = Math.Max(drawingNum, AQDASETTINGS.MinimumDrawing.Value);
                    }

                }
                if (PROJECTSETTINGS != null)
                {
                    int maxDrawing = PROJECTSETTINGS.DRAWING_MAX_NDOCS;
                    if (drawingNum > maxDrawing)
                        drawingNum = maxDrawing;
                }
                return drawingNum;
            }
        }

        [NotMapped]
        public int CalculateAutomaticARDADrawings
        {
            get
            {
                double area = PBS.AreaValue;
                int drawingNum = 0;
                if (ARDASETTINGS != null && ARDASETTINGS.ReferenceArea > 0)
                {
                    if (area == 0.0)
                    {
                        drawingNum = 0;
                    }
                    else if (area > 0.0 && area <= 1.0)
                    {
                        drawingNum = 1;
                    }
                    else
                    {
                        drawingNum = (int)Math.Ceiling(area / ARDASETTINGS.ReferenceArea.Value);
                        drawingNum = Math.Max(drawingNum, ARDASETTINGS.MinimumDrawing.Value);
                    }
                }
                if (PROJECTSETTINGS != null)
                {
                    int maxDrawing = PROJECTSETTINGS.DRAWING_MAX_NDOCS;
                    if (drawingNum > maxDrawing)
                        drawingNum = maxDrawing;
                }
                return drawingNum;
            }
        }

        public int CalculateDrawing(string tcmCode)
        {
            int num = 0;
            if (tcmCode == "AP-DA")
            {
                num = CalculateAutomaticAPDADrawings;
                if (MustBeProcessed(APDANumDocs))
                    num = APDANumDocs.Value;
            }
            else if (tcmCode == "AR-DA")
            {
                num = CalculateAutomaticARDADrawings;
                if (MustBeProcessed(ARDANumDocs))
                    num = ARDANumDocs.Value;
            }
            else if (tcmCode == "AQ-DA")
            {
                num = CalculateAutomaticAQDADrawings;
                if (MustBeProcessed(AQDANumDocs))
                    num = AQDANumDocs.Value;
            }
            if (PROJECTSETTINGS != null)
            {
                int maxDrawing = PROJECTSETTINGS.DRAWING_MAX_NDOCS;
                if (num > maxDrawing)
                    num = maxDrawing;
            }
            return num;
        }

        private bool MustBeProcessed(int? value)
        {
            return value != null && value.HasValue;
        }

        [NotMapped]
        public int APDANumDocsRevision { get; set; }

        [NotMapped]
        public int AQDANumDocsRevision { get; set; }

        [NotMapped]
        public int ARDANumDocsRevision { get; set; }
    }
}
