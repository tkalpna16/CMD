﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// DRAWINGSCALES
    /// </summary>
    public class DOCUMENTTYPES
    {
        [Key]
        [Column("TypeID")]
        [Display(Name = "TypeID")]
        public int TypeID { get; set; }

        [Column("TCMCode")]
        [Display(Name = "TCMCode")]
        public string TCMCode { get; set; }

        [Column("DocumentType")]
        [Display(Name = "DocumentType")]
        public string DocumentType { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("AdditionalDescription")]
        [Display(Name = "AdditionalDescription")]
        public string AdditionalDescription { get; set; }

        [Column("DefaultScaleID")]
        [Display(Name = "DefaultScaleID")]
        public int? DefaultScaleID { get; set; }

        public DRAWINGSCALES DefaultScale { get; set; }

        [Column("DefaultDwgSizeID")]
        [Display(Name = "DefaultDwgSizeID")]
        public int? DefaultDwgSizeID { get; set; }

        public DRAWINGSIZES DefaultDwg { get; set; }

        [Column("Visible")]
        [Display(Name = "Visible")]
        public int? Visible { get; set; }

        [Column("TagTypeID")]
        [Display(Name = "TagTypeID")]
        public int? TagTypeID { get; set; }

        public TAGTYPES TAGTYPES { get; set; }

        [NotMapped]
        public bool IsVisible
        {
            get
            {
                if (Visible != null && Visible.HasValue)
                    return Visible.Value > 0;
                return false;
            }
        }
    }
}
