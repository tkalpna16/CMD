﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// DRAWINGSCALES
    /// </summary>
    public class DRAWINGSIZES
    {
        [Key]
        [Column("SizeID")]
        [Display(Name = "SizeID")]
        public int SizeID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("B")]
        [Display(Name = "B")]
        public double? B { get; set; }

        [Column("H")]
        [Display(Name = "H")]
        public double? H { get; set; }
    }
}
