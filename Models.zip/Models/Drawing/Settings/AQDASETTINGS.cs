﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing.Settings
{
    public class AQDASETTINGS
    {
        [Key]
        [Column("SettingsID")]
        [Display(Name = "SettingsID")]
        public int SettingsID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("SizeID")]
        [Display(Name = "SizeID")]
        public int? SizeID { get; set; }

        public DRAWINGSIZES SIZE { get; set; }

        [Column("ScaleID")]
        [Display(Name = "ScaleID")]
        public int? ScaleID { get; set; }

        public DRAWINGSCALES SCALE { get; set; }

        [Column("MinimumDrawing")]
        [Display(Name = "MinimumDrawing")]
        public int? MinimumDrawing { get; set; }

        [Column("ReferenceArea")]
        [Display(Name = "ReferenceArea")]
        public double? ReferenceArea { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("TCMCode")]
        [Display(Name = "TCMCode")]
        public string TCMCode { get; set; }

        public AQDASETTINGS() { }

        public AQDASETTINGS(AQDASETTINGS settings, int projectId, int userId)
        {
            this.ProjectID = projectId;
            this.UserID = userId;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
            this.SizeID = settings.SizeID.Value;
            this.ScaleID = settings.ScaleID.Value;
            this.MinimumDrawing = settings.MinimumDrawing.Value;
            this.ReferenceArea = settings.ReferenceArea.Value;
            this.Description = settings.Description;
            this.TCMCode = settings.TCMCode;
        }
    }
}
