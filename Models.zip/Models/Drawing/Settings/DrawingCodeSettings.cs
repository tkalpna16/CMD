﻿namespace CivilMasterData.Models.Drawing.Settings
{
    public class DrawingCodeSettings
    {
        public string ProjectCode { get; set; }
        public string TcmCode { get; set; }
        public string CWA { get; set; }
        public string Object { get; set; }


        public string ObjectCodeDescription { get; set; }
        public string DocumentTypeName { get; set; }
        public string DocumentTypeDescription { get; set; }
        public string DocumentTypeAdditionalDescription { get; set; }
        public string ItemTag { get; set; }

        public string Sequence { get; set; }
    }
}
