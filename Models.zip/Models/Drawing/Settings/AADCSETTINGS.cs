﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing.Settings
{
    public class AADCSETTINGS
    {
        [Key]
        [Column("SettingsID")]
        [Display(Name = "SettingsID")]
        public int SettingsID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("FoundationSizeID")]
        [Display(Name = "FoundationSizeID")]
        public int? FoundationSizeID { get; set; }

        public DRAWINGSIZES FoundationSize { get; set; }

        [Column("FoundationScaleID")]
        [Display(Name = "FoundationScaleID")]
        public int? FoundationScaleID { get; set; }

        public DRAWINGSCALES FOUNDATIONSCALE { get; set; }

        [Column("FoundationMinDrw")]
        [Display(Name = "FoundationMinDrw")]
        public int? FoundationMinDrw { get; set; }

        [Column("FoundationReferenceArea")]
        [Display(Name = "FoundationReferenceArea")]
        public double? FoundationReferenceArea { get; set; }


        // Foundation Pipes
        [Column("FoundPipeMinimumDrwFP")]
        [Display(Name = "FoundPipeMinimumDrwFP")]
        public int? FoundPipeMinimumDrwFP { get; set; }

        [Column("FoundPipeMinimumDrwFW")]
        [Display(Name = "FoundPipeMinimumDrwFW")]
        public int? FoundPipeMinimumDrwFW { get; set; }

        [Column("FoundPipeMinimumDrwRF")]
        [Display(Name = "FoundPipeMinimumDrwRF")]
        public int? FoundPipeMinimumDrwRF { get; set; }

        [Column("FoundPipeMinimumDrwBBS")]
        [Display(Name = "FoundPipeMinimumDrwBBS")]
        public int? FoundPipeMinimumDrwBBS { get; set; }


        // Foundation Process
        [Column("FoundProcessMinimumDrwFP")]
        [Display(Name = "FoundProcessMinimumDrwFP")]
        public int? FoundProcessMinimumDrwFP { get; set; }

        [Column("FoundProcessMinimumDrwFW")]
        [Display(Name = "FoundProcessMinimumDrwFW")]
        public int? FoundProcessMinimumDrwFW { get; set; }

        [Column("FoundProcessMinimumDrwRF")]
        [Display(Name = "FoundProcessMinimumDrwRF")]
        public int? FoundProcessMinimumDrwRF { get; set; }

        [Column("FoundProcessMinimumDrwBBS")]
        [Display(Name = "FoundProcessMinimumDrwBBS")]
        public int? FoundProcessMinimumDrwBBS { get; set; }


        // Foundation Equipment

        [Column("FoundEquipmentMinimumDrwFP")]
        [Display(Name = "FoundEquipmentMinimumDrwFP")]
        public int? FoundEquipmentMinimumDrwFP { get; set; }

        [Column("FoundEquipmentMinimumDrwFW")]
        [Display(Name = "FoundEquipmentMinimumDrwFW")]
        public int? FoundEquipmentMinimumDrwFW { get; set; }

        [Column("FoundEquipmentMinimumDrwRF")]
        [Display(Name = "FoundationReferenceArea")]
        public int? FoundEquipmentMinimumDrwRF { get; set; }

        [Column("FoundEquipmentMinimumDrwBBS")]
        [Display(Name = "FoundEquipmentMinimumDrwBBS")]
        public int? FoundEquipmentMinimumDrwBBS { get; set; }


        // Foundation Building

        [Column("FoundBuildingMinimumDrwFP")]
        [Display(Name = "FoundBuildingMinimumDrwFP")]
        public int? FoundBuildingMinimumDrwFP { get; set; }

        [Column("FoundBuildingMinimumDrwFW")]
        [Display(Name = "FoundBuildingMinimumDrwFW")]
        public int? FoundBuildingMinimumDrwFW { get; set; }

        [Column("FoundBuildingMinimumDrwRF")]
        [Display(Name = "FoundBuildingMinimumDrwRF")]
        public int? FoundBuildingMinimumDrwRF { get; set; }

        [Column("FoundBuildingMinimumDrwBBS")]
        [Display(Name = "FoundBuildingMinimumDrwBBS")]
        public int? FoundBuildingMinimumDrwBBS { get; set; }


        // Foundation Basin

        [Column("FoundBasinMinimumDrwFP")]
        [Display(Name = "FoundBasinMinimumDrwFP")]
        public int? FoundBasinMinimumDrwFP { get; set; }

        [Column("FoundBasinMinimumDrwFW")]
        [Display(Name = "FoundBasinMinimumDrwFW")]
        public int? FoundBasinMinimumDrwFW { get; set; }

        [Column("FoundBasinMinimumDrwRF")]
        [Display(Name = "FoundBasinMinimumDrwRF")]
        public int? FoundBasinMinimumDrwRF { get; set; }

        [Column("FoundBasinMinimumDrwBBS")]
        [Display(Name = "FoundBasinMinimumDrwBBS")]
        public int? FoundBasinMinimumDrwBBS { get; set; }


        // Foundation Others

        [Column("FoundOtherMinimumDrwFP")]
        [Display(Name = "FoundOtherMinimumDrwFP")]
        public int? FoundOtherMinimumDrwFP { get; set; }

        [Column("FoundOtherMinimumDrwFW")]
        [Display(Name = "FoundOtherMinimumDrwFW")]
        public int? FoundOtherMinimumDrwFW { get; set; }

        [Column("FoundOtherMinimumDrwRF")]
        [Display(Name = "FoundOtherMinimumDrwRF")]
        public int? FoundOtherMinimumDrwRF { get; set; }

        [Column("FoundOtherMinimumDrwBBS")]
        [Display(Name = "FoundOtherMinimumDrwBBS")]
        public int? FoundOtherMinimumDrwBBS { get; set; }


        // Elevation Pipes

        [Column("ElePipeMinimumDrwEP")]
        [Display(Name = "ElePipeMinimumDrwEP")]
        public int? ElePipeMinimumDrwEP { get; set; }

        [Column("ElePipeMinimumDrwFW")]
        [Display(Name = "ElePipeMinimumDrwFW")]
        public int? ElePipeMinimumDrwFW { get; set; }

        [Column("ElePipeMinimumDrwRF")]
        [Display(Name = "ElePipeMinimumDrwiRF")]
        public int? ElePipeMinimumDrwRF { get; set; }

        [Column("ElePipeMinimumDrwBBS")]
        [Display(Name = "ElePipeMinimumDrwBBS")]
        public int? ElePipeMinimumDrwBBS { get; set; }



        // Elevation Process

        [Column("EleProcessMinimumDrwEP")]
        [Display(Name = "EleProcessMinimumDrwEP")]
        public int? EleProcessMinimumDrwEP { get; set; }

        [Column("EleProcessMinimumDrwFW")]
        [Display(Name = "EleProcessMinimumDrwFW")]
        public int? EleProcessMinimumDrwFW { get; set; }

        [Column("EleProcessMinimumDrwRF")]
        [Display(Name = "EleProcessMinimumDrwRF")]
        public int? EleProcessMinimumDrwRF { get; set; }

        [Column("EleProcessMinimumDrwBBS")]
        [Display(Name = "EleProcessMinimumDrwBBS")]
        public int? EleProcessMinimumDrwBBS { get; set; }

        // Elevation Equipment
        [Column("EleEquipmentMinimumDrw")]
        [Display(Name = "EleEquipmentMinimumDrw")]
        public int? EleEquipmentMinimumDrw { get; set; }

        // Elevation Building
        [Column("EleBuildingMinimumDrw")]
        [Display(Name = "EleBuildingMinimumDrw")]
        public int? EleBuildingMinimumDrw { get; set; }


        // Elevation others
        [Column("EleOtherMinimumDrwEP")]
        [Display(Name = "EleOtherMinimumDrwEP")]
        public int? EleOtherMinimumDrwEP { get; set; }

        [Column("EleOtherMinimumDrwFW")]
        [Display(Name = "EleOtherMinimumDrwFW")]
        public int? EleOtherMinimumDrwFW { get; set; }

        [Column("EleOtherMinimumDrwRF")]
        [Display(Name = "EleOtherMinimumDrwiRF")]
        public int? EleOtherMinimumDrwRF { get; set; }

        [Column("EleOtherMinimumDrwBBS")]
        [Display(Name = "EleOtherMinimumDrwBBS")]
        public int? EleOtherMinimumDrwBBS { get; set; }


        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("TCMCode")]
        [Display(Name = "TCMCode")]
        public string TCMCode { get; set; }

        [Column("PipeRackMultFoundation")]
        [Display(Name = "PipeRackMultFoundation")]
        public int? PipeRackMultFoundation { get; set; }

        [Column("ProcessMultFoundation")]
        [Display(Name = "ProcessMultFoundation")]
        public int? ProcessMultFoundation { get; set; }

        [Column("EquipmentMultFoundation")]
        [Display(Name = "EquipmentMultFoundation")]
        public int? EquipmentMultFoundation { get; set; }

        [Column("BuildingMultFoundation")]
        [Display(Name = "BuildingMultFoundation")]
        public int? BuildingMultFoundation { get; set; }

        [Column("BasinMultFoundation")]
        [Display(Name = "BasinMultFoundation")]
        public int? BasinMultFoundation { get; set; }

        [Column("PipeRackMultElevation")]
        [Display(Name = "PipeRackMultElevation")]
        public int? PipeRackMultElevation { get; set; }

        [Column("ProcessMultElevation")]
        [Display(Name = "ProcessMultElevation")]
        public int? ProcessMultElevation { get; set; }



        public AADCSETTINGS() { }

        public AADCSETTINGS(AADCSETTINGS settings, int projectId, int userId)
        {
            this.ProjectID = projectId;
            this.UserID = userId;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
            this.FoundationSizeID = settings.FoundationSizeID.Value;
            this.FoundationScaleID = settings.FoundationScaleID.Value;
            this.FoundationMinDrw = settings.FoundationMinDrw.Value;
            this.FoundationReferenceArea = settings.FoundationReferenceArea.Value;

            this.FoundPipeMinimumDrwFP = settings.FoundPipeMinimumDrwFP.Value;
            this.FoundPipeMinimumDrwFW = settings.FoundPipeMinimumDrwFW.Value;
            this.FoundPipeMinimumDrwRF = settings.FoundPipeMinimumDrwRF;
            this.FoundPipeMinimumDrwBBS = settings.FoundPipeMinimumDrwBBS;

            this.FoundProcessMinimumDrwFP = settings.FoundProcessMinimumDrwFP.Value;
            this.FoundProcessMinimumDrwFW = settings.FoundProcessMinimumDrwFW.Value;
            this.FoundProcessMinimumDrwRF = settings.FoundProcessMinimumDrwRF.Value;
            this.FoundProcessMinimumDrwBBS = settings.FoundProcessMinimumDrwBBS.Value;

            this.FoundEquipmentMinimumDrwFP = settings.FoundEquipmentMinimumDrwFP.Value;
            this.FoundEquipmentMinimumDrwFW = settings.FoundEquipmentMinimumDrwFW.Value;
            this.FoundEquipmentMinimumDrwRF = settings.FoundEquipmentMinimumDrwRF.Value;
            this.FoundEquipmentMinimumDrwBBS = settings.FoundEquipmentMinimumDrwBBS.Value;

            this.FoundBuildingMinimumDrwFP = settings.FoundBuildingMinimumDrwFP.Value;
            this.FoundBuildingMinimumDrwFW = settings.FoundBuildingMinimumDrwFW.Value;
            this.FoundBuildingMinimumDrwRF = settings.FoundBuildingMinimumDrwRF.Value;
            this.FoundBuildingMinimumDrwBBS = settings.FoundBuildingMinimumDrwBBS.Value;

            this.FoundBasinMinimumDrwFP = settings.FoundBasinMinimumDrwFP.Value;
            this.FoundBasinMinimumDrwFW = settings.FoundBasinMinimumDrwFW.Value;
            this.FoundBasinMinimumDrwRF = settings.FoundBasinMinimumDrwRF.Value;
            this.FoundBasinMinimumDrwBBS = settings.FoundBasinMinimumDrwBBS.Value;

            this.FoundOtherMinimumDrwFP = settings.FoundOtherMinimumDrwFP.Value;
            this.FoundOtherMinimumDrwFW = settings.FoundOtherMinimumDrwFW.Value;
            this.FoundOtherMinimumDrwRF = settings.FoundOtherMinimumDrwRF.Value;
            this.FoundOtherMinimumDrwBBS = settings.FoundOtherMinimumDrwBBS.Value;

            this.ElePipeMinimumDrwEP = settings.ElePipeMinimumDrwEP.Value;
            this.ElePipeMinimumDrwFW = settings.ElePipeMinimumDrwFW.Value;
            this.ElePipeMinimumDrwRF = settings.ElePipeMinimumDrwRF.Value;
            this.ElePipeMinimumDrwBBS = settings.ElePipeMinimumDrwBBS.Value;

            this.EleProcessMinimumDrwEP = settings.EleProcessMinimumDrwEP.Value;
            this.EleProcessMinimumDrwFW = settings.EleProcessMinimumDrwFW.Value;
            this.EleProcessMinimumDrwRF = settings.EleProcessMinimumDrwRF.Value;
            this.EleProcessMinimumDrwBBS = settings.EleProcessMinimumDrwBBS.Value;

            this.EleEquipmentMinimumDrw = settings.EleEquipmentMinimumDrw.Value;
            this.EleBuildingMinimumDrw = settings.EleBuildingMinimumDrw.Value;

            this.EleOtherMinimumDrwEP = settings.EleOtherMinimumDrwEP.Value;
            this.EleOtherMinimumDrwFW = settings.EleOtherMinimumDrwFW.Value;
            this.EleOtherMinimumDrwRF = settings.EleOtherMinimumDrwRF.Value;
            this.EleOtherMinimumDrwBBS = settings.EleOtherMinimumDrwBBS.Value;

            this.PipeRackMultFoundation = settings.PipeRackMultFoundation.Value;
            this.ProcessMultFoundation = settings.ProcessMultFoundation.Value;
            this.EquipmentMultFoundation = settings.EquipmentMultFoundation.Value;
            this.BuildingMultFoundation = settings.BuildingMultFoundation.Value;
            this.BasinMultFoundation = settings.BasinMultFoundation.Value;
            this.PipeRackMultElevation = settings.PipeRackMultElevation.Value;
            this.ProcessMultElevation = settings.ProcessMultElevation.Value;
           
            this.Description = settings.Description;
            this.TCMCode = settings.TCMCode;
        }
    }
}
