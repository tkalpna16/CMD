﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing.Settings
{
    public class AIDUSETTINGS
    {
        [Key]
        [Column("SettingsID")]
        [Display(Name = "SettingsID")]
        public int SettingsID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("PipeStructureMinimumDrw")]
        [Display(Name = "PipeStructureMinimumDrw")]
        public int? PipeStructureMinimumDrw { get; set; }

        [Column("FoundProcessRefArea")]
        [Display(Name = "FoundProcessRefArea")]
        public double? FoundProcessRefArea { get; set; }

        [Column("FoundBuildingMinimumDrw")]
        [Display(Name = "FoundBuildingMinimumDrw")]
        public int? FoundBuildingMinimumDrw { get; set; }

        [Column("FoundOtherMinimumDrw")]
        [Display(Name = "FoundOtherMinimumDrw")]
        public int? FoundOtherMinimumDrw { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("TCMCode")]
        [Display(Name = "TCMCode")]
        public string TCMCode { get; set; }

        public AIDUSETTINGS() { }

        public AIDUSETTINGS(AIDUSETTINGS settings, int projectId, int userId)
        {
            this.ProjectID = projectId;
            this.UserID = userId;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
            this.PipeStructureMinimumDrw = settings.PipeStructureMinimumDrw.Value;
            this.FoundProcessRefArea = settings.FoundProcessRefArea.Value;
            this.FoundBuildingMinimumDrw = settings.FoundBuildingMinimumDrw.Value;
            this.FoundOtherMinimumDrw = settings.FoundOtherMinimumDrw.Value;

            this.Description = settings.Description;
            this.TCMCode = settings.TCMCode;
        }
    }
}
