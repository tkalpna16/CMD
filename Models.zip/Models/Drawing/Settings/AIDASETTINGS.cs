﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing.Settings
{
    public class AIDASETTINGS
    {
        [Key]
        [Column("SettingsID")]
        [Display(Name = "SettingsID")]
        public int SettingsID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("MinimumDrawing")]
        [Display(Name = "MinimumDrawing")]
        public int? MinimumDrawing { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("TCMCode")]
        [Display(Name = "TCMCode")]
        public string TCMCode { get; set; }

        public AIDASETTINGS() { }

        public AIDASETTINGS(AIDASETTINGS settings, int projectId, int userId)
        {
            this.ProjectID = projectId;
            this.UserID = userId;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
            this.MinimumDrawing = settings.MinimumDrawing.Value;
            this.Description = settings.Description;
            this.TCMCode = settings.TCMCode;
        }
    }
}
