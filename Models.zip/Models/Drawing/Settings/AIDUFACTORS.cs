﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Drawing.Settings
{
    public class AIDUFACTORS
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("LV01_Object_CodeID")]
        [Display(Name = "LV01_Object_CodeID")]
        public int? LV01_Object_CodeID { get; set; }

        public OBJECTCODES LV01_Object_Code { get; set; }

        [Column("TagTypeID")]
        [Display(Name = "TagTypeID")]
        public int TagTypeID { get; set; }

        public TAGTYPES TAGTYPES { get; set; }

        [Column("FactorValue")]
        [Display(Name = "FactorValue")]
        public double FactorValue { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("MinValue")]
        [Display(Name = "MinValue")]
        public double MinValue { get; set; }

        [Column("MaxValue")]
        [Display(Name = "MaxValue")]
        public double MaxValue { get; set; }

        [Column("Code")]
        [Display(Name = "Code")]
        public string Code { get; set; }
    }
}
