﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class DRAWINGS
    {
        #region Data
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("DrawingID")]
        [Display(Name = "DrawingID")]
        public int DrawingID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("ProjectDrawingID")]
        [Display(Name = "ProjectDrawingID")]
        public int? ProjectDrawingID { get; set; }

        [Column("TCMDrawingNumber")]
        [Display(Name = "TCMDrawingNumber")]
        public string TCMDrawingNumber { get; set; }

        [Column("DrawingDescription")]
        [Display(Name = "DrawingDescription")]
        public string DrawingDescription { get; set; }

        [Column("TypeID")]
        [Display(Name = "TypeID")]
        public int? TypeID { get; set; }

        public DOCUMENTTYPES DOCUMENTTYPE { get; set; }

        [Column("MainItemTag")]
        [Display(Name = "MainItemTag")]
        public string MainItemTag { get; set; }

        [Column("CWA")]
        [Display(Name = "CWA")]
        public string CWA { get; set; }

        [Column("RevisionsID")]
        [Display(Name = "RevisionsID")]
        public int? RevisionsID { get; set; }

        public REVISIONS REVISIONS { get; set; }


        [Column("DIGITS")]
        [Display(Name = "DIGITS")]
        public int DIGITS { get; set; }
        #endregion

        [NotMapped]
        public string GetKeyLevel
        {
            get
            {
                if (DOCUMENTTYPE != null)
                    return DOCUMENTTYPE.TCMCode[0].ToString();
                return string.Empty;
            }
        }
        [NotMapped]
        public string GetDepartmentCode
        {
            get
            {
                if (DOCUMENTTYPE != null)
                    return DOCUMENTTYPE.TCMCode[1].ToString();
                return string.Empty;
            }
        }
        [NotMapped]
        public string GetDocumentClassification
        {
            get
            {
                if (DOCUMENTTYPE != null)
                    return DOCUMENTTYPE.TCMCode.Split('-')[0];
                return string.Empty;
            }
        }
        [NotMapped]
        public string GetTCMCode
        {
            get
            {
                if (DOCUMENTTYPE != null)
                    return DOCUMENTTYPE.TCMCode;
                return string.Empty;
            }
        }
        [NotMapped]
        public string GetDocumentTypology
        {
            get
            {
                if (DOCUMENTTYPE != null)
                    return DOCUMENTTYPE.TCMCode.Split('-')[1];
                return string.Empty;
            }
        }
        [NotMapped]
        public string GetDocumentNumber
        {
            get
            {
                if (!string.IsNullOrEmpty(TCMDrawingNumber))
                {
                    string[] values = TCMDrawingNumber.Split('-');
                    if (values != null && values.Length > 0)
                        return values.Last();
                }
                return string.Empty;
            }
        }

        #region Constructor
        public DRAWINGS() { }
        #endregion

        #region Common documents
        public static async Task<List<DRAWINGS>> GetCommonDrawingList(
            DLGENERATORContext _context,
            List<DOCUMENTSETTINGS> docSettings, 
            int userId, 
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DrawingCodeSettings drawingSettings,
            int revisionId,
            REVISIONS lastRevision,
            List<REVISIONS> previousRevisions)
        {
            List<DRAWINGS> drawings = new List<DRAWINGS>();
            if (docSettings != null && docSettings.Count > 0)
            {
                int totalDrawings = 0;
                
                DateTime now = DateTime.UtcNow;
                int drawingId = 1;
                foreach (DOCUMENTSETTINGS docSetting in docSettings)
                {
                    totalDrawings = docSetting.NUMBEROFDOCUMENTS.HasValue ? docSetting.NUMBEROFDOCUMENTS.Value : 0;
                    if (totalDrawings > 0)
                    {
                        if (totalDrawings > projectSettings.DRAWING_MAX_FOR_TYPE)
                            totalDrawings = projectSettings.DRAWING_MAX_FOR_TYPE;

                        int existingDrawings = 0;
                        List<DRAWINGS> lastRevisionDrawing = null;
                        int digits = 0;
                        if (!string.IsNullOrEmpty(projectSettings.DRAWINGCWADIGIT))
                            digits += projectSettings.DRAWINGCWADIGIT.Length;
                        if (!string.IsNullOrEmpty(projectSettings.DRAWINGOBJECTDIGIT))
                            digits += projectSettings.DRAWINGOBJECTDIGIT.Length;
                        if (!string.IsNullOrEmpty(projectSettings.DRAWINGSEQDIGIT))
                            digits += projectSettings.DRAWINGSEQDIGIT.Length;

                        if (lastRevision != null)
                        {
                            lastRevisionDrawing = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                                d.DOCUMENTTYPE.TypeID == docSetting.DOCUMENTTYPE.TypeID &&
                                d.DIGITS == digits).OrderBy(d => d.DrawingID).ToListAsync();
                            if (lastRevisionDrawing != null)
                                existingDrawings = lastRevisionDrawing.Count;
                        }
                        if (existingDrawings > 0)
                        {
                            if (existingDrawings >= totalDrawings)
                            {
                                // Copy existing
                                for (int i = 0; i < totalDrawings; i++)
                                {
                                    DRAWINGS drawing = new DRAWINGS();
                                    drawing.CreationDate = now;
                                    drawing.LastModified = now;
                                    drawing.UserID = userId;
                                    drawing.TypeID = docSetting.DOCUMENTTYPE.TypeID;
                                    drawing.TCMDrawingNumber = lastRevisionDrawing[i].TCMDrawingNumber;
                                    drawing.DrawingDescription = lastRevisionDrawing[i].DrawingDescription;
                                    drawing.DIGITS = lastRevisionDrawing[i].DIGITS;
                                    drawing.ProjectID = project.ProjectID;
                                    drawing.RevisionsID = revisionId;
                                    drawings.Add(drawing);
                                    drawingId++;
                                }
                            }
                            else
                            {
                                // Copy existing
                                for (int i = 0; i < existingDrawings; i++)
                                {
                                    DRAWINGS drawing = new DRAWINGS();
                                    drawing.CreationDate = now;
                                    drawing.LastModified = now;
                                    drawing.UserID = userId;
                                    drawing.TypeID = docSetting.DOCUMENTTYPE.TypeID;
                                    drawing.TCMDrawingNumber = lastRevisionDrawing[i].TCMDrawingNumber;
                                    drawing.DrawingDescription = lastRevisionDrawing[i].DrawingDescription;
                                    drawing.DIGITS = lastRevisionDrawing[i].DIGITS;
                                    drawing.ProjectID = project.ProjectID;
                                    drawing.RevisionsID = revisionId;
                                    drawings.Add(drawing);
                                    drawingId++;
                                }

                                for (int i = existingDrawings; i < totalDrawings; i++)
                                {
                                    DRAWINGS drawing = new DRAWINGS();
                                    drawing.CreationDate = now;
                                    drawing.LastModified = now;
                                    drawing.UserID = userId;
                                    drawing.TypeID = docSetting.DOCUMENTTYPE.TypeID;
                                    drawing.TCMDrawingNumber = CalculateCommonDrawingCode(docSetting,
                                        projectSettings.DRAWINGNUMBER,
                                        drawingSettings,
                                        project,
                                        projectSettings,
                                        drawingId);
                                    drawing.DrawingDescription = CalculateDrawingDescription(docSetting.DOCUMENTTYPE,
                                        projectSettings.DRAWINGDESCCOMMON,
                                        drawingSettings,
                                        null,
                                        null,
                                        drawingId);
                                    drawing.ProjectID = project.ProjectID;
                                    drawing.RevisionsID = revisionId;
                                    drawing.DIGITS = digits;

                                    bool exist = await DrawingExist(_context, drawing.TCMDrawingNumber, lastRevision);
                                    while (exist)
                                    {
                                        drawingId++;
                                        drawing.TCMDrawingNumber = CalculateCommonDrawingCode(docSetting,
                                        projectSettings.DRAWINGNUMBER,
                                        drawingSettings,
                                        project,
                                        projectSettings,
                                        drawingId);
                                        drawing.DrawingDescription = CalculateDrawingDescription(docSetting.DOCUMENTTYPE,
                                            projectSettings.DRAWINGDESCCOMMON,
                                            drawingSettings,
                                            null,
                                            null,
                                            drawingId);
                                        drawing.DIGITS = digits;
                                        exist = await DrawingExist(_context, drawing.TCMDrawingNumber, lastRevision);
                                    }

                                    drawings.Add(drawing);
                                    drawingId++;
                                }
                            }
                        }
                        else
                        {
                            for (int i = 0; i < totalDrawings; i++)
                            {
                                DRAWINGS drawing = new DRAWINGS();
                                drawing.CreationDate = now;
                                drawing.LastModified = now;
                                drawing.UserID = userId;
                                drawing.TypeID = docSetting.DOCUMENTTYPE.TypeID;
                                drawing.TCMDrawingNumber = CalculateCommonDrawingCode(docSetting,
                                    projectSettings.DRAWINGNUMBER,
                                    drawingSettings,
                                    project,
                                    projectSettings,
                                    drawingId);
                                drawing.DrawingDescription = CalculateDrawingDescription(docSetting.DOCUMENTTYPE,
                                    projectSettings.DRAWINGDESCCOMMON,
                                    drawingSettings,
                                    null,
                                    null,
                                    drawingId);
                                drawing.DIGITS = digits;
                                drawing.ProjectID = project.ProjectID;
                                drawing.RevisionsID = revisionId;

                                bool exist = await DrawingExist(_context, drawing.TCMDrawingNumber, lastRevision);
                                while (exist)
                                {
                                    drawingId++;
                                    drawing.TCMDrawingNumber = CalculateCommonDrawingCode(docSetting,
                                    projectSettings.DRAWINGNUMBER,
                                    drawingSettings,
                                    project,
                                    projectSettings,
                                    drawingId);
                                    drawing.DrawingDescription = CalculateDrawingDescription(docSetting.DOCUMENTTYPE,
                                        projectSettings.DRAWINGDESCCOMMON,
                                        drawingSettings,
                                        null,
                                        null,
                                        drawingId);
                                    drawing.DIGITS = digits;
                                    exist = await DrawingExist(_context, drawing.TCMDrawingNumber, lastRevision);
                                }

                                drawings.Add(drawing);
                                drawingId++;
                            }
                        }
                    }
                }
            }
            return drawings;
        }

        private static string CalculateCommonDrawingCode(
            DOCUMENTSETTINGS documentSettings,
            string projectString,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            int drawingId)
        {
            string code = projectString;
            code = code.Replace(drawingSettings.ProjectCode, project.DLProjectCode);
            code = code.Replace(drawingSettings.TcmCode, documentSettings.DOCUMENTTYPE.TCMCode);

            if (!string.IsNullOrEmpty(project.CommonArea))
            {
                string area = project.CommonArea.PadRight(projectSettings.DRAWINGCWADIGIT.Length, '0');
                if (!string.IsNullOrEmpty(area))
                {
                    int l = area.Length;
                    if (l > projectSettings.DRAWINGCWADIGIT.Length && projectSettings.DRAWINGCWADIGIT.Length > 0)
                        area = area.Substring(0, projectSettings.DRAWINGCWADIGIT.Length);
                }
                code = code.Replace(drawingSettings.CWA, area);
            }
            else
                code = code.Replace(drawingSettings.CWA, 0.ToString(projectSettings.DRAWINGCWADIGIT));

            code = code.Replace(drawingSettings.Object, 0.ToString(projectSettings.DRAWINGOBJECTDIGIT));

            string sequence = drawingId.ToString(projectSettings.DRAWINGSEQDIGIT);
            code = code.Replace(drawingSettings.Sequence, sequence);
            return code;
        }

        private static string CalculateDrawingDescription(
            DOCUMENTTYPES docType,
            string drawingDescriptionText,
            DrawingCodeSettings drawingSettings,
            MAINITEMS mainItem,
            PBS pbs,
            int drawingId)
        {
            string code = drawingDescriptionText;
            if (mainItem != null)
            {
                if (mainItem.LV01_Object_Code != null)
                   code = code.Replace(drawingSettings.ObjectCodeDescription, mainItem.LV01_Object_Code.CodeDescription);
                else
                    code = code.Replace(drawingSettings.ObjectCodeDescription, "AREA");
                if (mainItem != null)
                {
                    if (!mainItem.IsBalance)
                        code = code.Replace(drawingSettings.ItemTag, mainItem.MainItemTag);
                    else
                        code = code.Replace(drawingSettings.ItemTag, mainItem.PBS.Area);
                }
            }

            code = code.Replace(drawingSettings.DocumentTypeName, docType.DocumentType);
            code = code.Replace(drawingSettings.DocumentTypeDescription, docType.Description);
            code = code.Replace(drawingSettings.DocumentTypeAdditionalDescription, docType.AdditionalDescription);
            if (mainItem != null)
                code = code.Replace(drawingSettings.CWA, mainItem.PBS.CWA);
            if (pbs != null)
                code = code.Replace(drawingSettings.CWA, pbs.CWA);

            code = code.Replace(drawingSettings.Sequence, drawingId.ToString());

            //string[] values = code.Split("-");
            //code = string.Empty;
            //for(int i = 0; i < values.Length; i++)
            //{
            //    code += values[i].Trim();
            //    if (i < (values.Length - 1))
            //        code += "-";
            //}
            return code;
        }
        #endregion

        #region PBS Drawings
        public static List<DRAWINGS> GetDrawingListPBS(
            string tcmCode,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DOCUMENTTYPES docType,
            int startIndex,
            int totalDrawings,
            PBS pbs,
            int userId,
            int revisionId,
            REVISIONS lastRevision)
        {
            List<DRAWINGS> drawings = new List<DRAWINGS>();
            DateTime now = DateTime.UtcNow;
            int drawingId = startIndex;
            if (pbs != null)
            {
                // Check Total Drawings
                if (totalDrawings > projectSettings.DRAWING_MAX_NDOCS)
                    totalDrawings = projectSettings.DRAWING_MAX_NDOCS;

                // Regenerate drawings
                for (int i = 0; i < totalDrawings; i++)
                {
                    DRAWINGS drawing = new DRAWINGS();
                    drawing.CreationDate = now;
                    drawing.LastModified = now;
                    drawing.UserID = userId;
                    drawing.TypeID = docType.TypeID;
                    drawing.TCMDrawingNumber = CalculateDrawingPBSCode(tcmCode, projectSettings.DRAWINGNUMBER,
                        drawingSettings, project, projectSettings, pbs, drawingId);
                    drawing.DrawingDescription = CalculateDrawingDescription(docType,
                        projectSettings.DRAWINGDESCAREA,
                        drawingSettings,
                        null,
                        pbs,
                        drawingId);
                    drawing.ProjectID = project.ProjectID;
                    drawing.CWA = pbs.CWA;
                    drawing.RevisionsID = revisionId;
                    drawings.Add(drawing);
                    drawingId++;
                }
            }
            return drawings;
        }

        private static string CalculateDrawingPBSCode(
            string tcmCode,
            string projectString,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            PBS pbs,
            int drawingId)
        {
            string code = projectString;
            code = code.Replace(drawingSettings.ProjectCode, project.DLProjectCode);
            code = code.Replace(drawingSettings.TcmCode, tcmCode);

            if (pbs != null)
            {
                string area = pbs.Area.PadRight(projectSettings.DRAWINGCWADIGIT.Length, '0');
                if (!string.IsNullOrEmpty(area))
                {
                    int l = area.Length;
                    if (l > projectSettings.DRAWINGCWADIGIT.Length && projectSettings.DRAWINGCWADIGIT.Length > 0)
                        area = area.Substring(0, projectSettings.DRAWINGCWADIGIT.Length);
                }
                code = code.Replace(drawingSettings.CWA, area);
            }

            code = code.Replace(drawingSettings.Object, 0.ToString(projectSettings.DRAWINGOBJECTDIGIT));

            string sequence = drawingId.ToString(projectSettings.DRAWINGSEQDIGIT);
            code = code.Replace(drawingSettings.Sequence, sequence);
            return code;
        }
        #endregion

        #region Main Item Drawings
        public static List<DRAWINGS> GetDrawingListMainItem(
            string tcmCode,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DOCUMENTTYPES docType,
            int startIndex,
            int totalDrawings,
            MAINITEMS mainItem,
            int userId,
            int revisionId)
        {
            List<DRAWINGS> drawings = new List<DRAWINGS>();
            DateTime now = DateTime.UtcNow;
            int drawingId = startIndex;

            if (mainItem != null)
            {
                // Check Total Drawings
                if (totalDrawings > projectSettings.DRAWING_MAX_NDOCS)
                    totalDrawings = projectSettings.DRAWING_MAX_NDOCS;

                // Copy
                for (int i = 0; i < totalDrawings; i++)
                {
                    DRAWINGS drawing = new DRAWINGS();
                    drawing.CreationDate = now;
                    drawing.LastModified = now;
                    drawing.UserID = userId;
                    drawing.TypeID = docType.TypeID;
                    drawing.TCMDrawingNumber = CalculateDrawingMainItemCode(tcmCode, projectSettings.DRAWINGNUMBER,
                        drawingSettings, project, projectSettings, mainItem, drawingId);
                    drawing.DrawingDescription = CalculateDrawingDescription(docType,
                        projectSettings.DRAWINGDESCITEMS,
                        drawingSettings,
                        mainItem,
                        null,
                        drawingId);
                    drawing.ProjectID = project.ProjectID;
                    drawing.MainItemTag = mainItem.MainItemTag;
                    drawing.RevisionsID = revisionId;
                    drawing.CWA = mainItem.PBS.CWA;
                    drawings.Add(drawing);
                    drawingId++;
                }
            }
            return drawings;
        }

        private static string CalculateDrawingMainItemCode(
            string tcmCode,
            string projectString,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            MAINITEMS mainItems,
            int drawingId)
        {
            string code = projectString;
            code = code.Replace(drawingSettings.ProjectCode, project.DLProjectCode);
            code = code.Replace(drawingSettings.TcmCode, tcmCode);

            if (mainItems != null)
            {
                string area = mainItems.PBS.Area.PadRight(projectSettings.DRAWINGCWADIGIT.Length, '0');
                if (!string.IsNullOrEmpty(area))
                {
                    int l = area.Length;
                    if (l > projectSettings.DRAWINGCWADIGIT.Length && projectSettings.DRAWINGCWADIGIT.Length > 0)
                        area = area.Substring(0, projectSettings.DRAWINGCWADIGIT.Length);
                }

                code = code.Replace(drawingSettings.CWA, area);

                if (mainItems.IsBalance)
                {
                    string itemTag = 0.ToString(projectSettings.DRAWINGOBJECTDIGIT);
                    code = code.Replace(drawingSettings.Object, itemTag);
                }
                else
                {
                    string itemTag = mainItems.MainItemTag.Split("-")[1];
                    itemTag = itemTag.PadRight(projectSettings.DRAWINGOBJECTDIGIT.Length, '0');
                    if (!string.IsNullOrEmpty(itemTag))
                    {
                        int l = itemTag.Length;
                        if (l > projectSettings.DRAWINGOBJECTDIGIT.Length && projectSettings.DRAWINGOBJECTDIGIT.Length > 0)
                            itemTag = itemTag.Substring(0, projectSettings.DRAWINGOBJECTDIGIT.Length);
                    }
                    code = code.Replace(drawingSettings.Object, itemTag);
                }
            }

            string sequence = drawingId.ToString(projectSettings.DRAWINGSEQDIGIT);
            code = code.Replace(drawingSettings.Sequence, sequence);
            return code;
        }
        #endregion

        #region Calculation
        private static async Task<bool> DrawingExist(DLGENERATORContext context, string code, REVISIONS previousRevisions)
        {
            if (previousRevisions == null)
                return false;
            var existingDrawings = await context.DRAWINGS.Where(d => d.RevisionsID.Value == previousRevisions.RevisionID &&
                        d.TCMDrawingNumber == code).FirstOrDefaultAsync();
            return existingDrawings != null;
        }
        public static async Task<List<DRAWINGS>> GetDrawingListFromDocumentType(
            DLGENERATORContext context,
            string tcmCode,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DOCUMENTTYPES docType,
            int startIndex,
            int totalDrawings,
            int userId,
            int revisionId,
            REVISIONS lastRevision,
            List<REVISIONS> previousRevisions)
        {
            List<DRAWINGS> drawings = new List<DRAWINGS>();
            
            DateTime now = DateTime.UtcNow;
            int drawingId = startIndex;

            if (totalDrawings > projectSettings.DRAWING_MAX_NDOCS)
                totalDrawings = projectSettings.DRAWING_MAX_NDOCS;

            if (lastRevision != null)
            {
                var existingDrawings = await context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                        d.DOCUMENTTYPE.TypeID == docType.TypeID).OrderBy(d => d.DrawingID).ToListAsync();
                int existingDrawing = 0;
                if (existingDrawings != null)
                    existingDrawing = existingDrawings.Count;

                if (existingDrawing == 0)
                {
                    // Create
                    for (int i = 0; i < totalDrawings; i++)
                    {
                        DRAWINGS drawing = new DRAWINGS();
                        drawing.CreationDate = now;
                        drawing.LastModified = now;
                        drawing.UserID = userId;
                        drawing.TypeID = docType.TypeID;
                        drawing.TCMDrawingNumber = CalculateDrawingFromDocumentType(tcmCode, projectSettings.DRAWINGNUMBER,
                            drawingSettings, project, projectSettings, drawingId);
                        drawing.DrawingDescription = CalculateDrawingDescription(docType,
                                projectSettings.DRAWINGDESCCOMMON,
                                drawingSettings,
                                null,
                                null,
                                drawingId);
                        drawing.RevisionsID = revisionId;
                        drawing.ProjectID = project.ProjectID;
                        bool exist = await DrawingExist(context, drawing.TCMDrawingNumber, lastRevision);
                        while (exist)
                        {
                            drawingId++;
                            drawing.TCMDrawingNumber = CalculateDrawingFromDocumentType(tcmCode, projectSettings.DRAWINGNUMBER,
                            drawingSettings, project, projectSettings, drawingId);
                            drawing.DrawingDescription = CalculateDrawingDescription(docType,
                                    projectSettings.DRAWINGDESCCOMMON,
                                    drawingSettings,
                                    null,
                                    null,
                                    drawingId);
                            exist = await DrawingExist(context, drawing.TCMDrawingNumber, lastRevision);
                        }

                        drawings.Add(drawing);
                        drawingId++;
                    }
                }
                else
                {
                    if (existingDrawing < totalDrawings)
                    {
                        // Copy
                        for (int i = 0; i < existingDrawing; i++)
                        {
                            DRAWINGS drawing = new DRAWINGS();
                            drawing.CreationDate = now;
                            drawing.LastModified = now;
                            drawing.UserID = userId;
                            drawing.TypeID = docType.TypeID;
                            drawing.TCMDrawingNumber = existingDrawings[i].TCMDrawingNumber;
                            drawing.DrawingDescription = existingDrawings[i].DrawingDescription;
                            drawing.ProjectID = project.ProjectID;
                            drawing.RevisionsID = revisionId;
                            drawings.Add(drawing);
                            drawingId++;
                        }

                        for (int i = existingDrawing; i < totalDrawings; i++)
                        {
                            DRAWINGS drawing = new DRAWINGS();
                            drawing.CreationDate = now;
                            drawing.LastModified = now;
                            drawing.UserID = userId;
                            drawing.TypeID = docType.TypeID;
                            drawing.TCMDrawingNumber = CalculateDrawingFromDocumentType(tcmCode, projectSettings.DRAWINGNUMBER,
                                drawingSettings, project, projectSettings, drawingId);
                            drawing.DrawingDescription = CalculateDrawingDescription(docType,
                                    projectSettings.DRAWINGDESCCOMMON,
                                    drawingSettings,
                                    null,
                                    null,
                                    drawingId);
                            drawing.RevisionsID = revisionId;
                            drawing.ProjectID = project.ProjectID;

                            bool exist = await DrawingExist(context, drawing.TCMDrawingNumber, lastRevision);
                            while (exist)
                            {
                                drawingId++;
                                drawing.TCMDrawingNumber = CalculateDrawingFromDocumentType(tcmCode, projectSettings.DRAWINGNUMBER,
                                drawingSettings, project, projectSettings, drawingId);
                                drawing.DrawingDescription = CalculateDrawingDescription(docType,
                                        projectSettings.DRAWINGDESCCOMMON,
                                        drawingSettings,
                                        null,
                                        null,
                                        drawingId);
                                exist = await DrawingExist(context, drawing.TCMDrawingNumber, lastRevision);
                            }


                            drawings.Add(drawing);
                            drawingId++;
                        }
                    }
                    else
                    {
                        // Copy
                        for (int i = 0; i < totalDrawings; i++)
                        {
                            DRAWINGS drawing = new DRAWINGS();
                            drawing.CreationDate = now;
                            drawing.LastModified = now;
                            drawing.UserID = userId;
                            drawing.TypeID = docType.TypeID;
                            drawing.TCMDrawingNumber = existingDrawings[i].TCMDrawingNumber;
                            drawing.DrawingDescription = existingDrawings[i].DrawingDescription;
                            drawing.ProjectID = project.ProjectID;
                            drawing.RevisionsID = revisionId;
                            drawings.Add(drawing);
                            drawingId++;
                        }
                    }
                }
            }
            else
            {
                for (int i = 0; i < totalDrawings; i++)
                {
                    DRAWINGS drawing = new DRAWINGS();
                    drawing.CreationDate = now;
                    drawing.LastModified = now;
                    drawing.UserID = userId;
                    drawing.TypeID = docType.TypeID;
                    drawing.TCMDrawingNumber = CalculateDrawingFromDocumentType(tcmCode, projectSettings.DRAWINGNUMBER,
                        drawingSettings, project, projectSettings, drawingId);
                    drawing.DrawingDescription = CalculateDrawingDescription(docType,
                            projectSettings.DRAWINGDESCCOMMON,
                            drawingSettings,
                            null,
                            null,
                            drawingId);
                    drawing.RevisionsID = revisionId;
                    drawing.ProjectID = project.ProjectID;

                    bool exist = await DrawingExist(context, drawing.TCMDrawingNumber, lastRevision);
                    while (exist)
                    {
                        drawingId++;
                        drawing.TCMDrawingNumber = CalculateDrawingFromDocumentType(tcmCode, projectSettings.DRAWINGNUMBER,
                        drawingSettings, project, projectSettings, drawingId);
                        drawing.DrawingDescription = CalculateDrawingDescription(docType,
                                projectSettings.DRAWINGDESCCOMMON,
                                drawingSettings,
                                null,
                                null,
                                drawingId);
                        exist = await DrawingExist(context, drawing.TCMDrawingNumber, lastRevision);
                    }

                    drawings.Add(drawing);
                    drawingId++;
                }
            }

            return drawings;
        }

        private static string CalculateDrawingFromDocumentType(
            string tcmCode,
            string projectString,
            DrawingCodeSettings drawingSettings,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            int drawingId)
        {
            string code = projectString;
            code = code.Replace(drawingSettings.ProjectCode, project.DLProjectCode);
            code = code.Replace(drawingSettings.TcmCode, tcmCode);

            if (!string.IsNullOrEmpty(project.CommonArea))
            {
                string area = project.CommonArea.PadRight(projectSettings.DRAWINGCWADIGIT.Length, '0');
                if (!string.IsNullOrEmpty(area))
                {
                    int l = area.Length;
                    if (l > projectSettings.DRAWINGCWADIGIT.Length && projectSettings.DRAWINGCWADIGIT.Length > 0)
                        area = area.Substring(0, projectSettings.DRAWINGCWADIGIT.Length);
                }
                code = code.Replace(drawingSettings.CWA, area);
            }
            else
                code = code.Replace(drawingSettings.CWA, 0.ToString(projectSettings.DRAWINGCWADIGIT));

            code = code.Replace(drawingSettings.Object, 0.ToString(projectSettings.DRAWINGOBJECTDIGIT));

            string sequence = drawingId.ToString(projectSettings.DRAWINGSEQDIGIT);
            code = code.Replace(drawingSettings.Sequence, sequence);
            return code;
        }
        #endregion
    }
}
