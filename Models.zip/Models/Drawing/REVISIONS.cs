﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;

namespace CivilMasterData.Models
{
    public class REVISIONS
    {
        #region Data
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("RevisionID")]
        [Display(Name = "RevisionID")]
        public int RevisionID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("RevisionNumber")]
        [Display(Name = "RevisionNumber")]
        public int? RevisionNumber { get; set; }
        #endregion

        #region Access members
        [NotMapped]
        public string GetDescription
        {
            get
            {
                string description = RevisionID.ToString();
                if (CreationDate != null && CreationDate.HasValue)
                    description += "-" + CreationDate.Value.ToShortDateString();
                return description;
            }
        }
        #endregion
    }
}
