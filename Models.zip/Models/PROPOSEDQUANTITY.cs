﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class PROPOSEDQUANTITY
    {
        [Key]
        [Column("PROPQTYID")]
        [Display(Name = "PROPQTYID")]
        public int PROPQTYID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "Unit cannot be longer than 32 characters.")]
        public string Unit { get; set; }

        [Column("Area")]
        [Display(Name = "Area")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "Area cannot be longer than 32 characters.")]
        public string Area { get; set; }

        [Column("Qty")]
        [Display(Name = "Quantity")]
        public double Qty { get; set; }
    }
}
