﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class HOLDS
    {
        [Key]
        [Column("HoldId")]
        [Display(Name = "HoldId")]
        public int HoldId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("HoldItemIndex")]
        [Display(Name = "HoldItemIndex")]
        public int HoldItemIndex { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [NotMapped]
        public string DateLastModify
        {
            get
            {
                if (LastModified != null && LastModified.HasValue)
                    return LastModified.Value.ToString("yyyy/MM/dd");
                return string.Empty;
            }
        }

        [NotMapped]
        public string LastModifyUser
        {
            get
            {
                return USERS != null ? USERS.IdentityUserName : string.Empty;
            }
        }

        [Column("QTYHOLD")]
        [Display(Name = "QTYHOLD")]
        public double? QTYHOLD { get; set; }

        [Column("HOLDTYPESID")]
        [Display(Name = "HOLDTYPESID")]
        public int? HOLDTYPESID { get; set; }

        public HOLDTYPES HOLDTYPES { get; set; }

        [Column("HoldStatus")]
        [Display(Name = "HoldStatus")]
        [StringLength(32, MinimumLength = 1, ErrorMessage = "CWA cannot be longer than 32 characters.")]
        public string HoldStatus { get; set; }

        [Column("ForeDateInput")]
        [Display(Name = "ForeDateInput")]
        [DataType(DataType.Date)]
        public DateTime? ForeDateInput { get; set; }
        [NotMapped]
        public string ForeDateInputGUI
        {
            get
            {
                if (ForeDateInput == null || !ForeDateInput.HasValue)
                    return null;
                string val = ForeDateInput.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        [Column("ForeDateRemoval")]
        [Display(Name = "ForeDateRemoval")]
        [DataType(DataType.Date)]
        public DateTime? ForeDateRemoval { get; set; }
        [NotMapped]
        public string ForeDateRemovalGUI
        {
            get
            {
                if (ForeDateRemoval == null || !ForeDateRemoval.HasValue)
                    return null;
                string val = ForeDateRemoval.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }


        [Column("ActualDateRemoval")]
        [Display(Name = "ActualDateInternal")]
        [DataType(DataType.Date)]
        public DateTime? ActualDateRemoval { get; set; }
        [NotMapped]
        public string ActualDateRemovalGUI
        {
            get
            {
                if (ActualDateRemoval == null || !ActualDateRemoval.HasValue)
                    return null;
                string val = ActualDateRemoval.Value.ToString("yyyy/MM/dd");
                return val;
            }
        }

        public HOLDS() { }

        public HOLDS(MAINITEMS mainItem, int userId, int holdType)
        {
            MainItemId = mainItem.MainItemID;
            UserID = userId;
            CreationDate = DateTime.UtcNow;
            LastModified = DateTime.UtcNow;
            QTYHOLD = 0.0;
            HOLDTYPESID = holdType;
            HoldStatus = string.Empty;
        }

        [NotMapped]
        public string GetHoldStatus
        {
            get
            {
                if (ActualDateRemoval == null || !ActualDateRemoval.HasValue)
                    return MainItemsCostants.HOLD_OPEN;
                return MainItemsCostants.HOLD_CLOSED;
            }
        }
    }
}
