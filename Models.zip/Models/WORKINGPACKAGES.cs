﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class WORKINGPACKAGES
    {
        [Key]
        [Column("IDWP")]
        [Display(Name = "IDWP")]
        public int IDWP { get; set; }

        [Column("NAME")]
        [Display(Name = "NAME")]
        public string NAME { get; set; }

        [Column("NOTES")]
        [Display(Name = "DESCRIPTION")]
        public string NOTES { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }
    }
}
