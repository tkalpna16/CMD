﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// QUANTITY_CE_REVISION
    /// </summary>
    public class QUANTITY_CE_REVISION
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }


        [Column("REVISIONSNUMBER")]
        [Display(Name = "REVISIONSNUMBER")]
        public int REVISIONSNUMBER { get; set; }

        [NotMapped]
        public string GetDescription
        {
            get 
            {
                string description = "Revision " + REVISIONSNUMBER.ToString();
                if (CreationDate != null && CreationDate.HasValue)
                    description += "-" + CreationDate.Value.ToString("MM.dd.yyyy");
                return description;
            }
        }
    }
}
