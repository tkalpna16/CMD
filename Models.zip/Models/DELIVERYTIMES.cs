﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class DELIVERYTIMES
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS PROJECTS { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("Date11")]
        [Display(Name = "Date11")]
        public string Date11 { get; set; }

        [Column("Date21")]
        [Display(Name = "Date21")]
        public string Date21 { get; set; }

        [Column("Value1")]
        [Display(Name = "Value1")]
        public int Value1 { get; set; }


        [Column("Date12")]
        [Display(Name = "Date12")]
        public string Date12 { get; set; }

        [Column("Date22")]
        [Display(Name = "Date22")]
        public string Date22 { get; set; }

        [Column("Value2")]
        [Display(Name = "Value2")]
        public int Value2 { get; set; }


        [Column("Date13")]
        [Display(Name = "Date13")]
        public string Date13 { get; set; }

        [Column("Date23")]
        [Display(Name = "Date23")]
        public string Date23 { get; set; }

        [Column("Value3")]
        [Display(Name = "Value3")]
        public int Value3 { get; set; }

        [Column("Date14")]
        [Display(Name = "Date14")]
        public string Date14 { get; set; }

        [Column("Date24")]
        [Display(Name = "Date24")]
        public string Date24 { get; set; }

        [Column("Value4")]
        [Display(Name = "Value4")]
        public int Value4 { get; set; }

        [Column("Date15")]
        [Display(Name = "Date15")]
        public string Date15 { get; set; }

        [Column("Date25")]
        [Display(Name = "Date25")]
        public string Date25 { get; set; }

        [Column("Value5")]
        [Display(Name = "Value5")]
        public int Value5 { get; set; }

        [Column("Date16")]
        [Display(Name = "Date16")]
        public string Date16 { get; set; }

        [Column("Date26")]
        [Display(Name = "Date26")]
        public string Date26 { get; set; }

        [Column("Value6")]
        [Display(Name = "Value6")]
        public int Value6 { get; set; }


        [Column("Date17")]
        [Display(Name = "Date17")]
        public string Date17 { get; set; }

        [Column("Date27")]
        [Display(Name = "Date27")]
        public string Date27 { get; set; }

        [Column("Value7")]
        [Display(Name = "Value7")]
        public int Value7 { get; set; }


        [Column("Date18")]
        [Display(Name = "Date18")]
        public string Date18 { get; set; }

        [Column("Date28")]
        [Display(Name = "Date28")]
        public string Date28 { get; set; }

        [Column("Value8")]
        [Display(Name = "Value8")]
        public int Value8 { get; set; }


        [Column("Date19")]
        [Display(Name = "Date19")]
        public string Date19 { get; set; }

        [Column("Date29")]
        [Display(Name = "Date29")]
        public string Date29 { get; set; }

        [Column("Value9")]
        [Display(Name = "Value9")]
        public int Value9 { get; set; }


        [Column("Date110")]
        [Display(Name = "Date110")]
        public string Date110 { get; set; }

        [Column("Date210")]
        [Display(Name = "Date210")]
        public string Date210 { get; set; }

        [Column("Value10")]
        [Display(Name = "Value10")]
        public int Value10 { get; set; }


        [Column("Date111")]
        [Display(Name = "Date111")]
        public string Date111 { get; set; }

        [Column("Date211")]
        [Display(Name = "Date211")]
        public string Date211 { get; set; }

        [Column("Value11")]
        [Display(Name = "Value11")]
        public int Value11 { get; set; }


        [Column("Date112")]
        [Display(Name = "Date112")]
        public string Date112 { get; set; }

        [Column("Date212")]
        [Display(Name = "Date212")]
        public string Date212 { get; set; }

        [Column("Value12")]
        [Display(Name = "Value12")]
        public int Value12 { get; set; }


        [Column("Date113")]
        [Display(Name = "Date113")]
        public string Date113 { get; set; }

        [Column("Date213")]
        [Display(Name = "Date213")]
        public string Date213 { get; set; }

        [Column("Value13")]
        [Display(Name = "Value13")]
        public int Value13 { get; set; }


        [Column("Date114")]
        [Display(Name = "Date114")]
        public string Date114 { get; set; }

        [Column("Date214")]
        [Display(Name = "Date214")]
        public string Date214 { get; set; }

        [Column("Value14")]
        [Display(Name = "Value14")]
        public int Value14 { get; set; }


        [Column("Date115")]
        [Display(Name = "Date115")]
        public string Date115 { get; set; }

        [Column("Date215")]
        [Display(Name = "Date215")]
        public string Date215 { get; set; }

        [Column("Value15")]
        [Display(Name = "Value15")]
        public int Value15 { get; set; }


        public DELIVERYTIMES() { }

        public void InitValueToDefault()
        {
            Date11 = "DATE IFC FORECAST";
            Date21 = "DATE IFC BASELINE (ENG)";
            Value1 = 0;

            Date12 = "DATE IFC QUALITY CHECK FORECAST";
            Date22 = "DATE IFC FORECAST";
            Value2 = 0;

            Date13 = "DATE IFR FORECAST";
            Date23 = "DATE IFR BASELINE (ENG)";
            Value3 = 0;

            Date14 = "DATE IFR QUALITY CHECK FORECAST";
            Date24 = "DATE IFR FORECAST";
            Value4 = 0;

            Date15 = "DATE INPUT FORECAST";
            Date25 = "DATE IFR QUALITY CHECK FORECAST";
            Value5 = 0;

            Date16 = string.Empty;
            Date26 = string.Empty;
            Value6 = 0;

            Date17 = string.Empty;
            Date27 = string.Empty;
            Value7 = 0;

            Date18 = string.Empty;
            Date28 = string.Empty;
            Value8 = 0;

            Date19 = string.Empty;
            Date29 = string.Empty;
            Value9 = 0;

            Date110 = string.Empty;
            Date210 = string.Empty;
            Value10 = 0;

            Date111 = string.Empty;
            Date211 = string.Empty;
            Value11 = 0;

            Date112 = string.Empty;
            Date212 = string.Empty;
            Value12 = 0;

            Date113 = string.Empty;
            Date213 = string.Empty;
            Value13 = 0;

            Date114 = string.Empty;
            Date214 = string.Empty;
            Value14 = 0;

            Date115 = string.Empty;
            Date215 = string.Empty;
            Value15 = 0;
        }
    }
}
