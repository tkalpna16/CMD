﻿using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Helpers;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using UnitsNet;
using UnitsNet.Units;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class MAINITEMS
    {
        [Key]
        [Column("MainItemID")]
        [Display(Name = "MainItemID")]
        public int MainItemID { get; set; }

        [Column("PBSID")]
        [Display(Name = "PBSID")]
        public int PBSID { get; set; }

        public PBS PBS { get; set; }

        [Column("LV01_Object_CodeID")]
        [Display(Name = "LV01_Object_CodeID")]
        public int? LV01_Object_CodeID { get; set; }

        public OBJECTCODES LV01_Object_Code { get; set; }

        [Column("LV01_Material_Work_GroupID")]
        [Display(Name = "LV01_Material_Work_GroupID")]
        public int? LV01_Material_Work_GroupID { get; set; }

        public MATERIALWORKGROUPS LV01_Material_Work_Group { get; set; }

        [Column("TagTypeID")]
        [Display(Name = "TagTypeID")]
        public int TagTypeID { get; set; }

        public TAGTYPES TAGTYPES { get; set; }

        [Column("MainItemTag")]
        [Display(Name = "MainItemTag")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Main Item cannot be longer than 32 characters.")]
        public string MainItemTag { get; set; }

        [Column("WORKINGPACKAGESID")]
        [Display(Name = "WORKINGPACKAGESID")]
        public int? WORKINGPACKAGESID { get; set; }

        public WORKINGPACKAGES WORKINGPACKAGES { get; set; }

        [Column("TagDescription")]
        [Display(Name = "TagDescription")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Tag Description cannot be longer than 32 characters.")]
        public string TagDescription { get; set; }

        [Column("TagClient")]
        [Display(Name = "TagDescription")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Tag Client cannot be longer than 32 characters.")]
        public string TagClient { get; set; }

        [Column("DrawNo")]
        [Display(Name = "DrawNo")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Tag Client cannot be longer than 32 characters.")]
        public string DrawNo { get; set; }

        [Column("ElDrawNo")]
        [Display(Name = "ElDrawNo")]
        [StringLength(128, MinimumLength = 1, ErrorMessage = "Tag Client cannot be longer than 32 characters.")]
        public string ElDrawNo { get; set; }

        [Column("OptRatio")]
        [Display(Name = "OPTRATIO")]
        public double? OPTRATIO { get; set; }

        [Column("TCMCode")]
        [Display(Name = "TCMCode")]
        public string TCMCode { get; set; }

        [Column("DRAWREV")]
        [Display(Name = "DRAWREV")]
        public string DRAWREV { get; set; }

        [Column("AddedManually")]
        [Display(Name = "AddedManually")]
        public int? AddedManually { get; set; }

        [Column("MAINITEMSTATUSID")]
        [Display(Name = "MAINITEMSTATUSID")]
        public int? MAINITEMSTATUSID { get; set; }

        public MAINITEMSTATUS MAINITEMSTATUS { get; set; }

        [Column("PARENTID")]
        [Display(Name = "PARENTID")]
        public int? PARENTID { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        [NotMapped]
        public string PARENT_TAG { get; set; }

        [NotMapped]
        public List<WORKINGPACKAGES> WORKINGPACKAGELIST  { get; set; }

        [Column("BALANCE")]
        [Display(Name = "BALANCE")]
        public int? BALANCE { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("LOTSID")]
        [Display(Name = "LOTSID")]
        public int? LOTSID { get; set; }

        public LOTS LOTS { get; set; }

        [Column("VENDORSID")]
        [Display(Name = "VENDORSID")]
        public int? VENDORSID { get; set; }

        public VENDORS VENDORS { get; set; }

        [Column("MATERIALREQUESTSID")]
        [Display(Name = "MATERIALREQUESTSID")]
        public int? MATERIALREQUESTSID { get; set; }

        public MATERIALREQUESTS MATERIALREQUESTS { get; set; }

        [Column("PURCHASEORDERSID")]
        [Display(Name = "PURCHASEORDERSID")]
        public int? PURCHASEORDERSID { get; set; }

        public PURCHASEORDERS PURCHASEORDERS { get; set; }

        [Column("BaseSurfaceArea")]
        [Display(Name = "BaseSurfaceArea")]
        public double? BASESURFACEAREA { get; set; }

        [Column("Volume")]
        [Display(Name = "Volume")]
        public double? VOLUME { get; set; }

        [Column("MainFloors")]
        [Display(Name = "MainFloors")]
        public int? MAINFLOORS { get; set; }

        [Column("Modules")]
        [Display(Name = "Modules")]
        public int? MODULES { get; set; }

        [Column("EquipmentTag")]
        [Display(Name = "EquipmentTag")]
        public string EquipmentTag { get; set; }

        [Column("EquipmentLayout")]
        [Display(Name = "EquipmentLayout")]
        public string EquipmentLayout { get; set; }

        [Column("Length")]
        [Display(Name = "Length")]
        public double? Length { get; set; }

        [Column("Width")]
        [Display(Name = "Width")]
        public double? Width { get; set; }

        [Column("ConcreteHeight")]
        [Display(Name = "ConcreteHeight")]
        public double? ConcreteHeight { get; set; }

        [Column("ConcreteLevels")]
        [Display(Name = "ConcreteLevels")]
        public int? ConcreteLevels { get; set; }

        [Column("SteelHeight")]
        [Display(Name = "SteelHeight")]
        public double? SteelHeight { get; set; }

        [Column("SteelLevels")]
        [Display(Name = "SteelLevels")]
        public int? SteelLevels { get; set; }

        [Column("IMPORTANCESTATUSID")]
        [Display(Name = "IMPORTANCESTATUSID")]
        public int? IMPORTANCESTATUSID { get; set; }

        public IMPORTANCESTATUS IMPORTANCESTATUS { get; set; }

        [Column("Remarks")]
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }

        [Column("SubContractor")]
        [Display(Name = "SubContractor")]
        public string SubContractor { get; set; }

        [Column("UserDescription")]
        [Display(Name = "UserDescription")]
        public string UserDescription { get; set; }

        [Column("DrawRevAcc")]
        [Display(Name = "DrawRevAcc")]
        public string DrawRevAcc { get; set; }

        [Column("MRNO")]
        [Display(Name = "MRNO")]
        public string MRNO { get; set; }


        [Column("AddedFromBIM360")]
        [Display(Name = "AddedFromBIM360")]
        public int? AddedFromBIM360 { get; set; }

        [Column("ModelName")]
        [Display(Name = "MODELNAME")]
        public string ModelName { get; set; }

        [NotMapped]
        public string DateLastModify
        {
            get
            {
                if (LastModified != null && LastModified.HasValue)
                    return LastModified.Value.ToString("yyyy/MM/dd");
                return string.Empty;
            }
        }

        [NotMapped]
        public string LastModifyUser
        {
            get
            {
                return USERS != null ? USERS.IdentityUserName : string.Empty;
            }
        }

        public bool IsEquipmentTag
        {

            get
            {
                if (LV01_Object_Code != null)
                {
                    string objectCode = LV01_Object_Code.Code;
                    if (objectCode == "EQ")
                        return true;
                    else if (!string.IsNullOrEmpty(LV01_Object_Code.Behaviour))
                    {
                        if (LV01_Object_Code.Behaviour == "EQ")
                            return true;
                    }
                }
                return false;
            }
        }

        public bool IsPipeRack
        {

            get
            {
                if (LV01_Object_Code != null)
                {
                    string objectCode = LV01_Object_Code.Code;
                    if (objectCode == "PR")
                        return true;
                    else if (!string.IsNullOrEmpty(LV01_Object_Code.Behaviour))
                    {
                        if (LV01_Object_Code.Behaviour == "PR")
                            return true;
                    }
                }
                return false;
            }
        }

        [NotMapped]
        public double SteelVolume
        {
            get
            {
                double l = 0.0;
                if (this.Length != null && this.Length.HasValue)
                    l = this.Length.Value;
                double w = 0.0;
                if (this.Width != null && this.Width.HasValue)
                    w = this.Width.Value;
                double h = 0.0;
                if (this.SteelHeight != null && this.SteelHeight.HasValue)
                    h = this.SteelHeight.Value;

                return l * w * h;
            }
        }

        [NotMapped]
        public string MainItemTagAsArea
        {
            get
            {
                return MainItemTag.Split("-")[0];
            }
        }

        [NotMapped]
        public string QtyUnits
        {
            get
            {
                return TAGTYPES.QtyUnits(PROJECTSETTINGS, TagTypeID);
            }
        }

        [NotMapped]
        public PLANNINGS PLANNINGS { get; set; }

        /// <summary>
        /// Only text parameters
        /// </summary>
        [NotMapped]
        public List<MAINITEMPARAMETERVALUES> ParameterValues { get; set; }


        #region Parameters

        [NotMapped]
        public string GetParameter1
        {
            get { return GetParameterValue(0); }
        }
        [NotMapped]
        public string GetParameter2
        {
            get { return GetParameterValue(1); }
        }
        [NotMapped]
        public string GetParameter3
        {
            get { return GetParameterValue(2); }
        }
        [NotMapped]
        public string GetParameter4
        {
            get { return GetParameterValue(3); }
        }
        [NotMapped]
        public string GetParameter5
        {
            get { return GetParameterValue(4); }
        }
        [NotMapped]
        public string GetParameter6
        {
            get { return GetParameterValue(5); }
        }
        [NotMapped]
        public string GetParameter7
        {
            get { return GetParameterValue(6); }
        }
        [NotMapped]
        public string GetParameter8
        {
            get { return GetParameterValue(7); }
        }
        [NotMapped]
        public string GetParameter9
        {
            get { return GetParameterValue(8); }
        }
        [NotMapped]
        public string GetParameter10
        {
            get { return GetParameterValue(9); }
        }
        [NotMapped]
        public string GetParameter11
        {
            get { return GetParameterValue(10); }
        }
        [NotMapped]
        public string GetParameter12
        {
            get { return GetParameterValue(11); }
        }
        [NotMapped]
        public string GetParameter13
        {
            get { return GetParameterValue(12); }
        }
        [NotMapped]
        public string GetParameter14
        {
            get { return GetParameterValue(13); }
        }
        [NotMapped]
        public string GetParameter15
        {
            get { return GetParameterValue(14); }
        }
        [NotMapped]
        public string GetParameter16
        {
            get { return GetParameterValue(15); }
        }
        [NotMapped]
        public string GetParameter17
        {
            get { return GetParameterValue(16); }
        }
        [NotMapped]
        public string GetParameter18
        {
            get { return GetParameterValue(17); }
        }
        [NotMapped]
        public string GetParameter19
        {
            get { return GetParameterValue(18); }
        }
        [NotMapped]
        public string GetParameter20
        {
            get { return GetParameterValue(19); }
        }




        [NotMapped]
        public double? GetParameterQty1
        {
            get { return GetParameterValueQty(0); }
        }
        [NotMapped]
        public double? GetParameterQty2
        {
            get { return GetParameterValueQty(1); }
        }
        [NotMapped]
        public double? GetParameterQty3
        {
            get { return GetParameterValueQty(2); }
        }
        [NotMapped]
        public double? GetParameterQty4
        {
            get { return GetParameterValueQty(3); }
        }
        [NotMapped]
        public double? GetParameterQty5
        {
            get { return GetParameterValueQty(4); }
        }
        [NotMapped]
        public double? GetParameterQty6
        {
            get { return GetParameterValueQty(5); }
        }
        [NotMapped]
        public double? GetParameterQty7
        {
            get { return GetParameterValueQty(6); }
        }
        [NotMapped]
        public double? GetParameterQty8
        {
            get { return GetParameterValueQty(7); }
        }
        [NotMapped]
        public double? GetParameterQty9
        {
            get { return GetParameterValueQty(8); }
        }
        [NotMapped]
        public double? GetParameterQty10
        {
            get { return GetParameterValueQty(9); }
        }
        #endregion

        [NotMapped]
        public bool IsBalance
        {
            get { return BALANCE != null ? BALANCE.Value > 0 : false; }
        }

        [NotMapped]
        public double Footprint
        {
            get
            {
                double l = Length != null && Length.HasValue ? Length.Value : 0.0;
                double w = Width != null && Width.HasValue ? Width.Value : 0.0;
                return l * w;
            }
        }

        [NotMapped]
        public string WPName
        {
            get { return WORKINGPACKAGES != null ? WORKINGPACKAGES.NAME : null; }
        }

        [NotMapped]
        public string MainItemTagWithoutMaterial
        {
            get
            {
                if (IsBalance)
                    return MainItemTag;
                if (string.IsNullOrEmpty(MainItemTag))
                    return string.Empty;

                string tag = MainItemTag;
                string material = string.Empty;
                if (LV01_Material_Work_Group != null)
                {
                    material = LV01_Material_Work_Group.GroupCode;
                    if (tag.EndsWith(material))
                        tag = tag.Remove(tag.Length - material.Length, material.Length);
                }
                return tag;
            }
        }

        public string GetParameterValue(int index)
        {
            string value = string.Empty;
            if (ParameterValues != null && ParameterValues.Count > index)
                value = ParameterValues[index].PARAMETERTEXT;
            return value;
        }

        public double? GetParameterValueQty(int index)
        {
            if (ParameterValues != null && ParameterValues.Count > index)
                return ParameterValues[index].PARAMETERDOUBLE;
            return null;
        }

        public string CalculateMainTag(int id, bool considerMaterialWorkGroup)
        {
            string separator = "-";
            string value = PBS.Area + separator;
            value += LV01_Object_Code.Code + id.ToString("000");
            if (considerMaterialWorkGroup && LV01_Material_Work_Group != null)
                value += LV01_Material_Work_Group.GroupCode;
            return value;
        }

        public string CalculateMainTag(string sequence, bool considerMaterialWorkGroup)
        {
            string separator = "-";
            string value = PBS.Area + separator;
            value += LV01_Object_Code.Code;
            if (!string.IsNullOrEmpty(sequence))
                value += sequence;
            if (considerMaterialWorkGroup && LV01_Material_Work_Group != null)
                value += LV01_Material_Work_Group.GroupCode;
            return value;
        }

        [NotMapped]
        public MAIN_ITEM_QUANTITY ITEM_QUANTITY { get; set; }

        [NotMapped]
        public string Status
        {
            get
            {
                if (MAINITEMSTATUSID != null && MAINITEMSTATUSID.HasValue)
                {
                    int value = MAINITEMSTATUSID.Value;
                    if (value == MainItemsCostants.REPLACED)
                        return "Replaced";
                    else if (value == MainItemsCostants.REPLACER)
                        return "Replacer";
                    else if (value == MainItemsCostants.COMBINED)
                        return "Combined";
                    else if (value == MainItemsCostants.DELETED)
                        return "Deleted";
                }
                return string.Empty;
            }
        }

        [NotMapped]
        public string Description
        {
            get
            {
                return MainItemTag + "-" + TAGTYPES.Description;
            } 
        }

        [NotMapped]
        public string CompleteDescription
        {
            get
            {
                return MainItemTag + "-" + TAGTYPES.Description + "-" + LOTS.NAME;
            }
        }

        [NotMapped]
        public MainItemData GetItemData
        {
            get
            {
                MainItemData mainItemData = new MainItemData();
                mainItemData.Description = Description;
                mainItemData.Area = PBS != null ? PBS.Area : string.Empty;
                mainItemData.WP = WORKINGPACKAGES != null ? WORKINGPACKAGES.NAME : string.Empty;
                mainItemData.ObjectCode = LV01_Object_Code != null ? LV01_Object_Code.Code : string.Empty;
                mainItemData.Material = LV01_Material_Work_Group != null ? LV01_Material_Work_Group.GroupCode : string.Empty;
                mainItemData.TagType = TAGTYPES != null ? TAGTYPES.Description : string.Empty;
                mainItemData.TagClient = TagClient;
                mainItemData.TagDescription = TagDescription;
                mainItemData.Lot = LOTS != null ? LOTS.NAME : string.Empty;
                return mainItemData;
            }
        }

        public static List<MAINITEMS> ReorderMainItems(List<MAINITEMS> mAINITEMs)
        {
            List<int> addedIds = new List<int>();
            List<MAINITEMS> orderedList = new List<MAINITEMS>();
            if (mAINITEMs != null)
            {
                mAINITEMs = mAINITEMs.OrderBy(m => m.IsReplaced).ToList();
                foreach (MAINITEMS item in mAINITEMs)
                {
                    if (item.IsReplaced)
                    {
                        if (!addedIds.Contains(item.MainItemID))
                        {
                            orderedList.Add(item);
                            addedIds.Add(item.MainItemID);
                        }
                        foreach (MAINITEMS item2 in mAINITEMs)
                            if (item2.PARENTID.HasValue && item2.PARENTID.Value == item.MainItemID)
                            {
                                if (!addedIds.Contains(item2.MainItemID))
                                {
                                    orderedList.Add(item2);
                                    addedIds.Add(item2.MainItemID);
                                }
                            }
                    }
                    else if (item.PARENTID.HasValue)
                    {
                        continue;
                    }
                    else
                    {
                        if (!addedIds.Contains(item.MainItemID))
                        {
                            orderedList.Add(item);
                            addedIds.Add(item.MainItemID);
                        }
                    }
                }
            }
            return orderedList;
        }

        [NotMapped]
        public List<MTOREVS> MAIN_ITEM_QTY_REV { get; set; }

        [NotMapped]
        public List<BIM360ITEMSTATUS> BIM360ITEMSTATUS { get; set; }


        [NotMapped]
        public PROJECTSETTINGS PROJECTSETTINGS { get; set; }

        [NotMapped]
        public double GetQty
        {
            get
            {
                if (BIM360ITEMSTATUS != null && BIM360ITEMSTATUS.Count > 0)
                {
                    var lastQty = BIM360ITEMSTATUS.OrderByDescending(q => q.ID).FirstOrDefault();
                    if (PROJECTSETTINGS == null)
                        return lastQty.QtyRounded;
                    else
                    {
                        if (TagTypeID == DatabaseCostants.TagType_Foundation_ID)
                        {
                            Volume volume = new Volume(lastQty.QtyRounded, VolumeUnit.CubicMeter);
                            var units = Volume.Units;
                            foreach(var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.FOUNDATIONCONCRETEUNIT)
                                    return System.Math.Round(volume.ToUnit(unit).Value, 1);
                            }
                            return lastQty.QtyRounded;
                        }
                        else if (TagTypeID == DatabaseCostants.TagType_Elevation_ID)
                        {
                            Volume volume = new Volume(lastQty.QtyRounded, VolumeUnit.CubicMeter);
                            var units = Volume.Units;
                            foreach (var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.ELEVATIONCONCRETEUNIT)
                                    return System.Math.Round(volume.ToUnit(unit).Value, 1);
                            }
                            return lastQty.QtyRounded;
                        }
                        else if (TagTypeID == DatabaseCostants.TagType_Paving_ID)
                        {
                            Volume volume = new Volume(lastQty.QtyRounded, VolumeUnit.CubicMeter);
                            var units = Volume.Units;
                            foreach (var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.PAVINGUNIT)
                                    return System.Math.Round(volume.ToUnit(unit).Value, 3);
                            }
                            return lastQty.QtyRounded;
                        }
                        else if (TagTypeID == DatabaseCostants.TagType_Pile_ID)
                        {
                            Length length = new Length(lastQty.QtyRounded, LengthUnit.Meter);
                            var units = UnitsNet.Length.Units;
                            foreach (var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.PILESUNIT)
                                    return System.Math.Round(length.ToUnit(unit).Value, 1);
                            }
                            return lastQty.QtyRounded;
                        }
                        else if (TagTypeID == DatabaseCostants.TagType_UndergroundPipe_ID)
                        {
                            Length length = new Length(lastQty.QtyRounded, LengthUnit.Meter);
                            var units = UnitsNet.Length.Units;
                            foreach (var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.UNDERGROUNDPIPEUNIT)
                                    return System.Math.Round(length.ToUnit(unit).Value, 3);
                            }
                            return lastQty.QtyRounded;
                        }
                        else if (TagTypeID == DatabaseCostants.TagType_Steel_ID)
                        {
                            Mass mass = new Mass(lastQty.QtyRounded, MassUnit.Kilogram);
                            var units = UnitsNet.Mass.Units;
                            foreach (var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.STEELUNIT)
                                    return System.Math.Round(mass.ToUnit(unit).Value, 1);
                            }
                        }
                        else if (TagTypeID == DatabaseCostants.TagType_Ground_Slab_Concrete_ID)
                        {
                            Volume volume = new Volume(lastQty.QtyRounded, VolumeUnit.CubicMeter);
                            var units = Volume.Units;
                            foreach (var unit in units)
                            {
                                if (unit.ToString() == PROJECTSETTINGS.CONCRETESLABUNIT)
                                    return System.Math.Round(volume.ToUnit(unit).Value, 1);
                            }
                            return lastQty.QtyRounded;
                        }
                        //else if (TagTypeID == DatabaseCostants.TagType_UndergroundPit_ID)
                        //{
                        //    Mass mass = new Mass(lastQty.QtyRounded, MassUnit.Kilogram);
                        //    var units = UnitsNet.Mass.Units;
                        //    foreach (var unit in units)
                        //    {
                        //        if (unit.ToString() == PROJECTSETTINGS.STEELUNIT)
                        //            return System.Math.Round(mass.ToUnit(unit).Value, 1);
                        //    }
                        //}
                        else
                            return lastQty.QtyRounded;
                    }
                }
                return 0.0;
            }
        }


        [NotMapped]
        public List<HOLDS> HOLDS { get; set; }

        [NotMapped]
        public string GetHoldStatus
        {
            get
            {
                if (HOLDS != null && HOLDS.Count > 0)
                {
                    foreach(HOLDS hold in HOLDS)
                    {
                        if (hold.ActualDateRemoval == null || !hold.ActualDateRemoval.HasValue)
                            return MainItemsCostants.HOLD_OPEN;
                    }
                    return MainItemsCostants.HOLD_CLOSED;
                }
                return string.Empty;
            }
        }

        [NotMapped]
        public double Qty3dHold
        {
            get
            {
                if (BIM360ITEMSTATUS != null && BIM360ITEMSTATUS.Count > 0)
                {
                    var lastQty = BIM360ITEMSTATUS.OrderByDescending(q => q.ID).FirstOrDefault();
                    return lastQty.QtyHoldRounded;
                }
                return 0.0;
            }
        }

        [NotMapped]
        public string GetEngStatus
        {
            get
            {
                if (ITEM_QUANTITY != null)
                {
                    if (ITEM_QUANTITY.QTY_IFC != null && ITEM_QUANTITY.QTY_IFC.HasValue && ITEM_QUANTITY.QTY_IFC.Value > 0.0)
                        return "IFC";
                    if (ITEM_QUANTITY.QTY_IFR != null && ITEM_QUANTITY.QTY_IFR.HasValue && ITEM_QUANTITY.QTY_IFR.Value > 0.0)
                        return "IFR";
                }
                if (BIM360ITEMSTATUS != null && BIM360ITEMSTATUS.Count > 0)
                {
                    var qty = GetQty;
                    if (qty > 0.0)
                        return "IFB";
                }
                return "-";
            }
        }

        [NotMapped]
        public double TotalQtyHold { get; set; }
        /// <summary>
        /// Se tutti gli Hold di una struttura risultano “CLOSED” ma il valore di “3D QTY HOLD” risulta essere ancora diverso da zero il campo “3D QTY HOLD” deve evidenziarsi di rosso
        /// </summary>
        [NotMapped]
        public bool ValidHoldModelConnectorClosed { get; set; }

        /// <summary>
        /// Se un qualsiasi Hold di una struttura risulta “OPEN” ma il valore di “3D QTY HOLD” risulta essere uguale a zero il campo “3D QTY HOLD” deve evidenziarsi di rosso.
        /// </summary>
        [NotMapped]
        public bool ValidHoldModelConnectorOpen { get; set; }

        /// <summary>
        /// per una singola struttura la somma delle quantità presenti nella colonna “QTY HOLD” deve sempre essere minore della “QTY LAST ISSUE” del modulo Quantity Manager. Se questa condizione non e’ verificata, la cella “QTY HOLD” deve essere evidenziata in rosso.
        /// </summary>
        [NotMapped]
        public bool ValidQtyHold
        {
            get
            {
                double qtyLastIssue = 0.0;
                if (ITEM_QUANTITY != null)
                    qtyLastIssue = ITEM_QUANTITY.QTY_LAST_ISSUE;
                return DoubleExtension.LessThanOrClose(TotalQtyHold, qtyLastIssue, 0.001);
            }
        }

        [NotMapped]
        public int? GetPilesCount
        {
            get
            {
                if (TagTypeID != DatabaseCostants.TagType_Pile_ID)
                    return null;
                if (BIM360ITEMSTATUS != null && BIM360ITEMSTATUS.Count > 0)
                {
                    var lastQty = BIM360ITEMSTATUS.OrderByDescending(q => q.ID).FirstOrDefault();
                    return lastQty.COUNT;
                }
                return null;
            }
        }
        [NotMapped]
        public string GetModelDate
        {
            get
            {
                if (BIM360ITEMSTATUS != null && BIM360ITEMSTATUS.Count > 0)
                {
                    var lastQty = BIM360ITEMSTATUS.OrderByDescending(q => q.ID).FirstOrDefault();
                    return lastQty.ModelDate;
                }
                return string.Empty;
            }
        }

        private double? CalculateModelQty(int engStatusIndex, int modelStatus)
        {
            MTOREVS lastBudget = null;
            if (MAIN_ITEM_QTY_REV != null)
            {
                foreach (MTOREVS rev in MAIN_ITEM_QTY_REV)
                {
                    if (rev.STATUSID == engStatusIndex && rev.MODELSTATUSID == modelStatus)
                    {
                        if (lastBudget == null)
                            lastBudget = rev;
                        else
                        {
                            if (lastBudget.REVID.Value < rev.REVID.Value)
                                lastBudget = rev;
                        }
                    }
                }
            }
            if (lastBudget == null)
                return null;
            else
            {
                if (lastBudget.QTY != null && lastBudget.QTY.HasValue)
                    lastBudget.QTY = System.Math.Round(lastBudget.QTY.Value, 2);
                return lastBudget.QTY;
            }
        }

        [NotMapped]
        public double? CalculateQtyBudgetFromModel
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.BUDGET_ID, 2);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFBFromModel
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.IFB_ID, 2);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFRFromModel
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.IFR_ID, 2);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFCFromModel
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.IFC_ID, 2);
            }
        }

        [NotMapped]
        public double? CalculateQtyBudgetManual
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.BUDGET_ID, 1);
            }
        }

        [NotMapped]
        public bool IsReplaced
        {
            get
            {
                if (MAINITEMSTATUSID != null && MAINITEMSTATUSID.HasValue)
                    return MAINITEMSTATUSID.Value == MainItemsCostants.REPLACED;
                return false;
            }
        }

        [NotMapped]
        public bool ConsiderForBIM360
        {
            get
            {
                return !IsReplaced && !IsDeleted;
            }
        }

        [NotMapped]
        public bool IsDeleted
        {
            get
            {
                if (MAINITEMSTATUSID != null && MAINITEMSTATUSID.HasValue)
                    return MAINITEMSTATUSID.Value == MainItemsCostants.DELETED;
                return false;
            }
        }

        [NotMapped]
        public double? CalculateQtyIFBManual
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.IFB_ID, 1);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFRManual
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.IFR_ID, 1);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFCManual
        {
            get
            {
                return CalculateModelQty(EngStatusCostants.IFC_ID, 1);
            }
        }

        [NotMapped]
        public double? FoundationFactor { get; set; }
        [NotMapped]
        public string FoundationFactorDescription { get; set; }
        [NotMapped]
        public double? ElevationFactor { get; set; }
        [NotMapped]
        public string ElevationFactorDescription { get; set; }

        [NotMapped]
        public AADCSETTINGS AADCSETTINGS { get; set; }

        [NotMapped]
        public AIDUSETTINGS AIDUSETTINGS { get; set; }

        [NotMapped]
        public int TotalDocuments { get; set; }

        public void UpdateDrawingFactors(List<AADCFACTORS> aadcFactors,
            List<AIDUFACTORS> aiduFactors,
            int foundationTagType, 
            int elevationTagType,
            int steelTagType)
        {
            if (IsBalance)
                return;

            if (LV01_Object_Code == null)
            {
                FoundationFactor = null;
                FoundationFactorDescription = null;
                ElevationFactor = null;
                ElevationFactorDescription = null;
                return;
            }

            List<AADCFACTORS> filteredAadcFactors = aadcFactors.Where(f => f.TagTypeID == TagTypeID &&
                LV01_Object_Code.Code == f.LV01_Object_Code.Code).ToList();
            if (filteredAadcFactors == null || filteredAadcFactors.Count == 0)
            {
                filteredAadcFactors = aadcFactors.Where(f => f.TagTypeID == TagTypeID &&
                    LV01_Object_Code.Behaviour == f.LV01_Object_Code.Code).ToList();
            }

            List<AIDUFACTORS> filteredAiduFactors = aiduFactors.Where(f => f.TagTypeID == TagTypeID &&
                LV01_Object_Code.Code == f.LV01_Object_Code.Code).ToList();
            if (filteredAiduFactors == null || filteredAiduFactors.Count == 0)
            {
                filteredAiduFactors = aiduFactors.Where(f => f.TagTypeID == TagTypeID &&
                    LV01_Object_Code.Behaviour == f.LV01_Object_Code.Code).ToList();
            }

            string objectCode = LV01_Object_Code.Code;
            if (TagTypeID == foundationTagType)
            {
                if (!LV01_Object_Code.SupportCode("EQ"))
                {
                    if (filteredAadcFactors == null || filteredAadcFactors.Count == 0)
                    {
                        FoundationFactor = 1.0;
                        FoundationFactorDescription = "DEFAULT (1)";
                        ElevationFactor = null;
                        ElevationFactorDescription = null;
                    }
                    else
                    {
                        double area = Footprint;
                        filteredAadcFactors = filteredAadcFactors.OrderBy(f => f.MinValue).ToList();
                        foreach (var factor in filteredAadcFactors)
                        {
                            if (area <= factor.MaxValue)
                            {
                                FoundationFactor = factor.FactorValue;
                                FoundationFactorDescription = factor.Code;
                                ElevationFactor = null;
                                ElevationFactorDescription = null;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    if (IMPORTANCESTATUS != null)
                    {
                        FoundationFactor = IMPORTANCESTATUS.FoundationCoefficient;
                        FoundationFactorDescription = IMPORTANCESTATUS.Description;
                        ElevationFactor = null;
                        ElevationFactorDescription = null;
                    }
                    else
                    {
                        FoundationFactor = 0.75;
                        FoundationFactorDescription = "MINOR(0.75)";
                        ElevationFactor = null;
                        ElevationFactorDescription = null;
                    }
                }
            }
            else if(TagTypeID == elevationTagType)
            {
                if (!LV01_Object_Code.SupportCode("EQ"))
                {
                    if (filteredAadcFactors == null || filteredAadcFactors.Count == 0)
                    {
                        FoundationFactor = null;
                        FoundationFactorDescription = null;
                        ElevationFactor = 1.0;
                        ElevationFactorDescription = "DEFAULT (1)";
                    }
                    else
                    {
                        double area = Footprint;
                        filteredAadcFactors = filteredAadcFactors.OrderBy(f => f.MinValue).ToList();
                        foreach (var factor in filteredAadcFactors)
                        {
                            if (area <= factor.MaxValue)
                            {
                                ElevationFactor = factor.FactorValue;
                                ElevationFactorDescription = factor.Code;
                                FoundationFactor = null;
                                FoundationFactorDescription = null;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    if (IMPORTANCESTATUS != null)
                    {
                        ElevationFactor = IMPORTANCESTATUS.FoundationCoefficient;
                        ElevationFactorDescription = IMPORTANCESTATUS.Description;
                        FoundationFactor = null;
                        FoundationFactorDescription = null;
                    }
                    else
                    {
                        FoundationFactor = 0.75;
                        FoundationFactorDescription = "MINOR(0.75)";
                        ElevationFactor = null;
                        ElevationFactorDescription = null;
                    }
                }
            }
            else if (TagTypeID == steelTagType)
            {
                if (filteredAiduFactors == null || filteredAiduFactors.Count == 0)
                {
                    FoundationFactor = 1.0;
                    FoundationFactorDescription = "DEFAULT (1)";
                    ElevationFactor = null;
                    ElevationFactorDescription = null;
                }
                else
                {
                    double area = Footprint;
                    filteredAiduFactors = filteredAiduFactors.OrderBy(f => f.MinValue).ToList();
                    foreach (var factor in filteredAiduFactors)
                    {
                        if (area <= factor.MaxValue)
                        {
                            FoundationFactor = factor.FactorValue;
                            FoundationFactorDescription = factor.Code;
                            ElevationFactor = null;
                            ElevationFactorDescription = null;
                            break;
                        }
                    }
                }
            }
            else
            {
                FoundationFactor = null;
                FoundationFactorDescription = null;
                ElevationFactor = null;
                ElevationFactorDescription = null;
            }
        }

        public void CalculateNumberOfDocuments(int foundationTagType, int elevationTagType, int steelTagType)
        {
            if (IsBalance)
                return;
            if (TagTypeID != foundationTagType && TagTypeID != elevationTagType && TagTypeID != steelTagType)
            {
                TotalDocuments = 0;
                return;
            }
            if (LV01_Object_Code == null)
                return;
            if (TagTypeID == foundationTagType)
            {
                string objectCode = LV01_Object_Code.Code;
                if (objectCode == "PR" || objectCode == "SS" || LV01_Object_Code.Behaviour == "PR")
                    TotalDocuments = AADCSETTINGS.FoundPipeMinimumDrwBBS.Value +
                        AADCSETTINGS.FoundPipeMinimumDrwFP.Value +
                        AADCSETTINGS.FoundPipeMinimumDrwFW.Value +
                        AADCSETTINGS.FoundPipeMinimumDrwRF.Value;
                else if (objectCode == "ST")
                    TotalDocuments = AADCSETTINGS.FoundProcessMinimumDrwBBS.Value +
                        AADCSETTINGS.FoundProcessMinimumDrwFP.Value +
                        AADCSETTINGS.FoundProcessMinimumDrwFW.Value +
                        AADCSETTINGS.FoundProcessMinimumDrwRF.Value;
                else if (objectCode == "EQ" || LV01_Object_Code.Behaviour == "EQ")
                    TotalDocuments = AADCSETTINGS.FoundEquipmentMinimumDrwBBS.Value +
                        AADCSETTINGS.FoundEquipmentMinimumDrwFP.Value +
                        AADCSETTINGS.FoundEquipmentMinimumDrwFW.Value +
                        AADCSETTINGS.FoundEquipmentMinimumDrwRF.Value;
                else if (objectCode == "BL")
                    TotalDocuments = AADCSETTINGS.FoundBuildingMinimumDrwBBS.Value +
                        AADCSETTINGS.FoundBuildingMinimumDrwFP.Value +
                        AADCSETTINGS.FoundBuildingMinimumDrwFW.Value +
                        AADCSETTINGS.FoundBuildingMinimumDrwRF.Value;
                else if (objectCode == "BS")
                    TotalDocuments = AADCSETTINGS.FoundBasinMinimumDrwBBS.Value +
                        AADCSETTINGS.FoundBasinMinimumDrwFP.Value +
                        AADCSETTINGS.FoundBasinMinimumDrwFW.Value +
                        AADCSETTINGS.FoundBasinMinimumDrwRF.Value;
                else
                    TotalDocuments = AADCSETTINGS.FoundOtherMinimumDrwBBS.Value +
                        AADCSETTINGS.FoundOtherMinimumDrwFP.Value +
                        AADCSETTINGS.FoundOtherMinimumDrwFW.Value +
                        AADCSETTINGS.FoundOtherMinimumDrwRF.Value;

                double coefficient = FoundationFactor != null && FoundationFactor.HasValue ? FoundationFactor.Value : 0.0;
                double doc = TotalDocuments * coefficient;
                TotalDocuments = (int)doc;
                if (TotalDocuments < doc)
                    TotalDocuments++;
            }
            else if(TagTypeID == elevationTagType)
            {
                string objectCode = LV01_Object_Code.Code;
                if (objectCode == "PR" || objectCode == "SS" || LV01_Object_Code.Behaviour == "PR")
                    TotalDocuments = AADCSETTINGS.ElePipeMinimumDrwBBS.Value +
                        AADCSETTINGS.ElePipeMinimumDrwEP.Value +
                        AADCSETTINGS.ElePipeMinimumDrwFW.Value +
                        AADCSETTINGS.ElePipeMinimumDrwRF.Value;
                else if (objectCode == "ST")
                    TotalDocuments = AADCSETTINGS.EleProcessMinimumDrwBBS.Value +
                        AADCSETTINGS.EleProcessMinimumDrwEP.Value +
                        AADCSETTINGS.EleProcessMinimumDrwFW.Value +
                        AADCSETTINGS.EleProcessMinimumDrwRF.Value;
                else if (objectCode == "EQ" || LV01_Object_Code.Behaviour == "EQ")
                    TotalDocuments = AADCSETTINGS.EleEquipmentMinimumDrw.Value;
                else if (objectCode == "BL")
                    TotalDocuments = AADCSETTINGS.EleBuildingMinimumDrw.Value;
                else
                    TotalDocuments = AADCSETTINGS.EleOtherMinimumDrwBBS.Value +
                        AADCSETTINGS.EleOtherMinimumDrwEP.Value +
                        AADCSETTINGS.EleOtherMinimumDrwFW.Value +
                        AADCSETTINGS.EleOtherMinimumDrwRF.Value;

                double coefficient = ElevationFactor != null && ElevationFactor.HasValue ? ElevationFactor.Value : 0.0;
                int level = ConcreteLevels != null && ConcreteLevels.HasValue ? ConcreteLevels.Value : 0;
                if (level <= 0)
                    level = 1;
                double doc = TotalDocuments * coefficient * level;
                TotalDocuments = (int)doc;
                if (TotalDocuments < doc)
                    TotalDocuments++;
            }
            else if (TagTypeID == steelTagType)
            {
                string objectCode = LV01_Object_Code.Code;
                int levels = SteelLevels != null && SteelLevels.HasValue ? SteelLevels.Value : 0;

                if (objectCode == "ST" || objectCode == "PAU")
                {
                    double refArea = AIDUSETTINGS.FoundProcessRefArea.Value;
                    int drawing = (int)Math.Ceiling(Footprint * levels / refArea);
                    if ((double)(drawing * refArea) < Footprint)
                        drawing++;
                    TotalDocuments = drawing;
                }
                else
                {
                    if (objectCode == "PR" || objectCode == "SS" || objectCode == "PAR" || LV01_Object_Code.Behaviour == "PR")
                        TotalDocuments = AIDUSETTINGS.PipeStructureMinimumDrw.Value;
                    else if (objectCode == "PR" || objectCode == "SS" || objectCode == "PAR" || LV01_Object_Code.Behaviour == "PR")
                        TotalDocuments = AIDUSETTINGS.FoundBuildingMinimumDrw.Value;
                    else
                        TotalDocuments = AIDUSETTINGS.FoundOtherMinimumDrw.Value;
                    double coefficient = FoundationFactor != null && FoundationFactor.HasValue ? FoundationFactor.Value : 0.0;
                    double doc = TotalDocuments * coefficient * levels;
                    TotalDocuments = (int)doc;
                    if (TotalDocuments < doc)
                        TotalDocuments++;
                }
            }
        }
    }
}
