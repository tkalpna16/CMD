﻿namespace CivilMasterData.Models.Costants
{
    public static class MainItemsCostants
    {
        public static int NONE = 0;
        public static int REPLACED = 1;
        public static int REPLACER = 2;
        public static int COMBINED = 3;
        public static int DELETED = 4;


        #region Dates
        public static string DATE_IFC_FORE = "DATE IFC FORECAST";
        public static string DATE_IFC_CHECK_FORE = "DATE IFC QUALITY CHECK FORECAST";
        public static string DATE_IFR_FORE = "DATE IFR FORECAST";
        public static string DATE_IFR_CHECK_FORE = "DATE IFR QUALITY CHECK FORECAST";
        public static string DATE_INP_FORE = "DATE INPUT FORECAST";

        public static string DATE_IFC_CHECK_ACTUAL = "DATE IFC QUALITY CHECK ACTUAL";
        public static string DATE_IFR_CHECK_ACTUAL = "DATE IFR QUALITY CHECK ACTUAL";
        public static string DATE_IFR_BASE_LEV3 = "DATE IFR BASELINE (LEV3)";
        public static string DATE_IFR_BASE_ENG = "DATE IFR BASELINE (ENG)";
        public static string DATE_IFC_BASE_LEV3 = "DATE IFC BASELINE (LEV3)";
        public static string DATE_IFC_BASE_ENG = "DATE IFC BASELINE (ENG)";

        public static string DATE_IFR_ACT = "DATE IFR ACTUAL";
        public static string DATE_IFC_ACT = "DATE IFC ACTUAL";
        #endregion

        #region HOLDS
        public static string HOLD_OPEN = "OPEN";
        public static string HOLD_CLOSED = "CLOSED";
        #endregion
    }
}
