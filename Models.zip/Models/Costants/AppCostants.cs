﻿using System;

namespace CivilMasterData.Models.Costants
{
    public static class AppCostants
    {
        public static int PROJECT_SETTINGS_DEFAULT = 0;
        public static string ALL_FAMILY_FILTER = "ALL";

        private static string IDENTIFIER = "$$";

        public static string STATUS_OK = "OK";

        public static string CE_ACTUAL_REVISION_NAME = "Actual";

        public static string GetSubstitutionString(string text)
        {
            if (String.IsNullOrEmpty(text))
                return text;
            return IDENTIFIER + text + IDENTIFIER;
        }

        public static string CleanSubstitutionString(string text)
        {
            if (String.IsNullOrEmpty(text))
                return text;
            return text.Replace(IDENTIFIER, "");
        }
    }
}
