﻿using CivilMasterData.Models.BIM360.Parameters;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace CivilMasterData.Models.Costants
{
    public static class DatabaseCostants
    {
        #region Forge
        public static string Forge_ParameterName_Lv02ObjectCode { get; set; }
        public static string Forge_ParameterName_Material { get; set; }
        public static string Forge_ParameterName_StructuralMaterial { get; set; }
        public static string Forge_ParameterName_TagType { get; set; }
        public static string Forge_ParameterName_FamilyName { get; set; }
        public static string Forge_ParameterName_ForgeItemName { get; set; }
        public static string Forge_ParameterName_ItemTag { get; set; }
        public static string Forge_ParameterName_MainItemTag { get; set; }
        public static string Forge_ParameterName_EngineeringStatus { get; set; }
        public static string Forge_ParameterName_QTY { get; set; }

        public static string Forge_ParameterName_Unit { get; set; }
        public static string Forge_ParameterName_AreaCode { get; set; }
        public static string Forge_ParameterName_CWA { get; set; }
        public static string Forge_ParameterName_SubDiscipline { get; set; }
        public static string Forge_ParameterName_WP { get; set; }
        public static string Forge_ParameterName_ObjectCode { get; set; }
        public static string Forge_ParameterName_MaterialGroup { get; set; }
        public static string Forge_ParameterName_MaterialGroup2 { get; set; }
        public static string Forge_ParameterName_Lot { get; set; }
        public static string Forge_ParameterName_CMD_Checker { get; set; }
        public static List<string> Forge_CMD_Checker_Filename_Filters { get; set; }

        public static string Forge_ParameterName_Hold { get; set; }
        public static string Forge_ParameterName_Hold_Steel { get; set; }
        #endregion

        #region Tag Types
        public static int TagType_Steel_ID { get; set; }
        public static int TagType_Pile_ID { get; set; }
        public static int TagType_Foundation_ID { get; set; }
        public static int TagType_Elevation_ID { get; set; }
        public static int TagType_UndergroundPit_ID { get; set; }
        public static int TagType_UndergroundPipe_ID { get; set; }
        public static int TagType_Paving_ID { get; set; }
        public static int TagType_Ground_Slab_Concrete_ID { get; set; }

        public static string TagType_Steel_Name { get; set; }
        public static string TagType_Pile_Name { get; set; }
        public static string TagType_Foundation_Name { get; set; }
        public static string TagType_Elevation_Name { get; set; }
        public static string TagType_UndergroundPit_Name { get; set; }
        public static string TagType_UndergroundPipe_Name { get; set; }
        public static string TagType_Paving_Name { get; set; }
        public static string TagType_Ground_Slab_Concrete_Name { get; set; }
        #endregion

        #region Material Work Group
        public static int MaterialWorkGroup_Steel_ID { get; set; }
        #endregion

        #region Oracle
        public static string Oracle_ConnectionString { get; set; }
        public static string Oracle_ProcedureInserForgeItem { get; set; }
        public static string Oracle_ProcedureFilename { get; set; }
        public static string Oracle_ProcedureObjectId { get; set; }
        public static string Oracle_ProcedurePropertyName { get; set; }
        public static string Oracle_ProcedurePropertyValue { get; set; }
        public static string Oracle_ProcedureSaveSecName { get; set; }
        public static string Oracle_ParameterNameMainItemId { get; set; }
        public static string Oracle_ParameterNameUserId { get; set; }
        public static string Oracle_ProcedureNameMTORev { get; set; }
        public static string Oracle_ModelStatusId { get; set; }
        public static string Oracle_EngStatusId { get; set; }
        public static string Oracle_Qty { get; set; }
        public static string Oracle_Qty_Hold { get; set; }
        #endregion

        #region Item Parameters
        public static int TextParameterID { get; set; }
        public static int QuantityParameterID { get; set; }
        public static int DateParameterID { get; set; }
        #endregion

        #region Others
        public static string DefaultLot { get; set; }
        #endregion

        #region Initialization
        public static void InitValues(IConfiguration _configuration)
        {
            #region Forge
            Forge_ParameterName_Lv02ObjectCode = _configuration.GetValue<string>("Forge:ParameterObjectCodeLV02");
            Forge_ParameterName_Material = _configuration.GetValue<string>("Forge:ParameterMaterial");
            Forge_ParameterName_StructuralMaterial = _configuration.GetValue<string>("Forge:ParameterStructuralMaterial");
            Forge_ParameterName_TagType = _configuration.GetValue<string>("Forge:ParameterTagType");
            Forge_ParameterName_FamilyName = _configuration.GetValue<string>("Forge:ParameterFamilyName");
            Forge_ParameterName_ForgeItemName = _configuration.GetValue<string>("Forge:ParameterForgeItemName");
            Forge_ParameterName_ItemTag = _configuration.GetValue<string>("Forge:ParameterNameItemTag");
            Forge_ParameterName_MainItemTag = _configuration.GetValue<string>("Forge:ParameterNameMainItemTag");
            Forge_ParameterName_EngineeringStatus = _configuration.GetValue<string>("Forge:ParameterEngineeringStatus");
            Forge_ParameterName_QTY = _configuration.GetValue<string>("Forge:ParameterQTY");
            Forge_ParameterName_Unit = _configuration.GetValue<string>("Forge:ParameterUnit");
            Forge_ParameterName_AreaCode = _configuration.GetValue<string>("Forge:ParameterArea");
            Forge_ParameterName_CWA = _configuration.GetValue<string>("Forge:ParameterCWA");
            Forge_ParameterName_SubDiscipline = _configuration.GetValue<string>("Forge:ParameterSubDiscipline");
            Forge_ParameterName_WP = _configuration.GetValue<string>("Forge:ParameterWP");
            Forge_ParameterName_ObjectCode = _configuration.GetValue<string>("Forge:ParameterObjectCode");
            Forge_ParameterName_MaterialGroup = _configuration.GetValue<string>("Forge:ParameterMaterialWorkGroup");
            Forge_ParameterName_MaterialGroup2 = _configuration.GetValue<string>("Forge:ParameterMaterialWorkGroup2");
            Forge_ParameterName_Lot = _configuration.GetValue<string>("Forge:ParameterLOT");
            Forge_ParameterName_CMD_Checker = _configuration.GetValue<string>("Forge:ParameterCMDChecker");
            Forge_ParameterName_Hold = _configuration.GetValue<string>("Forge:ParameterHold");
            Forge_ParameterName_Hold_Steel = _configuration.GetValue<string>("Forge:ParameterHoldSteel");

            string filterStr = _configuration.GetValue<string>("Forge:CMDCheckerFileNameFiler");
            Forge_CMD_Checker_Filename_Filters = ParsingUtils.ParseString(filterStr);
            #endregion

            #region Tag types
            TagType_Steel_ID = _configuration.GetValue<int>("Items:TagTypeSteel");
            TagType_Pile_ID = _configuration.GetValue<int>("Items:TagTypePiles");
            TagType_Foundation_ID = _configuration.GetValue<int>("Items:TagTypeFoundationConcrete");
            TagType_Elevation_ID = _configuration.GetValue<int>("Items:TagTypeElevationConcrete");
            TagType_UndergroundPit_ID = _configuration.GetValue<int>("Items:TagTypePit");
            TagType_UndergroundPipe_ID = _configuration.GetValue<int>("Items:TagTypePipes");
            TagType_Paving_ID = _configuration.GetValue<int>("Items:TagTypePaving");
            TagType_Ground_Slab_Concrete_ID = _configuration.GetValue<int>("Items:TagTypeGroundSlabConcrete");

            TagType_Steel_Name = _configuration.GetValue<string>("Items:TagTypeSteelName");
            TagType_Pile_Name = _configuration.GetValue<string>("Items:TagTypePilesName");
            TagType_Foundation_Name = _configuration.GetValue<string>("Items:TagTypeFoundationConcreteName");
            TagType_Elevation_Name = _configuration.GetValue<string>("Items:TagTypeElevationConcreteName");
            TagType_UndergroundPit_Name = _configuration.GetValue<string>("Items:TagTypePitName");
            TagType_UndergroundPipe_Name = _configuration.GetValue<string>("Items:TagTypePipesName");
            TagType_Paving_Name = _configuration.GetValue<string>("Items:TagTypePavingName");
            TagType_Ground_Slab_Concrete_Name = _configuration.GetValue<string>("Items:TagTypeGroundSlabConcreteName");
            #endregion

            #region Material Work Group
            MaterialWorkGroup_Steel_ID = _configuration.GetValue<int>("Items:MaterialWorkGroupSteelID");
            #endregion

            #region Oracle procedure
            //Oracle_ConnectionString = _configuration.GetValue<string>("Oracle:ConnectionString");
            string connectionString = _configuration.GetValue<string>("Oracle:ConnectionString:DefaultConnection");
            connectionString = AESService.Decrypt(connectionString);
            Oracle_ProcedureInserForgeItem = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItem");
            Oracle_ProcedureFilename = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemFILENAME");
            Oracle_ProcedureObjectId = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemOBJECTID");
            Oracle_ProcedurePropertyName = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemPROPERTYNAME");
            Oracle_ProcedurePropertyValue = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemPROPERTYVALUE");
            Oracle_ProcedureSaveSecName = _configuration.GetValue<string>("Oracle:ProcedureInsertSecItem");
            Oracle_ParameterNameMainItemId = _configuration.GetValue<string>("Oracle:ParameterNameMainItemId");
            Oracle_ParameterNameUserId = _configuration.GetValue<string>("Oracle:ParameterNameUserId");
            Oracle_ProcedureNameMTORev = _configuration.GetValue<string>("Oracle:ProcedureInsertMainQtyMTORev");
            Oracle_ModelStatusId = _configuration.GetValue<string>("Oracle:ParameterModelStatuId");
            Oracle_EngStatusId = _configuration.GetValue<string>("Oracle:ParameterEngStatusId");
            Oracle_Qty = _configuration.GetValue<string>("Oracle:ParameterQty");
            Oracle_Qty_Hold = _configuration.GetValue<string>("Oracle:ParameterQtyHold");
            #endregion

            #region Item Parameters
            TextParameterID = _configuration.GetValue<int>("Items:TextParameterID");
            QuantityParameterID = _configuration.GetValue<int>("Items:QuantityParameterID");
            DateParameterID = _configuration.GetValue<int>("Items:DateParameterID");
            #endregion

            #region Others
            DefaultLot = _configuration.GetValue<string>("Items:DefaultLotName");
            #endregion
        }
        #endregion
    }
}
