﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Costants
{
    public static class EngStatusCostants
    {
        public static int BUDGET_ID = 1;
        public static int IFB_ID = 2;
        public static int IFR_ID = 3;
        public static int IFC_ID = 4;
    }
}
