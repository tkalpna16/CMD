﻿using CivilMasterData.Models.Views;
using System.Collections.Generic;
using System.Linq;

namespace CivilMasterData.Models.Utilities
{
    public class MainItemUtils
    {
        public static List<MAINITEMS> OrderMainitems(List<MAINITEMS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !i.MainItemTag.Contains(balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.MainItemTag.Contains(balanceFilter)).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.TagTypeID).ThenBy(i => i.MainItemTag).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.TagTypeID).ThenBy(i => i.MainItemTag).ToList();
            var orderedItems = new List<MAINITEMS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<ITEMS> OrderItems(List<ITEMS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !(i.TagClient == balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.TagClient == balanceFilter).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.TagType).ThenBy(i => i.TagMet).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.TagType).ThenBy(i => i.TagMet).ToList();
            var orderedItems = new List<ITEMS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<PLANNINGS> OrderMainitemsPlannings(List<PLANNINGS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => i.MAINITEMS != null && !i.MAINITEMS.IsBalance).ToList();
            var balanceItems = items.Where(i => i.MAINITEMS != null && i.MAINITEMS.IsBalance).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.MAINITEMS.TagTypeID).ThenBy(i => i.MAINITEMS.MainItemTag).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.MAINITEMS.TagTypeID).ThenBy(i => i.MAINITEMS.MainItemTag).ToList();
            var orderedItems = new List<PLANNINGS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<HOLDS> OrderMainitemsHolds(List<HOLDS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !i.MAINITEMS.MainItemTag.Contains(balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.MAINITEMS.MainItemTag.Contains(balanceFilter)).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.MAINITEMS.TagTypeID).ThenBy(i => i.MAINITEMS.MainItemTag).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.MAINITEMS.TagTypeID).ThenBy(i => i.MAINITEMS.MainItemTag).ToList();
            var orderedItems = new List<HOLDS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<HOLDLISTS> OrderHoldList(List<HOLDLISTS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !(i.TagClient == balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.TagClient == balanceFilter).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.TagType).ThenBy(i => i.TagMet).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.TagType).ThenBy(i => i.TagMet).ToList();
            var orderedItems = new List<HOLDLISTS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<PROJECTPLANNINGS> OrderProjectPlanning(List<PROJECTPLANNINGS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !(i.TagClient == balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.TagClient == balanceFilter).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.TagType).ThenBy(i => i.TagMet).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.TagType).ThenBy(i => i.TagMet).ToList();
            var orderedItems = new List<PROJECTPLANNINGS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<STEELVENDORITEMLISTS> OrderSteelItems(List<STEELVENDORITEMLISTS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !(i.ItemTag == balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.ItemTag == balanceFilter).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.ItemTag).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.ItemTag).ToList();
            var orderedItems = new List<STEELVENDORITEMLISTS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }

        public static List<STEELPLANNINGS> OrderSteelPlanning(List<STEELPLANNINGS> items, string balanceFilter)
        {
            if (items == null)
                return items;
            var notBalanceItems = items.Where(i => !i.MAINITEMS.MainItemTag.Contains(balanceFilter)).ToList();
            var balanceItems = items.Where(i => i.MAINITEMS.MainItemTag.Contains(balanceFilter)).ToList();
            var orderedNotBalance = notBalanceItems.OrderBy(i => i.MAINITEMS.TagTypeID).ThenBy(i => i.MAINITEMS.MainItemTag).ToList();
            var orderedBalance = balanceItems.OrderBy(i => i.MAINITEMS.TagTypeID).ThenBy(i => i.MAINITEMS.MainItemTag).ToList();
            var orderedItems = new List<STEELPLANNINGS>();
            if (orderedNotBalance != null && orderedNotBalance.Count != 0)
                orderedItems.AddRange(orderedNotBalance);
            if (orderedBalance != null && orderedBalance.Count != 0)
                orderedItems.AddRange(orderedBalance);
            return orderedItems;
        }
    }
}
