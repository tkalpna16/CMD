﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Utilities
{
    public static class Utils
    {
        public static int MAX_ORACLE_QUERY_LIST = 1000;
        public static int USED_ORACLE_QUERY_LIST = 990;

        public static double[] SplitVector(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            values = values.Replace("\"", "");
            string[] spittedvalues = values.Split(',');
            double[] parsed = new double[spittedvalues.Length];
            double currentVal = 0.0;
            if (spittedvalues != null && spittedvalues.Length > 0)
            {
                int counter = 0;
                foreach (string s in spittedvalues)
                {
                    bool valid = double.TryParse(s, out currentVal);
                    if (valid)
                        parsed[counter] = currentVal;
                    counter++;
                }
            }
            return parsed;
        }
        public static double?[] SplitVectorWithNull(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            values = values.Replace("\"", "");
            string[] spittedvalues = values.Split(',');
            double?[] parsed = new double?[spittedvalues.Length];
            double currentVal = 0.0;
            if (spittedvalues != null && spittedvalues.Length > 0)
            {
                int counter = 0;
                foreach (string s in spittedvalues)
                {
                    bool valid = double.TryParse(s, out currentVal);
                    if (valid)
                        parsed[counter] = currentVal;
                    else
                        parsed[counter] = null;
                    counter++;
                }
            }
            return parsed;
        }
        public static int[] SplitIntVector(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            values = values.Replace("\"", "");
            string[] spittedvalues = values.Split(',');
            int[] parsed = new int[spittedvalues.Length];
            int currentVal = 0;
            if (spittedvalues != null && spittedvalues.Length > 0)
            {
                int counter = 0;
                foreach (string s in spittedvalues)
                {
                    bool valid = int.TryParse(s, out currentVal);
                    parsed[counter] = currentVal;
                    counter++;
                }
            }
            return parsed;
        }
        public static int?[] SplitIntVectorWithNull(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            values = values.Replace("\"", "");
            string[] spittedvalues = values.Split(',');
            int?[] parsed = new int?[spittedvalues.Length];
            int currentVal = 0;
            if (spittedvalues != null && spittedvalues.Length > 0)
            {
                int counter = 0;
                foreach (string s in spittedvalues)
                {
                    bool valid = int.TryParse(s, out currentVal);
                    if (valid)
                        parsed[counter] = currentVal;
                    else
                        parsed[counter] = null;
                    counter++;
                }
            }
            return parsed;
        }
        public static List<double[]> SplitDoubleVector(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("],[", ";");
            values = values.Replace("\"", "");
            string[] splittedvalues = values.Split(';');
            List<double[]> list = new List<double[]>();
            foreach (string str in splittedvalues)
            {
                double[] current = SplitVector(str);
                list.Add(current);
            }
            return list;
        }
        public static string[] SplitTextWithComma(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            string[] spittedvalues = values.Split("\",");
            if (spittedvalues != null)
                for (int i = 0; i < spittedvalues.Length; i++)
                    spittedvalues[i] = spittedvalues[i].Replace("\"", "");
            return spittedvalues;
        }
        public static string[] SplitText(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("\"", "");
            values = values.Replace("]", "");
            string[] spittedvalues = values.Split(',');
            return spittedvalues;
        }
        /// <summary>
        /// Break a list of items into chunks of a specific size
        /// </summary>
        public static IEnumerable<IEnumerable<T>> Chunk<T>(this IEnumerable<T> source, int chunksize)
        {
            while (source.Any())
            {
                yield return source.Take(chunksize);
                source = source.Skip(chunksize);
            }
        }
        public static bool[] SplitBoolean(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            values = values.Replace("\"", "");
            string[] spittedvalues = values.Split(',');
            bool[] parsed = new bool[spittedvalues.Length];
            bool currentVal = false;
            if (spittedvalues != null && spittedvalues.Length > 0)
            {
                int counter = 0;
                foreach (string s in spittedvalues)
                {
                    bool valid = bool.TryParse(s, out currentVal);
                    if (valid)
                        parsed[counter] = currentVal;
                    counter++;
                }
            }
            return parsed;
        }
        public static DateTime?[] SplitDate(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            string[] spittedvalues = values.Split(',');
            DateTime?[] dateTimes = new DateTime?[spittedvalues.Length];
            for (int i = 0; i < spittedvalues.Length; i++)
            {
                if (String.IsNullOrEmpty(spittedvalues[i]))
                    dateTimes[i] = DateTime.MinValue;
                else
                {
                    spittedvalues[i] = spittedvalues[i].Replace("\"", "");
                    DateTime date = DateTime.MinValue;
                    bool valid = DateTime.TryParse(spittedvalues[i], out date);
                    if (valid)
                        dateTimes[i] = date;
                    else
                        dateTimes[i] = null;
                }
            }
            return dateTimes;
        }

        public static string Truncate(this string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) { return value; }

            return value.Substring(0, Math.Min(value.Length, maxLength));
        }

        public static bool EqualString(string str1, string str2)
        {
            if (string.IsNullOrEmpty(str1) && string.IsNullOrEmpty(str2))
                return true;
            return str1 == str2;
        }
    }
}
