﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class HOLDTYPES
    {
        [Key]
        [Column("HoldTypeID")]
        [Display(Name = "HoldTypeID")]
        public int HoldTypeID { get; set; }

        [Column("Code")]
        [Display(Name = "Code")]
        public string Code { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Column("HOLDDEPTSID")]
        [Display(Name = "HOLDDEPTSID")]
        public int HOLDDEPTSID { get; set; }

        public HOLDDEPTS HOLDDEPTS { get; set; }
    }
}
