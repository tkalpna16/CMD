﻿using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class MAINITEMPLANNINGDATES
    {
        [Key]
        [Column("DateID")]
        [Display(Name = "DateID")]
        public int DateID { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "PROJECTID")]
        public int PROJECTID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("PARAMETERNAME")]
        [Display(Name = "PARAMETERNAME")]
        public string PARAMETERNAME { get; set; }
        
        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }
    }
}
