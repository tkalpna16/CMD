﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class LOTS
    {
        [Key]
        [Column("IDLOT")]
        [Display(Name = "IDLOT")]
        public int IDLOT { get; set; }

        [Column("NAME")]
        [Display(Name = "NAME")]
        public string NAME { get; set; }

        [Column("NOTES")]
        [Display(Name = "NOTES")]
        public string NOTES { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        public static LOTS GetNewLot(string name, int projectId, int userId)
        {
            LOTS lot = new LOTS();
            lot.NAME = name;
            lot.UserID = userId;
            lot.ProjectID = projectId;
            lot.CreationDate = DateTime.UtcNow;
            lot.LastModified = DateTime.UtcNow;
            return lot;
        }
    }
}
