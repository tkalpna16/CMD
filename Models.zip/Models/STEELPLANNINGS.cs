﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class STEELPLANNINGS
    {
        [Key]
        [Column("PlanningId")]
        [Display(Name = "PlanningId")]
        public int PlanningId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "Main Item")]
        public int? MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("DATE_IFP")]
        [Display(Name = "DATE_IFP")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFP { get; set; }

        [Column("DATE_IFF")]
        [Display(Name = "DATE_IFF")]
        [DataType(DataType.Date)]
        public DateTime? DATE_IFF { get; set; }

        [Column("DATE1_AIVD")]
        [Display(Name = "DATE1_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE1_AIVD { get; set; }

        [Column("DATE2_AIVD")]
        [Display(Name = "DATE2_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE2_AIVD { get; set; }

        [Column("DATE3_AIVD")]
        [Display(Name = "DATE3_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE3_AIVD { get; set; }

        [Column("DATE4_AIVD")]
        [Display(Name = "DATE4_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE4_AIVD { get; set; }

        [Column("DATE5_AIVD")]
        [Display(Name = "DATE5_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE5_AIVD { get; set; }

        [Column("DATE6_AIVD")]
        [Display(Name = "DATE6_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE6_AIVD { get; set; }

        [Column("DATE7_AIVD")]
        [Display(Name = "DATE7_AIVD")]
        [DataType(DataType.Date)]
        public DateTime? DATE7_AIVD { get; set; }

        /// <summary>
        /// Empty constructor
        /// </summary>
        public STEELPLANNINGS() { }

        /// <summary>
        /// Copy constructor
        /// </summary>
        /// <param name="pLANNINGS"></param>
        public STEELPLANNINGS(STEELPLANNINGS pLANNINGS)
        {
            if (pLANNINGS.MainItemId.HasValue)
                this.MainItemId = pLANNINGS.MainItemId.Value;
            UserID = pLANNINGS.UserID;
            CreationDate = pLANNINGS.CreationDate;
            LastModified = pLANNINGS.LastModified;
            DATE_IFP = pLANNINGS.DATE_IFP;
            DATE_IFF = pLANNINGS.DATE_IFF;
            DATE1_AIVD = pLANNINGS.DATE1_AIVD;
            DATE2_AIVD = pLANNINGS.DATE2_AIVD;
            DATE3_AIVD = pLANNINGS.DATE3_AIVD;
            DATE4_AIVD = pLANNINGS.DATE4_AIVD;
            DATE5_AIVD = pLANNINGS.DATE5_AIVD;
            DATE6_AIVD = pLANNINGS.DATE6_AIVD;
            DATE7_AIVD = pLANNINGS.DATE7_AIVD;
        }
    }
}
