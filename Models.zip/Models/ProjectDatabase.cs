﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class ProjectDatabase
    {
        public List<PROJECTS> PROJECTS { get; set; }
        public string SelectedProject { get; set; }
    }
}
