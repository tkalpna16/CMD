﻿using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.BIM360.Formulas;
using CivilMasterData.Models.BIM360.Logs;
using CivilMasterData.Models.Users;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class MODELCONNECTOR
    {
        [NotMapped]
        public int ProjectID { get; set; }
        public PROJECTS PROJECT { get; set; }
        public List<USERS> USERS { get; set; }
        public List<MISSING_MAINITEMS> MISSING_MAINITEMS { get; set; }
        public List<MAINITEMS> ITEMS_TO_DELETE { get; set; }
        public List<Log> LOGS { get; set; }


        public List<BIM360PARAMETERS> Parameters { get; set; } // List of project settings parameters

        public List<BIM360FILEREVISIONS> FileRevisions { get; set; }

        public List<BIM360INCORRECTFILES> IncorrectFiles { get; set; }

        public List<BIM360ITEMSTATUS> ItemStatusList { get; set; }

        // Tutti i tag in Main Item List con status diverso da “Deleted” o “Replaced” che non hanno nessuna corrispondenza modello;
        public List<ITEMSLISTCHECKS> ItemListCheck { get; set; }

        // tutti i tag in Main Item List con status uguale a “Deleted” o “Replaced” che hanno una corrispondenza a modello
        public List<DELETEDITEMSLISTCHECKS> DeletedMainItems { get; set; }

        public List<BIM360FOLDERS> Folders { get; set; }

        public List<BIM360ItemAttribute> BIM360ItemAttributes { get; set; }

        public List<string> ProjectParameters { get; set; }
    }
}
