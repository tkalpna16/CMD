﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class MATERIALWORKGROUPS
    {
        [Key]
        [Column("GROUPID")]
        [Display(Name = "GroupID")]
        public int GroupID { get; set; }

        [Column("GROUPCODE")]
        [Display(Name = "GroupCode")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "GroupDescription cannot be longer than 32 characters.")]
        public string GroupCode { get; set; }

        [Column("GROUPDESCRIPTION")]
        [Display(Name = "GroupDescription")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "GroupDescription cannot be longer than 32 characters.")]
        public string GroupDescription { get; set; }

        [Column("DISCIPLINECODE")]
        [Display(Name = "DisciplineCode")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineCode cannot be longer than 32 characters.")]
        public string DisciplineCode { get; set; }

        [Column("SUBDISCIPLINECODE")]
        [Display(Name = "SubDisciplineCode")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "SubDisciplineCode cannot be longer than 32 characters.")]
        public string SubDisciplineCode { get; set; }

        [Column("DISCIPLINEOWNER")]
        [Display(Name = "DisciplineOwner")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineOwner cannot be longer than 32 characters.")]
        public string DisciplineOwner { get; set; }

        [Column("SUBDISCIPLINEOWNER")]
        [Display(Name = "SubDisciplineOwner")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineOwner cannot be longer than 32 characters.")]
        public string SubDisciplineOwner { get; set; }
    }
}
