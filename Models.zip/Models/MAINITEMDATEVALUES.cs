﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class MAINITEMDATEVALUES
    {
        [Key]
        [Column("VALUEID")]
        [Display(Name = "VALUEID")]
        public int ValueID { get; set; }

        [Column("MAINITEMSID")]
        [Display(Name = "MAINITEMSID")]
        public int MainItemsID { get; set; }

        public MAINITEMS MainItems { get; set; }

        [Column("MAINITEMPLANNINGDATESID")]
        [Display(Name = "MAINITEMPLANNINGDATESID")]
        public int MainItemPlanningDatesID { get; set; }

        public MAINITEMPLANNINGDATES MAINITEMPLANNINGDATES { get; set; }
        
        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("PARAMETERDATE")]
        [Display(Name = "PARAMETERDATE")]
        [DataType(DataType.Date)]
        public DateTime? PARAMETERDATE { get; set; }
    }
}
