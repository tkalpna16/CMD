﻿using CivilMasterData.Models.Steel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class SteelItemListCreation
    {
        public PROJECTS Project { get; set; }

        public List<MAINITEMS> MainItems { get; set; }

        public List<LOTS> Lots { get; set; }

        public List<VENDORS> Vendors { get; set; }

        public List<MATERIALREQUESTS> Materialrequests { get; set; }

        public List<PURCHASEORDERS> PurchaseOrders { get; set; }
    }
}
