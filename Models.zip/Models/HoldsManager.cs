﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class HoldsManager
    {
        public List<MAINITEMS> MainItems { get; set; }

        public List<TAGTYPES> TagTypes { get; set; }

        public PROJECTS Project { get; set; }

        public List<HOLDDEPTS> HOLDDEPTS { get; set; }
        public List<HOLDTYPES> HOLDTYPES { get; set; }
        public List<HOLDS> HOLDS { get; set; }
    }
}
