﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class SEC_ITEM_QTY_REV
    {
        [Key]
        [Column("Sec_Item_Qty_Id")]
        [Display(Name = "Sec_Item_Qty_Id")]
        public int? Sec_Item_Qty_Id { get; set; }

        [Column("Sec_Item_Id")]
        [Display(Name = "Sec_Item_Id")]
        public int? Sec_Item_Id { get; set; }

        [Column("EngStatusId")]
        [Display(Name = "EngStatusId")]
        public int? EngStatusId { get; set; }
        
        [Column("QTY")]
        [Display(Name = "QTY")]
        public double? QTY { get; set; }        
    }
}
