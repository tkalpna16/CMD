﻿using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;

namespace CivilMasterData.Models
{
    /// <summary>
    /// Main Item Qty Revision
    /// </summary>
    public class MTOREVS
    {
        [Key]
        [Column("MTOID")]
        [Display(Name = "MTOID")]
        public int MTOID { get; set; }

        [Column("MAINITEMID")]
        [Display(Name = "MAINITEMID")]
        public int? MAINITEMID { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("STATUSID")]
        [Display(Name = "STATUSID")]
        public int? STATUSID { get; set; }

        /// <summary>
        /// From 3d Model or Manual Input
        /// </summary>
        [Column("MODELSTATUSID")]
        [Display(Name = "MODELSTATUSID")]
        public int? MODELSTATUSID { get; set; }

        [Column("REVID")]
        [Display(Name = "REVID")]
        public int? REVID { get; set; }

        [Column("QTY")]
        [Display(Name = "QTY")]
        public double? QTY { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }
    }
}
