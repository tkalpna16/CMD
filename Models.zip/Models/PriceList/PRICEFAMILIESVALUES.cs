﻿using CivilMasterData.Models.BIM360.Formulas;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.PriceList
{
    public class PRICEFAMILIESVALUES
    {
        [Key]
        [Column("FAMILYVALUEID")]
        [Display(Name = "FamilyValueID")]
        public int? FamilyValueID { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("FAMILYNAME")]
        [Display(Name = "FamilyName")]
        public string FamilyName { get; set; }

        [Column("FORMULA")]
        [Display(Name = "Formula")]
        public string Formula { get; set; }

        [Column("UNIT")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("PRICECODEDEFINITIONSID")]
        [Display(Name = "PRICECODEDEFINITIONSID")]
        public int PRICECODEDEFINITIONSID { get; set; }

        public PRICECODEDEFINITIONS PRICECODEDEFINITIONS { get; set; }

        [Column("LENGTHVALUE")]
        [Display(Name = "LengthValue")]
        public string LengthValue { get; set; }

        [Column("WIDTHVALUE")]
        [Display(Name = "WidthValue")]
        public string WidthValue { get; set; }

        [Column("HEIGHTVALUE")]
        [Display(Name = "HeightValue")]
        public string HeightValue { get; set; }

        [Column("AREAVALUE")]
        [Display(Name = "AreaValue")]
        public string AreaValue { get; set; }

        [Column("WEIGHTVALUE")]
        [Display(Name = "WeightValue")]
        public string WeightValue { get; set; }


        public FamilyFormula GetFamilyFormula()
        {
            FamilyFormula formula = new FamilyFormula(FamilyName, Formula, -1);
            return formula;
        }

        public PRICEFAMILIESVALUES() { }

        public PRICEFAMILIESVALUES Copy(int project, int priceCodeGroupId)
        {
            PRICEFAMILIESVALUES family = new PRICEFAMILIESVALUES();
            family.ProjectID = project;
            family.FamilyName = FamilyName;
            family.Formula = Formula;
            family.Unit = Unit;
            family.PRICECODEDEFINITIONSID = priceCodeGroupId;
            family.LengthValue = LengthValue;
            family.WidthValue = WidthValue;
            family.HeightValue = HeightValue;
            family.AreaValue = AreaValue;
            family.WeightValue = WeightValue;
            return family;
        }
    }
}
