﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.PriceList
{
    public class PRICECODEDEFINITIONS
    {
        [Key]
        [Column("PRICECODEDEFINITIONID")]
        [Display(Name = "PriceCodeDefinitionID")]
        public int? PriceCodeDefinitionID { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("GROUPCODE")]
        [Display(Name = "GroupCode")]
        public string GroupCode { get; set; }

        [Column("PRICEGROUPDESCRIPTION")]
        [Display(Name = "PriceGroupDescription")]
        public string PriceGroupDescription { get; set; }

        public PRICECODEDEFINITIONS() { }

        public PRICECODEDEFINITIONS Copy(int projectId)
        {
            PRICECODEDEFINITIONS newCode = new PRICECODEDEFINITIONS();
            newCode.ProjectID = projectId;
            newCode.GroupCode = GroupCode;
            newCode.PriceGroupDescription = PriceGroupDescription;
            return newCode;
        }
    }
}
