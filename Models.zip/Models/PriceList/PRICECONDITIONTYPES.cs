﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.PriceList
{
    public class PRICECONDITIONTYPES
    {
        [Key]
        [Column("ConditionTypeID")]
        [Display(Name = "ConditionTypeID")]
        public int ConditionTypeID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }
    }
}
