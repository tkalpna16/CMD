﻿using CivilMasterData.Models.PriceList.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.PriceList
{
    public class PRICECONDITIONS
    {
        [Key]
        [Column("CONDITIONID")]
        [Display(Name = "CONDITIONID")]
        public int? CONDITIONID { get; set; }

        [Column("PRICECODEID")]
        [Display(Name = "PRICECODEID")]
        public int? PRICECODEID { get; set; }

        public PRICECODES PRICECODE { get; set; }

        [Column("CONDITIONTYPEID")]
        [Display(Name = "CONDITIONTYPEID")]
        public int? CONDITIONTYPEID { get; set; }

        public PRICECONDITIONTYPES PRICECONDITIONTYPE { get; set; }

        [Column("CONDITIONPARAMETER")]
        [Display(Name = "CONDITIONPARAMETER")]
        public string CONDITIONPARAMETER { get; set; }

        [Column("COMPARISONTYPEID")]
        [Display(Name = "COMPARISONTYPEID")]
        public int? COMPARISONTYPEID { get; set; }

        public COMPARISONTYPES COMPARISONTYPE { get; set; }

        [Column("CONDITIONVALUE")]
        [Display(Name = "CONDITIONVALUE")]
        public string CONDITIONVALUE { get; set; }

        [Column("BOOLEANOPERATORID")]
        [Display(Name = "BOOLEANOPERATORID")]
        public int? BOOLEANOPERATORID { get; set; }

        public BOOLEANOPERATORS BOOLEANOPERATOR { get; set; }

        public Condition GetCondition()
        {
            ConditionType conditionType = (ConditionType)CONDITIONTYPEID.Value;
            Condition condition = null;
            bool valid = true;
            try
            {
                BooleanType booleanType = (BooleanType)BOOLEANOPERATORID.Value;
                switch (conditionType)
                {
                    case ConditionType.NUMERIC:
                        NumericCondition numericCondition = new NumericCondition();
                        NumericComparer numericComparer = (NumericComparer)COMPARISONTYPEID.Value;
                        numericCondition.BooleanType = booleanType;
                        numericCondition.Comparer = numericComparer;
                        double value = 0.0;
                        valid = double.TryParse(CONDITIONVALUE, out value);
                        numericCondition.Value = value;
                        numericCondition.Parameter = CONDITIONVALUE;
                        condition = numericCondition;
                        break;
                    case ConditionType.TEXT:
                        StringCondition stringCondition = new StringCondition();
                        StringComparer stringComparer = (StringComparer)COMPARISONTYPEID.Value;
                        stringCondition.BooleanType = booleanType;
                        stringCondition.Comparer = stringComparer;
                        stringCondition.Value = CONDITIONVALUE;
                        stringCondition.Parameter = CONDITIONVALUE;
                        condition = stringCondition;
                        break;
                    case ConditionType.NONE:
                        EmptyCondition emptyCondition = new EmptyCondition();
                        condition = emptyCondition;
                        break;
                }
            }
            catch { }

            return valid ? condition : null;
        }

        public PRICECONDITIONS() { }

        public PRICECONDITIONS Copy(int project, int priceCodeId)
        {
            PRICECONDITIONS condition = new PRICECONDITIONS();
            condition.PRICECODEID = priceCodeId;
            condition.CONDITIONTYPEID = null;
            if (CONDITIONTYPEID.HasValue)
                condition.CONDITIONTYPEID = CONDITIONTYPEID.Value;
            condition.CONDITIONPARAMETER = CONDITIONPARAMETER;
            condition.COMPARISONTYPEID = null;
            if (COMPARISONTYPEID.HasValue)
                condition.COMPARISONTYPEID = COMPARISONTYPEID.Value;
            condition.CONDITIONVALUE = CONDITIONVALUE;
            condition.BOOLEANOPERATORID = null;
            if (BOOLEANOPERATORID.HasValue)
                condition.BOOLEANOPERATORID = BOOLEANOPERATORID.Value;
            return condition;
        }
    }
}
