﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.PriceList
{
    public class BOOLEANOPERATORS
    {
        [Key]
        [Column("OperatorID")]
        [Display(Name = "OperatorID")]
        public int OperatorID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }
    }
}
