﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.PriceList
{
    public class PRICECODES
    {
        [Key]
        [Column("PRICECODEID")]
        [Display(Name = "PriceCodeID")]
        public int? PriceCodeID { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("PRICECODEDEFINITIONID")]
        [Display(Name = "PRICECODEDEFINITIONID")]
        public int PriceCodeDefinitionID { get; set; }

        public PRICECODEDEFINITIONS PRICECODEDEFINITIONS { get; set; }

        [Column("CODE")]
        [Display(Name = "Code")]
        public string Code { get; set; }

        [Column("PRICEDESCRIPTION")]
        [Display(Name = "PriceDescription")]
        public string PriceDescription { get; set; }

        [Column("UNIT")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [NotMapped]
        public string ReducedDescription
        {
            get
            {
                string str = null;
                if (PriceDescription != null)
                {
                    if (PriceDescription.Length > 96)
                        str = PriceDescription.Substring(0, 96) + "..";
                    else
                        return PriceDescription;
                }
                return str;
            }
        }

        public PRICECODES() { }

        public PRICECODES Copy(int project, int priceGroup)
        {
            PRICECODES price = new PRICECODES();
            price.ProjectID = project;
            price.PriceCodeDefinitionID = priceGroup;
            price.Code = Code;
            price.PriceDescription = PriceDescription;
            price.Unit = Unit;
            return price;
        }
    }
}
