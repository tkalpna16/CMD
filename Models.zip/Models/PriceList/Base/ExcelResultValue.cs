﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.PriceList.Base
{
    public class ExcelResultValue
    {
        public string ItemCode { get; set; }
        public string PriceCode { get; set; }
        public string PriceDescription { get; set; }
        public string PriceGroupCode { get; set; }
        public string PriceGroupDescription { get; set; }
        public string Unit { get; set; }
        public double Length { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public double Area { get; set; }
        public double Weight { get; set; }
        public double Quantities { get; set; }
        public int Count { get; set; }

        public ExcelResultValue() { }

        public ExcelResultValue(ExcelResultValue excelResultValue)
        {
            this.ItemCode = excelResultValue.ItemCode;
            this.PriceCode = excelResultValue.PriceCode;
            this.PriceDescription = excelResultValue.PriceDescription;
            this.PriceGroupCode = excelResultValue.PriceGroupCode;
            this.PriceGroupDescription = excelResultValue.PriceGroupDescription;
            this.Unit = excelResultValue.Unit;
            this.Length = excelResultValue.Length;
            this.Width = excelResultValue.Width;
            this.Height = excelResultValue.Height;
            this.Area = excelResultValue.Area;
            this.Weight = excelResultValue.Weight;
            this.Quantities = excelResultValue.Quantities;
            this.Count = excelResultValue.Count;
        }
    }

    public class ResultManager
    {
        List<ExcelResultValue> results;

        public ResultManager(List<ExcelResultValue> results)
        {
            this.results = results;
        }

        /// <summary>
        /// Get List of Main Price Codes
        /// </summary>
        /// <returns></returns>
        public List<string> GetPriceGroups()
        {
            List<string> values = results.Select(x => x.PriceGroupDescription).Distinct().ToList();
            values = values.OrderBy(s => s).ToList();
            return values;
        }

        /// <summary>
        /// Get Price codes inside group
        /// </summary>
        /// <param name="mainGroupCode"></param>
        /// <returns></returns>
        public List<string> GetPriceCodes(string mainGroupCode)
        {
            List<string> values = results.Where(x => x.PriceGroupDescription == mainGroupCode).Select(x => x.PriceCode).Distinct().ToList();
            values = values.OrderBy(s => s).ToList();
            return values;
        }

        public List<ExcelResultValue> GetExcelResultValues(string priceCode)
        {
            List<ExcelResultValue> filteredResults = results.Where(x => x.PriceCode == priceCode).OrderBy(x => x.ItemCode).ToList();
            List<ExcelResultValue> values = new List<ExcelResultValue>();
            ExcelResultValue excelResult = null;
            if (filteredResults != null)
            {
                string currentCode = string.Empty;
                for (int i = 0; i < filteredResults.Count; i++)
                {
                    if (String.IsNullOrEmpty(currentCode))
                    {
                        currentCode = filteredResults[i].ItemCode;
                        excelResult = new ExcelResultValue(filteredResults[i]);
                        excelResult.Count = 1;
                        values.Add(excelResult);
                        continue;
                    }
                    if (filteredResults[i].ItemCode == currentCode)
                    {
                        excelResult.Count++;
                        excelResult.Length += filteredResults[i].Length;
                        excelResult.Width += filteredResults[i].Width;
                        excelResult.Height += filteredResults[i].Height;
                        excelResult.Area += filteredResults[i].Area;
                        excelResult.Weight += filteredResults[i].Weight;
                        excelResult.Quantities += filteredResults[i].Quantities;
                    }
                    else
                    {
                        currentCode = filteredResults[i].ItemCode;
                        excelResult = new ExcelResultValue(filteredResults[i]);
                        excelResult.Count = 1;
                        values.Add(excelResult);
                    }
                }
            }
            return values;
        }
    }
}
