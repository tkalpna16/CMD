﻿namespace CivilMasterData.Models.PriceList.Base
{
    public enum BooleanType
    {
        NONE = 0,
        AND = 1,
        OR = 2
    }
}
