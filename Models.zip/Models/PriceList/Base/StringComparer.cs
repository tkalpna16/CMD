﻿namespace CivilMasterData.Models.PriceList.Base
{
    public enum StringComparer
    {
        NONE = 0,
        EQUAL = 6,
        CONTAIN = 7,
        EQUAL_UPPERCASE = 8,
        CONTAIN_UPPERCASE = 9
    }
}
