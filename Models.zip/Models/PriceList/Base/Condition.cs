﻿namespace CivilMasterData.Models.PriceList.Base
{
    public class Condition
    {
        public string Parameter { get; set; }
        public BooleanType BooleanType { get; set; }

        public virtual bool Passed(object obj)
        {
            return false;
        }
    }
}
