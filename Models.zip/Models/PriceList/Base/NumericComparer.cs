﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.PriceList.Base
{
    public enum NumericComparer
    {
        NONE = 0,
        MINUS = 1,
        MAJOR = 2,
        MINUS_EQUAL = 3,
        MAJOR_EQUAL = 4
    }
}
