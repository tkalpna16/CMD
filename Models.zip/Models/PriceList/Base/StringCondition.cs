﻿namespace CivilMasterData.Models.PriceList.Base
{
    public class StringCondition : Condition
    {
        public string Value { get; set; }
        public StringComparer Comparer { get; set; }

        public override bool Passed(object obj)
        {
            bool passed = false;
            if (!(obj is string))
                return false;
            string paramVal = (string)obj;
            switch (Comparer)
            {
                case StringComparer.EQUAL:
                    passed = AreEqual(paramVal, Value, false);
                    break;
                case StringComparer.CONTAIN:
                    passed = AreContain(paramVal, Value, false);
                    break;
                case StringComparer.EQUAL_UPPERCASE:
                    passed = AreEqual(paramVal, Value, true);
                    break;
                case StringComparer.CONTAIN_UPPERCASE:
                    passed = AreContain(paramVal, Value, true);
                    break;

            }
            return passed;
        }

        static bool AreEqual(string paramValue, string value, bool upperCase)
        {
            if (string.IsNullOrEmpty(paramValue))
            {
                return string.IsNullOrEmpty(value);
            }
            else if (string.IsNullOrEmpty(value))
            {
                return string.IsNullOrEmpty(paramValue);
            }
            else
            {
                string a1 = upperCase ? paramValue : paramValue.ToUpper();
                string b1 = upperCase ? value : value.ToUpper();
                a1 = a1.Trim();
                b1 = b1.Trim();
                return string.Equals(a1, b1);
            }
        }

        static bool AreContain(string paramValue, string value, bool upperCase)
        {
            if (string.IsNullOrEmpty(paramValue))
            {
                return string.IsNullOrEmpty(value);
            }
            else if (string.IsNullOrEmpty(value))
            {
                return string.IsNullOrEmpty(paramValue);
            }
            else
            {
                string a1 = upperCase ? paramValue : paramValue.ToUpper();
                string b1 = upperCase ? value : value.ToUpper();
                return a1.Contains(b1);
            }
        }
    }
}
