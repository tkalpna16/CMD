﻿namespace CivilMasterData.Models.PriceList.Base
{
    public enum ConditionType
    {
        NONE = 0,
        NUMERIC = 1,
        TEXT = 2
    }
}
