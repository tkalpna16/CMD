﻿namespace CivilMasterData.Models.PriceList.Base
{
    public class NumericCondition : Condition
    {
        public double Value { get; set; }
        public NumericComparer Comparer { get; set; }

        public override bool Passed(object obj)
        {
            bool passed = false;
            if (!(obj is double))
                return false;
            double paramVal = (double)obj;
            switch (Comparer)
            {
                case NumericComparer.MAJOR:
                    passed = paramVal > Value;
                    break;
                case NumericComparer.MAJOR_EQUAL:
                    passed = paramVal >= Value;
                    break;
                case NumericComparer.MINUS:
                    passed = paramVal < Value;
                    break;
                case NumericComparer.MINUS_EQUAL:
                    passed = paramVal <= Value;
                    break;
                 
            }
            return passed;
        }
    }
}
