﻿namespace CivilMasterData.Models.PriceList.Base
{
    public class EmptyCondition : Condition
    {
        public override bool Passed(object obj)
        {
            return true;
        }
    }
}
