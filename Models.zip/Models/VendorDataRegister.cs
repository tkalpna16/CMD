﻿using CivilMasterData.Models.Steel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;



namespace CivilMasterData.Models
{
    public class VendorDataRegister
    {
        [Key]
        [Column("ID")]
        [Display(Name = "ID")]
        public int? ID { get; set; }

        [Column("DETAILER_NAME")]
        [Display(Name = "DETAILER NAME")]
        public string DETAILER_NAME { get; set; }

        [Column("DETAILER_NATION")]
        [Display(Name = "DETAILER NATION")]
        public string DETAILER_NATION { get; set; }

        [Column("DETAILER_CITY")]
        [Display(Name = "DETAILER CITY")]
        public string DETAILER_CITY { get; set; }

        [Column("DETAILER_KEY_USER")]
        [Display(Name = "DETAILER KEY USER")]
        public string DETAILER_KEY_USER { get; set; }

        [Column("DETAILER_EMAIL")]
        [Display(Name = "DETAILER EMAIL")]
        public string DETAILER_EMAIL { get; set; }

        [Column("DETAILER_PO_NO")]
        [Display(Name = "DETAILER PO NO")]
        public string DETAILER_PO_NO { get; set; }

        [Column("NOTES")]
        [Display(Name = "NOTES")]
        public string NOTES { get; set; }

        public List<VENDORS> Vendors { get; set; }
        public List<MATERIALREQUESTS> MaterialRequests { get; set; }
        public List<PURCHASEORDERS> PurchaseOrders { get; set; }

        
    }
}
