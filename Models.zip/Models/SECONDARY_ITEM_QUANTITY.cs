﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class SECONDARY_ITEM_QUANTITY
    {
        [Key]
        [Column("Sec_Item_Qty_Id")]
        [Display(Name = "Sec_Item_Qty_Id")]
        public int? Sec_Item_Qty_Id { get; set; }

        [Column("Sec_Item_Id")]
        [Display(Name = "Sec_Item_Id")]
        public int? Sec_Item_Id { get; set; }

        public SECONDARY_ITEM SECONDARY_ITEM { get; set; }

        [Column("EngStatusId")]
        [Display(Name = "EngStatusId")]
        public int? EngStatusId { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("Family Name")]
        [Display(Name = "Family Name")]
        public string FamilyName { get; set; }

        [Column("AB_L1")]
        [Display(Name = "AB_L1")]
        public double? AB_L1 { get; set; }

        [Column("AB_M")]
        [Display(Name = "AB_M")]
        public double? AB_M { get; set; }

        [Column("AB_P")]
        [Display(Name = "AB_P")]
        public double? AB_P { get; set; }

        [Column("Area")]
        [Display(Name = "Area")]
        public double? Area { get; set; }

        [Column("Bar Diameter")]
        [Display(Name = "Bar Diameter")]
        public double? BarDiameter { get; set; }

        [Column("Bar Length")]
        [Display(Name = "Bar Length")]
        public double? BarLength { get; set; }

        [Column("Cut Length")]
        [Display(Name = "Cut Length")]
        public double? CutLength { get; set; }

        [Column("DB_H")]
        [Display(Name = "DB_H")]
        public double? DB_H { get; set; }

        [Column("DB_L1")]
        [Display(Name = "DB_L1")]
        public double? DB_L1 { get; set; }

        [Column("DB_L2")]
        [Display(Name = "DB_L2")]
        public double? DB_L2 { get; set; }

        [Column("DB_PipeArea")]
        [Display(Name = "DB_PipeArea")]
        public double? DB_PipeArea { get; set; }

        [Column("Diameter")]
        [Display(Name = "Diameter")]
        public double? Diameter { get; set; }

        [Column("DT_Length")]
        [Display(Name = "DT_Length")]
        public double? DT_Length { get; set; }

        [Column("DT_MdArea")]
        [Display(Name = "DT_MdArea")]
        public double? DT_MdArea { get; set; }

        [Column("EC_B")]
        [Display(Name = "EC_B")]
        public double? EC_B { get; set; }

        [Column("EC_H")]
        [Display(Name = "EC_H")]
        public double? EC_H { get; set; }

        [Column("EC_Perimeter")]
        [Display(Name = "EC_Perimeter")]
        public double? EC_Perimeter { get; set; }

        [Column("FB_H1")]
        [Display(Name = "FB_H1")]
        public double? FB_H1 { get; set; }

        [Column("FB_L1")]
        [Display(Name = "FB_L1")]
        public double? FB_L1 { get; set; }

        [Column("Filter By")]
        [Display(Name = "Filter By")]
        public string FilterBy { get; set; }

        [Column("FL_H1")]
        [Display(Name = "FL_H1")]
        public double? FL_H1 { get; set; }

        [Column("Foundation Thickness")]
        [Display(Name = "Foundation Thickness")]
        public double? FoundationThickness { get; set; }
     
        [Column("FP_Area")]
        [Display(Name = "FP_Area")]
        public double? FP_Area { get; set; }

        [Column("FP_H1")]
        [Display(Name = "FP_H1")]
        public double? FP_H1 { get; set; }

        [Column("FP_L1")]
        [Display(Name = "FP_L1")]
        public double? FP_L1 { get; set; }

        [Column("FP_L1a")]
        [Display(Name = "FP_L1a")]
        public double? FP_L1a { get; set; }

        [Column("FP_L1b")]
        [Display(Name = "FP_L1b")]
        public double? FP_L1b { get; set; }

        [Column("FP_L1c")]
        [Display(Name = "FP_L1c")]
        public double? FP_L1c { get; set; }

        [Column("FP_L2")]
        [Display(Name = "FP_L2")]
        public double? FP_L2 { get; set; }

        [Column("FP_L2a")]
        [Display(Name = "FP_L2a")]
        public double? FP_L2a { get; set; }

        [Column("FP_L2b")]
        [Display(Name = "FP_L2b")]
        public double? FP_L2b { get; set; }

        [Column("FP_L2c")]
        [Display(Name = "FP_L2c")]
        public double? FP_L2c { get; set; }


        [Column("FP_Perimeter")]
        [Display(Name = "FP_Perimeter")]
        public double? FP_Perimeter { get; set; }

        [Column("FP_R")]
        [Display(Name = "FP_R")]
        public double? FP_R { get; set; }

        [Column("FP_R1")]
        [Display(Name = "FP_R1")]
        public double? FP_R1 { get; set; }

        [Column("FS_Area")]
        [Display(Name = "FS_Area")]
        public double? FS_Area { get; set; }

        [Column("FS_H1")]
        [Display(Name = "FS_H1")]
        public double? FS_H1 { get; set; }

        [Column("FS_L1")]
        [Display(Name = "FS_L1")]
        public double? FS_L1 { get; set; }

        [Column("FS_L1a")]
        [Display(Name = "FS_L1a")]
        public double? FS_L1a { get; set; }

        [Column("FS_L1b")]
        [Display(Name = "FS_L1b")]
        public double? FS_L1b { get; set; }

        [Column("FS_L1c")]
        [Display(Name = "FS_L1c")]
        public double? FS_L1c { get; set; }

        [Column("FS_L1d")]
        [Display(Name = "FS_L1d")]
        public double? FS_L1d { get; set; }

        [Column("FS_L2")]
        [Display(Name = "FS_L2")]
        public double? FS_L2 { get; set; }

        [Column("FS_L2a")]
        [Display(Name = "FS_L2a")]
        public double? FS_L2a { get; set; }

        [Column("FS_L2b")]
        [Display(Name = "FS_L2b")]
        public double? FS_L2b { get; set; }

        [Column("FS_L2c")]
        [Display(Name = "FS_L2c")]
        public double? FS_L2c { get; set; }

        [Column("FS_L2d")]
        [Display(Name = "FS_L2d")]
        public double? FS_L2d { get; set; }

        [Column("FS_Perimeter")]
        [Display(Name = "FS_Perimeter")]
        public double? FS_Perimeter { get; set; }

        [Column("GR_H1")]
        [Display(Name = "GR_H1")]
        public double? GR_H1 { get; set; }

        [Column("GR_L1")]
        [Display(Name = "GR_L1")]
        public double? GR_L1 { get; set; }

        [Column("GR_L2")]
        [Display(Name = "GR_L2")]
        public double? GR_L2 { get; set; }

        [Column("Horizontal Down Surface")]
        [Display(Name = "Horizontal Down Surface")]
        public string HorizontalDownSurface { get; set; }

        [Column("Horizontal Up Surface")]
        [Display(Name = "Horizontal Up Surface")]
        public double? HorizontalUpSurface { get; set; }

        [Column("Length")]
        [Display(Name = "Length")]
        public double? Length { get; set; }

        [Column("Perimeter")]
        [Display(Name = "Perimeter")]
        public double? Perimeter { get; set; }

        [Column("PI_H")]
        [Display(Name = "PI_H")]
        public double? PI_H { get; set; }

        [Column("PI_L1")]
        [Display(Name = "PI_L1")]
        public double? PI_L1 { get; set; }

        [Column("PI_L2")]
        [Display(Name = "PI_L2")]
        public double? PI_L2 { get; set; }

        [Column("Pipe_TotalNumb")]
        [Display(Name = "Pipe_TotalNumb")]
        public int? Pipe_TotalNumb { get; set; }

        [Column("PK_H1")]
        [Display(Name = "PK_H1")]
        public double? PK_H1 { get; set; }

        [Column("PK_L1")]
        [Display(Name = "PK_L1")]
        public double? PK_L1 { get; set; }

        [Column("PK_L2")]
        [Display(Name = "PK_L2")]
        public double? PK_L2 { get; set; }

        [Column("PL_D1")]
        [Display(Name = "PL_D1")]
        public double? PL_D1 { get; set; }

        [Column("PL_H1")]
        [Display(Name = "PL_H1")]
        public double? PL_H1 { get; set; }

        [Column("PL_H2_CUT_OFF")]
        [Display(Name = "PL_H2_CUT_OFF")]
        public double? PL_H2_CUT_OFF { get; set; }

        [Column("Plate_B")]
        [Display(Name = "Plate_B")]
        public double? Plate_B { get; set; }

        [Column("Plate_tp")]
        [Display(Name = "Plate_tp")]
        public double? Plate_tp { get; set; }

        [Column("QTY")]
        [Display(Name = "QTY")]
        public double? QTY { get; set; }

        [Column("QTY_REBAR")]
        [Display(Name = "QTY_REBAR")]
        public double? QTY_REBAR { get; set; }

        [Column("Quantity")]
        [Display(Name = "Quantity")]
        public double? Quantity { get; set; }

        [Column("Reinforcement Quantity")]
        [Display(Name = "Reinforcement Quantity")]
        public double? ReinforcementQuantity { get; set; }

        [Column("ShapeId")]
        [Display(Name = "ShapeId")]
        public double? ShapeId { get; set; }

        [Column("Slope")]
        [Display(Name = "Slope")]
        public double? Slope { get; set; }

        [Column("Structural Material")]
        [Display(Name = "Structural Material")]
        public string StructuralMaterial { get; set; }

        [Column("Thickness")]
        [Display(Name = "Thickness")]
        public double? Thickness { get; set; }

        [Column("Unconnected Height")]
        [Display(Name = "Unconnected Height")]
        public double? UnconnectedHeight { get; set; }

        [Column("Vertical Surface")]
        [Display(Name = "Vertical Surface")]
        public double? VerticalSurface { get; set; }

        [Column("Volume")]
        [Display(Name = "Volume")]
        public double? Volume { get; set; }

        [Column("Weight per Meter")]
        [Display(Name = "Weight per Meter")]
        public double? WeightperMeter { get; set; }

        [Column("Width")]
        [Display(Name = "Width")]
        public double? Width { get; set; }
    }
}
