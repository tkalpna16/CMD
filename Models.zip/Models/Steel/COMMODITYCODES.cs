﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Steel
{
    public class COMMODITYCODES
    {
        [Key]
        [Column("CODEID")]
        [Display(Name = "CodeID")]
        public int CodeID { get; set; }

        [Column("CODE")]
        [Display(Name = "Code")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "GroupDescription cannot be longer than 32 characters.")]
        public string Code { get; set; }

        [Column("CODEDESCRIPTION")]
        [Display(Name = "Description")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "GroupDescription cannot be longer than 32 characters.")]
        public string CodeDescription { get; set; }

        [Column("DETAILEDDESCRIPTION")]
        [Display(Name = "Detailed Description")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineCode cannot be longer than 32 characters.")]
        public string DetailedDescription { get; set; }

        [Column("SUBCODE")]
        [Display(Name = "SubCode")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "SubDisciplineCode cannot be longer than 32 characters.")]
        public string SubCode { get; set; }

        [Column("ITEMTYPE")]
        [Display(Name = "Main Item")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineOwner cannot be longer than 32 characters.")]
        public string ItemType { get; set; }

        [Column("UOM")]
        [Display(Name = "UoM")]
        [StringLength(256, MinimumLength = 1, ErrorMessage = "DisciplineOwner cannot be longer than 32 characters.")]
        public string UoM { get; set; }

        [Column("PROJECTID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        [Column("SELECTED")]
        [Display(Name = "Selected")]
        public bool Selected { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [NotMapped]
        public string CodeDescriptionShort
        {
            get
            {
                if (string.IsNullOrEmpty(CodeDescription))
                    return CodeDescription;
                return CodeDescription.Substring(0, 16) + "..";
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public COMMODITYCODES() { }

        /// <summary>
        /// Copy Constructor
        /// </summary>
        /// <param name="codeToCopy"></param>
        /// <param name="users"></param>
        /// <param name="pROJECTS"></param>
        public COMMODITYCODES(COMMODITYCODES codeToCopy, USERS users, PROJECTS pROJECTS)
        {
            this.Code = codeToCopy.Code;
            this.CodeDescription = codeToCopy.CodeDescription;
            this.DetailedDescription = codeToCopy.DetailedDescription;
            this.ItemType = codeToCopy.ItemType;
            this.SubCode = codeToCopy.SubCode;
            this.UoM = codeToCopy.UoM;
            this.Selected = false;
            this.ProjectID = pROJECTS.ProjectID;
            this.UserID = users.USERID;
            this.CreationDate = DateTime.UtcNow;
            this.LastModified = DateTime.UtcNow;
        }
    }
}
