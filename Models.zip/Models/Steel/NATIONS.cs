﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Steel
{
    public class NATIONS
    {
        [Key]
        [Column("IDNATION")]
        [Display(Name = "IDNATION")]
        public int IDNATION { get; set; }

        [Column("ISOCODE")]
        [Display(Name = "ISOCODE")]
        public string ISOCODE { get; set; }

        [Column("DESCRIPTION_EN")]
        [Display(Name = "DESCRIPTION_EN")]
        public string DESCRIPTION_EN { get; set; }
    }
}
