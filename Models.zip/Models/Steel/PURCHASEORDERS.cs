﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Steel
{
    public class PURCHASEORDERS
    {
        [Key]
        [Column("IDPO")]
        [Display(Name = "IDPO")]
        public int IDPO { get; set; }

        [Column("NAME")]
        [Display(Name = "Name")]
        public string NAME { get; set; }

        [Column("NOTES")]
        [Display(Name = "Notes")]
        public string NOTES { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("ISVISIBLE")]
        [Display(Name = "Visible")]
        public bool? IsVisible { get; set; }

        public static PURCHASEORDERS GetStartPO(string name, int projectId, int userId)
        {
            PURCHASEORDERS purchaseOrder = new PURCHASEORDERS();
            purchaseOrder.NAME = name;
            purchaseOrder.UserID = userId;
            purchaseOrder.ProjectID = projectId;
            purchaseOrder.CreationDate = DateTime.UtcNow;
            purchaseOrder.LastModified = DateTime.UtcNow;
            purchaseOrder.IsVisible = false;
            return purchaseOrder;
        }
    }
}
