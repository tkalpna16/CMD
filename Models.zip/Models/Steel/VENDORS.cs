﻿using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Steel
{
    public class VENDORS
    {
        [Key]
        [Column("IDVENDOR")]
        [Display(Name = "IDVENDOR")]
        public int IDVENDOR { get; set; }

        [Column("COMPANYNAME")]
        [Display(Name = "Name")]
        public string COMPANYNAME { get; set; }

        [Column("ADDRESS")]
        [Display(Name = "Address")]
        public string ADDRESS { get; set; }

        [Column("CAP")]
        [Display(Name = "Cap")]
        public string CAP { get; set; }

        [Column("CITY")]
        [Display(Name = "City")]
        public string CITY { get; set; }

        [Column("PROVINCE")]
        [Display(Name = "Province")]
        public string PROVINCE { get; set; }

        [Column("NATIONSID")]
        [Display(Name = "NATIONSID")]
        public int? NATIONSID { get; set; }

        public NATIONS NATIONS { get; set; }

        [Column("TELEPHONE")]
        [Display(Name = "Telephone")]
        public string TELEPHONE { get; set; }

        [Column("FAX")]
        [Display(Name = "Fax")]
        public string FAX { get; set; }

        [Column("EMAIL")]
        [Display(Name = "Email")]
        public string EMAIL { get; set; }

        [Column("WEBSITE")]
        [Display(Name = "Website")]
        public string WEBSITE { get; set; }

        [Column("NOTES")]
        [Display(Name = "Note")]
        public string NOTES { get; set; }

        [Column("RERERENCEPEOPLE")]
        [Display(Name = "Reference")]
        public string RERERENCEPEOPLE { get; set; }

        [Column("RERERENCEEMAIL")]
        [Display(Name = "Reference Email")]
        public string RERERENCEEMAIL { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("ISVISIBLE")]
        [Display(Name = "Visible")]
        public bool? IsVisible { get; set; }

        public static VENDORS GetStartVendor(string name, int projectId, int userId)
        {
            VENDORS vendors = new VENDORS();
            vendors.COMPANYNAME = name;
            vendors.UserID = userId;
            vendors.ProjectID = projectId;
            vendors.CreationDate = DateTime.UtcNow;
            vendors.LastModified = DateTime.UtcNow;
            vendors.IsVisible = false;
            return vendors;
        }
    }
}
