﻿using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Steel
{
    public class DETAILER
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("DETAILER_ID")]
        [Display(Name = "DETAILER ID")]
        public int? DETAILER_ID { get; set; }

        [Column("DETAILER_NAME")]
        [Display(Name = "DETAILER NAME")]
        public string DETAILER_NAME { get; set; }

        [Column("DETAILER_NATION")]
        [Display(Name = "DETAILER NATION")]
        public string DETAILER_NATION { get; set; }

        [Column("DETAILER_CITY")]
        [Display(Name = "DETAILER CITY")]
        public string DETAILER_CITY { get; set; }

        [Column("DETAILER_KEY_USER")]
        [Display(Name = "DETAILER KEY USER")]
        public string DETAILER_KEY_USER { get; set; }

        [Column("DETAILER_EMAIL")]
        [Display(Name = "DETAILER EMAIL")]
        public string DETAILER_EMAIL { get; set; }

        [Column("DETAILER_PO_NO")]
        [Display(Name = "DETAILER PO NO")]
        public string DETAILER_PO_NO { get; set; }

        [Column("NOTES")]
        [Display(Name = "NOTES")]
        public string NOTES { get; set; }

        [Column("ProjectID")]
        [Display(Name = "ProjectID")]
        public int ProjectID { get; set; }

        public PROJECTS Project { get; set; }

        //public NATIONS Nations { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }


        //public List<DETAILER> Detailers { get; set; }

        //public static DETAILER GetStartVendor(string name, int projectId, int userId)
        //{
        //    DETAILER detailers = new DETAILER();
        //    detailers.DETAILER_NAME = name;
        //   //// detailers.ID = userId;
                       
        //    return detailers;
        //}
    }
}
