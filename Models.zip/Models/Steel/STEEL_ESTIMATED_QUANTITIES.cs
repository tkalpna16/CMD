﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Steel
{
    public class STEEL_ESTIMATED_QUANTITIES
    {
        [Key]
        [Column("QuantityId")]
        [Display(Name = "QuantityId")]
        public int QuantityId { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("PO_E_QTY")]
        [Display(Name = "PO_E_QTY")]
        public double? PO_E_QTY { get; set; }

        [Column("IFP_E_QTY")]
        [Display(Name = "IFP_E_QTY")]
        public double? IFP_E_QTY { get; set; }

        [Column("IFP_DELTA_QTY")]
        [Display(Name = "IFP_DELTA_QTY")]
        public double? IFP_DELTA_QTY { get; set; }

        [Column("IFF_E_QTY")]
        [Display(Name = "IFF_E_QTY")]
        public double? IFF_E_QTY { get; set; }

        [Column("IFF_DELTA_QTY")]
        [Display(Name = "IFF_DELTA_QTY")]
        public double? IFF_DELTA_QTY { get; set; }
    }
}
