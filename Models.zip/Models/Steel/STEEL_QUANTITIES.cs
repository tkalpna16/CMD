﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models.Steel
{
    public class STEEL_QUANTITIES
    {
        [Key]
        [Column("QuantityId")]
        [Display(Name = "QuantityId")]
        public int QuantityId { get; set; }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int? MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }

        [Column("CodeId")]
        [Display(Name = "CodeId")]
        public int? CodeId { get; set; }

        public COMMODITYCODES Code { get; set; }

        [Column("QTY")]
        [Display(Name = "QTY")]
        public double? QTY { get; set; }
    }
}
