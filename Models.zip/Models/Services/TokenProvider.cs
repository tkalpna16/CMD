﻿using CivilMasterData.Data;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Services
{
    public class TokenProvider
    {
        public async Task<string> LoginUser(string Username, string Password, HomeContext context,
            string tokenServer)
        {
            if (String.IsNullOrEmpty(Username) || String.IsNullOrEmpty(Password))
                return null;

            //Get user details for the user who is trying to login
            var user = await context.USERS.FirstOrDefaultAsync(x => x.USERNAME.ToUpper() == Username.ToUpper());

            //Authenticate User, Check if its a registered user in DB
            if (user == null)
                return null;

            //If its registered user, check user password stored in DB 
            //For demo, password is not hashed. Its just a string comparison
            //In reality, password would be hashed and stored in DB. Before comparing, hash the password
            if (Password == user.PASSWORD)
            {
                //Authentication successful, Issue Token with user credentials - JRozario
                //Provide the security key which was given in the JWToken configuration in Startup.cs
                var key = Encoding.ASCII.GetBytes("YourKey-2374-OFFKDI940NG7:56753253-tyuw-5769-0921-kfirox29zoxv");
                //Generate Token for user - JRozario
                var JWToken = new JwtSecurityToken(
                    issuer: tokenServer,
                    audience: tokenServer,
                    claims: GetUserClaims(user),
                    notBefore: new DateTimeOffset(DateTime.Now).DateTime,
                    expires: new DateTimeOffset(DateTime.Now.AddDays(1)).DateTime,
                    //Using HS256 Algorithm to encrypt Token - JRozario
                    signingCredentials: new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                );
                var token = new JwtSecurityTokenHandler().WriteToken(JWToken);
                return token;
            }
            else
            {
                return null;
            }
        }

        //Using hard coded collection list as Data Store for demo. In reality, User data comes from Database or some other Data Source - JRozario
        private IEnumerable<Claim> GetUserClaims(USERS user)
        {
            List<Claim> claims = new List<Claim>();
            Claim _claim;
            _claim = new Claim(ClaimTypes.Name, user.FIRST_NAME + " " + user.LAST_NAME);
            claims.Add(_claim);
            _claim = new Claim("USERID", user.USERNAME);
            claims.Add(_claim);
            _claim = new Claim("EMAIL", user.EMAIL);
            claims.Add(_claim);
            _claim = new Claim("PHONE", user.PHONE);
            claims.Add(_claim);
            _claim = new Claim(user.ACCESS_LEVEL, user.ACCESS_LEVEL);
            claims.Add(_claim);

            if (user.WRITE_ACCESS != "")
            {
                _claim = new Claim(user.WRITE_ACCESS, user.WRITE_ACCESS);
                claims.Add(_claim);
            }
            return claims.AsEnumerable<Claim>();
        }
    }
}
