﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;

namespace CivilMasterData.Models.Charts
{
    public class FeasibilityCurve
    {
        #region Private members
        PROJECTS project;
        List<PLANNINGS> planningsDB;
        List<MAINITEMS> mainItemsDB;
        List<MAIN_ITEM_QUANTITY> mainItemQuanityDB;
        List<MTOREVS> mtoRevDB;
        #endregion

        #region Constructor
        public FeasibilityCurve(PROJECTS project,
            List<PLANNINGS> planningsDB,
            List<MAINITEMS> mainItemsDB,
            List<MAIN_ITEM_QUANTITY> mainItemQuanityDB,
            List<MTOREVS> mtoRevDB)
        {
            this.project = project;
            this.planningsDB = planningsDB;
            this.mainItemsDB = mainItemsDB;
            this.mainItemQuanityDB = mainItemQuanityDB;
            this.mtoRevDB = mtoRevDB;
        }
        #endregion

        #region Calculation functions
        private List<FeasibilityCurveMonthResult> Calculate(int ifrStatusId, int ifcStatusId, TAGTYPES tagType)
        {
            List<DateTime> dateTimes = GetDateList();
            List<FeasibilityCurveMonthResult> results = new List<FeasibilityCurveMonthResult>();
            foreach(DateTime dateTime in dateTimes)
            {
                FeasibilityCurveMonthResult result = new FeasibilityCurveMonthResult(dateTime,
                    project, mainItemsDB, planningsDB, mainItemQuanityDB, mtoRevDB);
                result.UpdateValues(ifrStatusId, ifcStatusId, tagType);
                results.Add(result);
            }
            return results;
        }
        private List<DateTime> GetDateList()
        {
            List<DateTime> dates = new List<DateTime>();
            DateTime currentDate = new DateTime(project.StartDate.Value.Year,
                project.StartDate.Value.Month, 1);
            dates.Add(currentDate);
            bool notReached = true;
            while (notReached)
            {
                currentDate = currentDate.AddMonths(1);
                if (currentDate <= project.EndDate.Value)
                    dates.Add(currentDate);
                else
                    notReached = false;
            }
            return dates;
        }
        #endregion

        #region Excel
        public bool CreateExcelFile(string templateName, string fileToSave,
            string sheetName, int startColumn, int startRow,
            int ifrStatusId, int ifcStatusId, TAGTYPES tagType)
        {
            if (!System.IO.File.Exists(templateName))
                return false;

            // Calculate
            List<FeasibilityCurveMonthResult> results = Calculate(ifrStatusId, ifcStatusId, tagType);
            if (results == null || results.Count == 0)
                return false;

            System.IO.FileInfo baseFile = new System.IO.FileInfo(templateName);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[sheetName];
            if (Sheet == null)
                return false;

            double ifrBaseCum = 0.0;
            double ifrActualCum = 0.0;
            double ifrForecastCum = 0.0;
            double ifcBaseCum = 0.0;
            double ifcActualCum = 0.0;
            double ifcForecastCum = 0.0;
            foreach (FeasibilityCurveMonthResult result in results)
            {
                ifrBaseCum += result.QtyIfrBaseline;
                ifrActualCum += result.QtyIfrActual;
                ifrForecastCum += result.QtyIfrForecast;
                ifcBaseCum += result.QtyIfcBaseline;
                ifcActualCum += result.QtyIfcActual;
                ifcForecastCum += result.QtyIfcForecast;

                Sheet.Cells[startRow, startColumn].Value = result.CurrentDateTime;
                Sheet.Cells[startRow + 1, startColumn].Value = result.QtyIfrBaseline;
                Sheet.Cells[startRow + 2, startColumn].Value = ifrBaseCum;
                Sheet.Cells[startRow + 3, startColumn].Value = result.QtyIfrActual;
                Sheet.Cells[startRow + 4, startColumn].Value = ifrActualCum;
                Sheet.Cells[startRow + 5, startColumn].Value = result.QtyIfrForecast;
                Sheet.Cells[startRow + 6, startColumn].Value = ifrForecastCum;
                Sheet.Cells[startRow + 7, startColumn].Value = result.QtyIfcBaseline;
                Sheet.Cells[startRow + 8, startColumn].Value = ifcBaseCum;
                Sheet.Cells[startRow + 9, startColumn].Value = result.QtyIfcActual;
                Sheet.Cells[startRow + 10, startColumn].Value = ifcActualCum;
                Sheet.Cells[startRow + 11, startColumn].Value = result.QtyIfcForecast;
                Sheet.Cells[startRow + 12, startColumn].Value = ifcForecastCum;

                startColumn++;
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            return true;
        }
        #endregion
    }
}
