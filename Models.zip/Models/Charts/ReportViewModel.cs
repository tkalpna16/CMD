﻿using Kendo.Mvc.UI;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Charts
{
    public class ReportViewModel
    {
        public DataTable Data { get; set; }
        public IEnumerable<GridColumnSettings> Columns { get; set; }
    }
}
