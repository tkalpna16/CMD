﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Oracle.ManagedDataAccess.Client;
/// <summary>
/// Created by Shweta Dalvi (TCMPL), 3-10-2022 to use Oracle dataaccess to fetch data from views
/// 
/// </summary>
namespace CivilMasterData.Models.Charts
{
    public static class ReportUtils
    {

        public static DataTable GetFeasibilityQueryData(string code, 
                        string connectionString, 
                        string procedureName, 
                        string para1, 
                        string para2)
        {
            DataTable dt = new DataTable();
            using (OracleConnection oCon = new OracleConnection(connectionString))
            {
                oCon.Open();
                // Create a Command object to call Get_Employee_Info procedure.
                OracleCommand cmd = new OracleCommand(procedureName, oCon);

                // Command Type is StoredProcedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                OracleParameter p1 = new OracleParameter(para1, OracleDbType.Varchar2, ParameterDirection.Input);
                p1.Value = code;
                OracleParameter p2 = new OracleParameter(para2, OracleDbType.RefCursor, ParameterDirection.Output);
                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);
                // Execute procedure.
                cmd.ExecuteReader();
                OracleDataAdapter adp = new OracleDataAdapter(cmd);
                adp.Fill(dt);
                oCon.Close();
            }
            return dt;
        }



        public static DataTable GetCurveLegends(string connectionString, string procedureName, string para1)
        {
            DataTable dt = new DataTable();
            using (OracleConnection oCon = new OracleConnection(connectionString))
            {
                oCon.Open();
                // Create a Command object to call Get_Employee_Info procedure.
                OracleCommand cmd = new OracleCommand(procedureName, oCon);

                // Command Type is StoredProcedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.Clear();

                OracleParameter p1 = new OracleParameter(para1, OracleDbType.RefCursor, ParameterDirection.Output);
                cmd.Parameters.Add(p1);
                // Execute procedure.
                cmd.ExecuteReader();
                OracleDataAdapter adp = new OracleDataAdapter(cmd);
                adp.Fill(dt);

                oCon.Close();
            }
            return dt;
        }


        public static decimal GetQty(DataTable dt, string monyy, string[] tagType, string[] wpList, string legend,
            //string[] engstatus,
            string[] subconlist)
        {
            DateTime dtMonYY; 
            decimal totSum = 0;
            
       

           ///
           ///NOTE 25-10-2022: IF CONTAINS CLAUSE IS USED IN  ENGSTATUS CONDITION, THEN IT SUMS FOR ALL ENG TYPES. INSTEAD TAKE IFR FOR IFR CURVES AND IFC FOR IFC CURVES
           ///Note 27-10-2022: the above condition is ruled out as the ENGSTATUS filter itself is removed.
           ///

            if (dt.Rows.Count > 0)
            {
                switch (legend)
                {
                    
                    case "IFR-BASELINE MONTHLY":
                        #region IFR-BASELINE-MONTHLY
                        //engstatus.Contains(x.Field<string>("eng_status")) y => y != null
                        //x.Field<string>("eng_Status").Equals("IFR")
                        totSum = dt.AsEnumerable()
                            .Where(x => 
                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                    && wpList.Contains(x.Field<string>("wP"))
                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_BASE_ENG"))
                                    && x.Field<string>("DATE_IFR_BASE_ENG").ToUpper() == monyy)
                            .Select(x => x.Field<decimal>("qty_wr_ifr")).Sum();

                        #endregion
                        break;

                    case "IFR-BASELINE CUM.":
                        #region IFR-BASELINE-CUM
                        dtMonYY = Convert.ToDateTime("01-" + monyy);
                        //var x = dt.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_BASE_ENG")) &&
                        //                x.Field<string>("DATE_IFR_BASE_ENG").ToUpper().Contains(monyy));
                        //if (x.Any())
                        //{
                        //    //DataTable dx = x.CopyToDataTable();
                        // x.Field<string>("eng_Status").Equals("IFR")
                        totSum = dt.AsEnumerable()
                        .Where(x =>
                                tagType.Contains(x.Field<string>("TAG_DESC"))
                                && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                && wpList.Contains(x.Field<string>("wP"))
                                && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_BASE_ENG"))
                                && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFR_BASE_ENG").ToUpper()) <= dtMonYY)
                        .Select(x => x.Field<decimal>("qty_wr_ifr")).Sum();

                        //}
                        //else
                        //{
                        //    totSum = 0;
                        //}

                        #endregion
                        break;

                    case "IFR-ACTUAL MONTHLY":
                        #region IFR-ACTUAL-MONTHLY
                        totSum = dt.AsEnumerable()
                            .Where(x => //x.Field<string>("eng_Status").Equals("IFR")
                                    //engstatus.Contains(x.Field<string>("eng_status"))
                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                    && wpList.Contains(x.Field<string>("wP"))
                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_ACTUAL"))
                                    && x.Field<string>("DATE_IFR_ACTUAL").ToUpper() == monyy)
                            .Select(x => x.Field<decimal>("QTY_IFR")).Sum();
                        #endregion
                        break;

                    case "IFR-ACTUAL CUM.":
                        #region IFR-ACTUAL-CUM
                        dtMonYY = Convert.ToDateTime("01-" + monyy);

                        var x = dt.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_ACTUAL")) &&
                                        x.Field<string>("DATE_IFR_ACTUAL").ToUpper().Contains(monyy));
                        var curdate = DateTime.Now;

                        if(dtMonYY.Month <= (curdate.Month)  && dtMonYY.Year == (curdate.Year))
                        { 
                        //if (x.Any())
                        //{
                        totSum = dt.AsEnumerable()
                            .Where(x => //x.Field<string>("eng_Status").Equals("IFR")
                                        //engstatus.Contains(x.Field<string>("eng_status"))
                                tagType.Contains(x.Field<string>("TAG_DESC"))
                                && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                && wpList.Contains(x.Field<string>("wP"))
                                && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_ACTUAL"))
                                && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFR_ACTUAL").ToUpper()) <= dtMonYY)
                            .Select(x => x.Field<decimal>("QTY_IFR")).Sum();
                        }
                        else
                        {
                            totSum = 0 ;
                        }

                        #endregion
                        break;

                    case "IFR-FORECAST MONTHLY":

                        #region GetLastMonth-IFR-Actual-Cum
                        DateTime dtIFRActual; string mmyyIFRAct = "";
                        //Get the last month of ifr-actual-cum
                        var dtifract = dt.AsEnumerable()
                            .Where(x => //x.Field<string>("eng_Status").Equals("IFR")
                                        //engstatus.Contains(x.Field<string>("eng_status"))
                                tagType.Contains(x.Field<string>("TAG_DESC"))
                                && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                && wpList.Contains(x.Field<string>("wP"))
                                && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_ACTUAL")))
                            .Select(x => x.Field<string>("DATE_IFR_ACTUAL").ToUpper()).ToList();
                        //.Select(x => Convert.ToDateTime("01-" + x.Field<string>("DATE_IFR_ACTUAL").ToUpper())).Max();
                        if (dtifract.Any())
                        {
                            
                           // dtIFRActual = dtifract.Select(x => Convert.ToDateTime("01-" + x.ToUpper())).Max(); //Commented by kalpna on 24-11-2022 for the current month date

                            dtIFRActual =  DateTime.Now;
                            //DateTime now = DateTime.Now;
                            dtIFRActual = new DateTime(dtIFRActual.Year, dtIFRActual.Month, 1);

                            mmyyIFRAct = dtIFRActual.AddMonths(-1).ToString("MMM-yy").ToUpper();

                                #region IFR-FORECAST-MONTHLY
                                //Get total starting from last month of ifr actual cum
                                totSum = dt.AsEnumerable()
                                    .Where(x => //x.Field<string>("eng_Status").Equals("IFR")
                                                //engstatus.Contains(x.Field<string>("eng_status"))
                                            tagType.Contains(x.Field<string>("TAG_DESC"))
                                            && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                            && wpList.Contains(x.Field<string>("wP"))
                                            && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_FORE"))
                                            && Convert.ToDateTime("01" + x.Field<string>("DATE_IFR_FORE").ToUpper()) >= dtIFRActual
                                            && x.Field<string>("DATE_IFR_FORE").ToUpper() == monyy)
                                    .Select(x => x.Field<decimal>("qty_CE_ifr")).Sum();
                           
                            #endregion
                        }
                        else
                        {
                            totSum = 0;
                        }

                        #endregion


                        break;

                    case "IFR-FORECAST CUM.":

                        #region GetLastMonth-IFR-Actual-Cum
                        //Get the last month of ifr-actual-cum
                                               

                            dtifract = dt.AsEnumerable()
                            .Where(x => //x.Field<string>("eng_Status").Equals("IFR")
                            //engstatus.Contains(x.Field<string>("eng_status"))
                                tagType.Contains(x.Field<string>("TAG_DESC"))
                                && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                && wpList.Contains(x.Field<string>("wP"))
                                && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_ACTUAL")))
                            .Select(x => x.Field<string>("DATE_IFR_ACTUAL").ToUpper()).ToList();
                            //.Select(x => Convert.ToDateTime("01-" + x.Field<string>("DATE_IFR_ACTUAL").ToUpper())).Max();

                            if (dtifract.Any())
                            {
                                //dtIFRActual = dtifract.Select(x => Convert.ToDateTime("01-" + x.ToUpper())).Max();
                            
                            dtIFRActual = DateTime.Now;                            
                            dtIFRActual = new DateTime(dtIFRActual.Year, dtIFRActual.Month, 1);
                            //dtIFRActual = dtifrac

                            mmyyIFRAct = dtIFRActual.AddMonths(-1).ToString("MMM-yy").ToUpper();

                                #region IFR-FORECASE-CUM
                                //The forecast cumulative will start from last month of ifr-actual
                                //The last ifr-actual cumulative will be starting point of ifr forecast cum
                                dtMonYY = Convert.ToDateTime("01-" + monyy);

                                decimal totLastIFRActualCum = dt.AsEnumerable()
                                        .Where(x => //x.Field<string>("eng_Status").Equals("IFR")
                                                    //engstatus.Contains(x.Field<string>("eng_status"))
                                            tagType.Contains(x.Field<string>("TAG_DESC"))
                                            && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                            && wpList.Contains(x.Field<string>("wP"))
                                            && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_ACTUAL"))
                                            && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFR_ACTUAL").ToUpper()) <= dtIFRActual.AddMonths(-1))
                                        .Select(x => x.Field<decimal>("QTY_IFR")).Sum();

                                if (mmyyIFRAct.ToUpper() == monyy.ToUpper())
                                {
                                    totSum = totLastIFRActualCum;
                                }
                                else if (dtMonYY > dtIFRActual.AddMonths(-1))
                                {
                                    //Add ifr forecast value of each month to ifr actual cumulative to form continuous graph
                                    totSum = totLastIFRActualCum + dt.AsEnumerable()
                                           .Where(x => //engstatus.Contains(x.Field<string>("eng_status"))
                                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                                    && wpList.Contains(x.Field<string>("wP"))
                                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFR_FORE"))
                                                    && Convert.ToDateTime("01" + x.Field<string>("DATE_IFR_FORE").ToUpper()) >= dtIFRActual
                                                    && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFR_FORE").ToUpper()) <= dtMonYY)
                                            .Select(x => x.Field<decimal>("qty_CE_ifr")).Sum();
                                    ////&& x.Field<string>("DATE_IFR_FORE").ToUpper() == monyy)
                                }
                                else
                                {
                                    totSum = 0;
                                }

                                #endregion
                            }
                        

                        #endregion

                        break;
                    
                    case "IFC-BASELINE MONTHLY":
                        #region IFC-BASELINE-MONTHLY
                        totSum = dt.AsEnumerable()
                            .Where(x => // x.Field<string>("eng_Status").Equals("IFC")
                            // engstatus.Contains(x.Field<string>("eng_status"))
                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                    && wpList.Contains(x.Field<string>("wP"))
                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_BASE_ENG"))
                                    && x.Field<string>("DATE_IFC_BASE_ENG").ToUpper() == monyy)
                            .Select(x => x.Field<decimal>("qty_wr_ifC")).Sum();
                        #endregion
                        break;

                    case "IFC-BASELINE CUM.":
                        #region IFC-BASELINE-CUM
                        dtMonYY = Convert.ToDateTime("01-" + monyy);
                        //x = dt.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_BASE_ENG")) &&
                        //               x.Field<string>("DATE_IFC_BASE_ENG").ToUpper().Contains(monyy));
                        //if (x.Any())
                        //{
                        totSum = dt.AsEnumerable()
                        .Where(x => //x.Field<string>("eng_Status").Equals("IFC")
                        //engstatus.Contains(x.Field<string>("eng_status"))
                                tagType.Contains(x.Field<string>("TAG_DESC"))
                                && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                && wpList.Contains(x.Field<string>("wP"))
                                && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_BASE_ENG"))
                                && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_BASE_ENG").ToUpper()) <= dtMonYY)
                        .Select(x => x.Field<decimal>("qty_wr_ifC")).Sum();
                        //}
                        //else
                        //{
                        //    totSum = 0;
                        //}

                        #endregion
                        break;

                    case "IFC-ACTUAL MONTHLY":
                        #region IFC-ACTUAL-MONTHLY
                        totSum = dt.AsEnumerable()
                            .Where(x => //x.Field<string>("eng_Status").Equals("IFC")
                            //engstatus.Contains(x.Field<string>("eng_status"))
                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                    && wpList.Contains(x.Field<string>("wP"))
                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_ACTUAL"))
                                    && x.Field<string>("DATE_IFC_ACTUAL").ToUpper() == monyy)
                            .Select(x => x.Field<decimal>("QTY_IFC")).Sum();

                        #endregion
                        break;
            
                    case "IFC-ACTUAL CUM.":
                        #region IFC-ACTUAL-CUM
                        dtMonYY = Convert.ToDateTime("01-" + monyy);
                        x = dt.AsEnumerable().Where(x => !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_ACTUAL")) &&
                                      x.Field<string>("DATE_IFC_ACTUAL").ToUpper().Contains(monyy));
                        //if (x.Any())
                        //{
                        var IFCcurdate = DateTime.Now;

                        if (dtMonYY.Month <= (IFCcurdate.Month) && dtMonYY.Year == (IFCcurdate.Year))
                        {
                            totSum = dt.AsEnumerable()
                                .Where(x => //x.Field<string>("eng_Status").Equals("IFC")
                                //engstatus.Contains(x.Field<string>("eng_status"))
                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                    && wpList.Contains(x.Field<string>("wP"))
                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_ACTUAL"))
                                    && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_ACTUAL").ToUpper()) <= dtMonYY)
                                .Select(x => x.Field<decimal>("QTY_IFC")).Sum();
                        }
                        else
                        {
                            totSum = 0;
                        }

                        #endregion
                        break;

                    case "IFC-FORECAST MONTHLY":
                        #region GetLastMonth-IFC-Actual-Cum
                        DateTime dtIFCActual;
                        string mmyyIFCAct;
                        //Get the last month of ifc-actual-cum
                        var dtifcact = dt.AsEnumerable()
                                               .Where(x =>// x.Field<string>("eng_Status").Equals("IFC")
                                                          //engstatus.Contains(x.Field<string>("eng_status"))
                                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                                    && wpList.Contains(x.Field<string>("wP"))
                                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_ACTUAL")))
                                               .Select(x => x.Field<string>("DATE_IFC_ACTUAL").ToUpper()).ToList();
                        // .Select(x => Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_ACTUAL").ToUpper())).Max();

                        if (dtifcact.Any())
                        {

                            // dtIFCActual = dtifcact.Select(x => Convert.ToDateTime("01-" + x)).Max();
                            dtIFCActual = DateTime.Now;                           
                            
                            dtIFCActual = new DateTime(dtIFCActual.Year, dtIFCActual.Month, 1);

                            mmyyIFCAct = dtIFCActual.AddMonths(-1).ToString("MMM-yy").ToUpper();

                            #region IFC-FORECAST-MONTHLY
                            totSum = dt.AsEnumerable()
                                .Where(x => //x.Field<string>("eng_Status").Equals("IFC")
                                            //engstatus.Contains(x.Field<string>("eng_status"))
                                        tagType.Contains(x.Field<string>("TAG_DESC"))
                                        && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                        && wpList.Contains(x.Field<string>("wP"))
                                        && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_FORE"))
                                        && Convert.ToDateTime("01" + x.Field<string>("DATE_IFC_FORE").ToUpper()) >= dtIFCActual
                                        && x.Field<string>("DATE_IFC_FORE").ToUpper() == monyy)
                                .Select(x => x.Field<decimal>("qty_CE_ifC")).Sum();

                            #endregion
                        }
                        else
                        {
                            totSum = 0;
                        }
                        

                        #endregion


                        break;

                    case "IFC-FORECAST CUM.":
                        #region GetLastMonth-IFC-Actual-Cum
                        //Get the last month of ifc-actual-cum

                        
                            dtifcact = dt.AsEnumerable()
                                               .Where(x =>// x.Field<string>("eng_Status").Equals("IFC")
                                                          //engstatus.Contains(x.Field<string>("eng_status"))
                                                    tagType.Contains(x.Field<string>("TAG_DESC"))
                                                    && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                                    && wpList.Contains(x.Field<string>("wP"))
                                                    && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_ACTUAL")))
                                               .Select(x => x.Field<string>("DATE_IFC_ACTUAL").ToUpper()).ToList();
                            //.Select(x => Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_ACTUAL").ToUpper())).Max();
                            if (dtifcact.Any())
                            {
                                //dtIFCActual = dtifcact.Select(x => Convert.ToDateTime("01-" + x)).Max();
                                dtIFCActual = DateTime.Now;

                                mmyyIFCAct = dtIFCActual.AddMonths(-1).ToString("MMM-yy").ToUpper();

                                #region IFC-FORECAST-CUM
                                //The forecast cumulative will start from last month of ifc-actual
                                //The last ifc-actual cumulative will be starting point of ifc forecast cum

                                dtMonYY = Convert.ToDateTime("01-" + monyy);

                                decimal totLastIFCActualCum = dt.AsEnumerable()
                                      .Where(x => //x.Field<string>("eng_Status").Equals("IFC")
                                                  //engstatus.Contains(x.Field<string>("eng_status"))
                                          tagType.Contains(x.Field<string>("TAG_DESC"))
                                          && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                          && wpList.Contains(x.Field<string>("wP"))
                                          && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_ACTUAL"))
                                          && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_ACTUAL").ToUpper()) <= dtIFCActual.AddMonths(-1))
                                      .Select(x => x.Field<decimal>("QTY_IFC")).Sum();

                                if (mmyyIFCAct.ToUpper() == monyy.ToUpper())
                                {
                                    totSum = totLastIFCActualCum;
                                }
                                else if (dtMonYY > dtIFCActual.AddMonths(-1))
                                {
                                    //Add IFC forecast value of each month to IFC actual cumulative to form continuous graph
                                    totSum = totLastIFCActualCum + dt.AsEnumerable()
                                            .Where(x => //engstatus.Contains(x.Field<string>("eng_status"))
                                                tagType.Contains(x.Field<string>("TAG_DESC"))
                                                && subconlist.Contains(x.Field<string>("SUBCONTRACTOR"))
                                                && wpList.Contains(x.Field<string>("wP"))
                                                && !string.IsNullOrEmpty(x.Field<string>("DATE_IFC_FORE"))
                                                && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_FORE").ToUpper()) >= dtIFCActual
                                                && Convert.ToDateTime("01-" + x.Field<string>("DATE_IFC_FORE").ToUpper()) <= dtMonYY)
                                            .Select(x => x.Field<decimal>("qty_CE_ifC")).Sum();

                                    //&& x.Field<string>("DATE_IFC_FORE").ToUpper() == monyy)
                                }
                                else
                                {
                                    totSum = 0;
                                }

                                #endregion
                            }

                        
                        #endregion


                        break;                 
                        
                    default:
                        totSum = 0;
                        break;
                }
                //return totSum;
            }
            return Math.Round(totSum);
        }

        public static DataTable GetCurveDataTable(
            DataTable dtFeasData, DataTable dtLegends, 
            List<string> monthlist, string[] tagType, string[] wpList, 
            //string[] engStatus, 
            string[] subcont
            )
        {
            DataTable dtCurveData = new DataTable();
            dtCurveData.Columns.Add("LEGEND");
            //Filter only required Legends based on IFR , IFC etc
            //DataTable dtlegs = dtLegends.AsEnumerable().Where(x => engStatus. x.Field<string>(1)).CopyToDataTable();
            foreach (DataRow row in dtLegends.Rows)
            {
                DataRow dr = dtCurveData.NewRow();
                dr["Legend"] = row[1].ToString();
                dtCurveData.Rows.Add(dr);
                //for (int i = 0; i < engStatus.Length; i++)
                //{
                //    if (!string.IsNullOrEmpty(engStatus[i].ToString()))
                //    {
                //        if (row[1].ToString().Contains(engStatus[i].ToString()))
                //        {
                //dr["Legend"] = row[1].ToString();
                //dtCurveData.Rows.Add(dr);
                //        }
                //    }
                //}
            }
            foreach (var mm in monthlist)
            {
                dtCurveData.Columns.Add(mm.ToString());
            }

            string strLegend = "";
            foreach (DataRow dataRow in dtCurveData.Rows)
            {
                decimal tempqty = 0;
                foreach (DataColumn dataColumn in dtCurveData.Columns)
                {
                    if (dataColumn.ColumnName == "LEGEND")
                    {
                        strLegend = dataRow[dataColumn.ColumnName].ToString();
                    }
                    else
                    {
                        //if (dataRow["LEGEND"].ToString().ToUpper().Contains("FORECAST MONTHLY"))//comment later for testing
                        //{
                            string colName = dataColumn.ColumnName;
                            

                            decimal qty = ReportUtils.GetQty(dtFeasData, colName, tagType, wpList, strLegend, subcont);

                            dataRow[colName] = qty;

                            #region NewCodeToStandardizedLikeExcel
                            int colIndex = dataColumn.Ordinal - 1;
                            if (dataRow[dataColumn.ColumnName].ToString() == "0")
                            {
                                dataRow[colName] = null;
                            }
                            else
                            {
                                if (dataRow[colIndex].ToString() == "" &&
                                    (dataRow["LEGEND"].ToString().ToUpper().Contains("BASELINE CUM.") ||
                                    dataRow["LEGEND"].ToString().ToUpper().Contains("ACTUAL CUM.")))
                                {
                                    dataRow[colIndex] = 0;
                                }

                                //else if (dataRow["LEGEND"].ToString().ToUpper().Contains("FORECAST MONTHLY"))
                                //{                                //    tempqty = Convert.ToInt32(dataRow[dataColumn.ColumnName].ToString());                                //    dataRow[colName] = null;                                //}

                                else
                                {
                                    dataRow[colName] = Convert.ToInt32(dataRow[dataColumn.ColumnName].ToString());
                                }                               
                            }

                            #region Block added by Kalpna on 22-11-2022 for IFC-FORECAST MONTHLY and IFR-FORECAST MONTHLY start from Nov
                            //if (colName.Contains("NOV") && dataRow["LEGEND"].ToString().ToUpper().Contains("FORECAST MONTHLY"))
                            //{
                            //    dataRow[colName] = tempqty;
                            //}
                            #endregion

                            #endregion


                       // }
                    }

                }
            }

            return dtCurveData;
        }


        public static bool GenerateFeasibilityReport(DataTable dtCurve, 
            string _ProjectDetails, string wpList,
            string templateName, string fileToSave,
            string sheetName, int startColumn, int startRow, int legendRow, int legendCol,string subcont,string tagTypeStr)
        {
            if (!System.IO.File.Exists(templateName))
                return false;

            System.IO.FileInfo baseFile = new System.IO.FileInfo(templateName);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[sheetName];
            if (Sheet == null)
                return false;
            //Print legends
            int lastCol = 0;

            Color colFromHex = System.Drawing.ColorTranslator.FromHtml("#fafa2f");
            

            //if only IFR and IFC is selected then toggle the legnedRow index else it will give error.
            foreach (DataRow dataRow in dtCurve.Rows)
            {
                if(Sheet.Cells[legendRow, legendCol].Value.ToString().ToUpper() == dataRow[0].ToString())
                {
                    int dcol = 53;
                    int col = startColumn; 
                    foreach (DataColumn dataColumn in dtCurve.Columns)
                    {
                        //int colIndex = dataColumn.Ordinal -1;
                        if (dataColumn.ColumnName != "LEGEND")
                        {
                            Sheet.Cells[startRow, col].Value = dataColumn.ColumnName;
                            if (dataRow[dataColumn.ColumnName].ToString() == "0")
                            {
                                Sheet.Cells[legendRow, col].Value = null;   
                            }
                            else if (string.IsNullOrEmpty(dataRow[dataColumn.ColumnName].ToString()))
                            {
                                Sheet.Cells[legendRow, col].Value = null;
                                
                            }
                            else
                            {
                                if(Sheet.Cells[legendRow, col-1].Value==null && 
                                    (Sheet.Cells[legendRow,1].Value.ToString().ToUpper().Contains("BASELINE CUM.") ||
                                    Sheet.Cells[legendRow, 1].Value.ToString().ToUpper().Contains("ACTUAL CUM.")))
                                {
                                    Sheet.Cells[legendRow, col - 1].Value = 0;
                                }

                                Sheet.Cells[legendRow, col].Value = Convert.ToInt32(dataRow[dataColumn.ColumnName].ToString());
                            }

                            #region Block added by kalpna for dynamic column BG color and formating
                            Sheet.Cells[36, col].Style.Fill.PatternType = ExcelFillStyle.Solid;
                            Sheet.Cells[36, col].Style.Fill.BackgroundColor.SetColor(colFromHex);
                            Sheet.Cells[37, col].Style.Fill.PatternType = ExcelFillStyle.Solid;
                            Sheet.Cells[37, col].Style.Fill.BackgroundColor.SetColor(colFromHex);
                            if (col > 50)   {
                                if (col < dtCurve.Columns.Count)
                                {
                                    Sheet.Cells[36, dcol].Value = col; dcol++;
                                }
                                Sheet.Cells[legendRow, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[legendRow, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[legendRow, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[legendRow, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                                Sheet.Cells[36, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[36, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[36, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[36, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                                Sheet.Cells[37, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[37, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[37, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[37, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                                Sheet.Cells[50, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[50, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[50, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[50, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                                Sheet.Cells[51, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[51, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[51, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[51, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                                Sheet.Cells[52, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[52, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[52, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[52, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                                Sheet.Cells[53, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[53, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[53, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                Sheet.Cells[53, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                //Sheet.SelectedRange[50,col,53,col].Style.Border.Top= ExcelBorderStyle.Thin;
                               
                            }
                            #endregion
                            col++;
                        }
                    }
                    lastCol = col++;
                    legendRow++;
                }
                
            }

            //Delete blank columns; 52 is last column in template
            //   Sheet.DeleteColumn(lastCol, 52);
            for (int i = lastCol; i <= 52; i++)
            {
                Sheet.Column(i).Hidden = true;
            }

            Sheet.Cells["A1"].Value = _ProjectDetails;
            Sheet.Cells["C4"].Value = System.DateTime.Now.ToShortDateString();
            //Sheet.Cells["F4"].Value = "Concrete (m3)/Steel (t)/UG (?) - " + wpList.Replace("\"","");
            //Code updated by Kalpna on 21-11-2022 for dynamic title name for Tagtype and Subcont.
            Sheet.Cells["F4"].Value = tagTypeStr.Replace("\"", "") + wpList.Replace("\"", "")+ subcont.Replace("\"", "");
            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            

            //Sheet.Cells[].LoadFromDataTable(dtCurve, false)
            return true;
        }
    }

  
}

