﻿using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.Data;

namespace CivilMasterData.Models
{
    public class Reports
    {
        public List<PROJECTS> Projects { get; set; }
        public List<USERS> Users { get; set; }
        public List<PBS> PBS { get; set; }
        public List<TAGTYPES> TAGTYPES { get; set; }
        public List<SECONDARY_ITEM> SECONDARY_ITEMS { get; set; }
        public List<string> WPLIST { get; set; }
        public List<ENGINEERING_STATUS> ENG_STATUS { get; set; }
        public List<string> ProjectTimeframe { get; set; }
        public List<string> ReportType { get; set; }

        public List<string> SubContractors { get; set; }

        //This can be changed if required. just to make things working added here
        public DataTable curveData { get; set; }
        public Reports()
        {

        }
    }

    
}
