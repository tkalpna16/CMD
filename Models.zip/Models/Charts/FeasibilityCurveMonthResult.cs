﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CivilMasterData.Models.Charts
{
    public class FeasibilityCurveMonthResult
    {
        #region Public members
        public DateTime CurrentDateTime { private set; get; }
        public double QtyIfrBaseline { private set; get; }
        public double QtyIfrForecast { private set; get; }
        public double QtyIfrActual { private set; get; }
        public double QtyIfcBaseline { private set; get; }
        public double QtyIfcForecast { private set; get; }
        public double QtyIfcActual { private set; get; }
        #endregion

        #region Private members
        PROJECTS project;
        List<PLANNINGS> planningsDB;
        List<MAINITEMS> mainItemsDB;
        List<MAIN_ITEM_QUANTITY> mainItemQuanityDB;
        List<MTOREVS> mtoRevDB;
        #endregion

        #region Constructor
        public FeasibilityCurveMonthResult(DateTime currentDate,
            PROJECTS project,
            List<MAINITEMS> mainItemsDB,
            List<PLANNINGS> planningsDB,
            List<MAIN_ITEM_QUANTITY> mainItemQuanityDB,
            List<MTOREVS> mtoRevDB)
        {
            this.CurrentDateTime = currentDate;
            this.project = project;
            this.planningsDB = planningsDB;
            this.mainItemsDB = mainItemsDB;
            this.mainItemQuanityDB = mainItemQuanityDB;
            this.mtoRevDB = mtoRevDB;
        }
        #endregion

        #region Methods
        public void UpdateValues(int ifrStatusId, int ifcStatusId, TAGTYPES tagType)
        {
            ResetValues();
            double qty = 0.0;
            if (mainItemsDB != null)
            {
                foreach(MAINITEMS mainItem in mainItemsDB)
                {
                    if (mainItem.TagTypeID != tagType.TagTypeID)
                        continue;
                    var mainItemQty = mainItemQuanityDB.Where(q => q.MainItemId == mainItem.MainItemID).FirstOrDefault();
                    if (mainItemQty == null)
                        continue;
                    var planning = planningsDB.Where(q => q.MainItemId == mainItem.MainItemID).FirstOrDefault();
                    if (planning == null)
                        continue;
                    qty = Calculate_IFR_Baseline_Monthly(mainItemQty, planning, CurrentDateTime.Year, CurrentDateTime.Month);
                    QtyIfrBaseline += qty;
                    qty = Calculate_IFC_Baseline_Monthly(mainItemQty, planning, CurrentDateTime.Year, CurrentDateTime.Month);
                    QtyIfcBaseline += qty;
                    qty = Calculate_IFR_Forecast_Monthly(mainItemQty, planning, CurrentDateTime.Year, CurrentDateTime.Month);
                    QtyIfrForecast += qty;
                    qty = Calculate_IFC_Forecast_Monthly(mainItemQty, planning, CurrentDateTime.Year, CurrentDateTime.Month);
                    QtyIfcForecast += qty;

                    qty = Calculate_IFR_Actual_Monthly(mainItem, planning, CurrentDateTime.Year, CurrentDateTime.Month, ifrStatusId);
                    QtyIfrActual += qty;
                    qty = Calculate_IFC_Actual_Monthly(mainItem, planning, CurrentDateTime.Year, CurrentDateTime.Month, ifcStatusId);
                    QtyIfcActual += qty;
                }
            }
        }
        private void ResetValues()
        {
            QtyIfrBaseline = 0.0;
            QtyIfrForecast = 0.0;
            QtyIfrActual = 0.0;
            QtyIfcBaseline = 0.0;
            QtyIfcForecast = 0.0;
            QtyIfcActual = 0.0;
        }
        #endregion

        #region Baseline Calculations
        private double Calculate_IFR_Baseline_Monthly(MAIN_ITEM_QUANTITY mainItemQty,
            PLANNINGS planning,
            int year,
            int month)
        {
            double val = 0.0;
            //DateTime? dateTime = planning.DATE_BASE_IFR_ENG;
            //if (dateTime != null && dateTime.HasValue)
            //{
            //    if (dateTime.Value.Year == year && dateTime.Value.Month == month)
            //        if (mainItemQty.QTY_WR.HasValue)
            //            val = mainItemQty.QTY_WR.Value;
            //}
            return val;
        }
        private double Calculate_IFC_Baseline_Monthly(MAIN_ITEM_QUANTITY mainItemQty,
            PLANNINGS planning,
            int year,
            int month)
        {
            double val = 0.0;
            //DateTime? dateTime = planning.DATE_BASE_IFC_ENG;
            //if (dateTime != null && dateTime.HasValue)
            //{
            //    //if (dateTime.Value.Year == year && dateTime.Value.Month == month)
            //    //    if (mainItemQty.QTY_CE.HasValue)
            //    //        val = mainItemQty.QTY_CE.Value;
            //}
            return val;
        }
        #endregion

        #region Forecast Calculations
        private double Calculate_IFR_Forecast_Monthly(MAIN_ITEM_QUANTITY mainItemQty,
            PLANNINGS planning, 
            int year, 
            int month)
        {
            double val = 0.0;
            //DateTime? dateTime = planning.DATE_FORE_IFR;
            //if (dateTime != null && dateTime.HasValue)
            //{
            //    if (dateTime.Value.Year == year && dateTime.Value.Month == month)
            //        if (mainItemQty.QTY_WR.HasValue)
            //            val = mainItemQty.QTY_WR.Value;
            //}
            return val;
        }
        private double Calculate_IFC_Forecast_Monthly(MAIN_ITEM_QUANTITY mainItemQty,
            PLANNINGS planning,
            int year,
            int month)
        {
            double val = 0.0;
            //DateTime? dateTime = planning.DATE_FORE_IFC;
            //if (dateTime != null && dateTime.HasValue)
            //{
            //    //if (dateTime.Value.Year == year && dateTime.Value.Month == month)
            //    //    if (mainItemQty.QTY_CE.HasValue)
            //    //        val = mainItemQty.QTY_CE.Value;
            //}
            return val;
        }
        #endregion

        #region Actual Calculations
        private double Calculate_IFR_Actual_Monthly(MAINITEMS mainItem,
            PLANNINGS planning,
            int year,
            int month,
            int ifrStatusId)
        {
            double val = 0.0;
            //DateTime? dateTime = planning.DATE_ACT_IFR;
            //if (dateTime != null && dateTime.HasValue)
            //{
            //    if (dateTime.Value.Year == year && dateTime.Value.Month == month)
            //    {
            //        // Find all item with status IFR
            //        var revQty = mtoRevDB.Where(s => s.STATUSID ==
            //            ifrStatusId && s.MAINITEMID == mainItem.MainItemID).OrderByDescending(s => s.REVID).FirstOrDefault();
            //        if (revQty != null && revQty.QTY != null && revQty.QTY.HasValue)
            //            val = revQty.QTY.Value;
            //    }
            //}
            return val;
        }
        private double Calculate_IFC_Actual_Monthly(MAINITEMS mainItem,
            PLANNINGS planning,
            int year,
            int month,
            int ifcStatusId)
        {
            double val = 0.0;
            //DateTime? dateTime = planning.DATE_ACT_IFR;
            //if (dateTime != null && dateTime.HasValue)
            //{
            //    if (dateTime.Value.Year == year && dateTime.Value.Month == month)
            //    {
            //        // Find all item with status IFC
            //        var revQty = mtoRevDB.Where(s => s.STATUSID ==
            //            ifcStatusId && s.MAINITEMID == mainItem.MainItemID).OrderByDescending(s => s.REVID).FirstOrDefault();
            //        if (revQty != null && revQty.QTY != null && revQty.QTY.HasValue)
            //            val = revQty.QTY.Value;
            //    }
            //}
            return val;
        }
        #endregion
    }
}
