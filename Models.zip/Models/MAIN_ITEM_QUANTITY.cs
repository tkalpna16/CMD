﻿using CivilMasterData.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace CivilMasterData.Models
{
    /// <summary>
    /// PBS Chapter 6.2.1
    /// </summary>
    public class MAIN_ITEM_QUANTITY
    {
        [Key]
        [Column("QuantityId")]
        [Display(Name = "QuantityId")]
        public int QuantityId { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int MainItemId { get; set; }

        public MAINITEMS MAINITEMS { get; set; }


        [Column("QTY_BUDGET")]
        [Display(Name = "QTY_BUDGET")]
        public double? QTY_BUDGET { get; set; }

        [Column("MANUAL_QTY_HOLD")]
        [Display(Name = "MANUAL_QTY_HOLD")]
        public double? MANUAL_QTY_HOLD { get; set; }

        [Column("QTY_WR")]
        [Display(Name = "QTY_WR")]
        public double? QTY_WR { get; set; }

        [Column("QTY_REINF")]
        [Display(Name = "QTY_REINF")]
        public double? QTY_REINF { get; set; }

        [Column("QTY_IFR")]
        [Display(Name = "QTY_IFR")]
        public double? QTY_IFR { get; set; }

        [Column("QTY_IFC")]
        [Display(Name = "QTY_IFC")]
        public double? QTY_IFC { get; set; }

        [Column("QTY_VD")]
        [Display(Name = "QTY_VD")]
        public double? QTY_VD { get; set; }

        [Column("QTY_ACC")]
        [Display(Name = "QTY_ACC")]
        public double? QTY_ACC { get; set; }

        [Column("QTY_NEXT_CE")]
        [Display(Name = "QTY_NEXT_CE")]
        public double? QTY_NEXT_CE { get; set; }

        [Column("CONNECTION_INDICENCE")]
        [Display(Name = "CONNECTION_INDICENCE")]
        public double? CONNECTION_INDICENCE { get; set; }

        [Column("AI_VOLUME_LAST_ISSUE")]
        [Display(Name = "AI_VOLUME_LAST_ISSUE")]
        public double? AI_VOLUME_LAST_ISSUE { get; set; }

        [NotMapped]
        public List<MAIN_ITEM_QUANTITY_CE> CERevisions { get; set; }

        [NotMapped]
        public double QTY_LAST_ISSUE
        {
            get
            {
                if (QTY_ACC != null && QTY_ACC.HasValue && QTY_ACC.Value > 0.0)
                    return QTY_ACC.Value;
                if (QTY_VD != null && QTY_VD.HasValue && QTY_VD.Value > 0.0)
                    return QTY_VD.Value;
                if (QTY_IFC != null && QTY_IFC.HasValue && QTY_IFC.Value > 0.0)
                    return QTY_IFC.Value;
                if (QTY_IFR != null && QTY_IFR.HasValue && QTY_IFR.Value > 0.0)
                    return QTY_IFR.Value;
                return 0.0;
            }
        }

        [NotMapped]
        public double GetLastCEQty
        {
            get
            {
                if (CERevisions != null && CERevisions.Count > 0)
                {
                    var qty = CERevisions.OrderByDescending(r => r.RevId).FirstOrDefault();
                    if (qty.QTY_CE != null && qty.QTY_CE.HasValue)
                        return qty.QTY_CE.Value;
                }
                return 0.0;
            }
        }

        [NotMapped]
        public double AiVolumeIncidence
        {
            get
            {
                double qtyAiLastIssue = 0.0;
                if (AI_VOLUME_LAST_ISSUE != null && AI_VOLUME_LAST_ISSUE.HasValue)
                    qtyAiLastIssue = AI_VOLUME_LAST_ISSUE.Value;
                double qtyLastIssue = QTY_LAST_ISSUE;
                if (qtyLastIssue > 0.0)
                    return System.Math.Round(qtyAiLastIssue / qtyLastIssue, 2);
                return 0.0;
            }
        }

        [NotMapped]
        public double ReinfIncidence
        {
            get
            {
                double reinf = 0.0;
                if (QTY_REINF != null && QTY_REINF.HasValue)
                    reinf = QTY_REINF.Value;
                double qtyLastIssue = QTY_LAST_ISSUE;
                if (qtyLastIssue > 0.0)
                    return reinf / qtyLastIssue;
                return 0.0;
            }
        }

        [NotMapped]
        public double KNextCe
        {
            get
            {
                double qtyCe = 0.0;
                if (QTY_NEXT_CE != null && QTY_NEXT_CE.HasValue)
                    qtyCe = QTY_NEXT_CE.Value;
                double qtyIssue = 0.0;
                if (QTY_LAST_ISSUE > 0.0)
                    qtyIssue = QTY_LAST_ISSUE;
                if (qtyIssue > 0.0)
                    return qtyCe / qtyIssue;
                return 0.0;
            }
        }

        [NotMapped]
        public double GetQTYNextCERounded
        {
            get
            {
                if (QTY_NEXT_CE != null && QTY_NEXT_CE.HasValue)
                    return Math.Round(QTY_NEXT_CE.Value, 2);
                return 0.00;
            }
        }

        [NotMapped]
        public double GetKNextCERounded
        {
            get
            {
                return Math.Round(KNextCe, 2);
            }
        }

        [NotMapped]
        public string GetEngStatusOld
        {
            get
            {
                if (QTY_IFC != null && QTY_IFC.HasValue && QTY_IFC.Value > 0.0)
                    return "IFC";
                if (QTY_IFR != null && QTY_IFR.HasValue && QTY_IFR.Value > 0.0)
                    return "IFR";
                return "-";
            }
        }

        [Column("USERID")]
        [Display(Name = "USERID")]
        public int? UserID { get; set; }

        public USERS USERS { get; set; }

        [Column("CREATIONDATE")]
        [Display(Name = "CreationDate")]
        public DateTime? CreationDate { get; set; }

        [Column("LASTMODIFIED")]
        [Display(Name = "LastModified")]
        public DateTime? LastModified { get; set; }


        [NotMapped]
        public string DateLastModify
        {
            get
            {
                if (LastModified != null && LastModified.HasValue)
                    return LastModified.Value.ToString("yyyy/MM/dd");
                return string.Empty;
            }
        }

        [NotMapped]
        public string LastModifyUser
        {
            get
            {
                return USERS != null ? USERS.IdentityUserName : string.Empty;
            }
        }

        public MAIN_ITEM_QUANTITY()
        {
            this.QTY_BUDGET = 0.0;
            this.QTY_WR = 0.0;
            this.QTY_IFR = 0.0;
            this.QTY_IFC = 0.0;
            this.QTY_ACC = 0.0;
            this.QTY_NEXT_CE = 0.0;
            this.MANUAL_QTY_HOLD = 0.0;
            this.QTY_REINF = 0.0;
            this.CONNECTION_INDICENCE = 0.0;
            this.AI_VOLUME_LAST_ISSUE = 0.0;
        }

    }
}
