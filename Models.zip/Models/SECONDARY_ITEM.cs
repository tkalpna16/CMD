﻿using CivilMasterData.Models.BIM360.Formulas;
using CivilMasterData.Models.PriceList;
using CivilMasterData.Models.PriceList.Base;
using org.mariuszgromada.math.mxparser;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class SECONDARY_ITEM
    {
        [Key]
        [Column("Sec_Item_Id")]
        [Display(Name = "Sec_Item_Id")]
        public int Sec_Item_Id { get; set; }

        [Column("MainItemId")]
        [Display(Name = "MainItemId")]
        public int? MainItemId { get; set; }

        public MAINITEMS MainItem { get; set; }

        [Column("Item Tag")]
        [Display(Name = "Item Tag")]
        public string ItemTag { get; set; }

        [Column("TagTypeId")]
        [Display(Name = "TagTypeId")]
        public int TagTypeId { get; set; }

        [Column("LV01_Object Code")]
        [Display(Name = "LV01_Object Code")]
        public string LV01_Object_Code { get; set; }

        [Column("LV01_Sequence Number")]
        [Display(Name = "LV01_Sequence Number")]
        public string LV01_Sequence_Number { get; set; }

        [Column("LV01_Material Work Group")]
        [Display(Name = "LV01_Material Work Group")]
        public string LV01_Material_Work_Group { get; set; }

        [Column("Object Code Description")]
        [Display(Name = "Object Code Description")]
        public string Object_Code_Description { get; set; }

        [Column("LV02_Object Code")]
        [Display(Name = "LV02_Object Code")]
        public string LV02_Object_Code { get; set; }

        [Column("LV02_Sequence Number")]
        [Display(Name = "LV02_Sequence Number")]
        public string LV02_Sequence_Number { get; set; }

        [Column("LV02_Material Work Group")]
        [Display(Name = "LV02_Material Work Group")]
        public string LV02_Material_Work_Group { get; set; }



        public bool IsInPBS(PBS pbs, List<MAINITEMS> mainItems)
        {
            if (pbs == null || mainItems == null)
                return false;
            MAINITEMS mAINITEM = null;
            foreach(MAINITEMS m in mainItems)
                if (m.MainItemTag.ToUpper() == this.MainItem.MainItemTag.ToUpper())
                {
                    mAINITEM = m;
                    break;
                }
            if (mAINITEM == null)
                return false;
            return mAINITEM.PBSID == pbs.PBSID;
        }

        public ExcelResultValue GetExcelResultValue(PRICEFAMILIESVALUES pRICEFAMILIESVALUES, 
            List<PRICECONDITIONS> conditions,
            SECONDARY_ITEM_QUANTITY qUANTITY,
            PRICECODEDEFINITIONS pRICECODEDEFINITIONS,
            PRICECODES priceCodes)
        {
            ExcelResultValue resultValue = null;
            if (qUANTITY == null || pRICECODEDEFINITIONS == null)
                return null;
            if (!qUANTITY.FamilyName.ToUpper().Contains(pRICEFAMILIESVALUES.FamilyName.ToUpper()))
                return null;

            // Add Contition Evalution
            List<Condition> conditionList = new List<Condition>();
            if (conditions != null)
            {
                foreach (PRICECONDITIONS condition in conditions)
                {
                    if (condition.PRICECODE.PriceCodeDefinitionID == pRICECODEDEFINITIONS.PriceCodeDefinitionID)
                    {
                        Condition currentCondition = condition.GetCondition();
                        if (currentCondition != null)
                            conditionList.Add(currentCondition);
                    }
                }
            }
            if (conditionList.Count > 0)
            {
                // Evalutate if pass condition
                bool passed = true;
                List<Tuple<bool, BooleanType>> results = new List<Tuple<bool, BooleanType>>();
                foreach(Condition condition in conditionList)
                {
                    if (condition is EmptyCondition)
                        continue;

                    // Get the value of the parameter
                    object paramValue = GetParameterValue(qUANTITY, condition.Parameter);
                    if (paramValue != null)
                        passed = condition.Passed(paramValue);
                    else
                        passed = false;
                    results.Add(new Tuple<bool, BooleanType>(passed, condition.BooleanType));
                }
                if (results.Count == 0)
                    passed = true;
                else if (results.Count == 1)
                    passed = results[0].Item1;
                else
                {
                    bool currentPassed = true;
                    for (int i = 1; i < results.Count; i++)
                    {
                        bool value1 = results[i - 1].Item1;
                        bool value2 = results[i].Item1;
                        BooleanType booleanType = results[i - 1].Item2;
                        switch (booleanType)
                        {
                            case BooleanType.AND:
                                currentPassed = value1 && value2;
                                break;
                            case BooleanType.OR:
                                currentPassed = value1 || value2;
                                break;
                        }
                        passed &= currentPassed;
                    }
                }
                if (!passed)
                    return null;
            }

            // Evaluate quantity
            resultValue = new ExcelResultValue();
            resultValue.ItemCode = this.ItemTag;
            object parvalue = GetParameterValue(qUANTITY, pRICEFAMILIESVALUES.LengthValue);
            if (parvalue != null && parvalue is double)
                resultValue.Length = (double)parvalue;
            parvalue = GetParameterValue(qUANTITY, pRICEFAMILIESVALUES.WidthValue);
            if (parvalue != null && parvalue is double)
                resultValue.Width = (double)parvalue;
            parvalue = GetParameterValue(qUANTITY, pRICEFAMILIESVALUES.HeightValue);
            if (parvalue != null && parvalue is double)
                resultValue.Height = (double)parvalue;
            parvalue = GetParameterValue(qUANTITY, pRICEFAMILIESVALUES.AreaValue);
            if (parvalue != null && parvalue is double)
                resultValue.Area = (double)parvalue;
            parvalue = GetParameterValue(qUANTITY, pRICEFAMILIESVALUES.WeightValue);
            if (parvalue != null && parvalue is double)
                resultValue.Weight = (double)parvalue;
            resultValue.Unit = pRICEFAMILIESVALUES.Unit;
            resultValue.PriceCode = priceCodes.Code;
            resultValue.PriceDescription = priceCodes.PriceDescription;
            resultValue.PriceGroupCode = pRICECODEDEFINITIONS.GroupCode;
            resultValue.PriceGroupDescription = pRICECODEDEFINITIONS.PriceGroupDescription;
            double value = EvaluateQty(pRICEFAMILIESVALUES.GetFamilyFormula(), qUANTITY);
            resultValue.Quantities = value;

            if (value == 0.0)
                return null;

            return resultValue;
        }
        private double EvaluateQty(FamilyFormula familyFormula, SECONDARY_ITEM_QUANTITY qUANTITY)
        {
            double qty = 0.0;

            string formula = familyFormula.Formula.Replace(" ", "");
            List<Argument> arguments = new List<Argument>();
            Argument argument = null;

            foreach (var prop in qUANTITY.GetType().GetProperties())
            {
                object obj = prop.GetValue(qUANTITY, null);
                if (obj is double || obj is int)
                {
                    string value = prop.Name + " = " + prop.GetValue(qUANTITY, null).ToString();
                    argument = new Argument(value);
                    if (argument != null && formula.Contains(prop.Name))
                        arguments.Add(argument);
                }
            }
            Expression e = new Expression(familyFormula.Formula, arguments.ToArray());
            qty = e.calculate();
            if (double.IsNaN(qty))
                qty = 0.0;
            return qty;
        }

        private object GetParameterValue(SECONDARY_ITEM_QUANTITY qUANTITY, string paramterName)
        {
            if (string.IsNullOrEmpty(paramterName))
                return null;
            foreach (var prop in qUANTITY.GetType().GetProperties())
            {
                if (prop.Name == paramterName)
                {
                    object obj = prop.GetValue(qUANTITY, null);
                    return obj;
                }
            }
            return null;
        }
    }
}
