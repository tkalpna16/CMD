﻿using CivilMasterData.Models.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class ViewManager
    {
        public PROJECTS Project { get; set; }

        public List<ITEMS> ITEMS { get; set; }

        public List<SECONDARYITEMS> SECONDARYITEMS { get; set; }

        public List<HOLDLISTS> HOLDLISTS { get; set; }

        public List<PROJECTPLANNINGS> PROJECTPLANNINGS { get; set; }

        public List<MAINITEMS> MAINITEMS { get; set; }

        public List<STEELVENDORITEMLISTS> STEELVENDORITEMLISTS { get; set; }

        public List<TagTypeResult> TagTypeResult { get; set; }

        public int TotalItems
        {
            get
            {
                if (TagTypeResult == null)
                    return 0;
                return TagTypeResult.Sum(t => t.Items);
            }
        }

        public int ConcreteModels { get; set; }
        public int SteelModels { get; set; }
        public int UndergroundModels { get; set; }
        public int PavingModels { get; set; }
        public int TotalModels
        {
            get
            {
                return ConcreteModels + SteelModels + UndergroundModels + PavingModels;
            }
        }
    }
}
