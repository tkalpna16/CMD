﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Views
{
    public class OVERALLS
    {
        public ITEMS ITEMS { get; set; }
        public HOLDLISTS HOLDLISTS { get; set; }
        public PROJECTPLANNINGS PROJECTPLANNINGS { get; set; }
    }
}
