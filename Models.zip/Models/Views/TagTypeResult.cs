﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Views
{
    public class TagTypeResult
    {
        public string Description { get; set; }
        public double QtyCE { get; set; }
        public string Unit { get; set; }
        public int Items { get; set; }
    }
}
