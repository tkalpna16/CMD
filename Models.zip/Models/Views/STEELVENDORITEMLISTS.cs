﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models.Views
{
    public class STEELVENDORITEMLISTS
    {
        [Key]
        [Column("MainItemID")]
        [Display(Name = "MainItemID")]
        public int? MainItemID { get; set; }

        [Column("Project")]
        [Display(Name = "Project")]
        public string Project { get; set; }

        [Column("ItemTag")]
        [Display(Name = "ItemTag")]
        public string ItemTag { get; set; }

        [Column("Lot")]
        [Display(Name = "Lot")]
        public string Lot { get; set; }

        [Column("Vendor")]
        [Display(Name = "Vendor")]
        public string Vendor { get; set; }

        [Column("MR")]
        [Display(Name = "MR")]
        public string MR { get; set; }

        [Column("PO")]
        [Display(Name = "PO")]
        public string PO { get; set; }
    }
}
