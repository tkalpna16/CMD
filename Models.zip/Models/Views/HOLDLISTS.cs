﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class HOLDLISTS
    {
        [Key]
        [Column("ItemId")]
        [Display(Name = "ItemId")]
        public int ItemId { get; set; }

        [Column("Project")]
        [Display(Name = "Project")]
        public string Project { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("Area")]
        [Display(Name = "Area")]
        public string Area { get; set; }

        [Column("WP")]
        [Display(Name = "WP")]
        public string WP { get; set; }

        [Column("TagMet")]
        [Display(Name = "TagMet")]
        public string TagMet { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("TagClient")]
        [Display(Name = "TagClient")]
        public string TagClient { get; set; }

        [Column("TagDescription")]
        [Display(Name = "TagDescription")]
        public string TagDescription { get; set; }

        [Column("QTY_HOLD")]
        [Display(Name = "QTY_HOLD")]
        public double? QTY_HOLD { get; set; }

        [Column("HOLD_TYPE")]
        [Display(Name = "HOLD_TYPE")]
        public string HOLD_TYPE { get; set; }

        [Column("HOLD_DEP")]
        [Display(Name = "HOLD_DEP")]
        public string HOLD_DEP { get; set; }

        [Column("HOLD_STATUS")]
        [Display(Name = "HOLD_STATUS")]
        public string HOLD_STATUS { get; set; }

        [Column("FORE_DATE_INPUT")]
        [Display(Name = "FORE_DATE_INPUT")]
        public DateTime? FORE_DATE_INPUT { get; set; }

        [Column("FORE_DATE_INTERNAL")]
        [Display(Name = "FORE_DATE_INTERNAL")]
        public DateTime? FORE_DATE_INTERNAL { get; set; }

        [Column("ACTUAL_DATE_INTERNAL")]
        [Display(Name = "ACTUAL_DATE_INTERNAL")]
        public DateTime? ACTUAL_DATE_INTERNAL { get; set; }
    }
}
