﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class PROJECTPLANNINGS
    {
        [Key]
        [Column("ItemId")]
        [Display(Name = "ItemId")]
        public int ItemId { get; set; }

        [Column("Project")]
        [Display(Name = "Project")]
        public string Project { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("Area")]
        [Display(Name = "Area")]
        public string Area { get; set; }

        [Column("WP")]
        [Display(Name = "WP")]
        public string WP { get; set; }

        [Column("TagMet")]
        [Display(Name = "TagMet")]
        public string TagMet { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("TagClient")]
        [Display(Name = "TagClient")]
        public string TagClient { get; set; }

        [Column("TagDescription")]
        [Display(Name = "TagDescription")]
        public string TagDescription { get; set; }

        [Column("DATE_BASE_IFR_LEV3")]
        [Display(Name = "DATE_BASE_IFR_LEV3")]
        public DateTime? DATE_BASE_IFR_LEV3 { get; set; }

        [Column("DATE_BASE_IFR_ENG")]
        [Display(Name = "DATE_BASE_IFR_ENG")]
        public DateTime? DATE_BASE_IFR_ENG { get; set; }

        [Column("DATE_FORE_IFR")]
        [Display(Name = "DATE_FORE_IFR")]
        public DateTime? DATE_FORE_IFR { get; set; }

        [Column("DATE_ACT_IFR")]
        [Display(Name = "DATE_ACT_IFR")]
        public DateTime? DATE_ACT_IFR { get; set; }

        [Column("DATE_BASE_IFC_LEV3")]
        [Display(Name = "DATE_BASE_IFC_LEV3")]
        public DateTime? DATE_BASE_IFC_LEV3 { get; set; }

        [Column("DATE_BASE_IFC_ENG")]
        [Display(Name = "DATE_BASE_IFC_ENG")]
        public DateTime? DATE_BASE_IFC_ENG { get; set; }

        [Column("DATE_FORE_IFC")]
        [Display(Name = "DATE_FORE_IFC")]
        public DateTime? DATE_FORE_IFC { get; set; }

        [Column("DATE_ACT_IFC")]
        [Display(Name = "DATE_ACT_IFC")]
        public DateTime? DATE_ACT_IFC { get; set; }
    }
}
