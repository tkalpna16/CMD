﻿using CivilMasterData.Models.Costants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class ITEMS
    {
        [Key]
        [Column("MainItemID")]
        [Display(Name = "MainItemID")]
        public int? MainItemID { get; set; }

        [Column("Project")]
        [Display(Name = "Project")]
        public string Project { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("Area")]
        [Display(Name = "Area")]
        public string Area { get; set; }

        [Column("WP")]
        [Display(Name = "WP")]
        public string WP { get; set; }

        [Column("TagMet")]
        [Display(Name = "TagMet")]
        public string TagMet { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("TagClient")]
        [Display(Name = "TagClient")]
        public string TagClient { get; set; }

        [Column("TagDescription")]
        [Display(Name = "TagDescription")]
        public string TagDescription { get; set; }

        [Column("DrawNo")]
        [Display(Name = "DrawNo")]
        public string DrawNo { get; set; }

        [Column("ElDrawNo")]
        [Display(Name = "ElDrawNo")]
        public string ElDrawNo { get; set; }

        [Column("QTYCE")]
        [Display(Name = "QTYCE")]
        public double? QTYCE { get; set; }

        [Column("OptRatio")]
        [Display(Name = "OptRatio")]
        public double? OptRatio { get; set; }

        [NotMapped]
        public List<MTOREVS> MAIN_ITEM_QTY_REV { get; set; }
        [NotMapped]
        public MAIN_ITEM_QUANTITY MAIN_ITEM_QTY { get; set; }

        private double? CalculateQty(int engStatusIndex)
        {
            MTOREVS lastBudget = null;
            if (MAIN_ITEM_QTY_REV != null)
            {
                foreach (MTOREVS rev in MAIN_ITEM_QTY_REV)
                {
                    if (rev.STATUSID == engStatusIndex)
                    {
                        if (lastBudget == null)
                            lastBudget = rev;
                        else
                        {
                            if (lastBudget.REVID.Value < rev.REVID.Value)
                                lastBudget = rev;
                        }
                    }
                }
            }
            if (lastBudget == null)
                return null;
            else
            {
                if (lastBudget.QTY != null && lastBudget.QTY.HasValue)
                    lastBudget.QTY = System.Math.Round(lastBudget.QTY.Value, 2);
                return lastBudget.QTY;
            }
        }

        [NotMapped]
        public double? CalculateQtyBudget
        {
            get
            {
                double qtyBudget = 0.0;
                if (MAIN_ITEM_QTY != null && MAIN_ITEM_QTY.QTY_BUDGET != null && MAIN_ITEM_QTY.QTY_BUDGET.HasValue)
                    qtyBudget = MAIN_ITEM_QTY.QTY_BUDGET.Value;
                return qtyBudget;
            }
        }

        [NotMapped]
        public double? CalculateQtyIFB
        {
            get
            {
                return CalculateQty(EngStatusCostants.IFB_ID);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFR
        {
            get
            {
                return CalculateQty(EngStatusCostants.IFR_ID);
            }
        }

        [NotMapped]
        public double? CalculateQtyIFC
        {
            get
            {
                return CalculateQty(EngStatusCostants.IFC_ID);
            }
        }
    }
}
