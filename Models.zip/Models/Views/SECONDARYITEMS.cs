﻿using CivilMasterData.Models.Costants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CivilMasterData.Models
{
    public class SECONDARYITEMS
    {
        [Key]
        [Column("ItemID")]
        [Display(Name = "ItemID")]
        public int? ItemID { get; set; }

        [Column("ItemTag")]
        [Display(Name = "ItemTag")]
        public string ItemTag { get; set; }

        [Column("Project")]
        [Display(Name = "Project")]
        public string Project { get; set; }

        [Column("Unit")]
        [Display(Name = "Unit")]
        public string Unit { get; set; }

        [Column("Area")]
        [Display(Name = "Area")]
        public string Area { get; set; }

        [Column("WP")]
        [Display(Name = "WP")]
        public string WP { get; set; }

        [Column("TagMet")]
        [Display(Name = "TagMet")]
        public string TagMet { get; set; }

        [Column("TagType")]
        [Display(Name = "TagType")]
        public string TagType { get; set; }

        [Column("TagClient")]
        [Display(Name = "TagClient")]
        public string TagClient { get; set; }

        [Column("TagDescription")]
        [Display(Name = "TagDescription")]
        public string TagDescription { get; set; }

        [Column("DrawNo")]
        [Display(Name = "DrawNo")]
        public string DrawNo { get; set; }

        [Column("ElDrawNo")]
        [Display(Name = "ElDrawNo")]
        public string ElDrawNo { get; set; }

        [Column("QTYCE")]
        [Display(Name = "QTYCE")]
        public double? QTYCE { get; set; }

        [Column("OptRatio")]
        [Display(Name = "OptRatio")]
        public double? OptRatio { get; set; }

        [Column("Status")]
        [Display(Name = "Status")]
        public string Status { get; set; }
    }
}
