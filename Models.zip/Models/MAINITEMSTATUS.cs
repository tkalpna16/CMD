﻿using CivilMasterData.Models.Users;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class MAINITEMSTATUS
    {
        [Key]
        [Column("StatusID")]
        [Display(Name = "StatusID")]
        public int StatusID { get; set; }

        [Column("Description")]
        [Display(Name = "Description")]
        public string Description { get; set; }
    }
}
