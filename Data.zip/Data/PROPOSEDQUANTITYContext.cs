﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PROPOSEDQUANTITYContext : DbContext
    {
        public PROPOSEDQUANTITYContext(DbContextOptions<PROPOSEDQUANTITYContext> options) : base(options)
        {
        }

        public DbSet<PROPOSEDQUANTITY> PROPOSEDQUANTITY { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
    }
}
