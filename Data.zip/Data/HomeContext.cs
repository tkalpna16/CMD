﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Data
{
    public class HomeContext : DbContext
    {
        public HomeContext(DbContextOptions<HomeContext> options) : base(options)
        {
        }

        public DbSet<USERS> USERS { get; set; }

        public DbSet<ACTIVEUSERS> ACTIVEUSERS { get; set; }
    }
}
