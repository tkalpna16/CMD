﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PROJECTSETTINGSContext : DbContext
    {
        public PROJECTSETTINGSContext (DbContextOptions<PROJECTSETTINGSContext> options)
            : base(options)
        {
        }

        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }

        public DbSet<PROJECTS> PROJECTS { get; set; }

        public DbSet<USERS> USERS { get; set; }
    }
}
