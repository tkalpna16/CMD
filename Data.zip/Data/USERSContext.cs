﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace CivilMasterData.Models
{
    public class USERSContext : DbContext
    {
        public USERSContext(DbContextOptions<USERSContext> options) : base(options)
        {
        }

        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }

        public static List<string> AvailableRoles
        {
            get { return Roles.AvailableRoles(); }
        }
    }
}
