﻿using CivilMasterData.Models.PriceList;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PriceEvaluatorContext : DbContext
    {
        public PriceEvaluatorContext(DbContextOptions<PriceEvaluatorContext> options) : base(options)
        {
        }

        public DbSet<BOOLEANOPERATORS> BOOLEANOPERATORS { get; set; }
        public DbSet<COMPARISONTYPES> COMPARISONTYPES { get; set; }
        public DbSet<PRICECONDITIONTYPES> PRICECONDITIONTYPES { get; set; }
        public DbSet<PRICECONDITIONS> PRICECONDITIONS { get; set; }
        public DbSet<PRICECODES> PRICECODES { get; set; }
        public DbSet<PRICECODEDEFINITIONS> PRICECODEDEFINITIONS { get; set; }
        public DbSet<PRICEFAMILIESVALUES> PRICEFAMILIESVALUES { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<SECONDARY_ITEM> SECONDARY_ITEM { get; set; }
        public DbSet<SECONDARY_ITEM_QUANTITY> SECONDARY_ITEM_QUANTITY { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public int ProjectID { get; set; }
    }
}
