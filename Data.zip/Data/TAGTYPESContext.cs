﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class TAGTYPESContext : DbContext
    {
        public TAGTYPESContext(DbContextOptions<TAGTYPESContext> options)
            : base(options)
        {
        }

        public DbSet<CivilMasterData.Models.TAGTYPES> TAGTYPES { get; set; }
    }
}
