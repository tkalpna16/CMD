﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class VENDORDATAREGISTERContext : DbContext
    {
        public VENDORDATAREGISTERContext(DbContextOptions<VENDORDATAREGISTERContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }

        public DbSet<VENDORS> VENDORS { get; set; }
        public DbSet<MATERIALREQUESTS> MATERIALREQUESTS { get; set; }
        public DbSet<PURCHASEORDERS> PURCHASEORDERS { get; set; }
    }
}
