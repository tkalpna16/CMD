﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
namespace CivilMasterData.Models
{
    public class MAINITEMPLANNINGDATESContext : DbContext
    {
        public MAINITEMPLANNINGDATESContext(DbContextOptions<MAINITEMPLANNINGDATESContext> options) : base(options)
        {
        }

        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
    }
}
