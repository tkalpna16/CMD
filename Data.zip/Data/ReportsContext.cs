﻿using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Data
{
    public class ReportsContext : DbContext
    {
        public ReportsContext(DbContextOptions<ReportsContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public DbSet<PLANNINGS> PLANNINGS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<MTOREVS> MTOREVS { get; set; }
        public DbSet<WORKINGPACKAGES> WORKINGPACKAGES { get; set; }
        
        //Added new line to enable eng status in Report Context class, on 19092022 by shweta dalvi
        public DbSet<ENGINEERING_STATUS> ENGINEERING_STATUS { get; set; }


    }
}
