﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class COMMODITYCODESContext : DbContext
    {
        public COMMODITYCODESContext(DbContextOptions<COMMODITYCODESContext> options) : base(options)
        {
        }

        public DbSet<COMMODITYCODES> COMMODITYCODES { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
    }
}
