﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace CivilMasterData.Models
{
    public class DETAILERDRContext : DbContext
    {
        public DETAILERDRContext(DbContextOptions<DETAILERDRContext> options) : base(options)
        {
        }
        
        public DbSet<DETAILER> DETAILER { get; set; }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }

        //public DbSet<USERS> USERS { get; set; }
        //public DbSet<NATIONS> NATIONS { get; set; }
    }
}
