﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class ENGINEERING_STATUSContext : DbContext
    {
        public ENGINEERING_STATUSContext(DbContextOptions<ENGINEERING_STATUSContext> options)
            : base(options)
        {
        }

        public DbSet<CivilMasterData.Models.ENGINEERING_STATUS> ENGINEERING_STATUS { get; set; }
    }
}
