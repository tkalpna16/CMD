﻿using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class STEELPLANNINGSContext : DbContext
    {
        public STEELPLANNINGSContext(DbContextOptions<STEELPLANNINGSContext> options) : base(options)
        {
        }

        public DbSet<STEELPLANNINGS> STEELPLANNINGS { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
    }
}
