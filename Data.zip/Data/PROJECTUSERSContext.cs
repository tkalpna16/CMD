﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PROJECTUSERSContext : DbContext
    {
        public PROJECTUSERSContext(DbContextOptions<PROJECTUSERSContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
    }
}
