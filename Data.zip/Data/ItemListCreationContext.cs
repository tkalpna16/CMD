﻿using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
namespace CivilMasterData.Models
{
    public class ItemListCreationContext : DbContext
    {
        public ItemListCreationContext(DbContextOptions<ItemListCreationContext> options) : base(options)
        {
        }

        public DbSet<MATERIALWORKGROUPS> MATERIALWORKGROUPS { get; set; }
        public DbSet<OBJECTCODES> OBJECTCODES { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<IMPORTANCESTATUS> IMPORTANCESTATUS { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<PLANNINGS> PLANNINGS { get; set; }
        public DbSet<STEELPLANNINGS> STEELPLANNINGS { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<MAINITEMPARAMETERS> MAINITEMPARAMETERS { get; set; }
        public DbSet<MAINITEMPARAMETERVALUES> MAINITEMPARAMETERVALUES { get; set; }
        public DbSet<STEEL_QUANTITIES> STEEL_QUANTITIES { get; set; }
        public DbSet<STEEL_ESTIMATED_QUANTITIES> STEEL_ESTIMATED_QUANTITIES { get; set; }
        public DbSet<HOLDS> HOLDS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
        public DbSet<COMMODITYCODES> COMMODITYCODES { get; set; }
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<PURCHASEORDERS> PURCHASEORDERS { get; set; }
        public DbSet<MATERIALREQUESTS> MATERIALREQUESTS { get; set; }
        public DbSet<WORKINGPACKAGES> WORKINGPACKAGES { get; set; }
        public DbSet<VENDORS> VENDORS { get; set; }
        public DbSet<MTOREVS> MTOREVS { get; set; }

        public DbSet<QUANTITY_CE_REVISION> QUANTITY_CE_REVISION { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY_CE> MAIN_ITEM_QUANTITY_CE { get; set; }

        // Drawing Settings
        public DbSet<MAINITEMDRAWINGS> MAINITEMDRAWINGS { get; set; }
        public DbSet<PBSDRAWINGS> PBSDRAWINGS { get; set; }

        public DbSet<DRAWINGS> DRAWINGS { get; set; }

        public DbSet<BIM360ITEMSTATUS> BIM360ITEMSTATUS { get; set; }

        public DbSet<ITEMSLISTCHECKS> ITEMSLISTCHECKS { get; set; }

        public DbSet<DELETEDITEMSLISTCHECKS> DELETEDITEMSLISTCHECKS { get; set; }
    }
}
