﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class VENDORSContext : DbContext
    {
        public VENDORSContext(DbContextOptions<VENDORSContext> options) : base(options)
        {
        }

        public DbSet<VENDORS> VENDORS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<NATIONS> NATIONS { get; set; }
    }

   
}
