﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class WORKINGPACKAGESContext : DbContext
    {
        public WORKINGPACKAGESContext(DbContextOptions<WORKINGPACKAGESContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<WORKINGPACKAGES> WORKINGPACKAGES { get; set; }
        public DbSet<USERS> USERS { get; set; }
    }
}
