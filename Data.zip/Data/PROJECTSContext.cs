﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.PriceList;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PROJECTSContext : DbContext
    {
        public PROJECTSContext (DbContextOptions<PROJECTSContext> options)
            : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int? SelectedProjectId { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
        public DbSet<DOCUMENTTYPES> DOCUMENTTYPES { get; set; }
        public DbSet<DOCUMENTSETTINGS> DOCUMENTSETTINGS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
        public DbSet<OBJECTCODES> OBJECTCODES { get; set; }
        public DbSet<COMMODITYCODES> COMMODITYCODES { get; set; }
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<MATERIALREQUESTS> MATERIALREQUESTS { get; set; }
        public DbSet<PURCHASEORDERS> PURCHASEORDERS { get; set; }
        public DbSet<VENDORS> VENDORS { get; set; }

        // PLANNING
        public DbSet<DELIVERYTIMES> DELIVERYTIMES { get; set; }

        // DRAWING SETTINGS
        public DbSet<AACSSETTINGS> AACSSETTINGS { get; set; }
        public DbSet<AADASETTINGS> AADASETTINGS { get; set; }
        public DbSet<AADCSETTINGS> AADCSETTINGS { get; set; }
        public DbSet<AICSSETTINGS> AICSSETTINGS { get; set; }
        public DbSet<AIDASETTINGS> AIDASETTINGS { get; set; }
        public DbSet<AIDUSETTINGS> AIDUSETTINGS { get; set; }
        public DbSet<APDASETTINGS> APDASETTINGS { get; set; }
        public DbSet<AQDASETTINGS> AQDASETTINGS { get; set; }
        public DbSet<ARDASETTINGS> ARDASETTINGS { get; set; }

        // Price Code Settings
        public DbSet<PRICECODEDEFINITIONS> PRICECODEDEFINITIONS { get; set; }
        public DbSet<PRICECODES> PRICECODES { get; set; }
        public DbSet<PRICECONDITIONS> PRICECONDITIONS { get; set; }
        public DbSet<PRICEFAMILIESVALUES> PRICEFAMILIESVALUES { get; set; }
    }
}
