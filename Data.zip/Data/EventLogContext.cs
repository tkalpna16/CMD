﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class EventLogContext : DbContext
    {
        public EventLogContext(DbContextOptions<EventLogContext> options) : base(options)
        {
        }

        public DbSet<ACTIVEUSERS> ACTIVEUSERS { get; set; }
    }
}
