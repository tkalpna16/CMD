﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PLANNINGSContext : DbContext
    {
        public PLANNINGSContext(DbContextOptions<PLANNINGSContext> options) : base(options)
        {
        }

        public DbSet<PLANNINGS> PLANNINGS { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }

        public DbSet<MAINITEMPARAMETERS> MAINITEMPARAMETERS { get; set; }
        public DbSet<MAINITEMPARAMETERVALUES> MAINITEMPARAMETERVALUES { get; set; }

        public DbSet<DELIVERYTIMES> DELIVERYTIMES { get; set; }

        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
        public DbSet<HOLDS> HOLDS { get; set; }

        public DbSet<WORKINGPACKAGES> WORKINGPACKAGES { get; set; }
    }
}
