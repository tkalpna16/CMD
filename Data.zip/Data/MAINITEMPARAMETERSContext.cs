﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
namespace CivilMasterData.Models
{
    public class MAINITEMPARAMETERSContext : DbContext
    {
        public MAINITEMPARAMETERSContext(DbContextOptions<MAINITEMPARAMETERSContext> options) : base(options)
        {
        }

        public DbSet<MAINITEMPARAMETERS> MAINITEMPARAMETERS { get; set; }
        public DbSet<MAINITEMPARAMETERCATEGORIES> MAINITEMPARAMETERCATEGORIES { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<MAINITEMPARAMETERVALUES> MAINITEMPARAMETERVALUES { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<SECONDARY_ITEM> SECONDARY_ITEM { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
    }
}
