﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class OBJECTCODESContext : DbContext
    {
        public OBJECTCODESContext(DbContextOptions<OBJECTCODESContext> options) : base(options)
        {
        }
        
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<OBJECTCODES> OBJECTCODES { get; set; }
        public DbSet<USERS> USERS { get; set; }

        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }

        public DbSet<MAINITEMS> MAINITEMS { get; set; }
    }
}
