﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class ADMINContext : DbContext
    {
        public ADMINContext(DbContextOptions<ADMINContext> options) : base(options)
        {
        }

        public DbSet<USERS> USERS { get; set; }
    }
}
