﻿using CivilMasterData.Models;
using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Data
{
    public class HoldManagerContext : DbContext
    {
        public HoldManagerContext(DbContextOptions<HoldManagerContext> options) : base(options)
        {
        }

        public DbSet<PBS> PBS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public int ProjectID { get; set; }
        public DbSet<HOLDTYPES> HOLDTYPES { get; set; }
        public DbSet<HOLDDEPTS> HOLDDEPTS { get; set; }
        public DbSet<HOLDS> HOLDS { get; set; }
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }

        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
        public DbSet<BIM360ITEMSTATUS> BIM360ITEMSTATUS { get; set; }
    }
}
