﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class MATERIALWORKGROUPSContext : DbContext
    {
        public MATERIALWORKGROUPSContext(DbContextOptions<MATERIALWORKGROUPSContext> options) : base(options)
        {
        }

        public DbSet<MATERIALWORKGROUPS> MATERIALWORKGROUPS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
    }
}
