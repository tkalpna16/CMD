﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PURCHASEORDERSContext : DbContext
    {
        public PURCHASEORDERSContext(DbContextOptions<PURCHASEORDERSContext> options) : base(options)
        {
        }

        public DbSet<PURCHASEORDERS> PURCHASEORDERS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<HOLDS> HOLDS { get; set; }
    }
}
