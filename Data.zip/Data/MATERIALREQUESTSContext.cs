﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class MATERIALREQUESTSContext : DbContext
    {
        public MATERIALREQUESTSContext(DbContextOptions<MATERIALREQUESTSContext> options) : base(options)
        {
        }

        public DbSet<MATERIALREQUESTS> MATERIALREQUESTS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
    }
}
