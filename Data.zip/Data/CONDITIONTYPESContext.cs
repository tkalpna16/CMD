﻿using CivilMasterData.Models.PriceList;
using Microsoft.EntityFrameworkCore;
namespace CivilMasterData.Models
{
    public class PRICECONDITIONTYPESContext : DbContext
    {
        public PRICECONDITIONTYPESContext(DbContextOptions<PRICECONDITIONTYPESContext> options) : base(options)
        {
        }

        public DbSet<PRICECONDITIONTYPES> PRICECONDITIONTYPES { get; set; }
    }
}
