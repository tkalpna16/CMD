﻿using CivilMasterData.Models.Steel;
using Microsoft.EntityFrameworkCore;
namespace CivilMasterData.Models
{
    public class SteelItemListCreationContext : DbContext
    {
        public SteelItemListCreationContext(DbContextOptions<SteelItemListCreationContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<PURCHASEORDERS> PURCHASEORDERS { get; set; }
        public DbSet<MATERIALREQUESTS> MATERIALREQUESTS { get; set; }
        public DbSet<VENDORS> VENDORS { get; set; }
    }
}
