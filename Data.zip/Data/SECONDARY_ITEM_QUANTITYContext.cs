﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class SECONDARY_ITEM_QUANTITYContext : DbContext
    {
        public SECONDARY_ITEM_QUANTITYContext(DbContextOptions<SECONDARY_ITEM_QUANTITYContext> options) : base(options)
        {
        }

        public DbSet<PBS> PBS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<SECONDARY_ITEM_QUANTITY> SECONDARY_ITEM_QUANTITY { get; set; }
    }
}
