﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class SECONDARY_ITEMContext : DbContext
    {
        public SECONDARY_ITEMContext(DbContextOptions<SECONDARY_ITEMContext> options) : base(options)
        {
        }

        public DbSet<PBS> PBS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<SECONDARY_ITEM> SECONDARY_ITEM { get; set; }
    }
}
