﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class DLGENERATORContext : DbContext
    {
        public DLGENERATORContext(DbContextOptions<DLGENERATORContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<REVISIONS> REVISIONS { get; set; }
        public DbSet<DRAWINGS> DRAWINGS { get; set; }
        public DbSet<DOCUMENTTYPES> DOCUMENTTYPES { get; set; }
        public DbSet<DRAWINGSCALES> DRAWINGSCALES { get; set; }
        public DbSet<DRAWINGSIZES> DRAWINGSIZES { get; set; }
        public DbSet<DOCUMENTSETTINGS> DOCUMENTSETTINGS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<IMPORTANCESTATUS> IMPORTANCESTATUS { get; set; }
        public DbSet<MAINITEMDRAWINGS> MAINITEMDRAWINGS { get; set; }
        public DbSet<PBSDRAWINGS> PBSDRAWINGS { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<OBJECTCODES> OBJECTCODES { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }

        public DbSet<AACSSETTINGS> AACSSETTINGS { get; set; }
        public DbSet<AADASETTINGS> AADASETTINGS { get; set; }
        public DbSet<AADCSETTINGS> AADCSETTINGS { get; set; }
        public DbSet<AICSSETTINGS> AICSSETTINGS { get; set; }
        public DbSet<AIDASETTINGS> AIDASETTINGS { get; set; }
        public DbSet<AIDUSETTINGS> AIDUSETTINGS { get; set; }
        public DbSet<AQDASETTINGS> AQDASETTINGS { get; set; }
        public DbSet<APDASETTINGS> APDASETTINGS { get; set; }
        public DbSet<ARDASETTINGS> ARDASETTINGS { get; set; }

        public DbSet<AADCFACTORS> AADCFACTORS { get; set; }
        public DbSet<AIDUFACTORS> AIDUFACTORS { get; set; }

        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }

    }
}
