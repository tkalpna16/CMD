﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models.PriceList
{
    public class PRICECONDITIONSContext : DbContext
    {
        public PRICECONDITIONSContext(DbContextOptions<PRICECONDITIONSContext> options) : base(options)
        {
        }

        public DbSet<PRICECONDITIONS> PRICECONDITIONS { get; set; }
        public DbSet<PRICECODES> PRICECODES { get; set; }
        public DbSet<PRICECODEDEFINITIONS> PRICECODEDEFINITIONS { get; set; }
        public DbSet<PRICECONDITIONTYPES> PRICECONDITIONTYPES { get; set; }
        public DbSet<COMPARISONTYPES> COMPARISONTYPES { get; set; }
        public DbSet<BOOLEANOPERATORS> BOOLEANOPERATORS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
    }
}
