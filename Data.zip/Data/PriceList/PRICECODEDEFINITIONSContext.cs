﻿using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models.PriceList
{
    public class PRICECODEDEFINITIONSContext : DbContext
    {
        public PRICECODEDEFINITIONSContext(DbContextOptions<PRICECODEDEFINITIONSContext> options) : base(options)
        {
        }

        public DbSet<PRICECODEDEFINITIONS> PRICECODEDEFINITIONS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
    }
}
