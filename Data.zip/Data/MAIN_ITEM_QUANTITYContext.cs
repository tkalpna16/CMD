﻿using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class MAIN_ITEM_QUANTITYContext : DbContext
    {
        public MAIN_ITEM_QUANTITYContext(DbContextOptions<MAIN_ITEM_QUANTITYContext> options) : base(options)
        {
        }

        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<PBS> PBS { get; set; }
    }
}
