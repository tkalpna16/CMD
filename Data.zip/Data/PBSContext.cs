﻿using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class PBSContext : DbContext
    {
        public PBSContext(DbContextOptions<PBSContext> options) : base(options)
        {
        }

        public DbSet<PBS> PBS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<MAINITEMPARAMETERS> MAINITEMPARAMETERS { get; set; }
        public DbSet<MAINITEMPARAMETERVALUES> MAINITEMPARAMETERVALUES { get; set; }
        public DbSet<PLANNINGS> PLANNINGS { get; set; }
        public DbSet<STEELPLANNINGS> STEELPLANNINGS { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<STEEL_QUANTITIES> STEEL_QUANTITIES { get; set; }
        public DbSet<STEEL_ESTIMATED_QUANTITIES> STEEL_ESTIMATED_QUANTITIES { get; set; }
        public DbSet<PBSDRAWINGS> PBSDRAWINGS { get; set; }
        public DbSet<MAINITEMDRAWINGS> MAINITEMDRAWINGS { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<HOLDS> HOLDS { get; set; }

        public DbSet<COMMODITYCODES> COMMODITYCODES { get; set; }
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<PURCHASEORDERS> PURCHASEORDERS { get; set; }
        public DbSet<MATERIALREQUESTS> MATERIALREQUESTS { get; set; }
        public DbSet<VENDORS> VENDORS { get; set; }

        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }
    }
}
