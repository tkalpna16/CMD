﻿using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Views;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Models
{
    public class ViewManagerContext : DbContext
    {
        public ViewManagerContext(DbContextOptions<ViewManagerContext> options) : base(options)
        {
        }

        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }

        public DbSet<TAGTYPES> TAGTYPES { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }
        public DbSet<ITEMS> ITEMS { get; set; }
        public DbSet<STEELVENDORITEMLISTS> STEELVENDORITEMLISTS { get; set; }
        public DbSet<SECONDARYITEMS> SECONDARYITEMS { get; set; }
        public DbSet<HOLDTYPES> HOLDTYPES { get; set; }
        public DbSet<HOLDDEPTS> HOLDDEPTS { get; set; }
        public DbSet<HOLDLISTS> HOLDLISTS { get; set; }
        public DbSet<PROJECTPLANNINGS> PROJECTPLANNINGS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<MTOREVS> MTOREVS { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<MAIN_ITEM_QUANTITY_CE> MAIN_ITEM_QUANTITY_CE { get; set; }
        public DbSet<BIM360ITEMSTATUS> BIM360ITEMSTATUS { get; set; }
        public DbSet<USERS> USERS { get; set; }
    }
}
