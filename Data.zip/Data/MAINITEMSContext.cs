﻿using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
namespace CivilMasterData.Models
{
    public class MAINITEMSContext : DbContext
    {
        public MAINITEMSContext(DbContextOptions<MAINITEMSContext> options) : base(options)
        {
        }

        public DbSet<MAINITEMS> MAINITEMS { get; set; }

        public DbSet<MAIN_ITEM_QUANTITY> MAIN_ITEM_QUANTITY { get; set; }
        public DbSet<USERS> USERS { get; set; }
        public DbSet<SECONDARY_ITEM> SECONDARY_ITEM { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public DbSet<PROJECTSETTINGS> PROJECTSETTINGS { get; set; }

        public DbSet<PROJECTUSERS> PROJECTUSERS { get; set; }

        public DbSet<HOLDS> HOLDS { get; set; }

        public DbSet<DRAWINGS> DRAWINGS { get; set; }

        public DbSet<DELETEDITEMSLISTCHECKS> DELETEDITEMSLISTCHECKS { get; set; }

        public DbSet<ITEMSLISTCHECKS> ITEMSLISTCHECKS { get; set; }
    }
}
