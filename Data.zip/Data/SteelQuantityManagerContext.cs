﻿using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Data
{
    public class SteelQuantityManagerContext : DbContext
    {
        public SteelQuantityManagerContext(DbContextOptions<SteelQuantityManagerContext> options) : base(options)
        {
        }

        public DbSet<STEEL_QUANTITIES> STEEL_QUANTITIES { get; set; }
        public DbSet<STEEL_ESTIMATED_QUANTITIES> STEEL_ESTIMATED_QUANTITIES { get; set; }
        public DbSet<COMMODITYCODES> COMMODITYCODES { get; set; }
        public DbSet<PBS> PBS { get; set; }
        public DbSet<LOTS> LOTS { get; set; }
        public DbSet<MAINITEMS> MAINITEMS { get; set; }
        public DbSet<PROJECTS> PROJECTS { get; set; }
        public int ProjectID { get; set; }
        public DbSet<USERS> USERS { get; set; }
    }
}
