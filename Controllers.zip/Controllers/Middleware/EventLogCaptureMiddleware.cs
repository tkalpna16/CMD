﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

using CivilMasterData.Models;
using CivilMasterData.Models.Users;

namespace CivilMasterData.Controllers.Middleware
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class EventLogCaptureMiddleware
    {
        private readonly RequestDelegate _next;

        public EventLogCaptureMiddleware(RequestDelegate next)
        {
            _next = next;
        }


        public Task Invoke(HttpContext httpContext, EventLogContext context)
        {
            string name = httpContext.User.Identity.Name;
            if (string.IsNullOrEmpty(name))
                return _next(httpContext);

            var activeUser = context.ACTIVEUSERS.Where(u => u.Username == name).FirstOrDefault();
            if (activeUser != null)
                activeUser.LoginDate = DateTime.UtcNow;
            else
            {
                activeUser = new ACTIVEUSERS
                {
                    LoginDate = DateTime.UtcNow,
                    Username = name
                };
                context.Add(activeUser);
            }
            var tasks = new Task[] { context.SaveChangesAsync() };

            Task.WaitAll(tasks);

            return _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class EventLogCaptureMiddlewareExtensions
    {
        public static IApplicationBuilder UseEventLogCaptureMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<EventLogCaptureMiddleware>();
        }
    }
}
