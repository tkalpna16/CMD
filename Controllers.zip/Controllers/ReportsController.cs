﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Data;
using CivilMasterData.Models;
using CivilMasterData.Models.Charts;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace CivilMasterData.Controllers
{
    [UnAuthorized]
    public class ReportsController : Controller
    {
        private readonly ReportsContext _context;
        protected readonly ISharedResource _sharedResource;
        private IWebHostEnvironment _env;
        private IConfiguration _configuration;

        public ReportsController(ReportsContext context, IWebHostEnvironment env, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            _env = env;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var pROJECTS = await _context.PROJECTS.FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
            if (pROJECTS == null)
                return NotFound();

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.WORKINGPACKAGES).Where(m => m.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            List<string> wp = new List<string>();
            string wpEmpty = _configuration.GetValue<string>("Items:WPNotDefined");

            if (mainItems != null)
                foreach (MAINITEMS m in mainItems)
                {
                    if (m.WORKINGPACKAGES != null)
                    {
                        if (!wp.Contains(m.WORKINGPACKAGES.NAME))
                            wp.Add(m.WORKINGPACKAGES.NAME);
                    }
                    else
                    {
                        if (!wp.Contains(wpEmpty))
                            wp.Add(wpEmpty);
                    }
                }

            Reports reports = new Reports();
            reports.PBS = pbs;
            reports.TAGTYPES = tagTypes;
            reports.WPLIST = wp;

            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;            
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            DataTable dtCurve = new DataTable();            
            reports.curveData = dtCurve;

            return View(reports);
        }
        
        [HttpGet]
        public async Task<ActionResult> CreateExcelFeasibilityCurve(string code, string tagTypeStr, string wpStr)
        {
            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:FeasibilityCurveTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot,tempFolder, excelTemplate);

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            if (string.IsNullOrEmpty(tagTypeStr))
                return NotFound();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var tagType = tagTypes.Where(t => t.Description == tagTypeStr).FirstOrDefault();
            var wpList = Utils.SplitText(wpStr);

            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(x => x.WORKINGPACKAGES).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            // Filter main items
            List<MAINITEMS> filteredList = new List<MAINITEMS>();
            string wpEmpty = _configuration.GetValue<string>("Items:WPNotDefined");
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.WORKINGPACKAGES == null)
                    {
                        if (wpList.Contains(wpEmpty))
                            filteredList.Add(item);
                    }
                    else
                    {
                        if (wpList.Contains(item.WORKINGPACKAGES.NAME))
                            filteredList.Add(item);
                    }
                }
            }
            mainItems = filteredList;
            List<int> itemsId = mainItems.Select(m => m.MainItemID).ToList();
            if (itemsId == null)
                itemsId = new List<int>();

            var plannings = await _context.PLANNINGS.Where(x => itemsId.Contains(x.MainItemId.Value)).ToListAsync();
            var mainItemQty = await _context.MAIN_ITEM_QUANTITY.Where(x => itemsId.Contains(x.MainItemId)).ToListAsync();
            var mtoRevs = await _context.MTOREVS.Where(x => itemsId.Contains(x.MAINITEMID.Value)).ToListAsync();

            string excelSheet = _configuration.GetValue<string>("Excel:FeasibilityCurveSheetName");
            int startColumn = _configuration.GetValue<int>("Excel:FeasibilityCurveStartColumn");
            int startRow = _configuration.GetValue<int>("Excel:FeasibilityCurveStartRow");
            int statusIfrId = _configuration.GetValue<int>("Items:StatusIFR");
            int statusIfcId = _configuration.GetValue<int>("Items:StatusIFC");
            FeasibilityCurve feasibility = new FeasibilityCurve(project, plannings, mainItems, mainItemQty, mtoRevs);
            feasibility.CreateExcelFile(baseReportFile, fileToSave, excelSheet, startColumn, startRow, statusIfrId, statusIfcId, tagType);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        public async Task<IActionResult> FeasibilityCurve(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var pROJECTS = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
                return NotFound();

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.ToListAsync();
            var status = await _context.ENGINEERING_STATUS.ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.WORKINGPACKAGES).Where(m => m.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            List<string> wp = new List<string>();
            string wpEmpty = _configuration.GetValue<string>("Items:WPNotDefined");

            
            if (mainItems != null)
                foreach (MAINITEMS m in mainItems)
                {
                    if (m.WORKINGPACKAGES != null)
                    {
                        if (!wp.Contains(m.WORKINGPACKAGES.NAME))
                            wp.Add(m.WORKINGPACKAGES.NAME);
                    }
                    else
                    {
                        if (!wp.Contains(wpEmpty))
                            wp.Add(wpEmpty);
                    }
                }

            List<string> ReportType = new List<string>();
            ReportType.Add("MONTHLY"); ReportType.Add("WEEKLY");

            List<string> projecttimeframe = new List<string>();
            projecttimeframe.Add("Project LifeTime");
            projecttimeframe.Add("Selected Period");

            List<string> subcont = new List<string>();
            subcont = _context.MAINITEMS.Include(m => m.SubContractor).Where(m => m.SubContractor != "" && m.PBS.ProjectID == pROJECTS.ProjectID).Select(m => m.SubContractor).Distinct().ToList();
            Reports reports = new Reports();
            reports.PBS = pbs;
            reports.TAGTYPES = tagTypes;
            reports.WPLIST = wp;
            reports.ENG_STATUS = status;
            reports.ReportType = ReportType;
            reports.ProjectTimeframe = projecttimeframe;
            reports.SubContractors = subcont;

            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            return View(reports);
        }

        //http://localhost:3000/Reports/PopulateFeasibilityCurve?code=P4325&ReportType=MONTHLY&ProjectTimeframe=Project%20LifeTime&startDt=null&endDt=null
        //async Task<ActionResult> PopulateFeasibilityCurve

        //[HttpPost]
        //Desc: To generate table and graph on selected Filters.
        public JsonResult PopulateFeasibilityCurve
            (string code,
            //string engstatus,
            string tagTypeStr,
            string wpStr,
            string ReportType, 
            string ProjectTimeframe, 
            string start_Dt, string end_Dt, string subcont)
        {
            Reports reports = new Reports();

            string[] wpList = Utils.SplitText(wpStr);
            string[] tagType = Utils.SplitText(tagTypeStr);
            string[] subconList = Utils.SplitText(subcont);
            for (int i = 0; i < subconList.Length; i++)
            {
                if (subconList[i].Trim() == "")
                {
                    subconList[i] = null;
                }
            }

            //  string[] statusList = Utils.SplitText(engstatus);
            DateTime startDt = Convert.ToDateTime(start_Dt);
            DateTime endDt = Convert.ToDateTime(end_Dt);

            var errorMessage = "";
            DataTable dtCurve = new DataTable();            
            string strSD = "", strED = "";
            try
            {
                if (string.IsNullOrEmpty(code))
                    return null;

                var pROJECTS = _context.PROJECTS.FirstOrDefault(m => m.Code == code);
                if (pROJECTS == null)
                    return null;

                //If Report type is Month 
                var monthlist = new List<string>();
                if (ProjectTimeframe == "Project LifeTime")
                {
                    startDt = pROJECTS.StartDate.Value;
                    endDt = pROJECTS.EndDate.Value;
                    strSD = pROJECTS.StartDate.Value.ToString("MMM-yy").ToUpper();
                    strED = pROJECTS.EndDate.Value.ToString("MMM-yy").ToUpper();
                }
                else
                {
                    strSD = startDt.ToString("MMM-yy").ToUpper();
                    strED = endDt.ToString("MMM-yy").ToUpper();
                }
                // Add months as per selection in monthlist
                while (strSD.ToUpper() != strED.ToUpper())
                {
                    monthlist.Add(startDt.ToString("MMM-yy").ToUpper());
                    startDt = startDt.AddMonths(1);
                    strSD = startDt.ToString("MMM-yy").ToUpper();
                }
                monthlist.Add(startDt.ToString("MMM-yy").ToUpper());

                //if Report type is Weeks then ask how to design months.

                //Formulating Curve data
                string connectionString = _configuration.GetValue<string>("Oracle:ConnectionString:DefaultConnection");
                string procedureName = _configuration.GetValue<string>("Oracle:ProcedureFeasibilityCurveQuery");
                string procedurePara1 = _configuration.GetValue<string>("Oracle:ProcedureFeasCurvePara1");
                string procedurePara2 = _configuration.GetValue<string>("Oracle:ProcedureFeasCurvePara2");

                //Get curve legends parameters
                string procedureCurLeg = _configuration.GetValue<string>("Oracle:ProcedureCurveLegends");
                string procedureCurLegPara1 = _configuration.GetValue<string>("Oracle:ProcedureCurvePara1");

                DataTable dt = ReportUtils.GetFeasibilityQueryData(code, AESService.Decrypt(connectionString), procedureName, procedurePara1, procedurePara2);
                DataTable dtLegends = ReportUtils.GetCurveLegends(AESService.Decrypt(connectionString), procedureCurLeg, procedureCurLegPara1);

                dtCurve = ReportUtils.GetCurveDataTable(dt, dtLegends, monthlist, tagType, wpList, subconList);

                reports.curveData = dtCurve;
                errorMessage = "success";
              
            }
            catch (System.Exception ex)
            {
                errorMessage = ex.Message;
                //return Json(new { errorMessage });
            }

            //var jsonresult = this.Json(new { data = dtCurve }, errorMessage);
            //return jsonresult;

            var JSONString = string.Empty;            
            JSONString = JsonConvert.SerializeObject(dtCurve);
            return Json(JSONString);
        }

        //Desc: To generate excel file with table and graph
        [HttpGet]
        public ActionResult GenerateFeasibilityCurve(string code,
              string engstatus,
              string tagTypeStr,
              string wpStr,
              string ReportType,
              string ProjectTimeframe,
              string start_Dt, string end_Dt, string subcont)
        {
            string[] wpList = Utils.SplitText(wpStr);
            string[] tagType = Utils.SplitText(tagTypeStr);
            string[] subconList = Utils.SplitText(subcont);
            for (int i = 0; i < subconList.Length; i++)
            {
                if (subconList[i].Trim() == "")
                {
                    subconList[i] = null;
                }
            }
            string[] statusList = Utils.SplitText(engstatus);
            string _ProjectDetal = "";
            DateTime startDt = Convert.ToDateTime(start_Dt);
            DateTime endDt = Convert.ToDateTime(end_Dt);

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:FeasibilityCurveTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, excelTemplate);

            var errorMessage = "";
            DataTable dtCurve = new DataTable();
            string strSD = "", strED = "";
            if (string.IsNullOrEmpty(code))
                return null;

            var project = _context.PROJECTS.FirstOrDefault(m => m.Code == code);
            if (project == null)
                return null;

            try
            {
                _ProjectDetal = project.GetCompleteDescription;
                //If Report type is Month 
                var monthlist = new List<string>();
                if (ProjectTimeframe == "Project LifeTime")
                {
                    startDt = project.StartDate.Value;
                    endDt = project.EndDate.Value;
                    strSD = project.StartDate.Value.ToString("MMM-yy").ToUpper();
                    strED = project.EndDate.Value.ToString("MMM-yy").ToUpper();
                }
                else
                {
                    strSD = startDt.ToString("MMM-yy").ToUpper();
                    strED = endDt.ToString("MMM-yy").ToUpper();
                }
                // Add months as per selection in monthlist
                while (strSD.ToUpper() != strED.ToUpper())
                {
                    monthlist.Add(startDt.ToString("MMM-yy").ToUpper());
                    startDt = startDt.AddMonths(1);
                    strSD = startDt.ToString("MMM-yy").ToUpper();
                }
                monthlist.Add(startDt.ToString("MMM-yy").ToUpper());

                // if Report type is Weeks then ask how to design months.

                //Formulating Curve data
                string connectionString = _configuration.GetValue<string>("Oracle:ConnectionString:DefaultConnection");
                string procedureName = _configuration.GetValue<string>("Oracle:ProcedureFeasibilityCurveQuery");
                string procedurePara1 = _configuration.GetValue<string>("Oracle:ProcedureFeasCurvePara1");
                string procedurePara2 = _configuration.GetValue<string>("Oracle:ProcedureFeasCurvePara2");

                //Get curve legends parameters
                string procedureCurLeg = _configuration.GetValue<string>("Oracle:ProcedureCurveLegends");
                string procedureCurLegPara1 = _configuration.GetValue<string>("Oracle:ProcedureCurvePara1");

                DataTable dt = ReportUtils.GetFeasibilityQueryData(code, AESService.Decrypt(connectionString), procedureName, procedurePara1, procedurePara2);
                DataTable dtLegends = ReportUtils.GetCurveLegends(AESService.Decrypt(connectionString), procedureCurLeg, procedureCurLegPara1);

                dtCurve = ReportUtils.GetCurveDataTable(dt, dtLegends, monthlist, tagType, wpList, subconList);

                //Get Excel Attributes
                string excelSheet = _configuration.GetValue<string>("Excel:FeasibilityCurveSheetName");
                int startColumn = _configuration.GetValue<int>("Excel:FeasibilityCurveStartColumn");
                int startRow = _configuration.GetValue<int>("Excel:FeasibilityCurveStartRow");
                int legendCol = _configuration.GetValue<int>("Excel:FeasibilityCurveLegendColumn");
                int legendRow = _configuration.GetValue<int>("Excel:FeasibilityCurveLegendRow");

                //int statusIfrId = _configuration.GetValue<int>("Items:StatusIFR");
                //int statusIfcId = _configuration.GetValue<int>("Items:StatusIFC");
                //FeasibilityCurve feasibility = new FeasibilityCurve(project, plannings, mainItems, mainItemQty, mtoRevs);
                //feasibility.CreateExcelFile(baseReportFile, fileToSave, excelSheet, startColumn, startRow, statusIfrId, statusIfcId, tagType);

                 ReportUtils.GenerateFeasibilityReport(dtCurve, _ProjectDetal, wpStr, baseReportFile, fileToSave, excelSheet, startColumn, startRow, legendRow, legendCol,subcont,tagTypeStr);

                errorMessage = "success";

            }
            catch (System.Exception ex)
            {
                errorMessage = ex.Message;
                //return Json(new { errorMessage });
            }


            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

    }
}

