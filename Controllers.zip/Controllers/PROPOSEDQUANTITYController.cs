﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;

namespace CivilMasterData.Controllers
{
    public class PROPOSEDQUANTITYController : Controller
    {
        private readonly PROPOSEDQUANTITYContext _context;

        public PROPOSEDQUANTITYController(PROPOSEDQUANTITYContext context)
        {
            _context = context;
        }

        // GET: PROPOSEDQUANTITY
        public async Task<IActionResult> Index(int? projectId)
        {
            if (projectId == null)
                return NotFound();
            _context.ProjectID = projectId.Value;

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.ProjectID == projectId.Value);
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            
            return View(await _context.PROPOSEDQUANTITY.Where(x => x.ProjectID == projectId.Value).ToListAsync());
        }

        // GET: PROPOSEDQUANTITY/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pROPOSEDQUANTITY = await _context.PROPOSEDQUANTITY
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.PROPQTYID == id);
            if (pROPOSEDQUANTITY == null)
            {
                return NotFound();
            }

            return View(pROPOSEDQUANTITY);
        }

        // GET: PROPOSEDQUANTITY/Create
        public IActionResult Create()
        {
            ViewData["ProjectID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID");
            return View();
        }

        // POST: PROPOSEDQUANTITY/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PROPQTYID,ProjectID,Unit,Area,Qty")] PROPOSEDQUANTITY pROPOSEDQUANTITY)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pROPOSEDQUANTITY);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProjectID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", pROPOSEDQUANTITY.ProjectID);
            return View(pROPOSEDQUANTITY);
        }

        // GET: PROPOSEDQUANTITY/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pROPOSEDQUANTITY = await _context.PROPOSEDQUANTITY.FindAsync(id);
            if (pROPOSEDQUANTITY == null)
            {
                return NotFound();
            }
            ViewData["ProjectID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", pROPOSEDQUANTITY.ProjectID);
            return View(pROPOSEDQUANTITY);
        }

        // POST: PROPOSEDQUANTITY/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PROPQTYID,ProjectID,Unit,Area,Qty")] PROPOSEDQUANTITY pROPOSEDQUANTITY)
        {
            if (id != pROPOSEDQUANTITY.PROPQTYID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pROPOSEDQUANTITY);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PROPOSEDQUANTITYExists(pROPOSEDQUANTITY.PROPQTYID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProjectID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", pROPOSEDQUANTITY.ProjectID);
            return View(pROPOSEDQUANTITY);
        }

        // GET: PROPOSEDQUANTITY/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pROPOSEDQUANTITY = await _context.PROPOSEDQUANTITY
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.PROPQTYID == id);
            if (pROPOSEDQUANTITY == null)
            {
                return NotFound();
            }

            return View(pROPOSEDQUANTITY);
        }

        // POST: PROPOSEDQUANTITY/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pROPOSEDQUANTITY = await _context.PROPOSEDQUANTITY.FindAsync(id);
            _context.PROPOSEDQUANTITY.Remove(pROPOSEDQUANTITY);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PROPOSEDQUANTITYExists(int id)
        {
            return _context.PROPOSEDQUANTITY.Any(e => e.PROPQTYID == id);
        }
    }
}
