﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Data;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Quantities;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;

namespace CivilMasterData.Controllers
{
    public class QuantityManagerController : Controller
    {
        private readonly QuantityManagerContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public QuantityManagerController(QuantityManagerContext context, ISharedResource sharedResource,
             IConfiguration configuration, IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            this._configuration = configuration;
            this._env = env;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.QUANTITY_SPECIALIST))
                return Redirect("~/Home/NoPermission");

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            QuantityManager itemListCreation = new QuantityManager();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var pbs = await _context.PBS.Where(m => m.ProjectID == project.ProjectID).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID &&
                x.TagTypeID != tagTypeSteel).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            // Update Main Items
            double totalQtyHold = 0.0;
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    totalQtyHold = 0.0;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                            }
                        }
                    }
                    item.TotalQtyHold = totalQtyHold;
                }
            }

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            itemListCreation.MainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.MAIN_ITEM_QUANTITY = mainItemsQty;
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        public async Task<IActionResult> Manager(string code, int showBalance)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();

            DatabaseCostants.InitValues(_configuration);

            QuantityManager itemListCreation = new QuantityManager();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            int projectId = project.ProjectID;

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }
            ViewBag.Role = user.ACCESS_LEVEL;

            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            if (mainItems != null && showBalance <= 0)
                mainItems = mainItems.Where(m => !m.IsBalance).ToList();
            mainItems = MAINITEMS.ReorderMainItems(mainItems);
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == projectId).ToListAsync();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var proposals = await _context.PROPOSEDQUANTITY.Where(x => x.ProjectID == projectId).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }


            double totalQtyHold = 0.0;

            // Update Main Items
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();

                    var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                    item.PLANNINGS = planning;

                    totalQtyHold = 0.0;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                            }
                        }
                        item.HOLDS = currentHolds;
                    }
                    item.TotalQtyHold = totalQtyHold;
                }
            }

            int quantityType = _configuration.GetValue<int>("Items:ParameterQuantityID");
            var quantityParameters = await _context.MAINITEMPARAMETERS.Where(d => d.PROJECTID == project.ProjectID && d.MAINITEMPARAMETERCATEGORIESID == quantityType).OrderBy(d => d.ParameterID).ToListAsync();
            int totalParameters = quantityParameters != null ? quantityParameters.Count : 0;
            if (totalParameters > 0 && mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    bool update = false;
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID &&
                        m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == quantityType).ToListAsync();
                    foreach (MAINITEMPARAMETERS currentParameter in quantityParameters)
                    {
                        MAINITEMPARAMETERVALUES currentValue = null;
                        if (values != null)
                            currentValue = values.Where(d => d.MainItemParametersID == currentParameter.ParameterID).FirstOrDefault();
                        if (currentValue == null) // Add date
                        {
                            MAINITEMPARAMETERVALUES newVal = new MAINITEMPARAMETERVALUES();
                            newVal.MainItemParametersID = currentParameter.ParameterID;
                            newVal.MainItemsID = item.MainItemID;
                            newVal.UserID = user.USERID;
                            newVal.CreationDate = DateTime.UtcNow;
                            newVal.LastModified = DateTime.UtcNow;
                            _context.MAINITEMPARAMETERVALUES.Add(newVal);
                            update = true;
                        }
                    }
                    // Search invalid dates
                    List<int> valueIds = quantityParameters.Select(v => v.ParameterID).ToList();
                    foreach (var val in values)
                        if (!valueIds.Contains(val.MainItemParametersID))
                        {
                            _context.Remove(val);
                            update = true;
                        }

                    if (update)
                    {
                        await _context.SaveChangesAsync();
                    }
                }
            }

            // Assign the qty to every planning
            if (mainItems != null && totalParameters > 0)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID && m.MainItemParametersID == quantityType).ToListAsync();
                    item.ParameterValues = values;
                }
            }

            SetViewBagParameters(quantityParameters);


            itemListCreation.MainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.MAIN_ITEM_QUANTITY = mainItemsQty;
            itemListCreation.PROPOSEDQUANTITIES = proposals;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.BalanceTitle = showBalance > 0 ? "HIDE BALANCE" : "SHOW BALANCE";

            return View(itemListCreation);
        }


        public async Task<IActionResult> QuantityView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();

            DatabaseCostants.InitValues(_configuration);

            QuantityManager itemListCreation = new QuantityManager();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            int projectId = project.ProjectID;

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }
            ViewBag.Role = user.ACCESS_LEVEL;

            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            mainItems = MAINITEMS.ReorderMainItems(mainItems);
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == projectId).ToListAsync();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var proposals = await _context.PROPOSEDQUANTITY.Where(x => x.ProjectID == projectId).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }


            double totalQtyHold = 0.0;

            // Update Main Items
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();

                    var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                    item.PLANNINGS = planning;

                    totalQtyHold = 0.0;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                            }
                        }
                        item.HOLDS = currentHolds;
                    }
                    item.TotalQtyHold = totalQtyHold;
                }
            }

            int quantityType = _configuration.GetValue<int>("Items:ParameterQuantityID");
            var quantityParameters = await _context.MAINITEMPARAMETERS.Where(d => d.PROJECTID == project.ProjectID && d.MAINITEMPARAMETERCATEGORIESID == quantityType).OrderBy(d => d.ParameterID).ToListAsync();
            int totalParameters = quantityParameters != null ? quantityParameters.Count : 0;
            if (totalParameters > 0 && mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    bool update = false;
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID &&
                        m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == quantityType).ToListAsync();
                    foreach (MAINITEMPARAMETERS currentParameter in quantityParameters)
                    {
                        MAINITEMPARAMETERVALUES currentValue = null;
                        if (values != null)
                            currentValue = values.Where(d => d.MainItemParametersID == currentParameter.ParameterID).FirstOrDefault();
                        if (currentValue == null) // Add date
                        {
                            MAINITEMPARAMETERVALUES newVal = new MAINITEMPARAMETERVALUES();
                            newVal.MainItemParametersID = currentParameter.ParameterID;
                            newVal.MainItemsID = item.MainItemID;
                            newVal.UserID = user.USERID;
                            newVal.CreationDate = DateTime.UtcNow;
                            newVal.LastModified = DateTime.UtcNow;
                            _context.MAINITEMPARAMETERVALUES.Add(newVal);
                            update = true;
                        }
                    }
                    // Search invalid dates
                    List<int> valueIds = quantityParameters.Select(v => v.ParameterID).ToList();
                    foreach (var val in values)
                        if (!valueIds.Contains(val.MainItemParametersID))
                        {
                            _context.Remove(val);
                            update = true;
                        }

                    if (update)
                    {
                        await _context.SaveChangesAsync();
                    }
                }
            }

            // Assign the qty to every planning
            if (mainItems != null && totalParameters > 0)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID && m.MainItemParametersID == quantityType).ToListAsync();
                    item.ParameterValues = values;
                }
            }

            SetViewBagParameters(quantityParameters);


            itemListCreation.MainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.MAIN_ITEM_QUANTITY = mainItemsQty;
            itemListCreation.PROPOSEDQUANTITIES = proposals;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        private void SetViewBagParameters(List<MAINITEMPARAMETERS> parameters)
        {
            if (parameters == null)
                return;
            int index = 0;
            ViewBag.TotalParameters = parameters != null ? parameters.Count : 0;

            ViewBag.ParameterName1 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName2 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName3 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName4 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName5 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName6 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName7 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName8 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName9 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName10 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
        }

        public async Task<IActionResult> CESubmission(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER))
                return Redirect("~/Home/NoPermission");

            QuantityManager itemListCreation = new QuantityManager();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            int projectId = project.ProjectID;


            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN && user.ACCESS_LEVEL != Roles.QUANTITY_SPECIALIST)
            {
                return Redirect("~/Home/NoPermission");
            }

            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID &&
                x.TagTypeID != tagTypeSteel).ToListAsync();
            mainItems = MAINITEMS.ReorderMainItems(mainItems);




            var revisions = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID).OrderByDescending(r => r.REVISIONSNUMBER).ToListAsync();
            List<string> revisionNames = null;
            if (revisions != null)
            {
                revisionNames = revisions.Select(r => r.GetDescription).ToList();
            }
            else
                revisionNames = new List<string>();

            revisionNames.Add(AppCostants.CE_ACTUAL_REVISION_NAME);

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            itemListCreation.MainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);
            itemListCreation.Project = project;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.Revisions = revisionNames;

            return View(itemListCreation);
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelCERev(string code, string revision1str, string revision2str)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:CETemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, excelTemplate);
            string excelSheet = _configuration.GetValue<string>("Excel:CESheetName");
            int startRow = _configuration.GetValue<int>("Excel:CESheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:CESheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:CEProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:CEProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;

            var tagtypesdb = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            bool firstActual = revision1str == AppCostants.CE_ACTUAL_REVISION_NAME;
            bool secondActual = revision2str == AppCostants.CE_ACTUAL_REVISION_NAME;
            var revision1 = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID &&
                    r.GetDescription == revision1str).FirstOrDefaultAsync();
            var revision2 = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID &&
                    r.GetDescription == revision2str).FirstOrDefaultAsync();


            var mainitems = await _context.MAINITEMS.Include(m => m.LOTS).
                Include(m => m.PBS)
                .Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            List<QuantityCEData> quantities = new List<QuantityCEData>();

            if (revision1 != null)
                Sheet.Cells[6, 5].Value = "Qty CE1 [" + revision1.CreationDate.Value.ToString("MM.dd.yyyy") + "]";
            else if (revision1str == "Actual")
                Sheet.Cells[6, 5].Value = "Qty CE1 [Actual]";
            else
                Sheet.Cells[6, 5].Value = "Qty CE1 [Undefined]";
            if (revision2 != null)
                Sheet.Cells[6, 6].Value = "Qty CE2 [" + revision2.CreationDate.Value.ToString("MM.dd.yyyy") + "]";
            else if (revision2str == "Actual")
                Sheet.Cells[6, 6].Value = "Qty CE2 [Actual]";
            else
                Sheet.Cells[6, 6].Value = "Qty CE2 [Undefined]";


            foreach (MAINITEMS mainitem in mainitems)
            {
                mainitem.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == mainitem.MainItemID).FirstOrDefault();
                var quantitiesCE = await _context.MAIN_ITEM_QUANTITY_CE.Where(m => m.MainItemId == mainitem.MainItemID).ToListAsync();
                if (quantitiesCE != null)
                {
                    QuantityCEData quantityCEData = new QuantityCEData();
                    quantityCEData.MainItemTag = mainitem.MainItemTag;
                    quantityCEData.TagTypeDescription = mainitem.TAGTYPES.Description;
                    quantityCEData.Lot = mainitem.LOTS.NAME;
                    if (revision1 != null)
                    {
                        var qty = quantitiesCE.Where(r => r.RevId == revision1.ID).FirstOrDefault();
                        if (qty != null && qty.QTY_CE != null && qty.QTY_CE.HasValue)
                            quantityCEData.QtyCE1 = qty.QTY_CE.Value;
                    }
                    else if (firstActual)
                    {
                        if (mainitem.ITEM_QUANTITY.QTY_NEXT_CE != null && mainitem.ITEM_QUANTITY.QTY_NEXT_CE.HasValue)
                            quantityCEData.QtyCE1 = mainitem.ITEM_QUANTITY.QTY_NEXT_CE.Value;
                    }
                    if (revision2 != null)
                    {
                        var qty = quantitiesCE.Where(r => r.RevId == revision2.ID).FirstOrDefault();
                        if (qty != null && qty.QTY_CE != null && qty.QTY_CE.HasValue)
                            quantityCEData.QtyCE2 = qty.QTY_CE.Value;
                    }
                    else if (secondActual)
                    {
                        if (mainitem.ITEM_QUANTITY.QTY_NEXT_CE != null && mainitem.ITEM_QUANTITY.QTY_NEXT_CE.HasValue)
                            quantityCEData.QtyCE2 = mainitem.ITEM_QUANTITY.QTY_NEXT_CE.Value;
                    }
                    quantityCEData.DeltaCE = quantityCEData.QtyCE2 - quantityCEData.QtyCE1;
                    quantities.Add(quantityCEData);
                }
            }

            if (quantities != null)
            {
                int currentRow = startRow;
                quantities = quantities.OrderBy(p => p.MainItemTag).ToList();

                foreach (QuantityCEData item in quantities)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.TagTypeDescription;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.Lot;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.QtyCE1;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.QtyCE2;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.DeltaCE;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        public async Task<string> DeleteCERevision(string code, string revisionstr)
        {
            if (string.IsNullOrEmpty(code))
                return "Project not found";

            QuantityManager itemListCreation = new QuantityManager();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            int projectId = project.ProjectID;
            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID &&
                x.TagTypeID != tagTypeSteel).ToListAsync();
            mainItems = MAINITEMS.ReorderMainItems(mainItems);

            bool deleted = false;
            var revisions = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID).ToListAsync();
            if (revisions != null)
            {
                var revision = revisions.Where(r => r.GetDescription == revisionstr).FirstOrDefault();
                if (revision != null)
                {
                    _context.QUANTITY_CE_REVISION.Remove(revision);
                    await _context.SaveChangesAsync();
                    deleted = true;
                }
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            if (deleted)
                return "Deleted";
            else
                return "Not valid";
        }

        private async Task<MAINITEMS> GetMAINITEMSByDescription(string mainitemdescription)
        {
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            TAGTYPES tagType = null;
            foreach (TAGTYPES t in tagTypes)
                if (mainitemdescription.Contains(t.Description))
                    tagType = t;
            string maintag = mainitemdescription.Replace("-" + tagType.Description, "");
            var mainItems = await _context.MAINITEMS.Where(x => x.TagTypeID == tagType.TagTypeID && x.MainItemTag == maintag).FirstOrDefaultAsync();
            return mainItems;
        }

        [HttpGet]
        public async Task<double> GetQuantity(string mainitemdescription)
        {
            var mainItems = await GetMAINITEMSByDescription(mainitemdescription);
            if (mainItems == null)
                return 0.0;
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MainItemId == mainItems.MainItemID).FirstOrDefaultAsync();
            if (mainItemsQty == null)
                return 0.0;

            return 0.0;
            //return mainItemsQty.QTY.Value;
        }

        [HttpPost]
        public async Task<string> UpdateQty(string code, string mainitemsstr, string tagtypesstr, string lotstr,
            string drawrevaccstr, string budgetstr, string wrqtystr,
            string ifrqtystr, string ifcqtystr, string qtyaccstr, string qtynextcestr,
            string qtyholdstr, string qtyrebarstr, string qtyconnincstr, string qtyvolstr,
            string param1ValuesStr,
            string param2ValuesStr,
            string param3ValuesStr,
            string param4ValuesStr,
            string param5ValuesStr,
            string param6ValuesStr,
            string param7ValuesStr,
            string param8ValuesStr,
            string param9ValuesStr,
            string param10ValuesStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] tagtypes = Utils.SplitText(tagtypesstr);
                    string[] lots = Utils.SplitText(lotstr);
                    string[] drawAcc = Utils.SplitText(drawrevaccstr);
                    double[] budgetqty = Utils.SplitVector(budgetstr);
                    double[] wrqty = Utils.SplitVector(wrqtystr);
                    double[] ifrqty = Utils.SplitVector(ifrqtystr);
                    double[] ifcqty = Utils.SplitVector(ifcqtystr);
                    double[] qtyAcc = Utils.SplitVector(qtyaccstr);
                    double[] nextceqty = Utils.SplitVector(qtynextcestr);
                    double[] holdqty = Utils.SplitVector(qtyholdstr);
                    double[] reinfqty = Utils.SplitVector(qtyrebarstr);
                    double[] qtyconninc = Utils.SplitVector(qtyconnincstr);
                    double[] qtyvol = Utils.SplitVector(qtyvolstr);

                    double?[] param1Values = Utils.SplitVectorWithNull(param1ValuesStr);
                    double?[] param2Values = Utils.SplitVectorWithNull(param2ValuesStr);
                    double?[] param3Values = Utils.SplitVectorWithNull(param3ValuesStr);
                    double?[] param4Values = Utils.SplitVectorWithNull(param4ValuesStr);
                    double?[] param5Values = Utils.SplitVectorWithNull(param5ValuesStr);
                    double?[] param6Values = Utils.SplitVectorWithNull(param6ValuesStr);
                    double?[] param7Values = Utils.SplitVectorWithNull(param7ValuesStr);
                    double?[] param8Values = Utils.SplitVectorWithNull(param8ValuesStr);
                    double?[] param9Values = Utils.SplitVectorWithNull(param9ValuesStr);
                    double?[] param10Values = Utils.SplitVectorWithNull(param10ValuesStr);

                    int quantityType = _configuration.GetValue<int>("Items:ParameterQuantityID");
                    var quantityParameters = await _context.MAINITEMPARAMETERS.Where(d => d.PROJECTID == project.ProjectID && d.MAINITEMPARAMETERCATEGORIESID == quantityType).OrderBy(d => d.ParameterID).ToListAsync();
                    int totalParameters = quantityParameters != null ? quantityParameters.Count : 0;

                    int itemCounter = 0;
                    foreach (string item in mainitems)
                    {
                        var mainitem = await _context.MAINITEMS.Include(m => m.LOTS).Where(m => m.MainItemTag == item &&
                            m.TAGTYPES.Description == tagtypes[itemCounter] &&
                            m.PBS.ProjectID == project.ProjectID &&
                            m.LOTS.NAME == lots[itemCounter]).FirstOrDefaultAsync();

                        if (mainitem != null)
                        {
                            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MainItemId == mainitem.MainItemID).FirstOrDefaultAsync();
                            var qtyRevisions = await _context.MAIN_ITEM_MANUAL_QTY_REV.Where(q => q.MainItemId.Value == mainitem.MainItemID).ToListAsync();
                            int? intIdt = qtyRevisions.Max(u => (int?)u.RevId);
                            if (mainItemsQty != null)
                            {
                                bool notdifferent = true;
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_BUDGET, budgetqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_WR, wrqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_IFR, ifrqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_IFC, ifcqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_ACC, qtyAcc[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_NEXT_CE, nextceqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.MANUAL_QTY_HOLD, holdqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.QTY_REINF, reinfqty[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.CONNECTION_INDICENCE, qtyconninc[itemCounter], 0.01);
                                notdifferent &= Models.Logs.Comparer.AreEqual(mainItemsQty.AI_VOLUME_LAST_ISSUE, qtyvol[itemCounter], 0.01);

                                if (!notdifferent)
                                {
                                    MAIN_ITEM_MANUAL_QTY_REV manualRev = new MAIN_ITEM_MANUAL_QTY_REV(mainItemsQty, user);
                                    if (intIdt != null && intIdt.HasValue)
                                        manualRev.RevId = intIdt.Value + 1;
                                    else
                                        manualRev.RevId = 0;
                                    _context.Add(manualRev);
                                }
                                mainItemsQty.QTY_BUDGET = budgetqty[itemCounter];
                                mainItemsQty.QTY_WR = wrqty[itemCounter];
                                mainItemsQty.QTY_IFR = ifrqty[itemCounter];
                                mainItemsQty.QTY_IFC = ifcqty[itemCounter];
                                mainItemsQty.QTY_ACC = qtyAcc[itemCounter];
                                mainItemsQty.QTY_NEXT_CE = nextceqty[itemCounter];
                                mainItemsQty.MANUAL_QTY_HOLD = holdqty[itemCounter];
                                mainItemsQty.QTY_REINF = reinfqty[itemCounter];
                                mainItemsQty.CONNECTION_INDICENCE = qtyconninc[itemCounter];
                                mainItemsQty.AI_VOLUME_LAST_ISSUE = qtyvol[itemCounter];
                                mainItemsQty.LastModified = DateTime.UtcNow;
                                mainItemsQty.UserID = user.USERID;

                                mainitem.DrawRevAcc = drawAcc[itemCounter];

                                if (totalParameters > 0)
                                {
                                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == mainitem.MainItemID).OrderBy(p => p.ValueID).ToListAsync();
                                    if (values != null)
                                    {
                                        int counter = 0;
                                        foreach (var parameter in quantityParameters)
                                        {
                                            var value = values.Where(v => v.MainItemParametersID == parameter.ParameterID).FirstOrDefault();
                                            if (value != null)
                                            {
                                                if (counter == 0)
                                                    value.PARAMETERDOUBLE = param1Values[itemCounter];
                                                else if (counter == 1)
                                                    value.PARAMETERDOUBLE = param2Values[itemCounter];
                                                else if (counter == 2)
                                                    value.PARAMETERDOUBLE = param3Values[itemCounter];
                                                else if (counter == 3)
                                                    value.PARAMETERDOUBLE = param4Values[itemCounter];
                                                else if (counter == 4)
                                                    value.PARAMETERDOUBLE = param5Values[itemCounter];
                                                else if (counter == 5)
                                                    value.PARAMETERDOUBLE = param6Values[itemCounter];
                                                else if (counter == 6)
                                                    value.PARAMETERDOUBLE = param7Values[itemCounter];
                                                else if (counter == 7)
                                                    value.PARAMETERDOUBLE = param8Values[itemCounter];
                                                else if (counter == 8)
                                                    value.PARAMETERDOUBLE = param9Values[itemCounter];
                                                else if (counter == 9)
                                                    value.PARAMETERDOUBLE = param10Values[itemCounter];
                                            }
                                            counter++;
                                        }
                                    }
                                }

                                await _context.SaveChangesAsync();

                                //// Add manual revision
                                //await AddRevision(mainitem.MainItemID, ifcqty[counter], EngStatusCostants.IFC_ID, user.USERID.Value);
                                //await AddRevision(mainitem.MainItemID, ifrqty[counter], EngStatusCostants.IFR_ID, user.USERID.Value);
                                //await AddRevision(mainitem.MainItemID, ifbqty[counter], EngStatusCostants.IFB_ID, user.USERID.Value);

                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_NOT_FOUND, item + " ");
                            }
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND, item + " ");
                        }
                        itemCounter++;
                    }
                    msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:QtyManagerTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "QuantityManager.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:QtyManagerSheetName");
            int startRow = _configuration.GetValue<int>("Excel:QtyManagerSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:QtyManagerSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:QtyManagerProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:QtyManagerProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;

            QuantityManager itemListCreation = new QuantityManager();
            int projectId = project.ProjectID;
            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            mainItems = MAINITEMS.ReorderMainItems(mainItems);
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == projectId).ToListAsync();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var proposals = await _context.PROPOSEDQUANTITY.Where(x => x.ProjectID == projectId).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            // Update Main Items
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();
                }
            }

            if (mainItems != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                }

                int currentRow = startRow;
                mainItems = mainItems.OrderBy(p => p.MainItemTag).ToList();
                foreach (MAINITEMS item in mainItems)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.LOTS != null ? item.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.Status;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.PARENT_TAG;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.ITEM_QUANTITY.GetEngStatusOld;
                    Sheet.Cells[currentRow, startColumn + 10].Value = string.Empty;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.DrawRevAcc;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.DrawRevAcc;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.MRNO;
                    Sheet.Cells[currentRow, startColumn + 14].Value = item.QtyUnits;
                    Sheet.Cells[currentRow, startColumn + 15].Value = item.GetQty;
                    Sheet.Cells[currentRow, startColumn + 16].Value = item.ITEM_QUANTITY.QTY_BUDGET;
                    Sheet.Cells[currentRow, startColumn + 17].Value = item.ITEM_QUANTITY.QTY_WR;
                    Sheet.Cells[currentRow, startColumn + 18].Value = item.ITEM_QUANTITY.QTY_IFR;
                    Sheet.Cells[currentRow, startColumn + 19].Value = item.ITEM_QUANTITY.QTY_IFC;
                    Sheet.Cells[currentRow, startColumn + 20].Value = item.ITEM_QUANTITY.QTY_VD;
                    Sheet.Cells[currentRow, startColumn + 21].Value = item.ITEM_QUANTITY.QTY_ACC;
                    Sheet.Cells[currentRow, startColumn + 22].Value = item.ITEM_QUANTITY.QTY_LAST_ISSUE;
                    Sheet.Cells[currentRow, startColumn + 23].Value = item.ITEM_QUANTITY.GetLastCEQty;
                    Sheet.Cells[currentRow, startColumn + 24].Value = item.ITEM_QUANTITY.GetKNextCERounded;
                    Sheet.Cells[currentRow, startColumn + 25].Value = item.ITEM_QUANTITY.QTY_NEXT_CE;
                    Sheet.Cells[currentRow, startColumn + 26].Value = item.Qty3dHold;
                    Sheet.Cells[currentRow, startColumn + 27].Value = item.ITEM_QUANTITY.MANUAL_QTY_HOLD;
                    Sheet.Cells[currentRow, startColumn + 28].Value = item.ITEM_QUANTITY.QTY_REINF;
                    Sheet.Cells[currentRow, startColumn + 29].Value = item.ITEM_QUANTITY.ReinfIncidence;
                    Sheet.Cells[currentRow, startColumn + 30].Value = item.ITEM_QUANTITY.CONNECTION_INDICENCE;
                    Sheet.Cells[currentRow, startColumn + 31].Value = item.ITEM_QUANTITY.AiVolumeIncidence;
                    Sheet.Cells[currentRow, startColumn + 32].Value = string.Empty;
                    Sheet.Cells[currentRow, startColumn + 33].Value = item.ITEM_QUANTITY.AI_VOLUME_LAST_ISSUE;
                    Sheet.Cells[currentRow, startColumn + 34].Value = string.Empty;
                    Sheet.Cells[currentRow, startColumn + 35].Value = item.GetModelDate;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }


        [HttpGet]
        public async Task<ActionResult> CreateExcelView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:QtyManagerViewTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "Quantities.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:QtyManagerSheetName");
            int startRow = _configuration.GetValue<int>("Excel:QtyManagerSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:QtyManagerSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:QtyManagerProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:QtyManagerProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            QuantityManager itemListCreation = new QuantityManager();
            int projectId = project.ProjectID;
            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Include(m => m.USERS).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            mainItems = MAINITEMS.ReorderMainItems(mainItems);
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == projectId).ToListAsync();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var proposals = await _context.PROPOSEDQUANTITY.Where(x => x.ProjectID == projectId).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            // Update Main Items
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();
                }
            }

            if (mainItems != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                }

                int currentRow = startRow;
                mainItems = mainItems.OrderBy(p => p.MainItemTag).ToList();
                foreach (MAINITEMS item in mainItems)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.LOTS != null ? item.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.Status;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.PARENT_TAG;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.ITEM_QUANTITY.GetEngStatusOld;
                    Sheet.Cells[currentRow, startColumn + 10].Value = item.DrawNo;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.DRAWREV;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.DrawRevAcc;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.MRNO;
                    Sheet.Cells[currentRow, startColumn + 14].Value = item.QtyUnits;
                    Sheet.Cells[currentRow, startColumn + 15].Value = item.GetQty;
                    Sheet.Cells[currentRow, startColumn + 16].Value = item.ITEM_QUANTITY.QTY_BUDGET;
                    Sheet.Cells[currentRow, startColumn + 17].Value = item.ITEM_QUANTITY.QTY_WR;
                    Sheet.Cells[currentRow, startColumn + 18].Value = item.ITEM_QUANTITY.QTY_IFR;
                    Sheet.Cells[currentRow, startColumn + 19].Value = item.ITEM_QUANTITY.QTY_IFC;
                    Sheet.Cells[currentRow, startColumn + 20].Value = item.ITEM_QUANTITY.QTY_VD;
                    Sheet.Cells[currentRow, startColumn + 21].Value = item.ITEM_QUANTITY.QTY_ACC;
                    Sheet.Cells[currentRow, startColumn + 22].Value = item.ITEM_QUANTITY.QTY_LAST_ISSUE;
                    Sheet.Cells[currentRow, startColumn + 23].Value = item.ITEM_QUANTITY.GetLastCEQty;
                    Sheet.Cells[currentRow, startColumn + 24].Value = item.ITEM_QUANTITY.GetKNextCERounded;
                    Sheet.Cells[currentRow, startColumn + 25].Value = item.ITEM_QUANTITY.QTY_NEXT_CE;
                    Sheet.Cells[currentRow, startColumn + 26].Value = item.Qty3dHold;
                    Sheet.Cells[currentRow, startColumn + 27].Value = item.ITEM_QUANTITY.MANUAL_QTY_HOLD;
                    Sheet.Cells[currentRow, startColumn + 28].Value = item.ITEM_QUANTITY.QTY_REINF;
                    Sheet.Cells[currentRow, startColumn + 29].Value = item.ITEM_QUANTITY.ReinfIncidence;
                    Sheet.Cells[currentRow, startColumn + 30].Value = item.ITEM_QUANTITY.CONNECTION_INDICENCE;
                    Sheet.Cells[currentRow, startColumn + 31].Value = item.ITEM_QUANTITY.AiVolumeIncidence;
                    Sheet.Cells[currentRow, startColumn + 32].Value = string.Empty;
                    Sheet.Cells[currentRow, startColumn + 33].Value = item.ITEM_QUANTITY.AI_VOLUME_LAST_ISSUE;
                    if (item.TagTypeID == DatabaseCostants.TagType_Pile_ID)
                    {
                        int? pilesCount = item.GetPilesCount;
                        if (pilesCount != null && pilesCount.HasValue)
                            Sheet.Cells[currentRow, startColumn + 34].Value = pilesCount.Value;
                    }
                    Sheet.Cells[currentRow, startColumn + 35].Value = item.GetModelDate;
                    Sheet.Cells[currentRow, startColumn + 36].Value = item.ITEM_QUANTITY.DateLastModify;
                    Sheet.Cells[currentRow, startColumn + 37].Value = item.ITEM_QUANTITY.LastModifyUser;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        private async Task<bool> AddRevision(int mainItemId, double newQty, int statusId, int userId)
        {
            bool updateNecessary = false;
            int manualStatus = _configuration.GetValue<int>("Items:StatusManualID");
            var qtyRevisionManual = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == mainItemId &&
                    m.MODELSTATUSID.Value == manualStatus && m.STATUSID == statusId).OrderByDescending(m => m.REVID).FirstOrDefaultAsync();
            double oldQty = qtyRevisionManual != null ? qtyRevisionManual.QTY.Value : 0.0;
            if (newQty > 0.0 || oldQty > 0.0)
            {
                if (qtyRevisionManual != null)
                {
                    if (System.Math.Abs(qtyRevisionManual.QTY.Value - newQty) > 0.01)
                        updateNecessary = true;
                }
                else
                    updateNecessary = true;
            }
            if (updateNecessary) // Add new IFC manual quantity
            {
                var qtyRevisions = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == mainItemId &&
                     m.STATUSID == statusId).ToListAsync();
                int maxIfcRev = (qtyRevisions != null && qtyRevisions.Count > 0) ? qtyRevisions.Select(m => m.REVID).Max().Value : 0;

                MTOREVS qtyRev = new MTOREVS();
                qtyRev.MAINITEMID = mainItemId;
                qtyRev.MODELSTATUSID = manualStatus;
                qtyRev.STATUSID = statusId;
                qtyRev.CreationDate = DateTime.UtcNow;
                qtyRev.LastModified = DateTime.UtcNow;
                qtyRev.UserID = userId;
                qtyRev.QTY = newQty;
                qtyRev.REVID = maxIfcRev + 1;
                _context.MTOREVS.Add(qtyRev);

                await _context.SaveChangesAsync();
            }
            return true;
        }

        public async Task<bool> SaveQuantity(string mainitemdescription, double qtyce, double kfactor)
        {
            var mainItems = await GetMAINITEMSByDescription(mainitemdescription);
            if (mainItems == null)
                return false;
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MainItemId == mainItems.MainItemID).FirstOrDefaultAsync();
            if (mainItemsQty == null)
                return false;
            //mainItemsQty.QTY_CE = qtyce;
            //mainItemsQty.K_Factor = kfactor;
            int result = await _context.SaveChangesAsync();
            return result > 0;
        }

        [HttpPost]
        public async Task<string> SaveQtyCE(string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    int revisionID = 1;

                    var revisions = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID).ToListAsync();
                    if (revisions != null && revisions.Count > 0)
                        revisionID = revisions.Select(r => r.REVISIONSNUMBER).Max() + 1;
                    if (revisionID < 1)
                        revisionID = 1;

                    // Add Revision
                    QUANTITY_CE_REVISION newRevision = new QUANTITY_CE_REVISION();
                    newRevision.CreationDate = DateTime.UtcNow;
                    newRevision.LastModified = DateTime.UtcNow;
                    newRevision.ProjectID = project.ProjectID;
                    newRevision.UserID = user.USERID;
                    newRevision.REVISIONSNUMBER = revisionID;
                    _context.QUANTITY_CE_REVISION.Add(newRevision);
                    await _context.SaveChangesAsync();

                    var mainitems = await _context.MAINITEMS.Include(m => m.LOTS).
                        Include(m => m.PBS)
                        .Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                    foreach (MAINITEMS mainitem in mainitems)
                    {
                        // Update Main Item Qty
                        var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MainItemId == mainitem.MainItemID).FirstOrDefaultAsync();
                        if (mainItemsQty != null)
                        {
                            // Add Main Item CE Quantitu
                            MAIN_ITEM_QUANTITY_CE ceQty = new MAIN_ITEM_QUANTITY_CE();
                            ceQty.CreationDate = DateTime.UtcNow;
                            ceQty.LastModified = DateTime.UtcNow;
                            ceQty.UserID = user.USERID;
                            ceQty.MainItemId = mainitem.MainItemID;
                            if (mainItemsQty.QTY_NEXT_CE != null && mainItemsQty.QTY_NEXT_CE.HasValue)
                                ceQty.QTY_CE = mainItemsQty.QTY_NEXT_CE.Value;
                            else
                                ceQty.QTY_CE = 0.0;
                            ceQty.RevId = newRevision.ID;

                            _context.MAIN_ITEM_QUANTITY_CE.Add(ceQty);
                            await _context.SaveChangesAsync();
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_NOT_FOUND, mainitem.MainItemTag);
                        }
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<List<QuantityCEData>> GetQtyCERevision(string code, string revision1str, string revision2str)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return null;

                    if (String.IsNullOrEmpty(code))
                        return null;
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return null;

                    var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    bool firstActual = revision1str == AppCostants.CE_ACTUAL_REVISION_NAME;
                    bool secondActual = revision2str == AppCostants.CE_ACTUAL_REVISION_NAME;
                    var revision1 = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID &&
                            r.GetDescription == revision1str).FirstOrDefaultAsync();
                    var revision2 = await _context.QUANTITY_CE_REVISION.Where(r => r.ProjectID == project.ProjectID &&
                            r.GetDescription == revision2str).FirstOrDefaultAsync();


                    var mainitems = await _context.MAINITEMS.Include(m => m.LOTS).
                        Include(m => m.PBS)
                        .Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
                    var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

                    List<QuantityCEData> quantities = new List<QuantityCEData>();

                    foreach (MAINITEMS mainitem in mainitems)
                    {
                        mainitem.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == mainitem.MainItemID).FirstOrDefault();
                        var quantitiesCE = await _context.MAIN_ITEM_QUANTITY_CE.Where(m => m.MainItemId == mainitem.MainItemID).ToListAsync();
                        if (quantitiesCE != null)
                        {
                            QuantityCEData quantityCEData = new QuantityCEData();
                            quantityCEData.MainItemTag = mainitem.MainItemTag;
                            quantityCEData.TagTypeDescription = mainitem.TAGTYPES.Description;
                            quantityCEData.Lot = mainitem.LOTS.NAME;
                            if (revision1 != null)
                            {
                                var qty = quantitiesCE.Where(r => r.RevId == revision1.ID).FirstOrDefault();
                                if (qty != null && qty.QTY_CE != null && qty.QTY_CE.HasValue)
                                    quantityCEData.QtyCE1 = qty.QTY_CE.Value;
                            }
                            else if (firstActual)
                            {
                                if (mainitem.ITEM_QUANTITY.QTY_NEXT_CE != null && mainitem.ITEM_QUANTITY.QTY_NEXT_CE.HasValue)
                                    quantityCEData.QtyCE1 = mainitem.ITEM_QUANTITY.QTY_NEXT_CE.Value;
                            }
                            if (revision2 != null)
                            {
                                var qty = quantitiesCE.Where(r => r.RevId == revision2.ID).FirstOrDefault();
                                if (qty != null && qty.QTY_CE != null && qty.QTY_CE.HasValue)
                                    quantityCEData.QtyCE2 = qty.QTY_CE.Value;
                            }
                            else if (secondActual)
                            {
                                if (mainitem.ITEM_QUANTITY.QTY_NEXT_CE != null && mainitem.ITEM_QUANTITY.QTY_NEXT_CE.HasValue)
                                    quantityCEData.QtyCE2 = mainitem.ITEM_QUANTITY.QTY_NEXT_CE.Value;
                            }
                            quantityCEData.DeltaCE = quantityCEData.QtyCE2 - quantityCEData.QtyCE1;
                            quantities.Add(quantityCEData);
                        }
                    }
                    return quantities;
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
            return null;
        }

    }
}
