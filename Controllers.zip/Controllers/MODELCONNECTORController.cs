﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Autodesk.Forge;
using Autodesk.Forge.Model;
using CivilMasterData.Data;
using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.BIM360.Database;
using CivilMasterData.Models.BIM360.Formulas;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Logs;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.BIM360.Logs;
using CivilMasterData.Models.BIM360.Checks;
using CivilMasterData.Models.Steel;
using OfficeOpenXml;

namespace CivilMasterData.Controllers
{
    public class MODELCONNECTORController : Controller
    {
        #region Private members
        /// <summary>
        /// BIM360 Credentials
        /// </summary>
        private Credentials Credentials { get; set; }
        private readonly MODELCONNECTORContext _context;
        private IWebHostEnvironment _env;
        private IConfiguration _configuration;
        protected readonly ISharedResource _sharedResource;
        #endregion

        #region Constructor
        public MODELCONNECTORController(MODELCONNECTORContext context, IWebHostEnvironment env, IConfiguration configuration,
            ISharedResource sharedResource)
        {
            _context = context;
            _env = env;
            _configuration = configuration;
            _sharedResource = sharedResource;
        }
        #endregion


        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            await UpdateMissingModels(project.ProjectID, user.USERID.Value);
            await UpdateDeletedModels(project.ProjectID, user.USERID.Value);

            var projectSettings = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            List<string> parametersToCheck = projectSettings.GetBim360Parameters();

            var itemsMissed = await _context.MISSING_MAINITEMS.Where(
                item => item.ProjectID == project.ProjectID && item.Created < 1).ToListAsync();

            MODELCONNECTOR model = new MODELCONNECTOR();
            model.PROJECT = project;
            model.ProjectID = project.ProjectID;
            model.MISSING_MAINITEMS = itemsMissed;

            OAuthController.ProjectCode = project.Code;

            model.ProjectParameters = parametersToCheck;
            model.Parameters = await _context.BIM360PARAMETERS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
            int totalParameters = 0;


            // Sort parameters
            if (model.Parameters != null && parametersToCheck != null && parametersToCheck.Count > 0)
            {
                totalParameters = parametersToCheck.Count;
                model.BIM360ItemAttributes = new List<BIM360ItemAttribute>();
                List<string> items = model.Parameters.Select(d => d.ForgeItemName).ToList();
                if (items != null)
                {
                    foreach (string item in items)
                    {
                        BIM360ItemAttribute bIM360ItemAttribute = new BIM360ItemAttribute();
                        bIM360ItemAttribute.AttributesValues = new List<string>();
                        var parameters = model.Parameters.Where(p => p.ForgeItemName == item);
                        foreach (string parameterName in parametersToCheck)
                        {
                            var current = parameters.Where(p => p.ParameterName == parameterName).FirstOrDefault();
                            if (current != null)
                            {
                                bIM360ItemAttribute.ModelName = current.ModelName;
                                bIM360ItemAttribute.ItemName = item;
                                bIM360ItemAttribute.AttributesValues.Add(current.ParameterValue);
                            }
                            else
                                bIM360ItemAttribute.AttributesValues.Add(string.Empty);
                        }
                        model.BIM360ItemAttributes.Add(bIM360ItemAttribute);
                    }
                }
            }


            model.FileRevisions = await _context.BIM360FILEREVISIONS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
            model.IncorrectFiles = await _context.BIM360INCORRECTFILES.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
            model.ItemStatusList = await _context.BIM360ITEMSTATUS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
            if (model.ItemStatusList != null)
            {
                foreach (var itemStatus in model.ItemStatusList)
                    itemStatus.PROJECTSETTINGS = projectSettings;
            }
            model.ItemListCheck = await _context.ITEMSLISTCHECKS
                .Include(m => m.MainItem)
                .Include(m => m.MainItem.PBS)
                .Include(m => m.MainItem.TAGTYPES)
                .Include(m => m.MainItem.LOTS)
                .Where(i => i.MainItem.PBS.ProjectID == project.ProjectID).ToListAsync();
            model.DeletedMainItems = await _context.DELETEDITEMSLISTCHECKS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
            model.Folders = await _context.BIM360FOLDERS.Include(f => f.USERS).Where(i => i.ProjectID == project.ProjectID).OrderBy(f => f.ID).ToListAsync();


            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.Info = project.GetForgeUpdateInfo;
            ViewBag.TotalParameters = totalParameters;

            return View(model);
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:ModelsTemplateView");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "ModelList.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:ModelsSheetName");
            int startRow = _configuration.GetValue<int>("Excel:PBSSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:PBSSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:PBSProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:PBSProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            var models = await _context.BIM360ITEMSTATUS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();

            // Inser data
            var pbsList = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            if (pbsList != null)
            {
                int currentRow = startRow;
                models = models.OrderBy(m => m.MainItemTag).ToList();
                foreach (BIM360ITEMSTATUS model in models)
                {
                    Sheet.Cells[currentRow, startColumn].Value = model.ModelName;
                    Sheet.Cells[currentRow, startColumn + 1].Value = model.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 2].Value = model.TagType;
                    Sheet.Cells[currentRow, startColumn + 3].Value = model.Lot;
                    Sheet.Cells[currentRow, startColumn + 4].Value = model.Qty;
                    Sheet.Cells[currentRow, startColumn + 5].Value = model.Hold;
                    Sheet.Cells[currentRow, startColumn + 6].Value = model.QtyHold;
                    Sheet.Cells[currentRow, startColumn + 7].Value = model.ModelDate;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        public async Task<IActionResult> ModelView(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            var projectSettings = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            List<string> parametersToCheck = projectSettings.GetBim360Parameters();

            var itemsMissed = await _context.MISSING_MAINITEMS.Where(
                item => item.ProjectID == project.ProjectID && item.Created < 1).ToListAsync();

            MODELCONNECTOR model = new MODELCONNECTOR();
            model.PROJECT = project;
            model.ProjectID = project.ProjectID;
            model.MISSING_MAINITEMS = itemsMissed;

            OAuthController.ProjectCode = project.Code;
            model.ItemStatusList = await _context.BIM360ITEMSTATUS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();


            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.Info = project.GetForgeUpdateInfo;

            return View(model);
        }

        #region Access configuration
        [HttpGet]
        public BIM360InitSettings GetAccessSettings()
        {
            BIM360InitSettings settings = new BIM360InitSettings();
            settings.ForgeClientId = GetAppSetting("FORGE_CLIENT_ID");
            settings.ForgeSecret = GetAppSetting("FORGE_CLIENT_SECRET");

            /// Filters
            settings.HubName = _configuration.GetValue<string>("Forge:Hub");
            settings.RootFolderName = _configuration.GetValue<string>("Forge:FolderProject");
            settings.FirstLevelFolderName = _configuration.GetValue<string>("Forge:FirstLevelFolderFilter");
            settings.SecondLevelFolderName = _configuration.GetValue<string>("Forge:SecondLevelFolderFilter");

            return settings;
        }
        /// <summary>
        /// Reads appsettings from web.config
        /// </summary>
        public static string GetAppSetting(string settingKey)
        {
            return Environment.GetEnvironmentVariable(settingKey);
        }
        #endregion

        [HttpGet]
        public async Task<string> IsProcessing(string code)
        {
            if (User.Identity.IsAuthenticated)
            {
                // Check User
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (user == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.USER_NOT_AUTHORIZED, code);
                    return ForgeLogManager.ExportString();
                }

                // Check Project
                if (string.IsNullOrEmpty(code))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportString();
                }
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                if (project == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportString();
                }

                if (project.ITEMPROCESSING != null && project.ITEMPROCESSING.HasValue)
                {
                    if (project.ITEMPROCESSING.Value > 0)
                    {
                        if (project.PROCESSINGUSERID != null && project.PROCESSINGUSERID.HasValue)
                        {
                            USERS processingUser = await _context.USERS.Where(u => u.USERID == project.PROCESSINGUSERID.Value).FirstAsync();
                            if (processingUser != null)
                                return "Processing by user " + processingUser.USERNAME;
                        }
                        else
                            return "Processing by user";
                    }
                    else
                        return "Valid";
                }
                return "Valid";
            }
            else
                return "Not valid user";
        }

        #region Database
        [HttpPost]
        [Route("api/forge/readitems")]
        public async Task<string> ReadItems(string code, string itemsStr)
        {
            if (User.Identity.IsAuthenticated)
            {
                // Check Item To Process
                List<string> itemTags = new List<string>();
                if (!string.IsNullOrEmpty(itemsStr))
                    itemTags = JsonConvert.DeserializeObject<List<string>>(itemsStr);

                // Check User
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (user == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.USER_NOT_AUTHORIZED, code);
                    return ForgeLogManager.ExportJson();
                }

                // Check Project
                if (string.IsNullOrEmpty(code))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                if (project == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                // Read DBs
                await _context.OBJECTCODES.ToListAsync();
                await _context.MATERIALWORKGROUPS.ToListAsync();
                await _context.TAGTYPES.ToListAsync();
                await _context.BIM360FILES.Where(b => b.PROJECTID == project.ProjectID).ToArrayAsync();

                // Check User
                Credentials = OAuthController.Credentials;
                if (Credentials == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.USER_NOT_AUTHORIZED, code);
                    return ForgeLogManager.ExportJson();
                }

                // Find Hub
                string hubName = _configuration.GetValue<string>("Forge:Hub");
                if (string.IsNullOrEmpty(hubName))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_HUB_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
                var hub = await GetHubAsync(hubName);
                if (hub == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_HUB_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                // Get Project
                var bim360Project = await GetProjectAsync(hub.id, code);
                if (bim360Project == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                // Get Project Files Folder
                string projectFilesFolderName = _configuration.GetValue<string>("Forge:FolderProject");
                if (string.IsNullOrEmpty(projectFilesFolderName))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_FOLDER_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
                var projectFilesFolder = await GetFolder(bim360Project.id, projectFilesFolderName);
                if (projectFilesFolder == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_FOLDER_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                // Get First Level Filter Folder
                string firstFolderName = _configuration.GetValue<string>("Forge:FirstLevelFolderFilter");
                if (string.IsNullOrEmpty(firstFolderName))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_FOLDER_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
                var firstFolder = await GetFirstLevelFolders(projectFilesFolder.id, firstFolderName);
                if (firstFolder == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_PROJECT_FOLDER_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                // Get WP Folder Name
                string folderWP = _configuration.GetValue<string>("Forge:SecondLevelFolderFilter");
                if (string.IsNullOrEmpty(hubName))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_WP_FOLDER_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
                var wpFolder = await GetFirstLevelFolders(firstFolder.id, folderWP);
                if (wpFolder == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_WP_FOLDER_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                // Find all model inside folder
                var bim360files = await GetFilesFromFolder(wpFolder.id);

                // Save File to Database
                if (bim360files != null && bim360files.Count > 0)
                {
                    bool valid = await SaveElementsToDatabase(bim360files, project.ProjectID,
                        user, Credentials, itemTags);
                }
                else
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.MODEL_CONNECTOR_REVIT_FILES_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
            }
            return ForgeLogManager.ExportJson();
        }

        [HttpPost]
        [Route("api/forge/saveitems")]
        [RequestSizeLimit(2147483648)]
        public async Task<string> SaveItems(string code, string filesstr, string itemsStr, string itemsTagStr,
            string folderStr, string filefilter)
        {
            ModelConnectionResults.Reset();

            if (User.Identity.IsAuthenticated)
            {
                // Check User
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (user == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.USER_NOT_AUTHORIZED, code);
                    return ForgeLogManager.ExportJson();
                }

                // Check Project
                if (string.IsNullOrEmpty(code))
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                if (project == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.PROJECT_NOT_FOUND, code);
                    return ForgeLogManager.ExportJson();
                }

                var projectSettings = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);

                // Check Item To Process
                List<string> itemTags = new List<string>();
                if (!string.IsNullOrEmpty(itemsTagStr))
                    itemTags = JsonConvert.DeserializeObject<List<string>>(itemsTagStr);

                // Deserialize
                var files = JsonConvert.DeserializeObject<List<BIM360FILES>>(filesstr);
                var forgeModels = JsonConvert.DeserializeObject<List<ForgeModel>>(itemsStr);

                // Folders
                List<string> folders = new List<string>();
                if (!string.IsNullOrEmpty(folderStr))
                    folders = JsonConvert.DeserializeObject<List<string>>(folderStr);

                // Check Objects
                if (files == null || forgeModels == null)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.BIM360_NOTHING_TO_PROCESS, code);
                    return ForgeLogManager.ExportJson();
                }
                if (files.Count != forgeModels.Count)
                {
                    ForgeLogManager.AddLog(MESSAGE_CODES.INCORRECT_DATA, code);
                    return ForgeLogManager.ExportJson();
                }

                var tagTypes = await _context.TAGTYPES.ToListAsync();

                // Filter file to process
                List<BIM360FILES> fileToProcess = new List<BIM360FILES>();
                List<ForgeItem> models = new List<ForgeItem>();
                for (int i = 0; i < files.Count; i++)
                {
                    if (!AlrearyContainFile(files[i]))
                    {
                        if (forgeModels[i].items != null)
                        {
                            fileToProcess.Add(files[i]);
                            models.AddRange(forgeModels[i].items);
                        }
                    }
                }
                bool valid = await SaveElementsToDatabaseParsed(models, project.ProjectID, projectSettings,
                        user, itemTags, fileToProcess, tagTypes);

                // Save Folders
                var currentFolders = await _context.BIM360FOLDERS.Where(i => i.ProjectID == project.ProjectID).OrderBy(f => f.ID).ToListAsync();
                // Update BIM360Foldes
                if (valid)
                {
                    if (folders != null)
                    {
                        bool added = false;
                        foreach (string folder in folders)
                        {
                            BIM360FOLDERS newFolder = new BIM360FOLDERS();
                            newFolder.CreationDate = DateTime.UtcNow;
                            newFolder.FolderName = folder;
                            newFolder.ProjectID = project.ProjectID;
                            newFolder.UserID = user.USERID;
                            newFolder.Version = 1;
                            if (currentFolders != null)
                            {
                                var list = currentFolders.Where(f => f.FolderName == folder).ToList();
                                if (list != null && list.Count > 0)
                                {
                                    int max = list.Max(f => f.Version) + 1;
                                    newFolder.Version = max;
                                }
                            }
                            newFolder.Filter = filefilter;
                            _context.BIM360FOLDERS.Add(newFolder);
                            added = true;
                        }
                        if (added)
                            await _context.SaveChangesAsync();
                    }
                }
            }
            else
            {
                ForgeLogManager.AddLog(MESSAGE_CODES.USER_NOT_AUTHORIZED, code);
                return ForgeLogManager.ExportJson();
            }
            return ForgeLogManager.ExportJson();
        }

        private async Task<bool> SaveElementsToDatabaseParsed(List<ForgeItem> forgeItems,
                int projectId,
                PROJECTSETTINGS pROJECTSETTINGS,
                USERS user,
                List<string> itemTags,
                List<BIM360FILES> files,
                List<TAGTYPES> tagTypes)
        {
            List<string> fileNotCompleted = new List<string>();

            // Check if process is not under calculation
            var project = await _context.PROJECTS.Where(p => p.ProjectID == projectId).FirstOrDefaultAsync();
            if (project == null || (project.ITEMPROCESSING != null && project.ITEMPROCESSING.HasValue &&
                project.ITEMPROCESSING.Value > 0))
                return false;

            int result = 0;
            try
            {
                // Init Settings
                DatabaseCostants.InitValues(_configuration);

                // Set Project Processing
                project.ITEMPROCESSING = 1;
                project.PROCESSINGUSERID = user.USERID;
                result = await _context.SaveChangesAsync();

                var status = await _context.ENGINEERING_STATUS.ToListAsync();
                var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();

                var webRoot = _env.WebRootPath;
                string settingsFolder = _configuration.GetValue<string>("AppSettings:SettingsFolder");
                string parameterDatabaseFileName = _configuration.GetValue<string>("AppSettings:ParameterDatabase");
                var fileJson = System.IO.Path.Combine(webRoot, settingsFolder, parameterDatabaseFileName);
                ParameterDictionary parameterDictionary = null;
                using (StreamReader file = System.IO.File.OpenText(fileJson))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    parameterDictionary = (ParameterDictionary)serializer.Deserialize(file, typeof(ParameterDictionary));
                }

                string formulaDatabaseFileName = _configuration.GetValue<string>("AppSettings:FormulaDatabase");
                fileJson = System.IO.Path.Combine(webRoot, settingsFolder, formulaDatabaseFileName);
                FamilyFormulaDictionary familyFormulaDictionary = null;
                using (StreamReader file = System.IO.File.OpenText(fileJson))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    familyFormulaDictionary = (FamilyFormulaDictionary)serializer.Deserialize(file, typeof(FamilyFormulaDictionary));
                }


                SecondaryItemDatabase secondaryItemDatabase = new SecondaryItemDatabase(forgeItems, parameterDictionary, familyFormulaDictionary);
                secondaryItemDatabase.SaveToDatabase(
                    mainItems,
                    status,
                    projectId,
                    user,
                    itemTags,
                    _context,
                    pROJECTSETTINGS,
                    ref fileNotCompleted);

                // Add Process files if completed without missing main items
                if (files != null && files.Count > 0)
                {
                    bool added = false;
                    foreach (BIM360FILES file in files)
                    {
                        if (!fileNotCompleted.Contains(file.FILENAME))
                        {
                            _context.BIM360FILES.Add(new BIM360FILES(file, user));
                            added = true;
                        }
                    }
                    if (added)
                        await _context.SaveChangesAsync();
                }

                // Save BIM360 Items
                var existingDBStatus = await _context.BIM360ITEMSTATUS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                if (!ModelConnectionResults.IsItemStatusEmpty)
                {
                    bool updated = false;
                    foreach (var item in ModelConnectionResults.ItemStatusList)
                    {
                        var file = files.Where(f => f.FILENAME == item.ModelName).FirstOrDefault();
                        if (file != null)
                            item.ModelDate = file.FILEDATE.ToString("yyyy-MM-dd");

                        var currentDBItem = existingDBStatus.Where(m => m.MainItemTag == item.MainItemTag && m.TagType == item.TagType &&
                            m.Lot == item.Lot).FirstOrDefault();
                        if (currentDBItem == null) // First time seen
                            _context.Add(item);
                        else
                        {
                            var currentMainItem = mainItems.Where(m => m.MainItemTag == item.MainItemTag && m.TAGTYPES.Description == item.TagType &&
                                m.LOTS.NAME == item.Lot).FirstOrDefault();
                            if (currentMainItem != null)
                            {
                                if (currentMainItem.IsDeleted || currentMainItem.IsReplaced)
                                {
                                    currentDBItem.MatchItem = BIM360ItemCostants.ITEM_NO_MATCH;
                                    currentDBItem.ActualDate = item.ActualDate;
                                    currentDBItem.Qty = item.Qty;
                                    currentDBItem.QtyHold = item.QtyHold;
                                    currentDBItem.Hold = item.QtyHold > 0.0;
                                    currentDBItem.Status = item.Status;
                                    currentDBItem.ModelName = item.ModelName;
                                    currentDBItem.COUNT = item.COUNT;
                                }
                                else
                                {
                                    currentDBItem.MatchItem = BIM360ItemCostants.ITEM_ALREADY_PRESENT;
                                    currentDBItem.ActualDate = item.ActualDate;
                                    currentDBItem.Qty = item.Qty;
                                    currentDBItem.QtyHold = item.QtyHold;
                                    currentDBItem.Hold = item.QtyHold > 0.0;
                                    currentDBItem.Status = item.Status;
                                    currentDBItem.ModelName = item.ModelName;
                                    currentDBItem.COUNT = item.COUNT;
                                }
                            }
                            else
                            {
                                currentDBItem.MatchItem = BIM360ItemCostants.ITEM_NO_MATCH;
                                currentDBItem.ActualDate = item.ActualDate;
                                currentDBItem.Qty = item.Qty;
                                currentDBItem.QtyHold = item.QtyHold;
                                currentDBItem.Hold = item.QtyHold > 0.0;
                                currentDBItem.Status = item.Status;
                                currentDBItem.ModelName = item.ModelName;
                                currentDBItem.COUNT = item.COUNT;
                            }

                            if (!item.EqualQty(currentDBItem) && currentDBItem.Qty > 0.0)
                                currentDBItem.Status = BIM360ItemCostants.ITEM_QTY_MODIFIED;
                        }
                        updated = true;
                    }
                    if (updated)
                        await _context.SaveChangesAsync();
                    //foreach (var item in ModelConnectionResults.ItemStatusList)
                    //{
                    //    if (item.MatchItem == BIM360ItemCostants.ITEM_NEW_MATCH)
                    //    {
                    //        // Search if already downloaded
                    //        var statusOld = existingStatus.Where(p => p.MainItemTag == item.MainItemTag &&
                    //            p.Lot == item.Lot && p.TagType == item.TagType).FirstOrDefault();
                    //        if (statusOld != null)
                    //        {
                    //            item.MatchItem = BIM360ItemCostants.ITEM_ALREADY_PRESENT;
                    //            statusOld.MatchItem = BIM360ItemCostants.ITEM_ALREADY_PRESENT;
                    //            if (!item.EqualQty(statusOld))
                    //            {
                    //                item.Status = BIM360ItemCostants.ITEM_QTY_MODIFIED;
                    //                statusOld.Status = item.Status;
                    //            }
                    //        }
                    //    }
                    //    else if (item.MatchItem == BIM360ItemCostants.ITEM_ALREADY_PRESENT)
                    //    {
                    //        var file = files.Where(f => f.FILENAME == item.ModelName).FirstOrDefault();
                    //        if (file != null)
                    //            item.ModelDate = file.FILEDATE.ToString("yyyy-MM-dd");

                    //        var currentTag = tagTypes.Where(t => t.Description == item.TagType).FirstOrDefault();
                    //        if (currentTag != null)
                    //        {
                    //            var quantities = OracleUtils.GetQuantity(item.MainItemTag, currentTag.TagTypeID, item.Lot,
                    //                secondaryItemDatabase.Items);
                    //            item.Qty = quantities[0];
                    //            item.QtyHold = quantities[1];
                    //            item.Hold = item.QtyHold > 0.0;

                    //            _context.BIM360ITEMSTATUS.Add(item);
                    //        }
                    //    }
                    //    else if (item.MatchItem == BIM360ItemCostants.ITEM_NO_MATCH)
                    //    {
                    //        var file = files.Where(f => f.FILENAME == item.ModelName).FirstOrDefault();
                    //        if (file != null)
                    //            item.ModelDate = file.FILEDATE.ToString("yyyy-MM-dd");

                    //        var currentTag = tagTypes.Where(t => t.Description == item.TagType).FirstOrDefault();
                    //        if (currentTag != null)
                    //        {
                    //            var quantities = OracleUtils.GetQuantity(item.MainItemTag, currentTag.TagTypeID, item.Lot,
                    //                secondaryItemDatabase.Items);
                    //            item.Qty = quantities[0];
                    //            item.QtyHold = quantities[1];
                    //            item.Hold = item.QtyHold > 0.0;

                    //            _context.BIM360ITEMSTATUS.Add(item);
                    //        }
                    //    }
                    //}
                    //await _context.SaveChangesAsync();
                }
                //if (!ModelConnectionResults.IsItemStatusEmpty)
                //{
                //    // Update model date
                //    foreach(BIM360ITEMSTATUS item in ModelConnectionResults.ItemStatusList)
                //    {
                //        var file = files.Where(f => f.FILENAME == item.ModelName).FirstOrDefault();
                //        if (file != null)
                //            item.ModelDate = file.FILEDATE.ToString("yyyy-MM-dd");

                //        // Update qry
                //        if (item.MatchItem == BIM360ItemCostants.ITEM_NO_MATCH)
                //        {
                //            var currentTag = tagTypes.Where(t => t.Description == item.TagType).FirstOrDefault();
                //            if (currentTag != null)
                //            {
                //                var quantities = OracleUtils.GetQuantity(item.MainItemTag, currentTag.TagTypeID, item.Lot,
                //                    secondaryItemDatabase.Items);
                //                item.Qty = quantities[0];
                //                item.QtyHold = quantities[1];
                //                item.Hold = item.QtyHold > 0.0;
                //            }
                //        }
                //    }

                //    _context.BIM360ITEMSTATUS.AddRange(ModelConnectionResults.ItemStatusList);
                //    await _context.SaveChangesAsync();
                //}

                //// Add MainItem in DB not existing in 3d model
                //var existingItem = await _context.ITEMSLISTCHECKS.Where(i => i.MainItem.PBS.ProjectID == project.ProjectID).ToListAsync();
                //if (existingItem != null && existingItem.Count > 0)
                //{
                //    _context.RemoveRange(existingItem);
                //    result = await _context.SaveChangesAsync();
                //}
                bool addedItems = false;
                //var mainItemsToCheck = mainItems.Where(m => !m.IsBalance && !m.IsDeleted && !m.IsReplaced).ToList();
                //if (mainItemsToCheck != null && mainItemsToCheck.Count > 0) 
                //{
                //    foreach (var currentDBItem in mainItemsToCheck)
                //    {
                //        BIM360ITEMSTATUS itemStatus = null;
                //        if (!ModelConnectionResults.IsItemStatusEmpty)
                //            itemStatus = ModelConnectionResults.ItemStatusList.Where(i => i.MainItemTag ==
                //                currentDBItem.MainItemTag && i.Lot == currentDBItem.LOTS.NAME && currentDBItem.TAGTYPES.Description == i.TagType).FirstOrDefault();
                //        if (itemStatus == null)
                //        {
                //            ITEMSLISTCHECKS item = new ITEMSLISTCHECKS();
                //            item.CreationDate = DateTime.UtcNow;
                //            item.LastModified = DateTime.UtcNow;
                //            item.UserID = user.USERID;
                //            item.MainItemID = currentDBItem.MainItemID;
                //            item.ModelName = string.Empty;
                //            addedItems = true;
                //            _context.ITEMSLISTCHECKS.Add(item);
                //        }
                //    }
                //}
                //if (addedItems)
                //    await _context.SaveChangesAsync();


                // Add MainItem in DB deleted or replaced existing in 3d model
                //var existingItemDeletes = await _context.DELETEDITEMSLISTCHECKS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                //if (existingItemDeletes != null && existingItemDeletes.Count > 0)
                //{
                //    _context.RemoveRange(existingItemDeletes);
                //    result = await _context.SaveChangesAsync();
                //}
                addedItems = false;
                if (!ModelConnectionResults.IsItemStatusEmpty)
                {
                    var mainItemsDeletedOrReplaced = mainItems.Where(m => !m.IsBalance && (m.IsDeleted || m.IsReplaced)).ToList();
                    if (mainItemsDeletedOrReplaced != null)
                    {
                        foreach (var currentDBItem in mainItemsDeletedOrReplaced)
                        {
                            BIM360ITEMSTATUS itemStatus = null;
                            if (!ModelConnectionResults.IsItemStatusEmpty)
                                itemStatus = ModelConnectionResults.ItemStatusList.Where(i => i.MainItemTag ==
                                    currentDBItem.MainItemTag && i.Lot == currentDBItem.LOTS.NAME && currentDBItem.TAGTYPES.Description == i.TagType).FirstOrDefault();
                            if (itemStatus != null)
                            {
                                DELETEDITEMSLISTCHECKS item = new DELETEDITEMSLISTCHECKS();
                                item.CreationDate = DateTime.UtcNow;
                                item.LastModified = DateTime.UtcNow;
                                item.UserID = user.USERID;
                                item.MainItemTag = currentDBItem.MainItemTag;
                                if (currentDBItem.IsDeleted)
                                    item.Status = "Deleted";
                                else
                                    item.Status = "Replaced";
                                item.Lot = currentDBItem.LOTS.NAME;
                                item.TagType = currentDBItem.TAGTYPES.Description;
                                item.ModelName = itemStatus.ModelName;
                                item.ProjectID = project.ProjectID;
                                addedItems = true;
                                _context.DELETEDITEMSLISTCHECKS.Add(item);
                            }
                        }
                    }
                }
                if (addedItems)
                    await _context.SaveChangesAsync();


                //var notProcessd = ModelConnectionResults.GetNotProcessedMainItems(mainItems);
                //if (notProcessd != null && notProcessd.Count > 0)
                //{
                //    var itemsNotFond = ModelConnectionResults.GetItemsNotFound(user.USERID.Value, projectId);
                //    if (itemsNotFond != null && itemsNotFond.Count > 0)
                //    {
                //        _context.DELETEDITEMSLISTCHECKS.AddRange(itemsNotFond);
                //        await _context.SaveChangesAsync();
                //    }
                //}

                //// Save not found Items
                //var existingItemDeletes = await _context.DELETEDITEMSLISTCHECKS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                //if (existingItemDeletes != null && existingItemDeletes.Count > 0)
                //{
                //    _context.RemoveRange(existingItemDeletes);
                //    result = await _context.SaveChangesAsync();
                //}
                //if (!ModelConnectionResults.IsNotExistingEmpty)
                //{
                //    var itemsNotFond = ModelConnectionResults.GetItemsNotFound(user.USERID.Value, projectId);
                //    if (itemsNotFond != null && itemsNotFond.Count > 0)
                //    {
                //        _context.DELETEDITEMSLISTCHECKS.AddRange(itemsNotFond);
                //        await _context.SaveChangesAsync();
                //    }
                //}

                // Save Parameters
                var existingParameters = await _context.BIM360PARAMETERS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                if (existingParameters != null && existingParameters.Count > 0)
                {
                    _context.RemoveRange(existingParameters);
                    result = await _context.SaveChangesAsync();
                }
                if (!ModelConnectionResults.IsParametersEmpty)
                {
                    if (ModelConnectionResults.Parameters.Count > 0)
                    {
                        _context.BIM360PARAMETERS.AddRange(ModelConnectionResults.Parameters);
                        await _context.SaveChangesAsync();
                    }
                }

                //// Add file revisions
                //var existingRevisions = await _context.BIM360FILEREVISIONS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                //if (!ModelConnectionResults.FileRevisionsEmpty)
                //{
                //    ModelConnectionResults.UpdateBIM360Revisions(existingRevisions);
                //    _context.BIM360FILEREVISIONS.AddRange(ModelConnectionResults.FileRevisions);
                //    await _context.SaveChangesAsync();
                //}

                //// Remove added items from missing main items
                //bool updateDeleted = false;
                //if (ModelConnectionResults.ItemStatusList != null)
                //{
                //    foreach (var currentItem in ModelConnectionResults.ItemStatusList)
                //    {
                //        var currentDBItem = mainItems.Where(m => m.MainItemTag == currentItem.MainItemTag && m.TAGTYPES.Description == currentItem.TagType &&
                //                m.LOTS.NAME == currentItem.Lot).FirstOrDefault();
                //        if (currentDBItem != null)
                //        {
                //            if (currentDBItem.IsReplaced || currentDBItem.IsDeleted)
                //            {
                //                var itemExist = await _context.DELETEDITEMSLISTCHECKS.Where(m => m.ProjectID == project.ProjectID &&
                //                    m.MainItemTag == currentDBItem.MainItemTag && m.TagType == currentDBItem.TAGTYPES.Description &&
                //                    currentDBItem.LOTS.NAME == m.Lot).FirstOrDefaultAsync();
                //                if (itemExist == null)
                //                {
                //                    DELETEDITEMSLISTCHECKS item = new DELETEDITEMSLISTCHECKS();
                //                    item.CreationDate = DateTime.UtcNow;
                //                    item.LastModified = DateTime.UtcNow;
                //                    item.UserID = user.USERID;
                //                    item.MainItemTag = currentDBItem.MainItemTag;
                //                    if (currentDBItem.IsDeleted)
                //                        item.Status = "Deleted";
                //                    else
                //                        item.Status = "Replaced";
                //                    item.Lot = currentDBItem.LOTS.NAME;
                //                    item.TagType = currentDBItem.TAGTYPES.Description;
                //                    item.ModelName = currentDBItem.ModelName;
                //                    item.ProjectID = currentDBItem.PBS.ProjectID;
                //                    _context.DELETEDITEMSLISTCHECKS.Add(item);
                //                    updateDeleted = true;
                //                }
                //            }
                //            else
                //            {
                //                var itemExist = await _context.DELETEDITEMSLISTCHECKS.Where(m => m.ProjectID == project.ProjectID &&
                //                    m.MainItemTag == currentDBItem.MainItemTag && m.TagType == currentDBItem.TAGTYPES.Description &&
                //                    currentDBItem.LOTS.NAME == m.Lot).FirstOrDefaultAsync();
                //                if (itemExist != null)
                //                {
                //                    _context.DELETEDITEMSLISTCHECKS.Remove(itemExist);
                //                    updateDeleted = true;
                //                }
                //            }
                //        }
                //    }
                //}
                //if (updateDeleted)
                //    await _context.SaveChangesAsync();


                // Save Incorrect Files
                //var incorrectFiles = await _context.BIM360INCORRECTFILES.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                //if (incorrectFiles != null && incorrectFiles.Count > 0)
                //{
                //    _context.RemoveRange(incorrectFiles);
                //    result = await _context.SaveChangesAsync();
                //}
                ModelConnectionResults.UpdateIncorrectFiles(files, projectId);
                if (!ModelConnectionResults.IsIncorrectFilesEmpty)
                {
                    foreach (var incorrectFile in ModelConnectionResults.IncorrectFiles)
                    {
                        var existing = await _context.BIM360INCORRECTFILES.Where(i => i.ProjectID == project.ProjectID &&
                            i.ModelName == incorrectFile.ModelName && i.Version == incorrectFile.Version).ToListAsync();
                        if (existing == null || existing.Count == 0) // Add if not existing
                            _context.BIM360INCORRECTFILES.Add(incorrectFile);
                    }
                    await _context.SaveChangesAsync();
                }

                //// Save BIM360 Items
                //var modelFileStatus = await _context.BIM360ITEMSTATUS.Where(i => i.ProjectID == project.ProjectID).ToListAsync();
                //if (modelFileStatus != null && modelFileStatus.Count > 0)
                //{
                //    _context.RemoveRange(modelFileStatus);
                //    result = await _context.SaveChangesAsync();
                //}
                //if (!ModelConnectionResults.IsItemStatusEmpty)
                //{
                //    _context.BIM360ITEMSTATUS.AddRange(ModelConnectionResults.ItemStatusList);
                //    await _context.SaveChangesAsync();
                //}

            }
            catch (Exception ex)
            {
                string message = ex.Message;
                return false;
            }

            // Set Project Processing
            project.ITEMPROCESSING = 0;
            project.PROCESSINGUSERID = null;
            project.LASTUPDATEFROMFORGE = DateTime.UtcNow;
            project.LASTUPDATEUSERID = user.USERID;
            try
            {
                result = await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                ForgeLogManager.AddLog(new ForgeLog(MESSAGE_CODES.GENERIC_ERROR, ex.Message));
            }

            return true;
        }

        private async Task<bool> SaveElementsToDatabase(List<jsTreeNode> filesToProcess,
                int projectId,
                USERS user,
                Credentials credentials,
                List<string> itemTags)
        {
            List<BIM360FILES> files = new List<BIM360FILES>();
            List<string> fileNotCompleted = new List<string>();

            BIM360FILES currentFile = null;

            // Check if process is not under calculation
            var project = await _context.PROJECTS.Where(p => p.ProjectID == projectId).FirstOrDefaultAsync();
            if (project == null || (project.ITEMPROCESSING != null && project.ITEMPROCESSING.HasValue &&
                project.ITEMPROCESSING.Value > 0))
                return false;

            var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == projectId).FirstOrDefaultAsync();

            int result = 0;
            try
            {
                // Init Settings
                DatabaseCostants.InitValues(_configuration);

                // Set Project Processing
                project.ITEMPROCESSING = 1;
                project.PROCESSINGUSERID = user.USERID;
                result = await _context.SaveChangesAsync();

                var status = await _context.ENGINEERING_STATUS.ToListAsync();
                var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();

                var webRoot = _env.WebRootPath;
                string settingsFolder = _configuration.GetValue<string>("AppSettings:SettingsFolder");
                string parameterDatabaseFileName = _configuration.GetValue<string>("AppSettings:ParameterDatabase");
                var fileJson = System.IO.Path.Combine(webRoot, settingsFolder, parameterDatabaseFileName);
                ParameterDictionary parameterDictionary = null;
                using (StreamReader file = System.IO.File.OpenText(fileJson))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    parameterDictionary = (ParameterDictionary)serializer.Deserialize(file, typeof(ParameterDictionary));
                }

                string formulaDatabaseFileName = _configuration.GetValue<string>("AppSettings:FormulaDatabase");
                fileJson = System.IO.Path.Combine(webRoot, settingsFolder, formulaDatabaseFileName);
                FamilyFormulaDictionary familyFormulaDictionary = null;
                using (StreamReader file = System.IO.File.OpenText(fileJson))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    familyFormulaDictionary = (FamilyFormulaDictionary)serializer.Deserialize(file, typeof(FamilyFormulaDictionary));
                }

                string connectionString = _configuration.GetValue<string>("Oracle:ConnectionString:DefaultConnection");
                connectionString = AESService.Decrypt(connectionString);
                string procedureInserForgeItem = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItem");
                string procedureFilename = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemFILENAME");
                string procedureObjectId = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemOBJECTID");
                string procedurePropertyName = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemPROPERTYNAME");
                string procedurePropertyValue = _configuration.GetValue<string>("Oracle:ProcedureInsertForgeItemPROPERTYVALUE");

                List<ForgeItem> models = new List<ForgeItem>();
                List<ForgeItem> currentModels = new List<ForgeItem>();
                if (filesToProcess != null)
                {
                    foreach (jsTreeNode file in filesToProcess)
                    {
                        IList<jsTreeNode> versions = await GetItemVersionsForTreehub(file.id);
                        if (versions != null)
                        {
                            jsTreeNode lastVersion = versions.First<jsTreeNode>();
                            if (lastVersion != null)
                            {
                                currentFile = new BIM360FILES();
                                currentFile.PROJECTID = project.ProjectID;
                                currentFile.FILENAME = file.text;
                                currentFile.FILEVERSION = lastVersion.text;

                                if (!AlrearyContainFile(currentFile))
                                {
                                    ForgeModel forgeModel = new ForgeModel(file.text, lastVersion.text);
                                    currentModels = await forgeModel.ReadForgeItemsAsync(
                                        lastVersion.id, credentials.TokenInternal, false, connectionString,
                                        procedureInserForgeItem, procedureFilename, procedureObjectId,
                                        procedurePropertyName, procedurePropertyValue);
                                    if (currentModels != null && currentModels.Count > 0)
                                        models.AddRange(currentModels);
                                    files.Add(currentFile);
                                }
                            }
                        }
                    }
                }
                SecondaryItemDatabase secondaryItemDatabase = new SecondaryItemDatabase(models, parameterDictionary, familyFormulaDictionary);
                secondaryItemDatabase.SaveToDatabase(
                    mainItems,
                    status,
                    projectId,
                    user,
                    itemTags,
                    _context,
                    projectSettings,
                    ref fileNotCompleted);
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                return false;
            }

            result = await _context.SaveChangesAsync();

            // Add Process files
            if (files != null && files.Count > 0)
            {
                bool added = false;
                foreach (BIM360FILES file in files)
                {
                    if (!fileNotCompleted.Contains(file.FILENAME))
                    {
                        _context.BIM360FILES.Add(file);
                        added = true;
                    }
                }
                if (added)
                    await _context.SaveChangesAsync();
            }


            // Set Project Processing
            project.ITEMPROCESSING = 0;
            project.PROCESSINGUSERID = null;
            project.LASTUPDATEFROMFORGE = DateTime.UtcNow;
            project.LASTUPDATEUSERID = user.USERID;
            result = await _context.SaveChangesAsync();

            return true;
        }

        private bool AlrearyContainFile(BIM360FILES file)
        {
            if (_context.BIM360FILES != null)
            {
                foreach (BIM360FILES currentFile in _context.BIM360FILES)
                    if (currentFile.IsEqual(file))
                        return true;
            }
            return false;
        }

        [HttpPost]
        public async Task<ExcelLogManager> CreateMainItems(string code,
            string itemTagStr,
            string tagTypesStr,
            string lotStr)
        {
            ExcelLogManager logManager = new ExcelLogManager();
            bool someItemsNotCreated = false;
            int totalItems = 0;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    DatabaseCostants.InitValues(_configuration);

                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        logManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                        return logManager;
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        logManager.Result = _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                        return logManager;
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);

                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    if (project == null)
                    {
                        logManager.Result = _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                        return logManager;
                    }

                    var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var objectCodes = await _context.OBJECTCODES.Where(o => o.ProjectID == project.ProjectID).ToListAsync();
                    var materialGroups = await _context.MATERIALWORKGROUPS.ToListAsync();

                    string[] itemTagList = Utils.SplitText(itemTagStr);
                    string[] tagTypesList = Utils.SplitText(tagTypesStr);
                    string[] lots = Utils.SplitText(lotStr);

                    string defaultLotStr = _configuration.GetValue<string>("Items:DefaultLotName");

                    var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var lotList = await _context.LOTS.Where(w => w.ProjectID == project.ProjectID).ToListAsync();
                    var defaultLot = lotList.Where(w => w.NAME == defaultLotStr && w.ProjectID == project.ProjectID).FirstOrDefault();

                    int result = -1;
                    List<MAINITEMS> itemsAdded = new List<MAINITEMS>();

                    for (int i = 0; i < itemTagList.Length; i++)
                    {
                        // Check if exist
                        var mainItemSearch = await _context.MAINITEMS.Include(m => m.PBS)
                            .Include(m => m.LOTS)
                            .Include(m => m.TAGTYPES)
                            .Where(b => b.PBS.ProjectID == project.ProjectID &&
                                b.MainItemTag == itemTagList[i] && b.LOTS.NAME == lots[i] &&
                                tagTypesList[i] == b.TAGTYPES.Description).FirstOrDefaultAsync();
                        if (mainItemSearch != null)
                        {
                            if (mainItemSearch.IsDeleted)
                                logManager.AddLog(i, 1, "Main item deleted " + itemTagList[i] + "-" + tagTypesList[i]);
                            else if (mainItemSearch.IsReplaced)
                                logManager.AddLog(i, 1, "Main item replaced " + itemTagList[i] + "-" + tagTypesList[i]);
                            else
                                logManager.AddLog(i, 1, "Main item existing " + itemTagList[i] + "-" + tagTypesList[i]);
                            continue;
                        }

                        BIM360ITEMSTATUS itemStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                            b.MainItemTag == itemTagList[i] && b.Lot == lots[i] && tagTypesList[i] == b.TagType).FirstOrDefaultAsync();
                        if (itemStatus == null)
                            continue;

                        //bool exist = true;
                        //if (itemStatus.MatchItem == BIM360ItemCostants.ITEM_NO_MATCH)
                        //    exist = false;
                        //if (exist)
                        //    continue;

                        string objectCodeStr = itemStatus.ObjectCode;
                        string material = itemStatus.Material;
                        string wp = itemStatus.WP;


                        string unit = itemStatus.Unit;
                        if (itemStatus.TagType == DatabaseCostants.TagType_Steel_Name)
                            unit = itemStatus.CWA;
                        string ca = itemStatus.CA;
                        string cwa = itemStatus.CWA;
                        string discipline = itemStatus.DAS;

                        var objectCode = objectCodes.Where(o => o.Code == objectCodeStr).FirstOrDefault();
                        if (itemStatus.TagType == DatabaseCostants.TagType_Steel_Name)
                        {
                            List<string> values = itemStatus.MainItemTag.Split("-").ToList();
                            if (values != null && values.Count > 1)
                            {
                                string currentCode = values[1];
                                foreach (var objCode in objectCodes)
                                {
                                    if (currentCode.StartsWith(objCode.Code))
                                        objectCode = objCode;
                                }
                            }
                        }
                        var materialGroup = materialGroups.Where(m => m.GroupCode == material).FirstOrDefault();
                        if (itemStatus.TagType == DatabaseCostants.TagType_Steel_Name)
                        {
                            materialGroup = materialGroups.Where(m => m.GroupID == DatabaseCostants.MaterialWorkGroup_Steel_ID).FirstOrDefault();
                        }
                        var currentTagType = await _context.TAGTYPES.Where(t => t.Description == tagTypesList[i]).FirstOrDefaultAsync();

                        if (String.IsNullOrEmpty(unit))
                        {
                            logManager.AddLog(i, 1, "Main item unit not valid " + itemTagList[i] + "-" + tagTypesList[i]);
                            someItemsNotCreated = true;
                            continue;
                        }
                        if (string.IsNullOrEmpty(ca) || objectCode == null || materialGroup == null)
                        {
                            logManager.AddLog(i, 1, "Main item ca not valid " + itemTagList[i] + "-" + tagTypesList[i]);
                            someItemsNotCreated = true;
                            continue;
                        }
                        if (objectCode == null)
                        {
                            logManager.AddLog(i, 1, "Main item object code not valid " + itemTagList[i] + "-" + tagTypesList[i]);
                            someItemsNotCreated = true;
                            continue;
                        }
                        if (materialGroup == null)
                        {
                            logManager.AddLog(i, 1, "Main item material group not valid " + itemTagList[i] + "-" + tagTypesList[i]);
                            someItemsNotCreated = true;
                            continue;
                        }

                        // Search for PBS
                        PBS currentPbs = await _context.PBS.Where(p => p.Unit.ToUpperInvariant() == unit.ToUpperInvariant() &&
                            p.Area.ToUpperInvariant() == ca.ToUpperInvariant() && p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                        // Create lot
                        LOTS currentLot = null;
                        if (string.IsNullOrEmpty(lots[i]))
                            currentLot = defaultLot;
                        else
                        {
                            currentLot = lotList.Where(l => l.NAME.ToUpperInvariant() == lots[i].ToUpperInvariant()).FirstOrDefault();
                            if (currentLot == null) // Add lot
                            {
                                currentLot = new LOTS();
                                currentLot.ProjectID = project.ProjectID;
                                currentLot.CreationDate = DateTime.UtcNow;
                                currentLot.LastModified = DateTime.UtcNow;
                                currentLot.NAME = lots[i];
                                currentLot.UserID = user.USERID;
                                _context.LOTS.Add(currentLot);
                                await _context.SaveChangesAsync();
                            }
                        }

                        if (currentPbs == null) // Try to create PBS
                        {
                            bool pbsCreated = await AddPBS(project, projectSettings, user, unit, ca, false, cwa, 0.0, string.Empty);
                            currentPbs = await _context.PBS.Where(p => p.Unit.ToUpperInvariant() == unit.ToUpperInvariant() &&
                                p.Area.ToUpperInvariant() == ca.ToUpperInvariant() && p.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                        }
                        if (currentPbs != null)
                        {
                            // Create Main Item
                            var currentMainItem = await _context.MAINITEMS.Where(it => it.PBSID == currentPbs.PBSID &&
                                it.MainItemTag.ToUpperInvariant() == itemTagList[i].ToUpperInvariant() &&
                                it.TagTypeID == currentTagType.TagTypeID && it.LOTSID.Value == currentLot.IDLOT).FirstOrDefaultAsync();
                            var missingMainItem = await _context.MISSING_MAINITEMS.Where(it => it.ProjectID == project.ProjectID &&
                                it.MainItemTag.ToUpperInvariant() == itemTagList[i].ToUpperInvariant() &&
                                it.TagType == currentTagType.Description && it.Lot == currentLot.NAME).FirstOrDefaultAsync();
                            //var wpItem = await _context.WORKINGPACKAGES.Where(w => w.NAME == wp && w.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                            //if (wpItem == null)
                            //{
                            //    if (!string.IsNullOrEmpty(wp))
                            //    {
                            //        WORKINGPACKAGES wpNew = new WORKINGPACKAGES();
                            //        wpNew.CreationDate = DateTime.UtcNow;
                            //        wpNew.LastModified = DateTime.UtcNow;
                            //        wpNew.UserID = user.USERID;
                            //        wpNew.NAME = wp;
                            //        wpNew.NOTES = "Created from Model Connector";
                            //        wpNew.ProjectID = project.ProjectID;
                            //        _context.WORKINGPACKAGES.Add(wpNew);
                            //        await _context.SaveChangesAsync();
                            //        wpItem = wpNew;
                            //    }
                            //}

                            if (currentMainItem == null)
                            {
                                MAINITEMS item = new MAINITEMS();
                                item.PBS = currentPbs;
                                item.PBSID = currentPbs.PBSID;
                                item.TAGTYPES = currentTagType;
                                item.TagTypeID = currentTagType.TagTypeID;
                                item.MainItemTag = itemTagList[i];
                                item.TagDescription = string.Empty;
                                item.TagClient = string.Empty;
                                item.AddedManually = 0;
                                item.AddedFromBIM360 = 1;
                                item.ModelName = missingMainItem.Filename;
                                //item.WORKINGPACKAGESID = wpItem?.IDWP;
                                item.WORKINGPACKAGESID = null;
                                item.LV01_Object_CodeID = objectCode.CodeID;
                                item.LV01_Material_Work_GroupID = materialGroup.GroupID;
                                item.BALANCE = 0;
                                item.LOTSID = currentLot.IDLOT;
                                item.MAINITEMSTATUSID = MainItemsCostants.NONE;

                                // Set User and Date
                                item.UserID = user.USERID;
                                item.CreationDate = DateTime.UtcNow;
                                item.LastModified = DateTime.UtcNow;

                                _context.MAINITEMS.Add(item);
                                result = _context.SaveChanges();

                                if (result > 0)
                                {
                                    itemsAdded.Add(item);
                                    missingMainItem.Created = 1;
                                    itemStatus.MatchItem = BIM360ItemCostants.ITEM_NEW_MATCH;

                                    logManager.AddLog(i, 0, "Main item created " + itemTagList[i] + "-" + tagTypesList[i]);

                                    result = _context.SaveChanges();
                                    totalItems++;
                                }
                                else
                                {
                                    logManager.AddLog(i, 1, "Main item not created " + itemTagList[i] + "-" + tagTypesList[i]);
                                }
                            }
                        }
                    }

                    PLANNINGS pLANNINGS = null;
                    MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                    MAINITEMDRAWINGS mainItemDrawing = null;

                    if (itemsAdded.Count > 0)
                    {
                        try
                        {
                            HOLDS mainItemHold = null;
                            int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                            int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

                            foreach (MAINITEMS item in itemsAdded)
                            {
                                // Add empty planning
                                pLANNINGS = new PLANNINGS();
                                pLANNINGS.MainItemId = item.MainItemID;
                                pLANNINGS.UserID = user.USERID;
                                pLANNINGS.CreationDate = DateTime.UtcNow;
                                pLANNINGS.LastModified = DateTime.UtcNow;
                                _context.PLANNINGS.Add(pLANNINGS);

                                mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                if (item.BALANCE.HasValue && item.BALANCE.Value > 0)
                                {
                                    // Continue
                                }
                                else
                                {
                                    mainItemDrawing = new MAINITEMDRAWINGS();
                                    mainItemDrawing.UserID = user.USERID;
                                    mainItemDrawing.CreationDate = DateTime.UtcNow;
                                    mainItemDrawing.LastModified = DateTime.UtcNow;
                                    mainItemDrawing.MainItemID = item.MainItemID;
                                    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                }

                                //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);
                                //_context.HOLDS.Add(mainItemHold);
                            }
                            result = _context.SaveChanges();

                        }
                        catch (Exception ex)
                        {
                            logManager.Result = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED, ex.Message);
                            return logManager;
                        }
                    }

                    if (logManager.Logs.Count > 0 && logManager.Logs.Where(l => l.ColumnName == "1").ToList().Count > 0)
                    {
                        logManager.Result = "Completed with errors";
                    }
                    else
                    {
                        logManager.Result = "Completed";
                    }
                }
                catch (Exception ex)
                {
                    logManager.Result = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                logManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return logManager;
        }

        private async Task<bool> UpdateMissingModels(int projectId, int userid)
        {
            var mainItemsDB = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.TAGTYPES)
                .Where(m => m.PBS.ProjectID == projectId &&
                !m.IsDeleted && !m.IsReplaced && !m.IsBalance).ToListAsync();
            var mainItemsModel = await _context.BIM360ITEMSTATUS.Where(m => m.ProjectID == projectId).ToListAsync();

            var items = await _context.ITEMSLISTCHECKS.Where(p => p.MainItem.PBS.ProjectID == projectId).ToListAsync();
            if (items != null && items.Count > 0)
            {
                _context.RemoveRange(items);
                await _context.SaveChangesAsync();
            }

            if (mainItemsDB != null && mainItemsDB.Count > 0)
            {
                bool found = false;
                bool added = false;
                foreach (MAINITEMS mainItem in mainItemsDB)
                {
                    found = false;
                    if (mainItemsModel != null)
                    {
                        var modelItem = mainItemsModel.Where(b => b.MainItemTag == mainItem.MainItemTag &&
                            b.Lot == mainItem.LOTS.NAME && b.TagType == mainItem.TAGTYPES.Description &&
                            b.ProjectID == mainItem.PBS.ProjectID).FirstOrDefault();
                        found = modelItem != null;
                    }
                    if (!found)
                    {
                        ITEMSLISTCHECKS item = new ITEMSLISTCHECKS();
                        item.MainItemID = mainItem.MainItemID;
                        item.ModelName = string.Empty;

                        // Set User and Date
                        item.UserID = userid;
                        item.CreationDate = DateTime.UtcNow;
                        item.LastModified = DateTime.UtcNow;

                        _context.Add(item);
                        added = true;
                    }
                }
                if (added)
                    await _context.SaveChangesAsync();
            }
            return true;
        }

        private async Task<bool> UpdateDeletedModels(int projectId, int userid)
        {
            var mainItemsDB = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.TAGTYPES)
                .Where(m => m.PBS.ProjectID == projectId &&
                (m.IsDeleted || m.IsReplaced) && !m.IsBalance).ToListAsync();
            var mainItemsModel = await _context.BIM360ITEMSTATUS.Where(m => m.ProjectID == projectId).ToListAsync();

            var items = await _context.DELETEDITEMSLISTCHECKS.Where(p => p.ProjectID == projectId).ToListAsync();
            if (items != null && items.Count > 0)
            {
                _context.RemoveRange(items);
                await _context.SaveChangesAsync();
            }

            if (mainItemsDB != null && mainItemsDB.Count > 0)
            {
                bool found = false;
                bool added = false;
                foreach (BIM360ITEMSTATUS mainItemBIM360 in mainItemsModel)
                {
                    found = false;
                    MAINITEMS mainItem = null;
                    if (mainItemsDB != null)
                    {
                        mainItem = mainItemsDB.Where(b => mainItemBIM360.MainItemTag == b.MainItemTag &&
                            mainItemBIM360.Lot == b.LOTS.NAME && mainItemBIM360.TagType == b.TAGTYPES.Description &&
                            mainItemBIM360.ProjectID == b.PBS.ProjectID).FirstOrDefault();
                        found = mainItem != null;
                    }
                    if (found)
                    {
                        DELETEDITEMSLISTCHECKS item = new DELETEDITEMSLISTCHECKS();
                        item.CreationDate = DateTime.UtcNow;
                        item.LastModified = DateTime.UtcNow;
                        item.UserID = userid;
                        item.MainItemTag = mainItem.MainItemTag;
                        if (mainItem.IsDeleted)
                            item.Status = "Deleted";
                        else
                            item.Status = "Replaced";
                        item.Lot = mainItem.LOTS.NAME;
                        item.TagType = mainItem.TAGTYPES.Description;
                        item.ModelName = mainItemBIM360.ModelName;
                        item.ProjectID = mainItem.PBS.ProjectID;
                        _context.DELETEDITEMSLISTCHECKS.Add(item);

                        _context.Add(item);
                        added = true;
                    }
                }
                if (added)
                    await _context.SaveChangesAsync();
            }
            return true;
        }

        private async Task<bool> AddPBS(
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            USERS user,
            string unit,
            string area,
            bool autoCWA,
            string cwa,
            double areasize,
            string areadescription)
        {
            PBS pBS = new PBS();
            pBS.Area = area;
            pBS.Unit = unit;
            pBS.ProjectID = project.ProjectID;
            pBS.AreaValue = areasize;
            pBS.AreaDescription = areadescription;
            pBS.AutoCWA = autoCWA;
            pBS.CWA = cwa;

            pBS.UpdateValues(projectSettings, user);

            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
            string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

            var lotDefault = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameDefault).FirstOrDefaultAsync();
            var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
            var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
            var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

            var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();

            using (var dbContextTransaction = _context.Database.BeginTransaction())
            {
                try
                {
                    // Set user and creation date
                    pBS.UserID = user.USERID;
                    pBS.USERS = user;
                    pBS.CreationDate = DateTime.UtcNow;
                    pBS.LastModified = DateTime.UtcNow;

                    _context.PBS.Add(pBS);
                    await _context.SaveChangesAsync();

                    // Add PBS drawing
                    PBSDRAWINGS pbsDrawing = new PBSDRAWINGS();
                    pbsDrawing.PBSID = pBS.PBSID;
                    pbsDrawing.UserID = user.USERID;
                    pbsDrawing.CreationDate = DateTime.UtcNow;
                    pbsDrawing.LastModified = DateTime.UtcNow;
                    _context.PBSDRAWINGS.Add(pbsDrawing);
                    await _context.SaveChangesAsync();

                    // Create a Balance Main Item for Every Tag Types
                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    bool added = false;
                    if (tagTypes != null)
                    {
                        PLANNINGS pLANNINGS = null;
                        STEELPLANNINGS steelPlanning = null;
                        MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                        STEEL_QUANTITIES steelQty = null;
                        STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

                        HOLDS mainItemHold = null;
                        int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                        int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

                        foreach (TAGTYPES tagtype in tagTypes)
                        {
                            if (tagtype.VALIDFORMAINITEMS > 0)
                            {
                                MAINITEMS mainItem = new MAINITEMS();
                                mainItem.MainItemTag = projectSettings.GetBalanceMainItemTag(pBS.Area);
                                mainItem.TagTypeID = tagtype.TagTypeID;
                                mainItem.TagDescription = projectSettings.BALANCE;
                                mainItem.TagClient = projectSettings.BALANCE;
                                mainItem.PBSID = pBS.PBSID;
                                mainItem.UserID = user.USERID;
                                mainItem.USERS = user;
                                mainItem.CreationDate = DateTime.UtcNow;
                                mainItem.LastModified = DateTime.UtcNow;
                                mainItem.AddedManually = 0;
                                mainItem.BALANCE = 1;
                                mainItem.MAINITEMSTATUSID = MainItemsCostants.NONE;

                                if (tagtype.TagTypeID == tagTypeSteel)
                                {
                                    mainItem.VENDORSID = vendor.IDVENDOR;
                                    mainItem.MATERIALREQUESTSID = mr.IDMR;
                                    mainItem.PURCHASEORDERSID = po.IDPO;
                                    mainItem.LOTSID = lotDefault.IDLOT;
                                }
                                else
                                {
                                    mainItem.LOTSID = lotDefault.IDLOT;
                                }
                                _context.MAINITEMS.Add(mainItem);


                                int result = _context.SaveChanges(true);
                                var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == mainItem.MainItemTag && m.PBSID == pBS.PBSID);

                                // Add parameter if existing
                                if (parameters != null && parameters.Count > 0)
                                {
                                    foreach (MAINITEMPARAMETERS parameter in parameters)
                                    {
                                        MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                        mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                        mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                        mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                        mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                                        mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                        _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                    }
                                    await _context.SaveChangesAsync();
                                }

                                // Add empty planning
                                pLANNINGS = new PLANNINGS();
                                pLANNINGS.MainItemId = mainItem.MainItemID;
                                pLANNINGS.UserID = user.USERID;
                                pLANNINGS.CreationDate = DateTime.UtcNow;
                                pLANNINGS.LastModified = DateTime.UtcNow;

                                mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                _context.PLANNINGS.Add(pLANNINGS);
                                //_context.HOLDS.Add(mainItemHold);
                                _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                added = true;

                                //if (tagtype.TagTypeID != tagTypeSteel)
                                //{

                                //    // Add empty planning
                                //    pLANNINGS = new PLANNINGS();
                                //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                //    pLANNINGS.UserID = user.USERID;
                                //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                //    pLANNINGS.LastModified = DateTime.UtcNow;

                                //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                //    //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                //    _context.PLANNINGS.Add(pLANNINGS);
                                //    //_context.HOLDS.Add(mainItemHold);
                                //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                //    added = true;
                                //}
                                //else
                                //{
                                //    // Add empty planning
                                //    pLANNINGS = new PLANNINGS();
                                //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                //    pLANNINGS.UserID = user.USERID;
                                //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                //    pLANNINGS.LastModified = DateTime.UtcNow;
                                //    _context.PLANNINGS.Add(pLANNINGS);

                                //    steelPlanning = new STEELPLANNINGS();
                                //    steelPlanning.MainItemId = mainItem.MainItemID;
                                //    steelPlanning.UserID = user.USERID;
                                //    steelPlanning.CreationDate = DateTime.UtcNow;
                                //    steelPlanning.LastModified = DateTime.UtcNow;
                                //    _context.STEELPLANNINGS.Add(steelPlanning);
                                //    added = true;

                                //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                //    steelEstimateQty.MainItemId = mainItem.MainItemID;
                                //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                //    steelEstimateQty.IFF_E_QTY = 0.0;
                                //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                //    steelEstimateQty.IFP_E_QTY = 0.0;
                                //    steelEstimateQty.PO_E_QTY = 0.0;
                                //    steelEstimateQty.UserID = user.USERID;
                                //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                                //    steelEstimateQty.LastModified = DateTime.UtcNow;
                                //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                //    if (commodities != null)
                                //    {
                                //        foreach (COMMODITYCODES code in commodities)
                                //        {
                                //            steelQty = new STEEL_QUANTITIES();
                                //            steelQty.MainItemId = mainItem.MainItemID;
                                //            steelQty.CodeId = code.CodeID;
                                //            steelQty.QTY = 0.0;
                                //            steelQty.UserID = user.USERID;
                                //            steelQty.CreationDate = DateTime.UtcNow;
                                //            steelQty.LastModified = DateTime.UtcNow;
                                //            _context.STEEL_QUANTITIES.Add(steelQty);
                                //        }
                                //    }
                                //}

                                // Add Main Item Drawing
                                MAINITEMDRAWINGS mainItemDrawing = new MAINITEMDRAWINGS();
                                mainItemDrawing.UserID = user.USERID;
                                mainItemDrawing.CreationDate = DateTime.UtcNow;
                                mainItemDrawing.LastModified = DateTime.UtcNow;
                                mainItemDrawing.MainItemID = mainItem.MainItemID;

                                _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                // Add CE Revision

                            }
                        }
                    }
                    if (added)
                    {
                        await _context.SaveChangesAsync();
                        dbContextTransaction.Commit();
                    }
                    else
                    {
                        dbContextTransaction.Rollback();
                    }
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return false;
                }
            }
            return true;
        }

        [HttpPost]
        public async Task<string> DeleteMainItems(string code,
            string tagTypesStr,
            string itemTagStr,
            string lotStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);

                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    string[] tagTypesList = Utils.SplitText(tagTypesStr);
                    string[] itemTagList = Utils.SplitText(itemTagStr);
                    string[] lotValues = Utils.SplitText(lotStr);
                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Include(m => m.LOTS).Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
                    var lots = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID).ToListAsync();

                    if (tagTypesList != null)
                    {
                        for (int i = 0; i < tagTypesList.Length; i++)
                        {
                            var mainItemModel = await _context.BIM360ITEMSTATUS.Where(m =>
                                    m.TagType == tagTypesList[i] && m.ProjectID == project.ProjectID &&
                                    m.Lot == lotValues[i] && m.MainItemTag == itemTagList[i]).FirstOrDefaultAsync();
                            bool addMissingItem = mainItemModel.Status != BIM360ItemCostants.ITEM_NO_MATCH;
                            if (mainItemModel != null)
                            {
                                _context.Remove(mainItemModel);

                                // Remove BIM360 Files
                                var bim360Files = await _context.BIM360FILES.Where(m => m.FILENAME ==
                                    mainItemModel.ModelName && m.FILEDATE.ToString("yyyy-MM-dd") == mainItemModel.ModelDate).FirstOrDefaultAsync();
                                if (bim360Files != null)
                                    _context.Remove(bim360Files);

                                // Add Missing Item
                                if (addMissingItem)
                                {
                                    var mainItem = await _context.MAINITEMS
                                        .Include(m => m.PBS)
                                        .Include(m => m.LOTS)
                                        .Include(m => m.TAGTYPES)
                                            .Where(m =>
                                                m.TAGTYPES.Description == tagTypesList[i] && m.PBS.ProjectID == project.ProjectID &&
                                                m.LOTS.NAME == lotValues[i] && m.MainItemTag == itemTagList[i]).FirstOrDefaultAsync();

                                    if (mainItem != null)
                                    {
                                        ITEMSLISTCHECKS item = new ITEMSLISTCHECKS();
                                        item.MainItemID = mainItem.MainItemID;
                                        item.ModelName = string.Empty;

                                        // Set User and Date
                                        item.UserID = user.USERID;
                                        item.CreationDate = DateTime.UtcNow;
                                        item.LastModified = DateTime.UtcNow;

                                        _context.Add(item);
                                    }
                                }
                            }
                        }
                    }

                    await _context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UnlockBim360(string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    project.ITEMPROCESSING = 0;

                    await _context.SaveChangesAsync();

                    msg = "Unlocked";
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region BIM360

        /// <summary>
        /// Get BIM360 Hubs
        /// </summary>
        /// <param name="hubName"></param>
        /// <returns></returns>
        private async Task<jsTreeNode> GetHubAsync(string hubName)
        {
            jsTreeNode hub = null;

            // the API SDK
            HubsApi hubsApi = new HubsApi();
            hubsApi.Configuration.AccessToken = Credentials.TokenInternal;

            var hubs = await hubsApi.GetHubsAsync();
            foreach (KeyValuePair<string, dynamic> hubInfo in new DynamicDictionaryItems(hubs.data))
            {
                // check the type of the hub to show an icon
                string nodeType = "hubs";
                switch ((string)hubInfo.Value.attributes.extension.type)
                {
                    case "hubs:autodesk.core:Hub":
                        nodeType = "hubs"; // if showing only BIM 360, mark this as 'unsupported'
                        break;
                    case "hubs:autodesk.a360:PersonalHub":
                        nodeType = "personalHub"; // if showing only BIM 360, mark this as 'unsupported'
                        break;
                    case "hubs:autodesk.bim360:Account":
                        nodeType = "bim360Hubs";
                        break;
                }

                // create a treenode with the values
                jsTreeNode hubNode = new jsTreeNode(hubInfo.Value.links.self.href, hubInfo.Value.attributes.name, nodeType, !(nodeType == "unsupported"));
                if (hubNode.text == hubName)
                    hub = hubNode;
            }

            return hub;
        }

        /// <summary>
        /// Get Project By Name
        /// </summary>
        /// <param name="href"></param>
        /// <param name="projectName"></param>
        /// <returns></returns>
        private async Task<jsTreeNode> GetProjectAsync(string href, string projectName)
        {
            jsTreeNode project = null;

            // the API SDK
            ProjectsApi projectsApi = new ProjectsApi();
            projectsApi.Configuration.AccessToken = Credentials.TokenInternal;

            // extract the hubId from the href
            string[] idParams = href.Split('/');
            string hubId = idParams[idParams.Length - 1];

            var projects = await projectsApi.GetHubProjectsAsync(hubId);
            foreach (KeyValuePair<string, dynamic> projectInfo in new DynamicDictionaryItems(projects.data))
            {
                // check the type of the project to show an icon
                string nodeType = "projects";
                switch ((string)projectInfo.Value.attributes.extension.type)
                {
                    case "projects:autodesk.bim360:Project":
                        nodeType = "bim360projects";
                        break;
                }

                // create a treenode with the values
                jsTreeNode projectNode = new jsTreeNode(projectInfo.Value.links.self.href, projectInfo.Value.attributes.name, nodeType, true);
                if (projectNode.text == projectName)
                    project = projectNode;
            }

            return project;
        }

        /// <summary>
        /// Get Folder By Name
        /// </summary>
        /// <param name="href"></param>
        /// <param name="folderName"></param>
        /// <returns></returns>
        private async Task<jsTreeNode> GetFolder(string href, string folderName)
        {
            jsTreeNode folderNodes = null;

            // the API SDK
            ProjectsApi projectApi = new ProjectsApi();
            projectApi.Configuration.AccessToken = Credentials.TokenInternal;

            // extract the projectId & folderId from the href
            string[] idParams = href.Split('/');
            string hubId = idParams[idParams.Length - 3];
            string projectId = idParams[idParams.Length - 1];

            var folders = await projectApi.GetProjectTopFoldersAsync(hubId, projectId);
            foreach (KeyValuePair<string, dynamic> folder in new DynamicDictionaryItems(folders.data))
            {
                jsTreeNode node = new jsTreeNode(folder.Value.links.self.href, folder.Value.attributes.displayName, "folders", true);
                if (node.text.ToUpper() == folderName.ToUpper())
                    folderNodes = node;
            }
            return folderNodes;
        }

        private async Task<jsTreeNode> GetFirstLevelFolders(string baseFolderId, string folderToSearch)
        {
            // Get folder inside project
            IList<jsTreeNode> nodesToProcess = await GetFolderContents(baseFolderId);
            jsTreeNode node = null;
            if (nodesToProcess != null)
            {
                for (int i = 0; i < nodesToProcess.Count; i++)
                {
                    node = nodesToProcess[i];
                    if (IsFolder(node) && node.text.ToUpper() == folderToSearch.ToUpper())
                        return node;
                }
            }
            return null;
        }

        /// <summary>
        /// Search a folder by name starting from the root
        /// </summary>
        /// <param name="id"></param>
        /// <param name="rootFolder">Starting folder name</param>
        /// <param name="folderToSearch">Name of the folder to search</param>
        /// <returns></returns>
        private async Task<jsTreeNode> GetFolders(string id, string rootFolder, string folderToSearch)
        {
            // Get folder inside project
            IList<jsTreeNode> nodesToProcess = await GetFolderContents(id);
            jsTreeNode node = null;
            bool containFolder = true;
            while (containFolder)
            {
                for (int i = 0; i < nodesToProcess.Count; i++)
                {
                    node = nodesToProcess[i];
                    if (IsFolder(node) && node.text.ToUpper() == rootFolder.ToUpper())
                    {
                        IList<jsTreeNode> folderToAdd = await GetFolderContents(node.id);
                        if (folderToAdd != null && folderToAdd.Count > 0)
                        {
                            foreach (jsTreeNode f in folderToAdd)
                            {
                                if (f.text.ToUpper() == folderToSearch.ToUpper())
                                    return f;
                            }
                        }
                    }
                }
                if (nodesToProcess.Count == 0)
                    containFolder = false;
            }
            return null;
        }

        /// <summary>
        /// Check if node is a folder
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public bool IsFolder(jsTreeNode element)
        {
            return element != null && element.type == "folders";
        }

        /// <summary>
        /// Get All Item Versions
        /// </summary>
        /// <param name="href"></param>
        /// <returns></returns>
        private async Task<IList<jsTreeNode>> GetItemVersionsForTreehub(string href)
        {
            IList<jsTreeNode> nodes = new List<jsTreeNode>();

            // the API SDK
            ItemsApi itemApi = new ItemsApi();
            itemApi.Configuration.AccessToken = Credentials.TokenInternal;

            // extract the projectId & itemId from the href
            string[] idParams = href.Split('/');
            string itemId = idParams[idParams.Length - 1];
            string projectId = idParams[idParams.Length - 3];

            var versions = await itemApi.GetItemVersionsAsync(projectId, itemId);
            foreach (KeyValuePair<string, dynamic> version in new DynamicDictionaryItems(versions.data))
            {
                DateTime versionDate = version.Value.attributes.lastModifiedTime;
                string verNum = version.Value.id.Split("=")[1];
                string userName = version.Value.attributes.lastModifiedUserName;

                string urn = string.Empty;
                try { urn = (string)version.Value.relationships.derivatives.data.id; }
                catch { urn = Base64Encode(version.Value.id); } // some BIM 360 versions don't have viewable

                jsTreeNode node = new jsTreeNode(
                    urn,
                    string.Format("v{0}: {1} by {2}", verNum, versionDate.ToString("dd/MM/yy HH:mm:ss"), userName),
                    "versions",
                    false);
                nodes.Add(node);
            }

            return nodes;
        }

        /// <summary>
        /// Encoding
        /// </summary>
        /// <param name="plainText"></param>
        /// <returns></returns>
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes).Replace("/", "_");
        }

        /// <summary>
        /// Get All Nodes inside a folder
        /// </summary>
        /// <param name="href"></param>
        /// <returns></returns>
        private async Task<IList<jsTreeNode>> GetFolderContents(string href)
        {
            IList<jsTreeNode> nodes = new List<jsTreeNode>();

            // the API SDK
            FoldersApi folderApi = new FoldersApi();
            folderApi.Configuration.AccessToken = Credentials.TokenInternal;

            // extract the projectId & folderId from the href
            string[] idParams = href.Split('/');
            string folderId = idParams[idParams.Length - 1];
            string projectId = idParams[idParams.Length - 3];

            // check if folder specifies visible types
            JArray visibleTypes = null;
            dynamic folder = (await folderApi.GetFolderAsync(projectId, folderId)).ToJson();
            if (folder.data.attributes != null && folder.data.attributes.extension != null && folder.data.attributes.extension.data != null && !(folder.data.attributes.extension.data is JArray) && folder.data.attributes.extension.data.visibleTypes != null)
                visibleTypes = folder.data.attributes.extension.data.visibleTypes;

            var folderContents = await folderApi.GetFolderContentsAsync(projectId, folderId);
            // the GET Folder Contents has 2 main properties: data & included (not always available)
            var folderData = new DynamicDictionaryItems(folderContents.data);
            var folderIncluded = (folderContents.Dictionary.ContainsKey("included") ? new DynamicDictionaryItems(folderContents.included) : null);

            // let's start iterating the FOLDER DATA
            foreach (KeyValuePair<string, dynamic> folderContentItem in folderData)
            {
                // do we need to skip some items? based on the visibleTypes of this folder
                string extension = folderContentItem.Value.attributes.extension.type;
                if (extension.IndexOf("Folder") /*any folder*/ == -1 && visibleTypes != null && !visibleTypes.ToString().Contains(extension)) continue;

                // if the type is items:autodesk.bim360:Document we need some manipulation...
                if (extension.Equals("items:autodesk.bim360:Document"))
                {
                    // as this is a DOCUMENT, lets interate the FOLDER INCLUDED to get the name (known issue)
                    foreach (KeyValuePair<string, dynamic> includedItem in folderIncluded)
                    {
                        // check if the id match...
                        if (includedItem.Value.relationships.item.data.id.IndexOf(folderContentItem.Value.id) != -1)
                        {
                            // found it! now we need to go back on the FOLDER DATA to get the respective FILE for this DOCUMENT
                            foreach (KeyValuePair<string, dynamic> folderContentItem1 in folderData)
                            {
                                if (folderContentItem1.Value.attributes.extension.type.IndexOf("File") == -1) continue; // skip if type is NOT File

                                // check if the sourceFileName match...
                                if (folderContentItem1.Value.attributes.extension.data.sourceFileName == includedItem.Value.attributes.extension.data.sourceFileName)
                                {
                                    // ready!

                                    // let's return for the jsTree with a special id:
                                    // itemUrn|versionUrn|viewableId
                                    // itemUrn: used as target_urn to get document issues
                                    // versionUrn: used to launch the Viewer
                                    // viewableId: which viewable should be loaded on the Viewer
                                    // this information will be extracted when the user click on the tree node, see ForgeTree.js:136 (activate_node.jstree event handler)
                                    string treeId = string.Format("{0}|{1}|{2}",
                                        folderContentItem.Value.id, // item urn
                                        Base64Encode(folderContentItem1.Value.relationships.tip.data.id), // version urn
                                        includedItem.Value.attributes.extension.data.viewableId // viewableID
                                    );
                                    nodes.Add(new jsTreeNode(treeId, WebUtility.UrlDecode(includedItem.Value.attributes.name), "bim360documents", false));
                                }
                            }
                        }
                    }
                }
                else
                {
                    // non-Plans folder items
                    //if (folderContentItem.Value.attributes.hidden == true) continue;
                    nodes.Add(new jsTreeNode(folderContentItem.Value.links.self.href, folderContentItem.Value.attributes.displayName, (string)folderContentItem.Value.type, true));
                }
            }

            return nodes;
        }

        /// <summary>
        /// Get All Files From Folder
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private async Task<List<jsTreeNode>> GetFilesFromFolder(string id)
        {
            List<jsTreeNode> bim360Files = new List<jsTreeNode>();

            // Get folder inside project
            List<jsTreeNode> folders = null;
            IList<jsTreeNode> nodesToProcess = await GetFolderContents(id);
            jsTreeNode node = null;
            bool containFolder = true;
            while (containFolder)
            {
                folders = new List<jsTreeNode>();
                for (int i = 0; i < nodesToProcess.Count; i++)
                {
                    node = nodesToProcess[i];
                    if (!IsFolder(node))
                    {
                        bim360Files.Add(node);
                    }
                    else
                    {
                        IList<jsTreeNode> folderToAdd = await GetFolderContents(node.id);
                        if (folderToAdd != null && folderToAdd.Count > 0)
                        {
                            foreach (jsTreeNode f in folderToAdd)
                                f.folder += node.folder + "\\" + node.text;
                            folders.AddRange(folderToAdd);
                        }
                    }
                }
                nodesToProcess = folders;
                if (nodesToProcess.Count == 0)
                    containFolder = false;
            }
            return bim360Files;
        }
        #endregion
    }
}