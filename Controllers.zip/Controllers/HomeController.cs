﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using Microsoft.AspNetCore.Http;
using CivilMasterData.Models.Services;
using CivilMasterData.Data;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CivilMasterData.Controllers
{
    public class HomeController : Controller
    {
        private const double MAX_SECONDS = 900;
        private readonly HomeContext _context;
        private IConfiguration _configuration;

        public HomeController(HomeContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            
            return View();
        }
        
        public IActionResult NoPermission()
        {
            return View();
        }
        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> LoginUser(USERS user)
        {
            TokenProvider _tokenProvider = new TokenProvider();

            string tokenServer = _configuration.GetValue<string>("AppSettings:TokenURLIssuer");
            tokenServer = AESService.Decrypt(tokenServer);
            //Authenticate user
            var userToken = await _tokenProvider.LoginUser(user.USERNAME.Trim(), user.PASSWORD.Trim(), _context, tokenServer);
            if (userToken != null)
            {
                //Save token in session object
                HttpContext.Session.SetString("JWToken", userToken);
            }
            return Redirect("~/Home/Index");
        }

        public ActionResult Logoff()
        {
            // return a request for an HTTP basic auth token, this will cause XmlHttp to pass the new header
            this.Response.StatusCode = 401;
            this.Response.Headers.Append("WWW-Authenticate", "basic realm=\"My Realm\"");

            return Content("Force AJAX component to sent header");
        }

        public async Task<List<ACTIVEUSERS>> GetActiveUsers()
        {
            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return null;

            List<ACTIVEUSERS> users = await _context.ACTIVEUSERS.ToListAsync();
            DateTime now = DateTime.Now;
            List<ACTIVEUSERS> activeUsers = new List<ACTIVEUSERS>();
            if (users != null)
            {
                for (int i = 0; i < users.Count; i++)
                {
                    if (users[i].Username != name)
                    {
                        if (users[i].LoginDate != null && users[i].LoginDate.HasValue)
                        {
                            TimeSpan ts = users[i].LoginDate.Value - now;
                            if (System.Math.Abs(ts.TotalSeconds) <= MAX_SECONDS)
                                activeUsers.Add(users[i]);
                        }
                    }
                }
            }

            return activeUsers;
        }
    }
}
