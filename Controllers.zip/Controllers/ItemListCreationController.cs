﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Models;
using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.BIM360.Parameters;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Helpers;
using CivilMasterData.Models.Logs;
using CivilMasterData.Models.MainItems;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OfficeOpenXml;

namespace CivilMasterData.Controllers
{
    public class ItemListCreationController : Controller
    {
        private readonly ItemListCreationContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public ItemListCreationController(ItemListCreationContext context,
            IWebHostEnvironment env,
            ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            _env = env;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            var materials = await _context.MATERIALWORKGROUPS.ToListAsync();
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).OrderBy(p => p.Code).ToListAsync();
            var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(w => w.ProjectID == project.ProjectID).ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(x => x.LOTS).
                Include(x => x.WORKINGPACKAGES).
                Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();
            if (mainItems != null)
                mainItems = mainItems.OrderBy(m => m.TagTypeID).ThenBy(m => m.MainItemTag).ToList();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            // Update Main Items Replaced or combined
            List<MAINITEMS> itemsWithChilds = new List<MAINITEMS>();
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                        {
                            item.PARENT_TAG = parent.MainItemTag;
                            itemsWithChilds.Add(parent);
                        }
                    }
                }
            }
            itemsWithChilds = itemsWithChilds.GroupBy(m => m.MainItemID).Select(g => g.First()).ToList();
            if (itemsWithChilds != null && itemsWithChilds.Count > 0)
            {
                string childStr = string.Empty;
                foreach (MAINITEMS parent in itemsWithChilds)
                {
                    childStr = string.Empty;
                    var childs = mainItems.Where(m => m.PARENTID != null && m.PARENTID.HasValue && m.PARENTID.Value == parent.MainItemID).ToList();
                    if (childs != null)
                    {
                        foreach (var child in childs)
                            childStr += child.MainItemTag + ";";
                        parent.PARENT_TAG = childStr;
                    }
                }
            }


            itemListCreation.Materials = materials;
            itemListCreation.ObjectCodes = objects;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;

            itemListCreation.MainItems = MainItemUtils.OrderMainitems(itemListCreation.MainItems, projectSettings.BALANCE);

            ViewBag.ItemTags = mainItems.Where(m => !m.IsBalance).Select(m => m.CompleteDescription).Distinct().ToList();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        public async Task<IActionResult> ItemsView(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            var materials = await _context.MATERIALWORKGROUPS.ToListAsync();
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).OrderBy(p => p.Code).ToListAsync();
            var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(w => w.ProjectID == project.ProjectID).ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(x => x.LOTS).
                Include(x => x.WORKINGPACKAGES).
                Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();
            if (mainItems != null)
                mainItems = mainItems.OrderBy(m => m.TagTypeID).ThenBy(m => m.MainItemTag).ToList();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            // Update Main Items Replaced or combined
            List<MAINITEMS> itemsWithChilds = new List<MAINITEMS>();
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                        {
                            item.PARENT_TAG = parent.MainItemTag;
                            itemsWithChilds.Add(parent);
                        }
                    }
                }
            }
            itemsWithChilds = itemsWithChilds.GroupBy(m => m.MainItemID).Select(g => g.First()).ToList();
            if (itemsWithChilds != null && itemsWithChilds.Count > 0)
            {
                string childStr = string.Empty;
                foreach (MAINITEMS parent in itemsWithChilds)
                {
                    childStr = string.Empty;
                    var childs = mainItems.Where(m => m.PARENTID != null && m.PARENTID.HasValue && m.PARENTID.Value == parent.MainItemID).ToList();
                    if (childs != null)
                    {
                        foreach (var child in childs)
                            childStr += child.MainItemTag + ";";
                        parent.PARENT_TAG = childStr;
                    }
                }
            }


            itemListCreation.Materials = materials;
            itemListCreation.ObjectCodes = objects;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;

            itemListCreation.MainItems = MainItemUtils.OrderMainitems(itemListCreation.MainItems, projectSettings.BALANCE);

            ViewBag.ItemTags = mainItems.Where(m => !m.IsBalance).Select(m => m.CompleteDescription).Distinct().ToList();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        public async Task<IActionResult> CivilItemsView(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            var materials = await _context.MATERIALWORKGROUPS.ToListAsync();
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).OrderBy(p => p.Code).ToListAsync();
            var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(w => w.ProjectID == project.ProjectID).ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(x => x.LOTS).
                Include(x => x.WORKINGPACKAGES).
                Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();
            if (mainItems != null)
                mainItems = mainItems.OrderBy(m => m.TagTypeID).ThenBy(m => m.MainItemTag).ToList();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            // Update Main Items Replaced or combined
            List<MAINITEMS> itemsWithChilds = new List<MAINITEMS>();
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                        {
                            item.PARENT_TAG = parent.MainItemTag;
                            itemsWithChilds.Add(parent);
                        }
                    }
                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();

                    var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                    item.PLANNINGS = planning;

                    double totalQtyHold = 0.0;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                            }
                        }
                        item.HOLDS = currentHolds;
                    }
                    item.TotalQtyHold = totalQtyHold;
                }
            }
            itemsWithChilds = itemsWithChilds.GroupBy(m => m.MainItemID).Select(g => g.First()).ToList();
            if (itemsWithChilds != null && itemsWithChilds.Count > 0)
            {
                string childStr = string.Empty;
                foreach (MAINITEMS parent in itemsWithChilds)
                {
                    childStr = string.Empty;
                    var childs = mainItems.Where(m => m.PARENTID != null && m.PARENTID.HasValue && m.PARENTID.Value == parent.MainItemID).ToList();
                    if (childs != null)
                    {
                        foreach (var child in childs)
                            childStr += child.MainItemTag + ";";
                        parent.PARENT_TAG = childStr;
                    }
                }
            }


            itemListCreation.Materials = materials;
            itemListCreation.ObjectCodes = objects;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;

            itemListCreation.MainItems = MainItemUtils.OrderMainitems(itemListCreation.MainItems, projectSettings.BALANCE);

            ViewBag.ItemTags = mainItems.Where(m => !m.IsBalance).Select(m => m.CompleteDescription).Distinct().ToList();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        // GET: MAINITEMS/Create
        public async Task<IActionResult> CreateAutomatic(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var materials = await _context.MATERIALWORKGROUPS.ToListAsync();
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).OrderBy(p => p.Code).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Materials = materials;
            itemListCreation.ObjectCodes = objects;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        // GET: MAINITEMS/Create
        public async Task<IActionResult> CreateManual(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            DatabaseCostants.InitValues(_configuration);

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "MainItemList.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:MainItemsListSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
            List<string> columnNames = ParsingUtils.ParseString(_configuration.GetValue<string>("Excel:ItemColumns"));

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsList = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.TAGTYPES)
                .Where(p => p.PBS.ProjectID == project.ProjectID)
                .OrderBy(m => m.MainItemTag)
                .ToListAsync();

            var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToList();
            if (parameters != null)
            {
                parameters = parameters.OrderBy(p => p.MAINITEMPARAMETERCATEGORIESID).ToList();
                int startIndex = columnNames.Count;
                var colBlue = System.Drawing.ColorTranslator.FromHtml("#4472C4");
                var colWhite = System.Drawing.ColorTranslator.FromHtml("#ffffff");

                foreach (var parameter in parameters)
                {
                    Sheet.Cells[startRow - 1, startIndex + 1].Value = parameter.PARAMETERNAME.ToUpperInvariant();
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Fill.BackgroundColor.SetColor(colBlue);
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Font.Color.SetColor(colWhite);
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Font.Bold = true;
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    startIndex++;
                }
            }

            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            if (mainItemsList != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItemsList)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItemsList.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }

                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();

                    var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                    item.PLANNINGS = planning;

                    double totalQtyHold = 0.0;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                            }
                        }
                        item.HOLDS = currentHolds;
                    }
                    item.TotalQtyHold = totalQtyHold;
                }

                int currentRow = startRow;
                foreach (MAINITEMS item in mainItemsList)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.LV01_Object_Code != null ? item.LV01_Object_Code.Code : null;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.LOTS != null ? item.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.WORKINGPACKAGES != null ? item.WORKINGPACKAGES.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.Status;
                    Sheet.Cells[currentRow, startColumn + 10].Value = item.EquipmentTag;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.EquipmentLayout;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.DrawNo;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.DRAWREV;
                    Sheet.Cells[currentRow, startColumn + 14].Value = item.DrawRevAcc;
                    Sheet.Cells[currentRow, startColumn + 15].Value = item.OPTRATIO;
                    Sheet.Cells[currentRow, startColumn + 16].Value = item.SubContractor;
                    Sheet.Cells[currentRow, startColumn + 17].Value = item.Remarks;
                    Sheet.Cells[currentRow, startColumn + 18].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_BUDGET : 0.0;
                    Sheet.Cells[currentRow, startColumn + 19].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_WR : 0.0;
                    Sheet.Cells[currentRow, startColumn + 20].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_IFR : 0.0;
                    Sheet.Cells[currentRow, startColumn + 21].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_IFC : 0.0;
                    Sheet.Cells[currentRow, startColumn + 22].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_ACC : 0.0;
                    Sheet.Cells[currentRow, startColumn + 23].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_NEXT_CE : 0.0;
                    Sheet.Cells[currentRow, startColumn + 24].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.QTY_REINF : 0.0;
                    Sheet.Cells[currentRow, startColumn + 25].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.CONNECTION_INDICENCE : 0.0;
                    Sheet.Cells[currentRow, startColumn + 26].Value = item.ITEM_QUANTITY != null ? item.ITEM_QUANTITY.AI_VOLUME_LAST_ISSUE : 0.0;

                    if (item.TAGTYPES.TagTypeID != DatabaseCostants.TagType_Steel_ID)
                    {
                        var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                        if (planning != null)
                        {
                            Sheet.Cells[currentRow, startColumn + 27].Value = planning.DATE_INPUT_FORE;
                            Sheet.Cells[currentRow, startColumn + 28].Value = planning.DATE_IFR_CHECK_FORE;
                            Sheet.Cells[currentRow, startColumn + 29].Value = planning.DATE_IFR_CHECK_ACTUAL;
                            Sheet.Cells[currentRow, startColumn + 30].Value = planning.DATE_IFR_FORE;
                            Sheet.Cells[currentRow, startColumn + 31].Value = planning.DATE_IFR_ACTUAL;
                            Sheet.Cells[currentRow, startColumn + 32].Value = planning.DATE_IFC_CHECK_FORE;
                            Sheet.Cells[currentRow, startColumn + 33].Value = planning.DATE_IFC_CHECK_ACTUAL;
                            Sheet.Cells[currentRow, startColumn + 34].Value = planning.DATE_IFC_FORE;
                            Sheet.Cells[currentRow, startColumn + 35].Value = planning.DATE_IFC_ACTUAL;
                        }
                    }
                    else
                    {
                    }

                    var parameterValues = await _context.MAINITEMPARAMETERVALUES.Include(m => m.MainItemParameters).Where(m => m.MainItemsID == item.MainItemID).ToListAsync();
                    if (parameterValues != null)
                    {
                        parameterValues = parameterValues.OrderBy(p => p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID).ToList();
                        int startIndex = columnNames.Count + 1;
                        foreach (var value in parameterValues)
                        {
                            if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.TextParameterID)
                                Sheet.Cells[currentRow, startIndex].Value = value.PARAMETERTEXT;
                            else if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.QuantityParameterID)
                            {
                                if (value.PARAMETERDOUBLE != null && value.PARAMETERDOUBLE.HasValue)
                                    Sheet.Cells[currentRow, startIndex].Value = value.PARAMETERDOUBLE.Value;
                            }
                            else if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.DateParameterID)
                            {
                                if (value.PARAMETERDATE != null && value.PARAMETERDATE.HasValue)
                                    Sheet.Cells[currentRow, startIndex].Value = value.PARAMETERDATE.Value.ToString("yyyy/MM/dd");
                            }
                            startIndex++;
                        }
                    }

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }


        [HttpGet]
        public async Task<ActionResult> CreateExcelItemsView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            DatabaseCostants.InitValues(_configuration);

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsViewTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "ItemsView.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:MainItemsListSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
            List<string> columnNames = ParsingUtils.ParseString(_configuration.GetValue<string>("Excel:ItemColumns"));

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsList = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.TAGTYPES)
                .Include(m => m.USERS)
                .OrderBy(m => m.MainItemTag)
                .Where(p => p.PBS.ProjectID == project.ProjectID).ToListAsync();

            var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToList();
            if (parameters != null)
            {
                parameters = parameters.OrderBy(p => p.MAINITEMPARAMETERCATEGORIESID).ToList();
                int startIndex = columnNames.Count;
                var colBlue = System.Drawing.ColorTranslator.FromHtml("#4472C4");
                var colWhite = System.Drawing.ColorTranslator.FromHtml("#ffffff");

                foreach (var parameter in parameters)
                {
                    Sheet.Cells[startRow - 1, startIndex + 1].Value = parameter.PARAMETERNAME.ToUpperInvariant();
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Fill.BackgroundColor.SetColor(colBlue);
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Font.Color.SetColor(colWhite);
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.Font.Bold = true;
                    Sheet.Cells[startRow - 1, startIndex + 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    startIndex++;
                }
            }



            if (mainItemsList != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItemsList)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItemsList.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;
                }

                int currentRow = startRow;
                foreach (MAINITEMS item in mainItemsList)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.LOTS != null ? item.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.WORKINGPACKAGES != null ? item.WORKINGPACKAGES.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.Remarks;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.Status;
                    Sheet.Cells[currentRow, startColumn + 10].Value = item.PARENT_TAG;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.EquipmentTag;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.EquipmentLayout;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.GetEngStatus;
                    Sheet.Cells[currentRow, startColumn + 14].Value = item.DrawNo;
                    Sheet.Cells[currentRow, startColumn + 15].Value = item.DRAWREV;
                    Sheet.Cells[currentRow, startColumn + 16].Value = item.DrawRevAcc;
                    Sheet.Cells[currentRow, startColumn + 17].Value = item.OPTRATIO;
                    Sheet.Cells[currentRow, startColumn + 18].Value = item.SubContractor;
                    Sheet.Cells[currentRow, startColumn + 19].Value = item.MRNO;
                    Sheet.Cells[currentRow, startColumn + 20].Value = item.ModelName;
                    Sheet.Cells[currentRow, startColumn + 21].Value = item.GetModelDate;
                    Sheet.Cells[currentRow, startColumn + 22].Value = item.LastModified != null && item.LastModified.HasValue ?
                            item.LastModified.Value.ToString("yyyy-MM-dd") : null;
                    Sheet.Cells[currentRow, startColumn + 23].Value = item.LastModifyUser;

                    if (item.TAGTYPES.TagTypeID != DatabaseCostants.TagType_Steel_ID)
                    {
                        var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                        if (planning != null)
                        {
                            Sheet.Cells[currentRow, startColumn + 27].Value = planning.DATE_INPUT_FORE;
                            Sheet.Cells[currentRow, startColumn + 28].Value = planning.DATE_IFR_CHECK_FORE;
                            Sheet.Cells[currentRow, startColumn + 29].Value = planning.DATE_IFR_CHECK_ACTUAL;
                            Sheet.Cells[currentRow, startColumn + 30].Value = planning.DATE_IFR_FORE;
                            Sheet.Cells[currentRow, startColumn + 30].Value = planning.DATE_IFR_ACTUAL;
                            Sheet.Cells[currentRow, startColumn + 31].Value = planning.DATE_IFC_CHECK_FORE;
                            Sheet.Cells[currentRow, startColumn + 32].Value = planning.DATE_IFC_CHECK_ACTUAL;
                            Sheet.Cells[currentRow, startColumn + 33].Value = planning.DATE_IFC_FORE;
                            Sheet.Cells[currentRow, startColumn + 34].Value = planning.DATE_IFC_ACTUAL;
                        }
                    }
                    else
                    {
                    }

                    var parameterValues = await _context.MAINITEMPARAMETERVALUES.Include(m => m.MainItemParameters).Where(m => m.MainItemsID == item.MainItemID).ToListAsync();
                    if (parameterValues != null)
                    {
                        parameterValues = parameterValues.OrderBy(p => p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID).ToList();
                        int startIndex = columnNames.Count + 1;
                        foreach (var value in parameterValues)
                        {
                            if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.TextParameterID)
                                Sheet.Cells[currentRow, startIndex].Value = value.PARAMETERTEXT;
                            else if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.QuantityParameterID)
                            {
                                if (value.PARAMETERDOUBLE != null && value.PARAMETERDOUBLE.HasValue)
                                    Sheet.Cells[currentRow, startIndex].Value = value.PARAMETERDOUBLE.Value;
                            }
                            else if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.DateParameterID)
                            {
                                if (value.PARAMETERDATE != null && value.PARAMETERDATE.HasValue)
                                    Sheet.Cells[currentRow, startIndex].Value = value.PARAMETERDATE.Value.ToString("yyyy/MM/dd");
                            }
                            startIndex++;
                        }
                    }

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelItemsDetailedView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            DatabaseCostants.InitValues(_configuration);

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsViewDetailedTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "CivilItems.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:MainItemsListSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
            List<string> columnNames = ParsingUtils.ParseString(_configuration.GetValue<string>("Excel:ItemColumns"));

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsList = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.TAGTYPES)
                .Include(m => m.USERS)
                .OrderBy(m => m.MainItemTag)
                .Where(p => p.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            if (mainItemsList != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItemsList)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItemsList.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }

                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                    var mtorevs = await _context.MTOREVS.Where(m => m.MAINITEMID.Value == item.MainItemID).ToListAsync();
                    item.MAIN_ITEM_QTY_REV = mtorevs;
                    item.PROJECTSETTINGS = projectSettings;

                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;

                    if (item.ITEM_QUANTITY != null)
                        item.ITEM_QUANTITY.CERevisions = await _context.MAIN_ITEM_QUANTITY_CE.Where(r => r.MainItemId == item.MainItemID).ToListAsync();

                    var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                    item.PLANNINGS = planning;

                    double totalQtyHold = 0.0;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                            }
                        }
                        item.HOLDS = currentHolds;
                    }
                    item.TotalQtyHold = totalQtyHold;
                }

                int currentRow = startRow;
                foreach (MAINITEMS item in mainItemsList)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.LOTS != null ? item.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.WORKINGPACKAGES != null ? item.WORKINGPACKAGES.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.Remarks;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.Status;
                    Sheet.Cells[currentRow, startColumn + 10].Value = item.PARENT_TAG;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.EquipmentTag;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.EquipmentLayout;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.GetEngStatus;
                    Sheet.Cells[currentRow, startColumn + 14].Value = item.DrawNo;
                    Sheet.Cells[currentRow, startColumn + 15].Value = item.DRAWREV;
                    Sheet.Cells[currentRow, startColumn + 16].Value = item.DrawRevAcc;
                    Sheet.Cells[currentRow, startColumn + 17].Value = item.OPTRATIO;
                    Sheet.Cells[currentRow, startColumn + 18].Value = item.SubContractor;
                    Sheet.Cells[currentRow, startColumn + 19].Value = item.MRNO;
                    Sheet.Cells[currentRow, startColumn + 20].Value = item.QtyUnits;
                    Sheet.Cells[currentRow, startColumn + 21].Value = item.GetQty;
                    Sheet.Cells[currentRow, startColumn + 22].Value = item.ITEM_QUANTITY.QTY_BUDGET;
                    Sheet.Cells[currentRow, startColumn + 23].Value = item.ITEM_QUANTITY.QTY_WR;
                    Sheet.Cells[currentRow, startColumn + 24].Value = item.ITEM_QUANTITY.QTY_IFR;
                    Sheet.Cells[currentRow, startColumn + 25].Value = item.ITEM_QUANTITY.QTY_IFC;
                    Sheet.Cells[currentRow, startColumn + 26].Value = item.ITEM_QUANTITY.QTY_VD;
                    Sheet.Cells[currentRow, startColumn + 27].Value = item.ITEM_QUANTITY.QTY_ACC;
                    Sheet.Cells[currentRow, startColumn + 28].Value = item.ITEM_QUANTITY.QTY_LAST_ISSUE;
                    Sheet.Cells[currentRow, startColumn + 29].Value = item.ITEM_QUANTITY.GetLastCEQty;
                    Sheet.Cells[currentRow, startColumn + 30].Value = item.ITEM_QUANTITY.GetKNextCERounded;
                    Sheet.Cells[currentRow, startColumn + 31].Value = item.ITEM_QUANTITY.QTY_NEXT_CE;
                    Sheet.Cells[currentRow, startColumn + 32].Value = item.Qty3dHold;
                    Sheet.Cells[currentRow, startColumn + 33].Value = item.ITEM_QUANTITY.MANUAL_QTY_HOLD;
                    Sheet.Cells[currentRow, startColumn + 34].Value = item.GetHoldStatus;
                    Sheet.Cells[currentRow, startColumn + 35].Value = item.ITEM_QUANTITY.QTY_REINF;
                    Sheet.Cells[currentRow, startColumn + 36].Value = item.ITEM_QUANTITY.ReinfIncidence;
                    Sheet.Cells[currentRow, startColumn + 37].Value = item.ITEM_QUANTITY.CONNECTION_INDICENCE;
                    Sheet.Cells[currentRow, startColumn + 38].Value = item.ITEM_QUANTITY.AiVolumeIncidence;
                    Sheet.Cells[currentRow, startColumn + 39].Value = string.Empty;
                    Sheet.Cells[currentRow, startColumn + 40].Value = item.ITEM_QUANTITY.AI_VOLUME_LAST_ISSUE;

                    if (item.TAGTYPES.TagTypeID != DatabaseCostants.TagType_Steel_ID)
                    {
                        var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                        if (planning != null)
                        {
                            Sheet.Cells[currentRow, startColumn + 41].Value = planning.DayToNextIssue;
                            Sheet.Cells[currentRow, startColumn + 42].Value = planning.DateInputForeGUI;
                            Sheet.Cells[currentRow, startColumn + 43].Value = planning.DateIfrBaseLev3GUI;
                            Sheet.Cells[currentRow, startColumn + 44].Value = planning.DateIfrBaseEngGUI;
                            Sheet.Cells[currentRow, startColumn + 45].Value = planning.DateIfrCheckForeGUI;
                            Sheet.Cells[currentRow, startColumn + 46].Value = planning.DateIfrCheckActualGUI;
                            Sheet.Cells[currentRow, startColumn + 47].Value = planning.DateIfrForeGUI;
                            Sheet.Cells[currentRow, startColumn + 48].Value = planning.DateIfrActualGUI;
                            Sheet.Cells[currentRow, startColumn + 49].Value = planning.DateIfcBaseLev3GUI;
                            Sheet.Cells[currentRow, startColumn + 50].Value = planning.DateIfcBaseEngGUI;
                            Sheet.Cells[currentRow, startColumn + 51].Value = planning.DateIfcCheckForeGUI;
                            Sheet.Cells[currentRow, startColumn + 52].Value = planning.DateIfcCheckActualGUI;
                            Sheet.Cells[currentRow, startColumn + 53].Value = planning.DateIfcForeGUI;
                            Sheet.Cells[currentRow, startColumn + 54].Value = planning.DateIfcActualGUI;
                        }
                    }
                    else
                    {
                    }

                    Sheet.Cells[currentRow, startColumn + 55].Value = item.ModelName;
                    Sheet.Cells[currentRow, startColumn + 56].Value = item.GetModelDate;
                    if (item.TagTypeID == DatabaseCostants.TagType_Pile_ID)
                    {
                        int? pilesCount = item.GetPilesCount;
                        if (pilesCount != null && pilesCount.HasValue)
                            Sheet.Cells[currentRow, startColumn + 57].Value = pilesCount.Value;
                    }
                    Sheet.Cells[currentRow, startColumn + 58].Value = item.LastModified != null && item.LastModified.HasValue ?
                            item.LastModified.Value.ToString("yyyy-MM-dd") : null;
                    Sheet.Cells[currentRow, startColumn + 59].Value = item.LastModifyUser;

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelItemSize(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsSizeTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "MainItemSizeList.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:MainItemsSizeSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var obj = await _context.OBJECTCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LV01_Object_Code).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            List<IMPORTANCESTATUS> statusList = await _context.IMPORTANCESTATUS.ToListAsync();
            mainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);

            List<MainItemGroup> mainItemGroups = new List<MainItemGroup>();
            if (mainItems != null)
            {
                List<string> tags = mainItems.Select(m => m.MainItemTag).Distinct().ToList();
                if (tags != null)
                {
                    foreach (string tag in tags)
                    {
                        List<MAINITEMS> itemList = mainItems.Where(m => m.MainItemTag == tag && !m.IsBalance).ToList();
                        MainItemGroup group = MainItemGroup.GetMainItemGroup(itemList);
                        if (group != null)
                        {
                            group.ImportanceStatusList = statusList;
                            mainItemGroups.Add(group);
                        }
                    }
                }
            }


            if (mainItemGroups != null)
            {
                int currentRow = startRow;
                foreach (MainItemGroup item in mainItemGroups)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.Length;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.Width;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.ConcreteHeight;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.ConcreteLevels;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.SteelHeight;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.SteelLevels;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.Modules;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.ImportanceName;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelParameters(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsTemplateParameters");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "MainItemListParameters.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:MainItemsListSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
            int startColumnHeader = _configuration.GetValue<int>("Excel:MainItemsParameterStartColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;
            var mainItemsList = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.WORKINGPACKAGES)
                .Include(m => m.LOTS)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.TAGTYPES)
                .OrderBy(m => m.MainItemTag)
                .Where(p => p.PBS.ProjectID == project.ProjectID).ToListAsync();
            if (mainItemsList != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItemsList)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItemsList.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                }

                // Count General Parameters
                int generalType = _configuration.GetValue<int>("Items:ParameterGeneralID");
                var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID && p.MAINITEMPARAMETERCATEGORIESID == generalType).OrderBy(p => p.ParameterID).ToList();

                // Set additional parameter headers
                if (parameters != null)
                {
                    int headerRow = startRow - 1;
                    foreach (var parameter in parameters)
                    {
                        Sheet.Cells[headerRow, startColumnHeader].Value = parameter.PARAMETERNAME;
                        startColumnHeader++;
                    }
                }

                int currentRow = startRow;
                try
                {
                    foreach (MAINITEMS item in mainItemsList)
                    {
                        var parameterValues = _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters).Where(p =>
                            p.MainItemsID == item.MainItemID && p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).OrderBy(p =>
                            p.MainItemParametersID).ToList();

                        List<WORKINGPACKAGES> wpItemList = null;
                        if (item.WORKINGPACKAGESID != null && item.WORKINGPACKAGESID.HasValue)
                            wpItemList = wp.Where(i => i.IDWP == item.WORKINGPACKAGESID.Value).ToList();

                        Sheet.Cells[currentRow, startColumn].Value = item.MainItemTag;
                        Sheet.Cells[currentRow, startColumn + 1].Value = item.Description;
                        Sheet.Cells[currentRow, startColumn + 2].Value = item.TAGTYPES.Description;
                        Sheet.Cells[currentRow, startColumn + 3].Value = item.LOTS.NAME;
                        Sheet.Cells[currentRow, startColumn + 4].Value = wpItemList != null && wpItemList.Count > 0 ? wpItemList[0].NAME : string.Empty;
                        Sheet.Cells[currentRow, startColumn + 5].Value = item.TagClient;
                        Sheet.Cells[currentRow, startColumn + 6].Value = item.SubContractor;
                        Sheet.Cells[currentRow, startColumn + 7].Value = item.Remarks;
                        Sheet.Cells[currentRow, startColumn + 8].Value = item.OPTRATIO;
                        Sheet.Cells[currentRow, startColumn + 9].Value = string.Empty;
                        Sheet.Cells[currentRow, startColumn + 10].Value = string.Empty;
                        if (parameterValues != null)
                        {
                            int columnIndex = startColumn + 11;
                            foreach (var value in parameterValues)
                            {
                                Sheet.Cells[currentRow, columnIndex].Value = value.PARAMETERTEXT;
                                columnIndex++;
                            }
                        }
                        currentRow++;
                    }
                }
                catch (Exception ex)
                {
                    string a = "";
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelGroupParameters(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsTemplateGroupParameters");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "MainItemListGroupParameters.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:MainItemsListSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
            int startColumnHeader = _configuration.GetValue<int>("Excel:MainItemsParameterStartColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;
            var mainItemsList = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.TAGTYPES)
                .OrderBy(m => m.MainItemTag)
                .Where(p => p.PBS.ProjectID == project.ProjectID).ToListAsync();

            List<IMPORTANCESTATUS> statusList = await _context.IMPORTANCESTATUS.ToListAsync();

            if (mainItemsList != null)
            {
                List<MainItemGroup> mainItemGroups = new List<MainItemGroup>();
                if (mainItemsList != null)
                {
                    List<string> tags = mainItemsList.Select(m => m.MainItemTag).Distinct().ToList();
                    if (tags != null)
                    {
                        foreach (string tag in tags)
                        {
                            List<MAINITEMS> itemList = mainItemsList.Where(m => m.MainItemTag == tag).ToList();
                            MainItemGroup group = MainItemGroup.GetMainItemGroup(itemList);
                            if (group != null)
                            {
                                group.ImportanceStatusList = statusList;
                                mainItemGroups.Add(group);
                            }
                        }
                    }
                }

                int currentRow = startRow;
                foreach (MainItemGroup item in mainItemGroups)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.MainItemDescritpion;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.EquipmentTag;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.EquipmentLayout;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.AssociatedTagTypes;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.Length;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.Width;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.ConcreteHeight;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.ConcreteLevels;
                    Sheet.Cells[currentRow, startColumn + 10].Value = item.SteelHeight;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.SteelLevels;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.Footprint;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.ConcreteVolume;
                    Sheet.Cells[currentRow, startColumn + 14].Value = item.SteelVolume;
                    Sheet.Cells[currentRow, startColumn + 15].Value = item.Modules;
                    Sheet.Cells[currentRow, startColumn + 16].Value = item.IMPORTANCESTATUS.Description;

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        private async Task<bool> AddPBS(
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            USERS user,
            string unit,
            string area,
            bool autoCWA,
            string cwa,
            double areasize,
            string areadescription)
        {
            PBS pBS = new PBS();
            pBS.Area = area;
            pBS.Unit = unit;
            pBS.ProjectID = project.ProjectID;
            pBS.AreaValue = areasize;
            pBS.AreaDescription = areadescription;
            pBS.AutoCWA = autoCWA;
            pBS.CWA = cwa;

            pBS.UpdateValues(projectSettings, user);

            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
            string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

            var lotDefault = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameDefault).FirstOrDefaultAsync();
            var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
            var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
            var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

            var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();

            using (var dbContextTransaction = _context.Database.BeginTransaction())
            {
                try
                {
                    // Set user and creation date
                    pBS.UserID = user.USERID;
                    pBS.USERS = user;
                    pBS.CreationDate = DateTime.UtcNow;
                    pBS.LastModified = DateTime.UtcNow;

                    _context.PBS.Add(pBS);
                    await _context.SaveChangesAsync();

                    // Add PBS drawing
                    PBSDRAWINGS pbsDrawing = new PBSDRAWINGS();
                    pbsDrawing.PBSID = pBS.PBSID;
                    pbsDrawing.UserID = user.USERID;
                    pbsDrawing.CreationDate = DateTime.UtcNow;
                    pbsDrawing.LastModified = DateTime.UtcNow;
                    _context.PBSDRAWINGS.Add(pbsDrawing);
                    await _context.SaveChangesAsync();

                    // Create a Balance Main Item for Every Tag Types
                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    bool added = false;
                    if (tagTypes != null)
                    {
                        PLANNINGS pLANNINGS = null;
                        STEELPLANNINGS steelPlanning = null;
                        MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                        STEEL_QUANTITIES steelQty = null;
                        STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

                        HOLDS mainItemHold = null;
                        int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                        int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

                        foreach (TAGTYPES tagtype in tagTypes)
                        {
                            if (tagtype.VALIDFORMAINITEMS > 0)
                            {
                                MAINITEMS mainItem = new MAINITEMS();
                                mainItem.MainItemTag = projectSettings.GetBalanceMainItemTag(pBS.Area);
                                mainItem.TagTypeID = tagtype.TagTypeID;
                                mainItem.TagDescription = projectSettings.BALANCE;
                                mainItem.TagClient = projectSettings.BALANCE;
                                mainItem.PBSID = pBS.PBSID;
                                mainItem.UserID = user.USERID;
                                mainItem.USERS = user;
                                mainItem.CreationDate = DateTime.UtcNow;
                                mainItem.LastModified = DateTime.UtcNow;
                                mainItem.AddedManually = 0;
                                mainItem.BALANCE = 1;
                                mainItem.MAINITEMSTATUSID = MainItemsCostants.NONE;

                                if (tagtype.TagTypeID == tagTypeSteel)
                                {
                                    mainItem.VENDORSID = vendor.IDVENDOR;
                                    mainItem.MATERIALREQUESTSID = mr.IDMR;
                                    mainItem.PURCHASEORDERSID = po.IDPO;
                                    mainItem.LOTSID = lotDefault.IDLOT;
                                }
                                else
                                {
                                    mainItem.LOTSID = lotDefault.IDLOT;
                                }
                                _context.MAINITEMS.Add(mainItem);


                                int result = _context.SaveChanges(true);
                                var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == mainItem.MainItemTag && m.PBSID == pBS.PBSID);

                                // Add parameter if existing
                                if (parameters != null && parameters.Count > 0)
                                {
                                    foreach (MAINITEMPARAMETERS parameter in parameters)
                                    {
                                        MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                        mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                        mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                        mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                        mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                                        mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                        _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                    }
                                    await _context.SaveChangesAsync();
                                }

                                // Add empty planning
                                pLANNINGS = new PLANNINGS();
                                pLANNINGS.MainItemId = mainItem.MainItemID;
                                pLANNINGS.UserID = user.USERID;
                                pLANNINGS.CreationDate = DateTime.UtcNow;
                                pLANNINGS.LastModified = DateTime.UtcNow;

                                mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                _context.PLANNINGS.Add(pLANNINGS);
                                //_context.HOLDS.Add(mainItemHold);
                                _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                added = true;

                                //if (tagtype.TagTypeID != tagTypeSteel)
                                //{

                                //    // Add empty planning
                                //    pLANNINGS = new PLANNINGS();
                                //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                //    pLANNINGS.UserID = user.USERID;
                                //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                //    pLANNINGS.LastModified = DateTime.UtcNow;

                                //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                //    //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                //    _context.PLANNINGS.Add(pLANNINGS);
                                //    //_context.HOLDS.Add(mainItemHold);
                                //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                //    added = true;
                                //}
                                //else
                                //{
                                //    // Add empty planning
                                //    pLANNINGS = new PLANNINGS();
                                //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                //    pLANNINGS.UserID = user.USERID;
                                //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                //    pLANNINGS.LastModified = DateTime.UtcNow;
                                //    _context.PLANNINGS.Add(pLANNINGS);

                                //    steelPlanning = new STEELPLANNINGS();
                                //    steelPlanning.MainItemId = mainItem.MainItemID;
                                //    steelPlanning.UserID = user.USERID;
                                //    steelPlanning.CreationDate = DateTime.UtcNow;
                                //    steelPlanning.LastModified = DateTime.UtcNow;
                                //    _context.STEELPLANNINGS.Add(steelPlanning);
                                //    added = true;

                                //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                //    steelEstimateQty.MainItemId = mainItem.MainItemID;
                                //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                //    steelEstimateQty.IFF_E_QTY = 0.0;
                                //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                //    steelEstimateQty.IFP_E_QTY = 0.0;
                                //    steelEstimateQty.PO_E_QTY = 0.0;
                                //    steelEstimateQty.UserID = user.USERID;
                                //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                                //    steelEstimateQty.LastModified = DateTime.UtcNow;
                                //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                //    if (commodities != null)
                                //    {
                                //        foreach (COMMODITYCODES code in commodities)
                                //        {
                                //            steelQty = new STEEL_QUANTITIES();
                                //            steelQty.MainItemId = mainItem.MainItemID;
                                //            steelQty.CodeId = code.CodeID;
                                //            steelQty.QTY = 0.0;
                                //            steelQty.UserID = user.USERID;
                                //            steelQty.CreationDate = DateTime.UtcNow;
                                //            steelQty.LastModified = DateTime.UtcNow;
                                //            _context.STEEL_QUANTITIES.Add(steelQty);
                                //        }
                                //    }
                                //}

                                // Add Main Item Drawing
                                MAINITEMDRAWINGS mainItemDrawing = new MAINITEMDRAWINGS();
                                mainItemDrawing.UserID = user.USERID;
                                mainItemDrawing.CreationDate = DateTime.UtcNow;
                                mainItemDrawing.LastModified = DateTime.UtcNow;
                                mainItemDrawing.MainItemID = mainItem.MainItemID;

                                _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                // Add CE Revision

                            }
                        }
                    }
                    if (added)
                    {
                        await _context.SaveChangesAsync();
                        dbContextTransaction.Commit();
                    }
                    else
                    {
                        dbContextTransaction.Rollback();
                    }
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return false;
                }
            }
            return true;
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }

                    DatabaseCostants.InitValues(_configuration);

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var cellTitle = worksheet.Cells[2, 10];
                    string title = cellTitle != null && cellTitle.Value != null ? cellTitle.Value.ToString() : null;
                    if (title != "STATUS")
                    {
                        excelLogManager.Result = "Excel not valid!!";
                        return excelLogManager;
                    }

                    var objectCodes = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();

                    bool someItemsNotCreated = false;

                    // Check Columns
                    int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
                    int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
                    List<string> columnNames = ParsingUtils.ParseString(_configuration.GetValue<string>("Excel:ItemColumns"));
                    var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToList();
                    if (parameters != null && parameters.Count > 0)
                        columnNames.AddRange(parameters.Select(p => p.PARAMETERNAME).ToList());
                    int index = 37;
                    if (parameters != null)
                    {
                        for (int i = 0; i < parameters.Count; i++)
                        {
                            var cell = worksheet.Cells[startRow - 1, index + i];
                            string value = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            if (!string.IsNullOrEmpty(value))
                                value = value.ToUpperInvariant();
                            if (value != columnNames[index + i - 1].ToUpperInvariant())
                            {
                                excelLogManager.Result = "Invalid Excel - Column " + (index + i).ToString() + " " + columnNames[index + i - 1];
                                return excelLogManager;
                            }
                        }
                    }

                    // Read Data
                    List<string> unitList = new List<string>();
                    List<string> caList = new List<string>();
                    List<string> itemTagList = new List<string>();
                    List<string> objecCodeList = new List<string>();
                    List<string> tagClientList = new List<string>();
                    List<string> tagDescriptionList = new List<string>();
                    List<string> tagTypesList = new List<string>();
                    List<string> lots = new List<string>();
                    List<string> wpList = new List<string>();
                    List<string> tagEquipList = new List<string>();
                    List<string> equipLayDrawNoList = new List<string>();
                    List<string> drawNoList = new List<string>();
                    List<string> drawRevList = new List<string>();
                    List<string> drawRevAccList = new List<string>();
                    List<double?> optRatioList = new List<double?>();
                    List<string> subContractorList = new List<string>();
                    List<string> remarkList = new List<string>();
                    List<double?> qtyBudgetList = new List<double?>();
                    List<double?> qtyWRList = new List<double?>();
                    List<double?> qtyIFRList = new List<double?>();
                    List<double?> qtyIFCList = new List<double?>();
                    List<double?> qtyACCList = new List<double?>();
                    List<double?> qtyNextCEList = new List<double?>();
                    List<double?> qtyRebarList = new List<double?>();
                    List<double?> qtyConnIncList = new List<double?>();
                    List<double?> aiVolList = new List<double?>();
                    List<DateTime?> dateInputForeList = new List<DateTime?>();
                    List<DateTime?> dateIFRQualityForeList = new List<DateTime?>();
                    List<DateTime?> dateIFRQualityActualList = new List<DateTime?>();
                    List<DateTime?> dateIFRForecastList = new List<DateTime?>();
                    List<DateTime?> dateIFRActualList = new List<DateTime?>();
                    List<DateTime?> dateIFCQualityCheckForeList = new List<DateTime?>();
                    List<DateTime?> dateIFCQualityCheckActualist = new List<DateTime?>();
                    List<DateTime?> dateIFCForeList = new List<DateTime?>();
                    List<DateTime?> dateIFCActualList = new List<DateTime?>();
                    List<OBJECTCODES> objecCodeIDList = new List<OBJECTCODES>();
                    List<List<object>> parameterValues = new List<List<object>>();

                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, 1];
                            string unit = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 2];
                            string area = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 3];
                            string currentTag = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 4];
                            string objectCode = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            OBJECTCODES currentObjectCode = null;
                            if (!string.IsNullOrEmpty(objectCode))
                                currentObjectCode = objectCodes.Where(o => o.Code == objectCode).FirstOrDefault();
                            bool validObjectCode = true;
                            if (currentObjectCode != null && !string.IsNullOrEmpty(currentTag))
                            {
                                var arrayStr = currentTag.Split('-').ToList();
                                if (arrayStr != null && arrayStr.Count > 1)
                                {
                                    validObjectCode = arrayStr[1].StartsWith(objectCode);
                                }
                            }

                            cell = worksheet.Cells[counter, 5];
                            string tagClient = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 6];
                            string tagDescr = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 7];
                            string currentTagType = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 8];
                            string lot = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 9];
                            string wp = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 11];
                            string tagEquip = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 12];
                            string equipLay = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 13];
                            string drawNo = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 14];
                            string drawRev = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 15];
                            string drawRevAcc = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 16];
                            double? optRatio = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                optRatio = (double)cell.Value;

                            cell = worksheet.Cells[counter, 17];
                            string subContractor = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 18];
                            string remarks = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 19];
                            double? qtyBudget = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyBudget = (double)cell.Value;

                            cell = worksheet.Cells[counter, 20];
                            double? qtyWR = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyWR = (double)cell.Value;

                            cell = worksheet.Cells[counter, 21];
                            double? qtyIFR = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyIFR = (double)cell.Value;

                            cell = worksheet.Cells[counter, 22];
                            double? qtyIFC = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyIFC = (double)cell.Value;

                            cell = worksheet.Cells[counter, 23];
                            double? qtyACC = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyACC = (double)cell.Value;

                            cell = worksheet.Cells[counter, 24];
                            double? qtyNextCE = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyNextCE = (double)cell.Value;

                            cell = worksheet.Cells[counter, 25];
                            double? qtyRebar = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qtyRebar = (double)cell.Value;

                            cell = worksheet.Cells[counter, 26];
                            double? connInc = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                connInc = (double)cell.Value;

                            cell = worksheet.Cells[counter, 27];
                            double? aiVol = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                aiVol = (double)cell.Value;

                            cell = worksheet.Cells[counter, 28];
                            DateTime? inputFore = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    inputFore = tempdt;
                            }

                            cell = worksheet.Cells[counter, 29];
                            DateTime? ifrQualityCheckFore = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifrQualityCheckFore = tempdt;
                            }

                            cell = worksheet.Cells[counter, 30];
                            DateTime? ifrQualityCheckActual = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifrQualityCheckActual = tempdt;
                            }

                            cell = worksheet.Cells[counter, 31];
                            DateTime? ifrFore = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifrFore = tempdt;
                            }

                            cell = worksheet.Cells[counter, 32];
                            DateTime? ifrActual = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifrActual = tempdt;
                            }

                            cell = worksheet.Cells[counter, 33];
                            DateTime? ifcQualityFore = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifcQualityFore = tempdt;
                            }

                            cell = worksheet.Cells[counter, 34];
                            DateTime? ifcQualityActual = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifcQualityActual = tempdt;
                            }

                            cell = worksheet.Cells[counter, 35];
                            DateTime? ifcFore = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifcFore = tempdt;
                            }

                            cell = worksheet.Cells[counter, 36];
                            DateTime? ifcActual = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    ifcActual = tempdt;
                            }

                            if (parameters != null && parameters.Count > 0)
                            {
                                int currentColum = 37;
                                List<object> currentValues = new List<object>();
                                foreach (var parameter in parameters)
                                {
                                    cell = worksheet.Cells[counter, currentColum];
                                    if (parameter.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.TextParameterID)
                                    {
                                        string currentText = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                        currentValues.Add(currentText);
                                    }
                                    else if (parameter.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.QuantityParameterID)
                                    {
                                        double? currentQty = null;
                                        if (cell != null && cell.Value != null && cell.Value is double)
                                            currentQty = (double)cell.Value;
                                        currentValues.Add(currentQty);
                                    }
                                    else if (parameter.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.DateParameterID)
                                    {
                                        DateTime? currentDate = null;
                                        if (cell != null && !string.IsNullOrEmpty(cell.Text))
                                        {
                                            DateTime tempdt;
                                            if (DateTime.TryParse(cell.Text, out tempdt))
                                                currentDate = tempdt;
                                        }
                                        currentValues.Add(currentDate);
                                    }
                                    currentColum++;
                                }
                                parameterValues.Add(currentValues);
                            }

                            if (string.IsNullOrEmpty(unit) && string.IsNullOrEmpty(currentTag))
                                notEmpty = false;
                            else
                            {
                                if (string.IsNullOrEmpty(unit))
                                    excelLogManager.AddLog(counter, 1, "Empty unit");
                                else if (string.IsNullOrEmpty(area))
                                    excelLogManager.AddLog(counter, 2, "Empty area");
                                else if (string.IsNullOrEmpty(currentTag))
                                    excelLogManager.AddLog(counter, 3, "Empty main item tag");
                                else if (string.IsNullOrEmpty(currentTagType))
                                    excelLogManager.AddLog(counter, 7, "Empty tag type");
                                else if (string.IsNullOrEmpty(lot))
                                    excelLogManager.AddLog(counter, 8, "Empty lot");
                                else
                                {
                                    bool validItem = false;
                                    var currentMainItem = await _context.MAINITEMS.Include(i => i.PBS).Where(it =>
                                                it.MainItemTag.ToUpperInvariant() == currentTag.ToUpperInvariant() &&
                                                it.TAGTYPES.Description.ToUpperInvariant() == currentTagType.ToUpperInvariant() &&
                                                it.LOTS.NAME == lot.ToUpperInvariant()).FirstOrDefaultAsync();

                                    bool isBalance = false;
                                    if (currentMainItem != null)
                                        isBalance = currentMainItem.IsBalance;
                                    if (!isBalance)
                                    {
                                        if (!string.IsNullOrEmpty(currentTag))
                                            isBalance = currentTag.Contains(projectSettings.BALANCE);
                                    }

                                    if (currentMainItem != null || isBalance)
                                    {
                                        validItem = true;
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(objectCode))
                                            excelLogManager.AddLog(counter, 4, "Empty object code");
                                        else if (currentObjectCode == null)
                                            excelLogManager.AddLog(counter, 4, "Invalid object code");
                                        else if (!validObjectCode)
                                            excelLogManager.AddLog(counter, 4, "Invalid object code - Main Item Tag");
                                        else
                                            validItem = true;
                                    }


                                    if (validItem)
                                    {
                                        unitList.Add(unit);
                                        caList.Add(area);
                                        itemTagList.Add(currentTag);
                                        tagClientList.Add(tagClient);
                                        tagDescriptionList.Add(tagDescr);
                                        tagTypesList.Add(currentTagType);
                                        lots.Add(lot);
                                        wpList.Add(wp);
                                        tagEquipList.Add(tagEquip);
                                        equipLayDrawNoList.Add(equipLay);
                                        drawNoList.Add(drawNo);
                                        drawRevList.Add(drawRev);
                                        drawRevAccList.Add(drawRevAcc);
                                        optRatioList.Add(optRatio);
                                        subContractorList.Add(subContractor);
                                        remarkList.Add(remarks);
                                        qtyBudgetList.Add(qtyBudget);
                                        qtyWRList.Add(qtyWR);
                                        qtyIFRList.Add(qtyIFR);
                                        qtyIFCList.Add(qtyIFC);
                                        qtyACCList.Add(qtyACC);
                                        qtyNextCEList.Add(qtyNextCE);
                                        qtyRebarList.Add(qtyRebar);
                                        qtyConnIncList.Add(connInc);
                                        aiVolList.Add(aiVol);
                                        dateInputForeList.Add(inputFore);
                                        dateIFRQualityForeList.Add(ifrQualityCheckFore);
                                        dateIFRQualityActualList.Add(ifrQualityCheckActual);
                                        dateIFRForecastList.Add(ifrFore);
                                        dateIFRActualList.Add(ifrActual);
                                        dateIFCQualityCheckForeList.Add(ifcQualityFore);
                                        dateIFCQualityCheckActualist.Add(ifcQualityActual);
                                        dateIFCForeList.Add(ifcFore);
                                        dateIFCActualList.Add(ifcActual);
                                        objecCodeIDList.Add(currentObjectCode);
                                    }
                                }
                            }
                            counter++;
                        }
                        catch
                        {
                            notEmpty = false;
                        }
                    }

                    // Configuration
                    string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                            {
                                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                                return excelLogManager;
                            }

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;
                            ViewBag.ProjectDescription = project.GetCompleteDescription;

                            var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                            var materialGroups = await _context.MATERIALWORKGROUPS.ToListAsync();
                            List<LOTS> lotList = await _context.LOTS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();

                            int result = -1;
                            List<MAINITEMS> itemsAdded = new List<MAINITEMS>();

                            for (int i = 0; i < unitList.Count; i++)
                            {
                                string unit = unitList[i];
                                string ca = caList[i];
                                var currentTagType = await _context.TAGTYPES.Where(t => t.Description == tagTypesList[i]).FirstOrDefaultAsync();

                                if (currentTagType == null)
                                {
                                    excelLogManager.AddLog(counter, 6, "Invalid Tag Type");
                                    continue;
                                }

                                // Search for LOT
                                LOTS currentLot = lotList.Where(l => l.NAME == lots[i] && l.ProjectID == project.ProjectID).FirstOrDefault();
                                if (currentLot == null)
                                {
                                    currentLot = LOTS.GetNewLot(lots[i], project.ProjectID, user.USERID.Value);
                                    _context.LOTS.Add(currentLot);
                                    result = _context.SaveChanges();
                                    lotList = await _context.LOTS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                                }
                                if (currentLot == null)
                                {
                                    excelLogManager.AddLog(counter, 7, "Unable to create lot");
                                    continue;
                                }

                                // Create Main Item
                                var currentMainItem = await _context.MAINITEMS.Include(i => i.PBS).Where(it =>
                                    it.MainItemTag.ToUpperInvariant() == itemTagList[i].ToUpperInvariant() &&
                                    it.TagTypeID == currentTagType.TagTypeID &&
                                    it.LOTS.IDLOT == currentLot.IDLOT).FirstOrDefaultAsync();

                                // Search for PBS
                                PBS currentPbs = null;
                                if (currentMainItem != null)
                                    currentPbs = currentMainItem.PBS;
                                else
                                {
                                    currentPbs = await _context.PBS.Where(p => p.Unit.ToUpperInvariant() == unit.ToUpperInvariant() &&
                                        p.Area.ToUpperInvariant() == ca.ToUpperInvariant() && p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                                    if (currentPbs == null) // Try to create PBS
                                    {
                                        await AddPBS(project, projectSettings, user, unit, ca, true, string.Empty, 0.0, "");

                                        currentPbs = await _context.PBS.Where(p => p.Unit.ToUpperInvariant() == unit.ToUpperInvariant() &&
                                        p.Area.ToUpperInvariant() == ca.ToUpperInvariant() && p.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                                    }
                                }

                                if (currentPbs == null)
                                {
                                    excelLogManager.AddLog(counter, -1, "Unable to create PBS");
                                    continue;
                                }

                                if (currentPbs != null && currentTagType != null && currentLot != null)
                                {
                                    if (currentMainItem == null || !currentMainItem.IsBalance)
                                    {
                                        var wpCurrent = await _context.WORKINGPACKAGES.Where(w => w.NAME == wpList[i] && w.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                                        if (currentMainItem == null && !itemTagList[i].Contains(projectSettings.BALANCE)) // Create new main Item
                                        {
                                            MAINITEMS item = new MAINITEMS();
                                            item.PBS = currentPbs;
                                            item.PBSID = currentPbs.PBSID;
                                            item.TAGTYPES = currentTagType;
                                            item.TagTypeID = currentTagType.TagTypeID;
                                            item.MainItemTag = itemTagList[i];
                                            item.TagDescription = tagDescriptionList[i];
                                            item.TagClient = tagClientList[i];
                                            item.AddedManually = 0;
                                            item.WORKINGPACKAGESID = wpCurrent?.IDWP;
                                            item.LV01_Object_CodeID = objecCodeIDList[i]?.CodeID;
                                            item.LV01_Material_Work_GroupID = null;
                                            item.LOTSID = currentLot.IDLOT;
                                            item.BALANCE = 0;
                                            item.MAINITEMSTATUSID = MainItemsCostants.NONE;
                                            item.EquipmentTag = tagEquipList[i];
                                            item.EquipmentLayout = equipLayDrawNoList[i];
                                            item.DrawNo = drawNoList[i];
                                            item.DRAWREV = drawRevList[i];
                                            item.DrawRevAcc = drawRevAccList[i];
                                            item.OPTRATIO = optRatioList[i];
                                            item.SubContractor = subContractorList[i];
                                            item.Remarks = remarkList[i];



                                            // Set User and Date
                                            item.UserID = user.USERID;
                                            item.CreationDate = DateTime.UtcNow;
                                            item.LastModified = DateTime.UtcNow;

                                            _context.MAINITEMS.Add(item);
                                            result = _context.SaveChanges();

                                            if (result > 0)
                                            {
                                                itemsAdded.Add(item);
                                                result = _context.SaveChanges();

                                                // Add Parameters
                                                if (parameters != null && parameters.Count > 0)
                                                {
                                                    if (parameterValues == null || parameterValues.Count <= i)
                                                    {
                                                        excelLogManager.AddLog(counter, -1, "Custom parameter values not valid");
                                                    }
                                                    else
                                                    {
                                                        var values = parameterValues[i];
                                                        int counterVal = 0;
                                                        foreach (var currentParameter in parameters)
                                                        {
                                                            MAINITEMPARAMETERVALUES newVal = new MAINITEMPARAMETERVALUES();
                                                            newVal.MainItemParametersID = currentParameter.ParameterID;
                                                            newVal.MainItemsID = item.MainItemID;
                                                            newVal.UserID = user.USERID;
                                                            newVal.CreationDate = DateTime.UtcNow;
                                                            newVal.LastModified = DateTime.UtcNow;
                                                            if (currentParameter.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.TextParameterID)
                                                            {
                                                                if (values[counterVal] == null)
                                                                    newVal.PARAMETERTEXT = null;
                                                                else
                                                                    newVal.PARAMETERTEXT = (string)values[counterVal];
                                                            }
                                                            else if (currentParameter.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.QuantityParameterID)
                                                            {
                                                                if (values[counterVal] == null)
                                                                    newVal.PARAMETERDOUBLE = null;
                                                                else
                                                                    newVal.PARAMETERDOUBLE = (double)values[counterVal];
                                                            }
                                                            else if (currentParameter.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.DateParameterID)
                                                            {
                                                                if (values[counterVal] == null)
                                                                    newVal.PARAMETERDATE = null;
                                                                else
                                                                    newVal.PARAMETERDATE = (DateTime)values[counterVal];
                                                            }
                                                            counterVal++;
                                                            _context.MAINITEMPARAMETERVALUES.Add(newVal);
                                                        }
                                                        result = _context.SaveChanges();
                                                    }
                                                }
                                            }
                                        }
                                        else // Update main item
                                        {
                                            if (currentMainItem == null || currentMainItem.IsBalance || currentMainItem.IsDeleted || currentMainItem.IsReplaced)
                                                continue;

                                            // Update main item
                                            currentMainItem.TagDescription = tagDescriptionList[i];
                                            currentMainItem.TagClient = tagClientList[i];
                                            currentMainItem.AddedManually = 0;
                                            currentMainItem.WORKINGPACKAGESID = wpCurrent?.IDWP;
                                            currentMainItem.LOTSID = currentLot.IDLOT;
                                            currentMainItem.EquipmentTag = tagEquipList[i];
                                            currentMainItem.EquipmentLayout = equipLayDrawNoList[i];
                                            currentMainItem.DrawNo = drawNoList[i];
                                            currentMainItem.DRAWREV = drawRevList[i];
                                            currentMainItem.DrawRevAcc = drawRevAccList[i];
                                            currentMainItem.OPTRATIO = optRatioList[i];
                                            currentMainItem.SubContractor = subContractorList[i];
                                            currentMainItem.Remarks = remarkList[i];

                                            // Set User and Date
                                            currentMainItem.UserID = user.USERID;
                                            currentMainItem.CreationDate = DateTime.UtcNow;
                                            currentMainItem.LastModified = DateTime.UtcNow;

                                            _context.MAINITEMS.Update(currentMainItem);
                                            result = _context.SaveChanges();

                                            if (parameterValues != null && parameterValues.Count > i)
                                            {
                                                var values = parameterValues[i];
                                                var parameterValuesItem = await _context.MAINITEMPARAMETERVALUES.Include(m => m.MainItemParameters)
                                                    .Where(m => m.MainItemsID == currentMainItem.MainItemID)
                                                    .OrderBy(m => m.MainItemParametersID)
                                                    .ToListAsync();

                                                int counterVal = 0;
                                                foreach (var value in parameterValuesItem)
                                                {
                                                    if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.TextParameterID)
                                                    {
                                                        if (values[counterVal] == null)
                                                            value.PARAMETERTEXT = null;
                                                        else
                                                            value.PARAMETERTEXT = (string)values[counterVal];
                                                    }
                                                    else if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.QuantityParameterID)
                                                    {
                                                        if (values[counterVal] == null)
                                                            value.PARAMETERDOUBLE = null;
                                                        else
                                                            value.PARAMETERDOUBLE = (double)values[counterVal];
                                                    }
                                                    else if (value.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == DatabaseCostants.DateParameterID)
                                                    {
                                                        if (values[counterVal] == null)
                                                            value.PARAMETERDATE = null;
                                                        else
                                                            value.PARAMETERDATE = (DateTime)values[counterVal];
                                                    }
                                                    counterVal++;
                                                }
                                            }
                                            result = await _context.SaveChangesAsync();
                                        }
                                    }
                                }
                            }

                            PLANNINGS pLANNINGS = null;
                            MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                            MAINITEMDRAWINGS mainItemDrawing = null;

                            // For main items added add quantities and planning dates
                            if (itemsAdded.Count > 0)
                            {
                                try
                                {
                                    HOLDS mainItemHold = null;
                                    int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                                    int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

                                    foreach (MAINITEMS item in itemsAdded)
                                    {
                                        // Add empty planning
                                        pLANNINGS = new PLANNINGS();
                                        pLANNINGS.MainItemId = item.MainItemID;
                                        pLANNINGS.UserID = user.USERID;
                                        pLANNINGS.CreationDate = DateTime.UtcNow;
                                        pLANNINGS.LastModified = DateTime.UtcNow;
                                        _context.PLANNINGS.Add(pLANNINGS);

                                        mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                        mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                        mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                        mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                        mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                        _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                        if (item.BALANCE.HasValue && item.BALANCE.Value > 0)
                                        {
                                            // Continue
                                            mainItemDrawing = new MAINITEMDRAWINGS();
                                            mainItemDrawing.UserID = user.USERID;
                                            mainItemDrawing.CreationDate = DateTime.UtcNow;
                                            mainItemDrawing.LastModified = DateTime.UtcNow;
                                            mainItemDrawing.MainItemID = item.MainItemID;
                                            _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                        }
                                        else
                                        {
                                            mainItemDrawing = new MAINITEMDRAWINGS();
                                            mainItemDrawing.UserID = user.USERID;
                                            mainItemDrawing.CreationDate = DateTime.UtcNow;
                                            mainItemDrawing.LastModified = DateTime.UtcNow;
                                            mainItemDrawing.MainItemID = item.MainItemID;
                                            _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                        }

                                        //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);
                                        //_context.HOLDS.Add(mainItemHold);
                                    }
                                    result = _context.SaveChanges();
                                }
                                catch (Exception ex)
                                {
                                    excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED) + " " + ex.Message);
                                }
                            }

                            if (someItemsNotCreated)
                            {
                                excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED));
                            }


                            // Update quantities and planning
                            for (int i = 0; i < unitList.Count; i++)
                            {
                                var currentTagType = await _context.TAGTYPES.Where(t => t.Description == tagTypesList[i]).FirstOrDefaultAsync();
                                LOTS currentLot = lotList.Where(l => l.NAME == lots[i] && l.ProjectID == project.ProjectID).FirstOrDefault();

                                if (currentTagType != null && currentLot != null)
                                {
                                    // Create Main Item
                                    var currentMainItem = await _context.MAINITEMS.Include(i => i.PBS).Where(it =>
                                        it.MainItemTag.ToUpperInvariant() == itemTagList[i].ToUpperInvariant() &&
                                        it.TagTypeID == currentTagType.TagTypeID &&
                                        it.LOTS.IDLOT == currentLot.IDLOT).FirstOrDefaultAsync();

                                    if (currentMainItem != null)
                                    {
                                        var quantity = await _context.MAIN_ITEM_QUANTITY.Where(q => q.MainItemId == currentMainItem.MainItemID).FirstOrDefaultAsync();
                                        if (quantity != null)
                                        {
                                            quantity.QTY_BUDGET = qtyBudgetList[i];
                                            quantity.QTY_WR = qtyWRList[i];
                                            quantity.QTY_IFR = qtyIFRList[i];
                                            quantity.QTY_IFC = qtyIFCList[i];
                                            quantity.QTY_ACC = qtyACCList[i];
                                            quantity.QTY_NEXT_CE = qtyNextCEList[i];
                                            quantity.QTY_REINF = qtyRebarList[i];
                                            quantity.CONNECTION_INDICENCE = qtyConnIncList[i];
                                            quantity.AI_VOLUME_LAST_ISSUE = aiVolList[i];
                                        }
                                        else
                                        {
                                            excelLogManager.AddLog(i, -1, "Quantity not found");
                                        }

                                        if (!currentMainItem.IsBalance)
                                        {
                                            var planning = await _context.PLANNINGS.Where(q => q.MainItemId == currentMainItem.MainItemID).FirstOrDefaultAsync();
                                            if (planning != null)
                                            {
                                                planning.DATE_INPUT_FORE = dateInputForeList[i];
                                                planning.DATE_IFR_CHECK_ACTUAL = dateIFRQualityForeList[i];
                                                planning.DATE_IFR_CHECK_FORE = dateIFRQualityActualList[i];
                                                planning.DATE_IFR_FORE = dateIFRForecastList[i];
                                                planning.DATE_IFR_ACTUAL = dateIFRActualList[i];
                                                planning.DATE_IFC_CHECK_FORE = dateIFCQualityCheckForeList[i];
                                                planning.DATE_IFC_CHECK_ACTUAL = dateIFCQualityCheckActualist[i];
                                                planning.DATE_IFC_FORE = dateIFCForeList[i];
                                                planning.DATE_IFC_ACTUAL = dateIFCActualList[i];
                                            }
                                            else
                                            {
                                                excelLogManager.AddLog(i, -1, "Planning not found");
                                            }
                                        }
                                    }
                                }
                            }
                            await _context.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR) + " " + ex.Message);
                        }
                    }
                    else
                    {
                        excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED));
                    }
                }
            }
            catch { }

            excelLogManager.Result = "Completed";
            return excelLogManager;
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportSizeExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    // Read Data
                    List<string> mainItemTagList = new List<string>();
                    List<double?> lengthList = new List<double?>();
                    List<double?> widthList = new List<double?>();
                    List<double?> aaHeightList = new List<double?>();
                    List<int?> aaLevelsList = new List<int?>();
                    List<double?> aiHeightList = new List<double?>();
                    List<int?> aiLevelsList = new List<int?>();
                    List<int?> moduleList = new List<int?>();
                    List<string> importanceList = new List<string>();

                    var importanceStatus = await _context.IMPORTANCESTATUS.ToListAsync();

                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, 1];
                            string tag = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 2];
                            double? length = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                length = (double)cell.Value;

                            cell = worksheet.Cells[counter, 3];
                            double? width = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                width = (double)cell.Value;

                            cell = worksheet.Cells[counter, 4];
                            double? aaH = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                aaH = (double)cell.Value;

                            cell = worksheet.Cells[counter, 5];
                            int? aaL = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                aaL = Convert.ToInt32(cell.Value);

                            cell = worksheet.Cells[counter, 6];
                            double? aiH = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                aiH = (double)cell.Value;

                            cell = worksheet.Cells[counter, 7];
                            int? aiL = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                aiL = Convert.ToInt32(cell.Value);

                            cell = worksheet.Cells[counter, 8];
                            int? module = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                module = Convert.ToInt32(cell.Value);

                            cell = worksheet.Cells[counter, 9];
                            string importance = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            bool validStatus = true;
                            if (!string.IsNullOrEmpty(importance))
                            {
                                var status = importanceStatus.Where(i => i.Description == importance).FirstOrDefault();
                                if (status == null)
                                    validStatus = false;
                            }


                            if (string.IsNullOrEmpty(tag))
                                notEmpty = false;
                            else
                            {
                                if (string.IsNullOrEmpty(tag))
                                    excelLogManager.AddLog(counter, 1, "Tag");
                                else if (!validStatus)
                                    excelLogManager.AddLog(counter, 9, "Importance (EQ)");
                                else if (length < 0.0)
                                    excelLogManager.AddLog(counter, 2, "LENGTH negative");
                                else if (width < 0.0)
                                    excelLogManager.AddLog(counter, 3, "WIDTH negative");
                                else if (aaH < 0.0)
                                    excelLogManager.AddLog(counter, 4, "AA HEIGHT negative");
                                else if (aaL < 0.0)
                                    excelLogManager.AddLog(counter, 5, "AA LEVELS negative");
                                else if (aiH < 0.0)
                                    excelLogManager.AddLog(counter, 6, "AI HEIGHT negative");
                                else if (module < 0.0)
                                    excelLogManager.AddLog(counter, 7, "AI LEVELS negative");
                                else
                                {
                                    mainItemTagList.Add(tag);
                                    lengthList.Add(length);
                                    widthList.Add(width);
                                    aaHeightList.Add(aaH);
                                    aaLevelsList.Add(aaL);
                                    aiHeightList.Add(aiH);
                                    aiLevelsList.Add(aiL);
                                    moduleList.Add(module);
                                    importanceList.Add(importance);
                                }
                            }
                            counter++;
                        }
                        catch (Exception ex)
                        {
                            notEmpty = false;
                        }
                    }

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                            {
                                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                                return excelLogManager;
                            }

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;
                            ViewBag.ProjectDescription = project.GetCompleteDescription;

                            bool changed = false;
                            for (int i = 0; i < mainItemTagList.Count; i++)
                            {
                                var mainitemList = await _context.MAINITEMS.Where(m => m.MainItemTag == mainItemTagList[i] && m.PBS.ProjectID == project.ProjectID).ToListAsync();
                                if (mainitemList != null)
                                {
                                    var currentImportance = importanceStatus.Where(p => p.Description == importanceList[i]).FirstOrDefault();
                                    foreach (MAINITEMS mainItem in mainitemList)
                                    {
                                        mainItem.Length = lengthList[i];
                                        mainItem.Width = widthList[i];
                                        mainItem.ConcreteHeight = aaHeightList[i];
                                        mainItem.ConcreteLevels = aaLevelsList[i];
                                        mainItem.SteelHeight = aiHeightList[i];
                                        mainItem.SteelLevels = aiLevelsList[i];
                                        mainItem.MODULES = moduleList[i];
                                        if (currentImportance != null)
                                            mainItem.IMPORTANCESTATUSID = currentImportance.StatusID;
                                        else
                                            mainItem.IMPORTANCESTATUSID = null;
                                        mainItem.LastModified = DateTime.UtcNow;
                                    }
                                    changed = true;
                                }
                                counter++;
                            }
                            if (changed)
                                await _context.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR) + " " + ex.Message);
                        }
                    }
                    else
                    {
                        excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED));
                    }
                }
            }
            catch { }

            excelLogManager.Result = "Completed";
            return excelLogManager;
        }

        [HttpPost]
        public async Task<string> ImportExcelParameters(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            string lfcr = "\r\n";
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                        return "Project not found";

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    // Read MainItems
                    var wpList = await _context.WORKINGPACKAGES.Where(w => w.ProjectID == project.ProjectID).ToListAsync();
                    var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES).Include(m => m.LOTS).Include(m => m.PBS).
                        Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                    // Parameters
                    int generalType = _configuration.GetValue<int>("Items:ParameterGeneralID");
                    var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID &&
                        p.MAINITEMPARAMETERCATEGORIESID == generalType).OrderBy(p => p.ParameterID).ToList();
                    int totalParameters = parameters != null ? parameters.Count : 0;

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;
                            ViewBag.ProjectDescription = project.GetCompleteDescription;

                            var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                            var objectCodes = await _context.OBJECTCODES.ToListAsync();
                            var materialGroups = await _context.MATERIALWORKGROUPS.ToListAsync();
                            var lotList = await _context.LOTS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();

                            bool notEmpty = true;
                            int counter = 3;
                            while (notEmpty)
                            {
                                try
                                {
                                    var cell = worksheet.Cells[counter, 1];
                                    string itemTag = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 2];
                                    string tagDescription = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 3];
                                    string tagType = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 4];
                                    string lot = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 5];
                                    string wp = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 6];
                                    string tagClient = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 7];
                                    string subContractor = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 8];
                                    string remarks = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                    cell = worksheet.Cells[counter, 9];
                                    double optRatio = cell != null && cell.Value != null ? (double)cell.Value : 0.0;

                                    // Read parameters
                                    List<string> parameterValues = new List<string>();
                                    int startColumn = 12;
                                    for (int i = 0; i < totalParameters; i++)
                                    {
                                        cell = worksheet.Cells[counter, startColumn];
                                        string value = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                                        parameterValues.Add(value);
                                        startColumn++;
                                    }

                                    var mainItem = mainItems.Where(m => m.TAGTYPES.Description == tagType &&
                                        m.LOTS.NAME == lot && m.MainItemTag == itemTag).FirstOrDefault();

                                    if (mainItem == null)
                                    {
                                        if (!string.IsNullOrEmpty(itemTag))
                                            msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_NOT_FOUND, itemTag) + lfcr;
                                        notEmpty = false;
                                        break;
                                    }

                                    var currentWp = wpList.Where(w => w.NAME == wp).FirstOrDefault();

                                    mainItem.TagClient = tagClient;
                                    mainItem.OPTRATIO = optRatio;
                                    if (currentWp != null)
                                        mainItem.WORKINGPACKAGESID = currentWp.IDWP;
                                    else
                                        mainItem.WORKINGPACKAGESID = null;
                                    mainItem.SubContractor = subContractor;
                                    mainItem.Remarks = remarks;


                                    var parameterValueList = _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters).Where(p =>
                                        p.MainItemsID == mainItem.MainItemID && p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).
                                        OrderBy(p => p.MainItemParametersID).ToList();

                                    if (parameterValueList != null)
                                    {
                                        if (parameterValueList.Count == parameterValues.Count)
                                        {
                                            for (int i = 0; i < parameterValues.Count; i++)
                                                parameterValueList[i].PARAMETERTEXT = parameterValues[i];
                                        }
                                    }

                                    await _context.SaveChangesAsync();

                                    counter++;
                                }
                                catch (Exception ex)
                                {
                                    notEmpty = false;
                                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message) + lfcr;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message) + lfcr;
                        }
                    }
                    else
                    {
                        msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED) + lfcr;
                    }
                }
            }
            catch { }

            return string.IsNullOrEmpty(msg) ? "Completed" : msg;
        }

        // GET: MAINITEMS/Create
        public async Task<IActionResult> MainItemTagTypes(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }


            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var obj = await _context.OBJECTCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();

            List<string> values = new List<string>();
            if (wp != null && wp.Count > 0)
                values.AddRange(wp.Select(n => n.NAME).ToList());
            ViewBag.WPList = values;

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            mainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);

            // Count General Parameters
            int generalType = _configuration.GetValue<int>("Items:ParameterGeneralID");
            var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID &&
                p.MAINITEMPARAMETERCATEGORIESID == generalType).OrderBy(p => p.ParameterID).ToList();


            // Search and assign main items parameters
            List<int> mainItemsIds = new List<int>();
            if (mainItems != null)
                mainItemsIds = mainItems.Select(m => m.MainItemID).ToList();

            List<MAINITEMPARAMETERVALUES> parameterValues = new List<MAINITEMPARAMETERVALUES>();
            if (mainItemsIds.Count < Utils.MAX_ORACLE_QUERY_LIST)
                parameterValues = await _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters).Where(p =>
                    mainItemsIds.Contains(p.MainItemsID) && p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).
                    OrderBy(p => p.MainItemParametersID).ToListAsync();
            else
            {
                IEnumerable<IEnumerable<int>> splitted = Utils.Chunk<int>(mainItemsIds, Utils.USED_ORACLE_QUERY_LIST);
                if (splitted != null)
                {
                    List<MAINITEMPARAMETERVALUES> currentList;
                    foreach (IEnumerable<int> split in splitted)
                    {
                        List<int> currentIds = split.ToList();
                        currentList = await _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters).Where(p =>
                            split.Contains(p.MainItemsID) && p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).
                            OrderBy(p => p.MainItemParametersID).ToListAsync();
                        if (currentList != null && currentList.Count > 0)
                        {
                            parameterValues.AddRange(currentList);
                        }
                    }
                }
            }
            if (mainItems != null)
            {
                foreach (MAINITEMS mainItem in mainItems)
                {
                    mainItem.WORKINGPACKAGELIST = wp;
                    mainItem.ParameterValues = parameterValues.Where(p => p.MainItemsID == mainItem.MainItemID).OrderBy(p => p.ValueID).ToList();
                }
            }

            // Update Main Items Replaced or combined
            List<MAINITEMS> itemsWithChilds = new List<MAINITEMS>();
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                        {
                            item.PARENT_TAG = parent.MainItemTag;
                            itemsWithChilds.Add(parent);
                        }
                    }
                }
            }
            itemsWithChilds = itemsWithChilds.GroupBy(m => m.MainItemID).Select(g => g.First()).ToList();
            if (itemsWithChilds != null && itemsWithChilds.Count > 0)
            {
                string childStr = string.Empty;
                foreach (MAINITEMS parent in itemsWithChilds)
                {
                    childStr = string.Empty;
                    var childs = mainItems.Where(m => m.PARENTID != null && m.PARENTID.HasValue && m.PARENTID.Value == parent.MainItemID).ToList();
                    if (childs != null)
                    {
                        foreach (var child in childs)
                            childStr += child.MainItemTag + ";";
                        parent.PARENT_TAG = childStr;
                    }
                }
            }

            // Search and assign BIM360 model names
            if (mainItems != null && mainItems.Count > 0)
            {
                var bim360StatusList = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID).ToListAsync();
                if (bim360StatusList != null && bim360StatusList.Count > 0)
                {
                    foreach (MAINITEMS mainItem in mainItems)
                    {
                        var bim360Status = bim360StatusList.Where(b => b.MainItemTag == mainItem.MainItemTag &&
                            b.TagType == mainItem.TAGTYPES.Description && b.Lot == mainItem.LOTS.NAME).ToList();
                        if (bim360Status != null && bim360Status.Count > 0)
                        {
                            mainItem.ModelName = bim360Status[0].ModelName;
                        }
                    }
                }
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.TotalParameters = parameters != null ? parameters.Count : 0;

            // Parameter titles
            SetViewBagParameters(parameters);

            return View(mainItems);
        }

        public async Task<IActionResult> MainItemData(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var obj = await _context.OBJECTCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LV01_Object_Code).Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            List<IMPORTANCESTATUS> statusList = await _context.IMPORTANCESTATUS.ToListAsync();
            mainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);

            // Count General Parameters
            int generalType = _configuration.GetValue<int>("Items:ParameterGeneralID");
            var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID &&
                p.MAINITEMPARAMETERCATEGORIESID == generalType).OrderBy(p => p.ParameterID).ToList();
            int totalParameters = parameters != null ? parameters.Count : 0;
            if (totalParameters > 0 && mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    bool update = false;
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID &&
                        m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).ToListAsync();
                    foreach (MAINITEMPARAMETERS currentParameter in parameters)
                    {
                        MAINITEMPARAMETERVALUES currentValue = null;
                        if (values != null)
                            currentValue = values.Where(d => d.MainItemParametersID == currentParameter.ParameterID).FirstOrDefault();
                        if (currentValue == null) // Add date
                        {
                            MAINITEMPARAMETERVALUES newVal = new MAINITEMPARAMETERVALUES();
                            newVal.MainItemParametersID = currentParameter.ParameterID;
                            newVal.MainItemsID = item.MainItemID;
                            newVal.UserID = user.USERID;
                            newVal.CreationDate = DateTime.UtcNow;
                            newVal.LastModified = DateTime.UtcNow;
                            _context.MAINITEMPARAMETERVALUES.Add(newVal);
                            update = true;
                        }
                    }
                    // Search invalid dates
                    List<int> valueIds = parameters.Select(v => v.ParameterID).ToList();
                    foreach (var val in values)
                        if (!valueIds.Contains(val.MainItemParametersID))
                        {
                            _context.Remove(val);
                            update = true;
                        }

                    if (update)
                    {
                        await _context.SaveChangesAsync();
                    }
                }
            }


            // Search and assign main items parameters
            List<int> mainItemsIds = new List<int>();
            if (mainItems != null)
                mainItemsIds = mainItems.Select(m => m.MainItemID).ToList();

            List<MAINITEMPARAMETERVALUES> parameterValues = new List<MAINITEMPARAMETERVALUES>();
            if (mainItemsIds.Count < Utils.MAX_ORACLE_QUERY_LIST)
                parameterValues = await _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters).Where(p =>
                    mainItemsIds.Contains(p.MainItemsID) && p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).
                    OrderBy(p => p.MainItemParametersID).ToListAsync();
            else
            {
                IEnumerable<IEnumerable<int>> splitted = Utils.Chunk<int>(mainItemsIds, Utils.USED_ORACLE_QUERY_LIST);
                if (splitted != null)
                {
                    List<MAINITEMPARAMETERVALUES> currentList;
                    foreach (IEnumerable<int> split in splitted)
                    {
                        List<int> currentIds = split.ToList();
                        currentList = await _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters).Where(p =>
                            split.Contains(p.MainItemsID) && p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType).
                            OrderBy(p => p.MainItemParametersID).ToListAsync();
                        if (currentList != null && currentList.Count > 0)
                        {
                            parameterValues.AddRange(currentList);
                        }
                    }
                }
            }

            List<MainItemGroup> mainItemGroups = new List<MainItemGroup>();
            if (mainItems != null)
            {
                List<string> tags = mainItems.Select(m => m.MainItemTag).Distinct().ToList();
                if (tags != null)
                {
                    foreach (string tag in tags)
                    {
                        List<MAINITEMS> itemList = mainItems.Where(m => m.MainItemTag == tag).ToList();
                        if (itemList != null)
                        {
                            foreach (MAINITEMS mainItem in itemList)
                            {
                                mainItem.WORKINGPACKAGELIST = wp;
                                mainItem.ParameterValues = parameterValues.Where(p => p.MainItemsID == mainItem.MainItemID).OrderBy(p => p.ValueID).ToList();
                                break;
                            }
                        }
                        MainItemGroup group = MainItemGroup.GetMainItemGroup(itemList);
                        if (group != null)
                        {
                            group.ImportanceStatusList = statusList;
                            if (itemList != null && itemList.Count > 0)
                            {
                                group.Parameter1Value = itemList[0].GetParameter1;
                                group.Parameter2Value = itemList[0].GetParameter2;
                                group.Parameter3Value = itemList[0].GetParameter3;
                                group.Parameter4Value = itemList[0].GetParameter4;
                                group.Parameter5Value = itemList[0].GetParameter5;
                                group.Parameter6Value = itemList[0].GetParameter6;
                                group.Parameter7Value = itemList[0].GetParameter7;
                                group.Parameter8Value = itemList[0].GetParameter8;
                                group.Parameter9Value = itemList[0].GetParameter9;
                                group.Parameter10Value = itemList[0].GetParameter10;
                            }
                            mainItemGroups.Add(group);
                        }
                    }
                }
            }

            if (mainItems != null)
            {
                foreach (MAINITEMS mainItem in mainItems)
                {
                    mainItem.WORKINGPACKAGELIST = wp;
                    mainItem.ParameterValues = parameterValues.Where(p => p.MainItemsID == mainItem.MainItemID).OrderBy(p => p.MainItemParametersID).ToList();
                    break;
                }
            }

            ViewBag.TotalParameters = parameters != null ? parameters.Count : 0;

            // Parameter titles
            SetViewBagParameters(parameters);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(mainItemGroups);
        }

        public async Task<IActionResult> MainItemSize(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();


            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            DatabaseCostants.InitValues(_configuration);

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var obj = await _context.OBJECTCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LV01_Object_Code).Where(x => x.PBS.ProjectID == project.ProjectID
                && !x.IsBalance && !x.IsDeleted && !x.IsReplaced &&
                (x.TagTypeID == DatabaseCostants.TagType_Foundation_ID || x.TagTypeID == DatabaseCostants.TagType_Elevation_ID ||
                x.TagTypeID == DatabaseCostants.TagType_Pile_ID || x.TagTypeID == DatabaseCostants.TagType_Steel_ID)).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            List<IMPORTANCESTATUS> statusList = await _context.IMPORTANCESTATUS.ToListAsync();
            mainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);

            List<MainItemGroup> mainItemGroups = new List<MainItemGroup>();
            if (mainItems != null)
            {
                List<string> tags = mainItems.Select(m => m.MainItemTag).Distinct().ToList();
                if (tags != null)
                {
                    foreach (string tag in tags)
                    {
                        List<MAINITEMS> itemList = mainItems.Where(m => m.MainItemTag == tag && !m.IsBalance).ToList();
                        MainItemGroup group = MainItemGroup.GetMainItemGroup(itemList);
                        if (group != null)
                        {
                            group.ImportanceStatusList = statusList;
                            mainItemGroups.Add(group);
                        }
                    }
                }
            }

            // Update Main Items Replaced or combined
            List<MAINITEMS> itemsWithChilds = new List<MAINITEMS>();
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                        {
                            item.PARENT_TAG = parent.MainItemTag;
                            itemsWithChilds.Add(parent);
                        }
                    }
                }
            }
            itemsWithChilds = itemsWithChilds.GroupBy(m => m.MainItemID).Select(g => g.First()).ToList();
            if (itemsWithChilds != null && itemsWithChilds.Count > 0)
            {
                string childStr = string.Empty;
                foreach (MAINITEMS parent in itemsWithChilds)
                {
                    childStr = string.Empty;
                    var childs = mainItems.Where(m => m.PARENTID != null && m.PARENTID.HasValue && m.PARENTID.Value == parent.MainItemID).ToList();
                    if (childs != null)
                    {
                        foreach (var child in childs)
                            childStr += child.MainItemTag + ";";
                        parent.PARENT_TAG = childStr;
                    }
                }
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(mainItemGroups);
        }

        private void SetViewBagParameters(List<MAINITEMPARAMETERS> parameters)
        {
            if (parameters == null)
                return;
            int index = 0;
            ViewBag.ParameterName1 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName2 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName3 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName4 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName5 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName6 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName7 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName8 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName9 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName10 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName11 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName12 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName13 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName14 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName15 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName16 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName17 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName18 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName19 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName20 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
        }

        [HttpPost]
        public async Task<string> SaveParameters(string code,
            string mainItemsStr,
            string tagtypesStr,
            string lotsStr,
            string wpsStr,
            string tagClientsStr,
            string subContractorsStr,
            string remarksStr,
            string optRatiosStr,
            string tcmcodesStr,
            string drawrevStr,
            string param1ValuesStr,
            string param2ValuesStr,
            string param3ValuesStr,
            string param4ValuesStr,
            string param5ValuesStr,
            string param6ValuesStr,
            string param7ValuesStr,
            string param8ValuesStr,
            string param9ValuesStr,
            string param10ValuesStr,
            string param11ValuesStr,
            string param12ValuesStr,
            string param13ValuesStr,
            string param14ValuesStr,
            string param15ValuesStr,
            string param16ValuesStr,
            string param17ValuesStr,
            string param18ValuesStr,
            string param19ValuesStr,
            string param20ValuesStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();
                    var wpsList = await _context.WORKINGPACKAGES.Where(w => w.ProjectID == project.ProjectID).ToListAsync();
                    int generalType = _configuration.GetValue<int>("Items:ParameterGeneralID");
                    var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID && p.MAINITEMPARAMETERCATEGORIESID == generalType).ToListAsync();
                    int totalParameters = parameters != null ? parameters.Count : 0;

                    string[] mainItems = Utils.SplitText(mainItemsStr);
                    string[] tagtypes = Utils.SplitText(tagtypesStr);
                    string[] lots = Utils.SplitText(lotsStr);
                    string[] wps = Utils.SplitText(wpsStr);
                    string[] tagClients = Utils.SplitText(tagClientsStr);
                    double[] optRatios = Utils.SplitVector(optRatiosStr);
                    string[] tcmcodes = Utils.SplitText(tcmcodesStr);
                    string[] drawrev = Utils.SplitText(drawrevStr);
                    string[] subContractors = Utils.SplitText(subContractorsStr);
                    string[] remarks = Utils.SplitText(remarksStr);
                    string[] param1Values = Utils.SplitText(param1ValuesStr);
                    string[] param2Values = Utils.SplitText(param2ValuesStr);
                    string[] param3Values = Utils.SplitText(param3ValuesStr);
                    string[] param4Values = Utils.SplitText(param4ValuesStr);
                    string[] param5Values = Utils.SplitText(param5ValuesStr);
                    string[] param6Values = Utils.SplitText(param6ValuesStr);
                    string[] param7Values = Utils.SplitText(param7ValuesStr);
                    string[] param8Values = Utils.SplitText(param8ValuesStr);
                    string[] param9Values = Utils.SplitText(param9ValuesStr);
                    string[] param10Values = Utils.SplitText(param10ValuesStr);
                    string[] param11Values = Utils.SplitText(param11ValuesStr);
                    string[] param12Values = Utils.SplitText(param12ValuesStr);
                    string[] param13Values = Utils.SplitText(param13ValuesStr);
                    string[] param14Values = Utils.SplitText(param14ValuesStr);
                    string[] param15Values = Utils.SplitText(param15ValuesStr);
                    string[] param16Values = Utils.SplitText(param16ValuesStr);
                    string[] param17Values = Utils.SplitText(param17ValuesStr);
                    string[] param18Values = Utils.SplitText(param18ValuesStr);
                    string[] param19Values = Utils.SplitText(param19ValuesStr);
                    string[] param20Values = Utils.SplitText(param20ValuesStr);

                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainItems)
                    {
                        var mainitem = await _context.MAINITEMS.Include(m => m.TAGTYPES)
                            .Include(m => m.LOTS)
                            .FirstOrDefaultAsync(m => m.MainItemTag == item &&
                            m.PBS.ProjectID == project.ProjectID && m.TAGTYPES.Description == tagtypes[counter] &&
                            m.LOTS.NAME == lots[counter]);
                        if (mainitem != null)
                        {
                            var wpsCurrent = wpsList.Where(w => w.NAME == wps[counter]).FirstOrDefault();
                            if (wpsCurrent != null)
                                mainitem.WORKINGPACKAGESID = wpsCurrent.IDWP;
                            mainitem.TagClient = tagClients[counter];
                            mainitem.OPTRATIO = optRatios[counter];
                            mainitem.TCMCode = tcmcodes[counter];
                            mainitem.DRAWREV = drawrev[counter];
                            mainitem.SubContractor = subContractors[counter];
                            mainitem.Remarks = remarks[counter];

                            // Set parameter values
                            var itemParameters = await _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters)
                                .Where(p => p.MainItemsID == mainitem.MainItemID &&
                                p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType)
                                .OrderBy(p => p.MainItemParametersID).ToListAsync();
                            if (itemParameters != null)
                            {
                                if (itemParameters.Count == totalParameters)
                                {
                                    for (int i = 0; i < totalParameters; i++)
                                    {
                                        string value = string.Empty;
                                        if (i == 0)
                                            value = param1Values[counter];
                                        else if (i == 1)
                                            value = param2Values[counter];
                                        else if (i == 2)
                                            value = param3Values[counter];
                                        else if (i == 3)
                                            value = param4Values[counter];
                                        else if (i == 4)
                                            value = param5Values[counter];
                                        else if (i == 5)
                                            value = param6Values[counter];
                                        else if (i == 6)
                                            value = param7Values[counter];
                                        else if (i == 7)
                                            value = param8Values[counter];
                                        else if (i == 8)
                                            value = param9Values[counter];
                                        else if (i == 9)
                                            value = param10Values[counter];
                                        else if (i == 10)
                                            value = param11Values[counter];
                                        else if (i == 11)
                                            value = param12Values[counter];
                                        else if (i == 12)
                                            value = param13Values[counter];
                                        else if (i == 13)
                                            value = param14Values[counter];
                                        else if (i == 14)
                                            value = param15Values[counter];
                                        else if (i == 15)
                                            value = param16Values[counter];
                                        else if (i == 16)
                                            value = param17Values[counter];
                                        else if (i == 17)
                                            value = param18Values[counter];
                                        else if (i == 18)
                                            value = param19Values[counter];
                                        else if (i == 19)
                                            value = param20Values[counter];

                                        itemParameters[i].PARAMETERTEXT = value;
                                    }
                                }
                            }

                            changed = true;
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.PARAMETERS_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        [HttpPost]
        public async Task<string> SaveGroupParameters(string code,
            string mainItemsStr,
            string tagClientsStr,
            string descriptionsStr,
            string equipmentTagsStr,
            string equipmentLayoutsStr,
            string lengthListStr,
            string widthListStr,
            string concreteHeightListStr,
            string concreteLevelListStr,
            string steelHeightListStr,
            string steelLevelListStr,
            string moduleListStr,
            string importanceListStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var importanceStatusList = await _context.IMPORTANCESTATUS.ToListAsync();

                    string[] mainItems = Utils.SplitText(mainItemsStr);
                    string[] tagClients = Utils.SplitText(tagClientsStr);
                    string[] descriptions = Utils.SplitText(descriptionsStr);
                    string[] equipmentTags = Utils.SplitText(equipmentTagsStr);
                    string[] equipmentLayouts = Utils.SplitText(equipmentLayoutsStr);
                    double[] lengthList = Utils.SplitVector(lengthListStr);
                    double[] widthList = Utils.SplitVector(widthListStr);
                    double[] concreteHeightList = Utils.SplitVector(concreteHeightListStr);
                    int[] concreteLevelList = Utils.SplitIntVector(concreteLevelListStr);
                    double[] steelHeightList = Utils.SplitVector(steelHeightListStr);
                    int[] steelLevelList = Utils.SplitIntVector(steelLevelListStr);
                    int[] moduleList = Utils.SplitIntVector(moduleListStr);
                    string[] importanceList = Utils.SplitText(importanceListStr);

                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainItems)
                    {
                        var mainitemList = await _context.MAINITEMS.Where(m => m.MainItemTag == item && m.PBS.ProjectID == project.ProjectID).ToListAsync();
                        if (mainitemList != null)
                        {
                            var currentImportance = importanceStatusList.Where(i => i.Description == importanceList[counter]).FirstOrDefault();
                            foreach (MAINITEMS mainItem in mainitemList)
                            {
                                mainItem.UserDescription = descriptions[counter];
                                mainItem.TagClient = tagClients[counter];
                                mainItem.EquipmentTag = equipmentTags[counter];
                                mainItem.EquipmentLayout = equipmentLayouts[counter];
                                mainItem.Length = lengthList[counter];
                                mainItem.Width = widthList[counter];
                                mainItem.ConcreteHeight = concreteHeightList[counter];
                                mainItem.ConcreteLevels = concreteLevelList[counter];
                                mainItem.SteelHeight = steelHeightList[counter];
                                mainItem.SteelLevels = steelLevelList[counter];
                                mainItem.MODULES = moduleList[counter];
                                if (currentImportance != null)
                                    mainItem.IMPORTANCESTATUSID = currentImportance.StatusID;
                                else
                                    mainItem.IMPORTANCESTATUSID = null;
                            }
                            changed = true;
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.PARAMETERS_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        [HttpPost]
        public async Task<string> SaveMainItemData(string code,
            string mainItemsStr,
            string tagClientsStr,
            string descriptionsStr,
            string equipmentTagsStr,
            string equipmentLayoutsStr,
            string param1ValuesStr,
            string param2ValuesStr,
            string param3ValuesStr,
            string param4ValuesStr,
            string param5ValuesStr,
            string param6ValuesStr,
            string param7ValuesStr,
            string param8ValuesStr,
            string param9ValuesStr,
            string param10ValuesStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var importanceStatusList = await _context.IMPORTANCESTATUS.ToListAsync();

                    string[] mainItems = Utils.SplitText(mainItemsStr);
                    string[] tagClients = Utils.SplitText(tagClientsStr);
                    string[] descriptions = Utils.SplitText(descriptionsStr);
                    string[] equipmentTags = Utils.SplitText(equipmentTagsStr);
                    string[] equipmentLayouts = Utils.SplitText(equipmentLayoutsStr);

                    string[] param1Values = Utils.SplitText(param1ValuesStr);
                    string[] param2Values = Utils.SplitText(param2ValuesStr);
                    string[] param3Values = Utils.SplitText(param3ValuesStr);
                    string[] param4Values = Utils.SplitText(param4ValuesStr);
                    string[] param5Values = Utils.SplitText(param5ValuesStr);
                    string[] param6Values = Utils.SplitText(param6ValuesStr);
                    string[] param7Values = Utils.SplitText(param7ValuesStr);
                    string[] param8Values = Utils.SplitText(param8ValuesStr);
                    string[] param9Values = Utils.SplitText(param9ValuesStr);
                    string[] param10Values = Utils.SplitText(param10ValuesStr);

                    int generalType = _configuration.GetValue<int>("Items:ParameterGeneralID");
                    var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID && p.MAINITEMPARAMETERCATEGORIESID == generalType).ToListAsync();
                    int totalParameters = parameters != null ? parameters.Count : 0;

                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainItems)
                    {
                        var mainitemList = await _context.MAINITEMS.Where(m => m.MainItemTag == item && m.PBS.ProjectID == project.ProjectID).ToListAsync();
                        if (mainitemList != null)
                        {
                            foreach (MAINITEMS mainItem in mainitemList)
                            {
                                mainItem.TagDescription = descriptions[counter];
                                mainItem.TagClient = tagClients[counter];
                                mainItem.EquipmentTag = equipmentTags[counter];
                                mainItem.EquipmentLayout = equipmentLayouts[counter];

                                // Set parameter values
                                var itemParameters = await _context.MAINITEMPARAMETERVALUES.Include(p => p.MainItemParameters)
                                        .Where(p => p.MainItemsID == mainItem.MainItemID &&
                                        p.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == generalType)
                                        .OrderBy(p => p.MainItemParametersID).ToListAsync();
                                if (itemParameters != null)
                                {
                                    if (itemParameters.Count == totalParameters)
                                    {
                                        for (int i = 0; i < totalParameters; i++)
                                        {
                                            string value = string.Empty;
                                            if (i == 0)
                                                value = param1Values[counter];
                                            else if (i == 1)
                                                value = param2Values[counter];
                                            else if (i == 2)
                                                value = param3Values[counter];
                                            else if (i == 3)
                                                value = param4Values[counter];
                                            else if (i == 4)
                                                value = param5Values[counter];
                                            else if (i == 5)
                                                value = param6Values[counter];
                                            else if (i == 6)
                                                value = param7Values[counter];
                                            else if (i == 7)
                                                value = param8Values[counter];
                                            else if (i == 8)
                                                value = param9Values[counter];
                                            else if (i == 9)
                                                value = param10Values[counter];

                                            itemParameters[i].PARAMETERTEXT = value;
                                        }
                                    }
                                }
                            }
                            changed = true;
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.PARAMETERS_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        [HttpPost]
        public async Task<string> SaveMainItemTagType(string code,
            string mainitemids,
            string wpstr,
            string drawnostr,
            string drawrevstr,
            string subcontractorstr,
            string remarkstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var existingWP = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    int[] mainItemIds = Utils.SplitIntVector(mainitemids);
                    if (mainitemids == null || mainitemids.Length == 0)
                        return _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_NOT_FOUND);

                    string[] wpList = Utils.SplitText(wpstr);
                    string[] drawList = Utils.SplitText(drawnostr);
                    string[] drawRevList = Utils.SplitText(drawrevstr);
                    string[] subcontractorList = Utils.SplitText(subcontractorstr);
                    string[] remarkList = Utils.SplitText(remarkstr);

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in mainItemIds)
                    {
                        var mainitem = await _context.MAINITEMS.Where(m => m.MainItemID == id).FirstOrDefaultAsync();
                        if (mainitem != null)
                        {
                            mainitem.DrawNo = drawList[counter];
                            mainitem.DRAWREV = drawRevList[counter];
                            mainitem.SubContractor = subcontractorList[counter];
                            mainitem.Remarks = remarkList[counter];

                            var currentWP = existingWP.Where(w => w.NAME == wpList[counter]).FirstOrDefault();
                            if (currentWP != null)
                                mainitem.WORKINGPACKAGESID = currentWP.IDWP;
                            else
                                mainitem.WORKINGPACKAGESID = null;

                            changed = true;
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.PARAMETERS_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        [HttpPost]
        public async Task<string> SaveMainItemSize(string code,
            string mainitemids,
            string lengthstr,
            string widthstr,
            string aaheightstr,
            string aalevelsstr,
            string aiheightstr,
            string ailevelsstr,
            string modulestr,
            string importancestr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var existingWP = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    string[] mainItemIds = Utils.SplitText(mainitemids);
                    if (mainitemids == null || mainitemids.Length == 0)
                        return _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_NOT_FOUND);

                    double[] lengthList = Utils.SplitVector(lengthstr);
                    double[] widthList = Utils.SplitVector(widthstr);
                    double[] aaHeightList = Utils.SplitVector(aaheightstr);
                    int[] aaLevelList = Utils.SplitIntVector(aalevelsstr);
                    double[] aiHeightList = Utils.SplitVector(aiheightstr);
                    int[] aiLevelList = Utils.SplitIntVector(ailevelsstr);
                    int[] moduleList = Utils.SplitIntVector(modulestr);
                    string[] importanceList = Utils.SplitText(importancestr);

                    var importanceStatusList = await _context.IMPORTANCESTATUS.ToListAsync();

                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainItemIds)
                    {
                        var mainitemList = await _context.MAINITEMS.Where(m => m.MainItemTag == item && m.PBS.ProjectID == project.ProjectID).ToListAsync();
                        if (mainitemList != null)
                        {
                            foreach (MAINITEMS mainItem in mainitemList)
                            {
                                mainItem.Length = lengthList[counter];
                                mainItem.Width = widthList[counter];
                                mainItem.ConcreteHeight = aaHeightList[counter];
                                mainItem.ConcreteLevels = aaLevelList[counter];
                                mainItem.SteelHeight = aiHeightList[counter];
                                mainItem.SteelLevels = aiLevelList[counter];
                                mainItem.MODULES = moduleList[counter];

                                var current = importanceStatusList.Where(p => p.Description == importanceList[counter]).FirstOrDefault();
                                if (current != null)
                                    mainItem.IMPORTANCESTATUSID = current.StatusID;
                                else
                                    mainItem.IMPORTANCESTATUSID = null;

                                changed = true;
                            }
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.PARAMETERS_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        // GET: MAINITEMS/Replace
        public async Task<IActionResult> Replace(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).OrderBy(p => p.Code).ToListAsync();
            var materials = await _context.MATERIALWORKGROUPS.OrderBy(m => m.GroupCode).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;
            itemListCreation.ObjectCodes = objects;
            itemListCreation.Materials = materials;

            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS)
                    .Include(m => m.LV01_Object_Code)
                    .Include(m => m.LV01_Material_Work_Group)
                    .Include(m => m.TAGTYPES)
                    .Include(m => m.PBS)
                    .Include(m => m.WORKINGPACKAGES)
                    .Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();

            List<string> descriptions = new List<string>();
            if (mainItems != null)
            {
                foreach (MAINITEMS mainItem in mainItems)
                    descriptions.Add(mainItem.Description);
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.Items = descriptions;

            return View(itemListCreation);
        }


        // GET: MAINITEMS/Combine
        public async Task<IActionResult> Combine(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).OrderBy(p => p.Code).ToListAsync();
            var materials = await _context.MATERIALWORKGROUPS.OrderBy(m => m.GroupCode).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES).Include(m => m.PBS).
                Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;
            itemListCreation.ObjectCodes = objects;
            itemListCreation.Materials = materials;
            itemListCreation.MainItems = mainItems;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(itemListCreation);
        }

        private async Task<List<MAINITEMS>> AddMainItemAutomaticallyToContext(string area, string wp, string objectcode,
            string material, bool considerMaterial, string tagtype, int totalItems, int projectId, USERS user,
            LOTS lot, VENDORS vendor, MATERIALREQUESTS mr, PURCHASEORDERS po, int tagTypeSteel,
            string code, int startNumber)
        {
            List<MAINITEMS> mAINITEMs = new List<MAINITEMS>();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == projectId);
            var materialitem = await _context.MATERIALWORKGROUPS.FirstOrDefaultAsync(x => x.GroupCode == material);
            var objects = await _context.OBJECTCODES.FirstOrDefaultAsync(x => x.Code == objectcode && x.ProjectID == project.ProjectID);
            var tagTypes = await _context.TAGTYPES.FirstOrDefaultAsync(x => x.Description == tagtype);
            var pbs = await _context.PBS.FirstOrDefaultAsync(x => x.Area == area && x.ProjectID == projectId);
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();
            var wpCurrent = await _context.WORKINGPACKAGES.Where(w => w.NAME == wp && w.ProjectID == project.ProjectID).FirstOrDefaultAsync();

            bool isSteel = tagTypes.TagTypeID == tagTypeSteel;

            MAINITEMS item = new MAINITEMS();
            item.PBS = pbs;
            item.PBSID = item.PBS.PBSID;
            item.LV01_Object_Code = objects;
            item.LV01_Object_CodeID = objects.CodeID;
            item.LV01_Material_Work_Group = materialitem;
            item.LV01_Material_Work_GroupID = materialitem?.GroupID;
            item.TAGTYPES = tagTypes;
            item.TagTypeID = tagTypes.TagTypeID;
            item.WORKINGPACKAGESID = wpCurrent?.IDWP;
            item.AddedManually = 0;
            item.BALANCE = 0;
            item.MAINITEMSTATUSID = MainItemsCostants.NONE;

            // Set User and Date
            item.UserID = user.USERID;
            item.CreationDate = DateTime.UtcNow;
            item.LastModified = DateTime.UtcNow;

            if (isSteel)
            {
                item.VENDORSID = vendor.IDVENDOR;
                item.MATERIALREQUESTSID = mr.IDMR;
                item.PURCHASEORDERSID = po.IDPO;
                item.LOTSID = lot.IDLOT;
            }
            else
            {
                item.LOTSID = lot.IDLOT;
            }

            int startIndex = startNumber;
            if (string.IsNullOrEmpty(code))
            {
                bool found = true;
                while (found)
                {
                    found = ContainsItem(item, startIndex, mainItems, false);
                    if (found)
                        startIndex++;
                    else
                        found = false;
                }
            }
            else
            {

            }

            if (totalItems > 0)
            {
                for (int i = 0; i < totalItems; i++)
                {
                    item = new MAINITEMS();
                    item.PBS = pbs;
                    item.PBSID = item.PBS.PBSID;
                    item.LV01_Object_Code = objects;
                    item.LV01_Object_CodeID = objects.CodeID;
                    item.LV01_Material_Work_Group = materialitem;
                    item.LV01_Material_Work_GroupID = materialitem?.GroupID;
                    item.TAGTYPES = tagTypes;
                    item.TagTypeID = tagTypes.TagTypeID;
                    item.WORKINGPACKAGESID = wpCurrent?.IDWP;
                    string tag = item.CalculateMainTag(startIndex, considerMaterial);
                    item.MainItemTag = tag;
                    item.AddedManually = 0;
                    item.BALANCE = 0;

                    // Set User and Date
                    item.UserID = user.USERID;
                    item.CreationDate = DateTime.UtcNow;
                    item.LastModified = DateTime.UtcNow;

                    if (isSteel)
                    {
                        item.VENDORSID = vendor.IDVENDOR;
                        item.MATERIALREQUESTSID = mr.IDMR;
                        item.PURCHASEORDERSID = po.IDPO;
                        item.LOTSID = lot.IDLOT;
                    }
                    else
                    {
                        item.LOTSID = lot.IDLOT;
                    }

                    startIndex++;

                    mAINITEMs.Add(item);
                    try
                    {
                        _context.MAINITEMS.Add(item);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.Print(ex.Message);
                    }
                }
            }
            return mAINITEMs;
        }

        [HttpPost]
        public async Task<List<MainItemData>> GetMainItems(int? projectId)
        {
            List<MainItemData> items = new List<MainItemData>();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == projectId);
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            if (project != null)
            {
                var mainItems = await _context.MAINITEMS.Include(m => m.LOTS)
                    .Include(m => m.LV01_Object_Code)
                    .Include(m => m.LV01_Material_Work_Group)
                    .Include(m => m.TAGTYPES)
                    .Include(m => m.PBS)
                    .Include(m => m.WORKINGPACKAGES)
                    .Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                if (mainItems != null)
                {
                    foreach (var mainItem in mainItems)
                        items.Add(mainItem.GetItemData);
                }
            }

            return items;
        }


        [HttpPost]
        public async Task<string> CreateElementAutomatically(string area, string objectcode,
            string material, bool materialChecked, string tagtype, int totalItems, string code, string lot,
            int sequenceNumber)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                bool valid = !String.IsNullOrEmpty(area) && !String.IsNullOrEmpty(objectcode);
                List<string> areas = null;
                List<string> codes = null;
                List<string> tagtypes = null;
                if (valid)
                {
                    areas = JsonConvert.DeserializeObject<List<string>>(area);
                    codes = JsonConvert.DeserializeObject<List<string>>(objectcode);
                    tagtypes = JsonConvert.DeserializeObject<List<string>>(tagtype);
                }
                valid &= areas != null && areas.Count > 0;
                valid &= codes != null && codes.Count > 0;
                valid &= tagtypes != null && tagtypes.Count > 0;

                PLANNINGS pLANNINGS = null;
                MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                MAINITEMDRAWINGS mainItemDrawing = null;
                HOLDS mainItemHold = null;
                STEEL_QUANTITIES steelQty = null;
                STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;
                int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");
                int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                string lotName = _configuration.GetValue<string>("Items:DefaultLotName");
                string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == User.Identity.Name.ToUpper());
                var defaultLot = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotName).FirstOrDefaultAsync();
                var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();
                var lotItem = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lot).FirstOrDefaultAsync();
                var tagTypes = await _context.TAGTYPES.FirstOrDefaultAsync(x => x.Description == tagtype);
                if (!String.IsNullOrEmpty(lot))
                {
                    if (lotItem == null)
                    {
                        LOTS newLot = LOTS.GetNewLot(lot, project.ProjectID, user.USERID.Value);
                        _context.LOTS.Add(newLot);
                        await _context.SaveChangesAsync();
                        lotItem = newLot;
                    }
                }
                else
                {
                    lotItem = defaultLot;
                }

                if (valid)
                {
                    List<MAINITEMS> mAINITEMs = new List<MAINITEMS>();
                    List<MAINITEMS> currentMAINITEMs = new List<MAINITEMS>();

                    string name = User.Identity.Name;

                    foreach (string a in areas)
                    {
                        foreach (string c in codes)
                        {
                            foreach (string currentTagType in tagtypes)
                            {
                                currentMAINITEMs = await AddMainItemAutomaticallyToContext(a, string.Empty, c, material, materialChecked, currentTagType,
                                    totalItems, project.ProjectID, user, lotItem, vendor, mr, po, tagTypeSteel, string.Empty, sequenceNumber);
                                if (currentMAINITEMs != null && currentMAINITEMs.Count > 0)
                                    mAINITEMs.AddRange(currentMAINITEMs);
                            }
                        }
                    }

                    var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();


                    if (mAINITEMs != null && mAINITEMs.Count > 0)
                    {
                        STEELPLANNINGS steelPlanning = null;
                        using (var dbContextTransaction = _context.Database.BeginTransaction())
                        {
                            try
                            {
                                int result = _context.SaveChanges(true);
                                foreach (MAINITEMS item in mAINITEMs)
                                {
                                    // Add parameter if existing
                                    if (parameters != null && parameters.Count > 0)
                                    {
                                        foreach (MAINITEMPARAMETERS parameter in parameters)
                                        {
                                            MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                            mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                            mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                            mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                            mAINITEMPARAMETERVALUES.MainItemsID = item.MainItemID;
                                            mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                            _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                        }
                                        await _context.SaveChangesAsync();
                                    }

                                    // Add empty planning
                                    pLANNINGS = new PLANNINGS();
                                    pLANNINGS.MainItemId = item.MainItemID;
                                    pLANNINGS.UserID = user.USERID;
                                    pLANNINGS.CreationDate = DateTime.UtcNow;
                                    pLANNINGS.LastModified = DateTime.UtcNow;

                                    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                    mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                                    mainItemDrawing = new MAINITEMDRAWINGS();
                                    mainItemDrawing.UserID = user.USERID;
                                    mainItemDrawing.CreationDate = DateTime.UtcNow;
                                    mainItemDrawing.LastModified = DateTime.UtcNow;
                                    mainItemDrawing.MainItemID = item.MainItemID;

                                    //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);

                                    _context.PLANNINGS.Add(pLANNINGS);
                                    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                    //_context.HOLDS.Add(mainItemHold);

                                    // Add BIM360 Item
                                    ITEMSLISTCHECKS bim360Item = new ITEMSLISTCHECKS();
                                    bim360Item.CreationDate = DateTime.UtcNow;
                                    bim360Item.LastModified = DateTime.UtcNow;
                                    bim360Item.UserID = user.USERID;
                                    bim360Item.MainItemID = item.MainItemID;
                                    bim360Item.ModelName = string.Empty;
                                    _context.ITEMSLISTCHECKS.Add(bim360Item);




                                    //    if (item.TagTypeID != tagTypeSteel)
                                    //    {
                                    //        // Add empty planning
                                    //        pLANNINGS = new PLANNINGS();
                                    //        pLANNINGS.MainItemId = item.MainItemID;
                                    //        pLANNINGS.UserID = user.USERID;
                                    //        pLANNINGS.CreationDate = DateTime.UtcNow;
                                    //        pLANNINGS.LastModified = DateTime.UtcNow;

                                    //        mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                    //        mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                    //        mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                    //        mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                    //        mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                                    //        mainItemDrawing = new MAINITEMDRAWINGS();
                                    //        mainItemDrawing.UserID = user.USERID;
                                    //        mainItemDrawing.CreationDate = DateTime.UtcNow;
                                    //        mainItemDrawing.LastModified = DateTime.UtcNow;
                                    //        mainItemDrawing.MainItemID = item.MainItemID;

                                    //        //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);

                                    //        _context.PLANNINGS.Add(pLANNINGS);
                                    //        _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                    //        _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                    //        //_context.HOLDS.Add(mainItemHold);
                                    //    }
                                    //    else
                                    //    {
                                    //        steelPlanning = new STEELPLANNINGS();
                                    //        steelPlanning.MainItemId = item.MainItemID;
                                    //        steelPlanning.UserID = user.USERID;
                                    //        steelPlanning.CreationDate = DateTime.UtcNow;
                                    //        steelPlanning.LastModified = DateTime.UtcNow;
                                    //        _context.STEELPLANNINGS.Add(steelPlanning);

                                    //        steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                    //        steelEstimateQty.MainItemId = item.MainItemID;
                                    //        steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                    //        steelEstimateQty.IFF_E_QTY = 0.0;
                                    //        steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                    //        steelEstimateQty.IFP_E_QTY = 0.0;
                                    //        steelEstimateQty.PO_E_QTY = 0.0;
                                    //        steelEstimateQty.UserID = user.USERID;
                                    //        steelEstimateQty.CreationDate = DateTime.UtcNow;
                                    //        steelEstimateQty.LastModified = DateTime.UtcNow;
                                    //        _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                    //        mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                    //        mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                    //        mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                    //        mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                    //        mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                    //        _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                    //        if (commodities != null)
                                    //        {
                                    //            foreach (COMMODITYCODES commodityCode in commodities)
                                    //            {
                                    //                steelQty = new STEEL_QUANTITIES();
                                    //                steelQty.MainItemId = item.MainItemID;
                                    //                steelQty.CodeId = commodityCode.CodeID;
                                    //                steelQty.QTY = 0.0;
                                    //                steelQty.UserID = user.USERID;
                                    //                steelQty.CreationDate = DateTime.UtcNow;
                                    //                steelQty.LastModified = DateTime.UtcNow;
                                    //                _context.STEEL_QUANTITIES.Add(steelQty);
                                    //            }
                                    //        }

                                    //        mainItemDrawing = new MAINITEMDRAWINGS();
                                    //        mainItemDrawing.UserID = user.USERID;
                                    //        mainItemDrawing.CreationDate = DateTime.UtcNow;
                                    //        mainItemDrawing.LastModified = DateTime.UtcNow;
                                    //        mainItemDrawing.MainItemID = item.MainItemID;

                                    //        _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                    //    }
                                }
                                result = _context.SaveChanges(true);
                                dbContextTransaction.Commit();
                                msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_CREATED);
                            }
                            catch (Exception ex)
                            {
                                msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED, ex.Message);
                                dbContextTransaction.Rollback();
                            }
                        }
                    }
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> CombineItems(string items, string itemCombined, string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Include(m => m.TAGTYPES).Include(m => m.LOTS)
                    .Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                List<string> itemsToCombine = JsonConvert.DeserializeObject<List<string>>(items);
                List<MAINITEMS> mainItemsToCombine = new List<MAINITEMS>();
                double qtyNextCE = 0.0;

                if (itemsToCombine != null)
                {
                    foreach (string description in itemsToCombine)
                    {
                        var mainItem = mainItems.Where(m => m.CompleteDescription == description).FirstOrDefault();
                        if (mainItem != null)
                        {
                            mainItemsToCombine.Add(mainItem);
                            var qtyItem = await _context.MAIN_ITEM_QUANTITY.Where(m => m.MainItemId == mainItem.MainItemID).FirstOrDefaultAsync();
                            if (qtyItem != null)
                            {
                                if (qtyItem.QTY_NEXT_CE != null && qtyItem.QTY_NEXT_CE.HasValue)
                                    qtyNextCE += qtyItem.QTY_NEXT_CE.Value;
                            }
                        }
                        else
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_NOT_FOUND);
                            return msg;
                        }
                    }
                    if (items.Contains(itemCombined))
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                        return msg;
                    }
                }
                MAINITEMS combinedItem = mainItems.Where(m => m.CompleteDescription == itemCombined).FirstOrDefault();
                if (combinedItem == null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_NOT_FOUND);
                    return msg;
                }

                if (mainItemsToCombine != null)
                    mainItemsToCombine = mainItemsToCombine.Where(m => m.MainItemID != combinedItem.MainItemID).ToList();
                if (mainItemsToCombine.Count < 1)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                    return msg;
                }

                List<HOLDS> holds = new List<HOLDS>();
                foreach (var item in mainItemsToCombine)
                {
                    item.MAINITEMSTATUSID = MainItemsCostants.REPLACED;
                    item.PARENTID = combinedItem.MainItemID;

                    var currentHolds = await _context.HOLDS.Where(h => h.MainItemId == item.MainItemID).ToListAsync();
                    if (currentHolds != null && currentHolds.Count > 0)
                        holds.AddRange(currentHolds);
                }
                combinedItem.MAINITEMSTATUSID = MainItemsCostants.COMBINED;
                combinedItem.PARENTID = null;

                var qty = await _context.MAIN_ITEM_QUANTITY.Where(m => m.MainItemId == combinedItem.MainItemID).FirstOrDefaultAsync();
                if (qty != null)
                {
                    if (qty.QTY_NEXT_CE != null && qty.QTY_NEXT_CE.HasValue)
                        qty.QTY_NEXT_CE += qtyNextCE;
                    else
                        qty.QTY_NEXT_CE = qtyNextCE;
                }

                // Move holds to item combined
                List<HOLDS> holdCombinedList = await _context.HOLDS.Where(h => h.MainItemId == combinedItem.MainItemID).ToListAsync();
                List<HOLDS> toBeDeleted = new List<HOLDS>();
                if (holds != null && holds.Count > 0)
                {
                    List<int> docTypes = new List<int>();
                    foreach (HOLDS hold in holds)
                    {
                        HOLDS newHold = null;
                        if (docTypes.Contains(hold.HOLDTYPESID.Value))
                        {
                            toBeDeleted.Add(hold);
                            continue;
                        }
                        if (holdCombinedList != null)
                            newHold = holdCombinedList.Where(h => h.HOLDTYPESID.Value == hold.HOLDTYPESID.Value).FirstOrDefault();
                        if (newHold == null)
                        {
                            hold.MainItemId = combinedItem.MainItemID;
                            var holdSameTypeList = holds.Where(d => d.HOLDTYPESID.Value == hold.HOLDTYPESID.Value).ToList();
                            double qtyNew = 0.0;
                            if (holdSameTypeList != null)
                                foreach (var h in holdSameTypeList)
                                    if (h.QTYHOLD != null && h.QTYHOLD.HasValue)
                                        qtyNew += h.QTYHOLD.Value;
                            hold.QTYHOLD = qtyNew;
                        }
                        else
                        {
                            var holdSameTypeList = holds.Where(d => d.HOLDTYPESID.Value == hold.HOLDTYPESID.Value).ToList();
                            double qtyNew = 0.0;
                            if (holdSameTypeList != null)
                                foreach (var h in holdSameTypeList)
                                    if (h.QTYHOLD != null && h.QTYHOLD.HasValue)
                                        qtyNew += h.QTYHOLD.Value;
                            if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue)
                                newHold.QTYHOLD += qtyNew;
                            toBeDeleted.Add(hold);
                        }
                        docTypes.Add(hold.HOLDTYPESID.Value);
                    }
                    if (toBeDeleted.Count > 0)
                        _context.HOLDS.RemoveRange(toBeDeleted);
                    await _context.SaveChangesAsync();
                }

                foreach (var item in mainItemsToCombine)
                {
                    var currentHolds = await _context.HOLDS.Where(h => h.MainItemId == item.MainItemID).ToListAsync();
                    if (currentHolds != null && currentHolds.Count > 0)
                        holds.AddRange(currentHolds);
                }
                if (holds != null)
                {
                    foreach (HOLDS hold in holds)
                        hold.MainItemId = combinedItem.MainItemID;
                }

                // Delete existing drawing
                List<DRAWINGS> drawings = new List<DRAWINGS>();
                foreach (var item in mainItemsToCombine)
                {
                    var currentDrawings = await _context.DRAWINGS.Where(h => h.ProjectID == project.ProjectID && h.MainItemTag == item.MainItemTag).ToListAsync();
                    if (currentDrawings != null && currentDrawings.Count > 0)
                        drawings.AddRange(currentDrawings);
                }
                if (drawings.Count > 0)
                    _context.DRAWINGS.RemoveRange(drawings);

                await _context.SaveChangesAsync();
                msg = "Combined";
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> DeleteItems(string items, string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Include(m => m.TAGTYPES).Include(m => m.LOTS)
                    .Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                List<string> itemsToDelete = JsonConvert.DeserializeObject<List<string>>(items);
                List<DRAWINGS> drawings = new List<DRAWINGS>();
                bool changed = false;
                if (itemsToDelete != null)
                {
                    foreach (string description in itemsToDelete)
                    {
                        var mainItem = mainItems.Where(m => m.CompleteDescription == description).FirstOrDefault();
                        if (mainItem != null)
                        {
                            _context.MAINITEMS.Remove(mainItem);
                            changed = true;

                            // Delete existing drawing
                            var currentDrawings = await _context.DRAWINGS.Where(h => h.ProjectID == project.ProjectID && h.MainItemTag == mainItem.MainItemTag).ToListAsync();
                            if (currentDrawings != null && currentDrawings.Count > 0)
                                drawings.AddRange(currentDrawings);
                        }
                    }
                }
                if (drawings.Count > 0)
                {
                    _context.DRAWINGS.RemoveRange(drawings);
                }

                if (changed)
                    await _context.SaveChangesAsync();
                msg = "Deleted";
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> CreateElementManual(string area,
            string tagdescription,
            string tagclient,
            string tagtype,
            string code,
            string material,
            bool materialChecked,
            string sequenceNumber,
            string objectcode,
            string lot)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                int projectId = project.ProjectID;
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                var tagTypes = await _context.TAGTYPES.ToListAsync();
                var tagTypeSelected = await _context.TAGTYPES.FirstOrDefaultAsync(x => x.Description == tagtype);
                var pbs = await _context.PBS.Where(x => x.ProjectID == projectId).ToListAsync();
                var selectedPbs = await _context.PBS.FirstOrDefaultAsync(x => x.Area == area && x.ProjectID == projectId);
                var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == projectId).ToListAsync();

                PLANNINGS pLANNINGS = null;
                STEELPLANNINGS steelPlanning = null;
                MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                MAINITEMDRAWINGS mainItemDrawing = null;
                HOLDS mainItemHold = null;
                STEEL_QUANTITIES steelQty = null;
                STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;
                int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");
                int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
                string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                var lotDefault = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameDefault).FirstOrDefaultAsync();
                LOTS currentLot = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lot).FirstOrDefaultAsync();
                if (currentLot == null && !string.IsNullOrEmpty(lot))
                {
                    currentLot = LOTS.GetNewLot(lot, project.ProjectID, user.USERID.Value);
                    _context.LOTS.Add(currentLot);
                }
                if (currentLot == null)
                    currentLot = lotDefault;

                var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();
                var objectCode = await _context.OBJECTCODES.Where(c => c.ProjectID == project.ProjectID && c.Code == objectcode).FirstOrDefaultAsync();
                if (objectcode == null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);
                    return msg;
                }
                var materialitem = await _context.MATERIALWORKGROUPS.FirstOrDefaultAsync(x => x.GroupCode == material);

                bool isSteel = false;
                if (project != null && tagTypeSelected != null && selectedPbs != null)
                {
                    isSteel = tagTypeSelected.TagTypeID == tagTypeSteel;

                    MAINITEMS item = new MAINITEMS();
                    item.PBS = selectedPbs;
                    item.PBSID = item.PBS.PBSID;
                    item.TAGTYPES = tagTypeSelected;
                    item.TagTypeID = tagTypeSelected.TagTypeID;
                    item.TagDescription = tagdescription;
                    item.TagClient = tagclient;
                    item.AddedManually = 1;
                    item.LV01_Object_CodeID = objectCode.ProjectID;
                    item.LV01_Object_Code = objectCode;
                    item.LV01_Material_Work_GroupID = materialitem?.GroupID;
                    item.LV01_Material_Work_Group = materialitem;
                    item.BALANCE = 0;
                    item.MAINITEMSTATUSID = MainItemsCostants.NONE;

                    if (!string.IsNullOrEmpty(sequenceNumber))
                    {
                        item.MainItemTag = item.CalculateMainTag(sequenceNumber, materialChecked);

                        bool existing = ContainsItem(item, sequenceNumber, lot, mainItems, materialChecked);
                        if (existing)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING, item.MainItemTag);
                            return msg;
                        }
                    }
                    else
                    {
                        int startIndex = 1;
                        bool found = true;
                        while (found)
                        {
                            found = ContainsItem(item, startIndex, mainItems, materialChecked);
                            if (found)
                                startIndex++;
                            else
                                found = false;
                        }

                        item.MainItemTag = item.CalculateMainTag(startIndex, materialChecked);
                    }

                    // Set User and Date
                    item.UserID = user.USERID;
                    item.CreationDate = DateTime.UtcNow;
                    item.LastModified = DateTime.UtcNow;

                    if (isSteel)
                    {
                        item.VENDORSID = vendor.IDVENDOR;
                        item.MATERIALREQUESTSID = mr.IDMR;
                        item.PURCHASEORDERSID = po.IDPO;
                        item.LOTSID = currentLot.IDLOT;
                    }
                    else
                    {
                        item.LOTSID = currentLot.IDLOT;
                    }

                    _context.MAINITEMS.Add(item);

                    var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();

                    using (var dbContextTransaction = _context.Database.BeginTransaction())
                    {
                        try
                        {
                            int result = _context.SaveChanges(true);

                            // Add parameter if existing
                            if (parameters != null && parameters.Count > 0)
                            {
                                foreach (MAINITEMPARAMETERS parameter in parameters)
                                {
                                    MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                    mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                    mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                    mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                    mAINITEMPARAMETERVALUES.MainItemsID = item.MainItemID;
                                    mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                    _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                }
                                await _context.SaveChangesAsync();
                            }

                            // Add empty planning
                            pLANNINGS = new PLANNINGS();
                            pLANNINGS.MainItemId = item.MainItemID;
                            pLANNINGS.UserID = user.USERID;
                            pLANNINGS.CreationDate = DateTime.UtcNow;
                            pLANNINGS.LastModified = DateTime.UtcNow;
                            _context.PLANNINGS.Add(pLANNINGS);

                            mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                            mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                            mAIN_ITEM_QUANTITY.UserID = user.USERID;
                            mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                            mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                            _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                            mainItemDrawing = new MAINITEMDRAWINGS();
                            mainItemDrawing.UserID = user.USERID;
                            mainItemDrawing.CreationDate = DateTime.UtcNow;
                            mainItemDrawing.LastModified = DateTime.UtcNow;
                            mainItemDrawing.MainItemID = item.MainItemID;
                            _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                            // Add Missing Item BIM360
                            ITEMSLISTCHECKS bim360Item = new ITEMSLISTCHECKS();
                            bim360Item.CreationDate = DateTime.UtcNow;
                            bim360Item.LastModified = DateTime.UtcNow;
                            bim360Item.UserID = user.USERID;
                            bim360Item.MainItemID = item.MainItemID;
                            bim360Item.ModelName = string.Empty;
                            _context.ITEMSLISTCHECKS.Add(bim360Item);

                            //if (!isSteel)
                            //{
                            //    // Add empty planning
                            //    pLANNINGS = new PLANNINGS();
                            //    pLANNINGS.MainItemId = item.MainItemID;
                            //    pLANNINGS.UserID = user.USERID;
                            //    pLANNINGS.CreationDate = DateTime.UtcNow;
                            //    pLANNINGS.LastModified = DateTime.UtcNow;
                            //    _context.PLANNINGS.Add(pLANNINGS);

                            //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                            //    mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                            //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                            //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                            //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                            //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                            //    mainItemDrawing = new MAINITEMDRAWINGS();
                            //    mainItemDrawing.UserID = user.USERID;
                            //    mainItemDrawing.CreationDate = DateTime.UtcNow;
                            //    mainItemDrawing.LastModified = DateTime.UtcNow;
                            //    mainItemDrawing.MainItemID = item.MainItemID;
                            //    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                            //    //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);
                            //    //_context.HOLDS.Add(mainItemHold);
                            //}
                            //else
                            //{
                            //    steelPlanning = new STEELPLANNINGS();
                            //    steelPlanning.MainItemId = item.MainItemID;
                            //    steelPlanning.UserID = user.USERID;
                            //    steelPlanning.CreationDate = DateTime.UtcNow;
                            //    steelPlanning.LastModified = DateTime.UtcNow;
                            //    _context.STEELPLANNINGS.Add(steelPlanning);

                            //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                            //    steelEstimateQty.MainItemId = item.MainItemID;
                            //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                            //    steelEstimateQty.IFF_E_QTY = 0.0;
                            //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                            //    steelEstimateQty.IFP_E_QTY = 0.0;
                            //    steelEstimateQty.PO_E_QTY = 0.0;
                            //    steelEstimateQty.UserID = user.USERID;
                            //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                            //    steelEstimateQty.LastModified = DateTime.UtcNow;
                            //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);


                            //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                            //    mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                            //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                            //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                            //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                            //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                            //    mainItemDrawing = new MAINITEMDRAWINGS();
                            //    mainItemDrawing.UserID = user.USERID;
                            //    mainItemDrawing.CreationDate = DateTime.UtcNow;
                            //    mainItemDrawing.LastModified = DateTime.UtcNow;
                            //    mainItemDrawing.MainItemID = item.MainItemID;
                            //    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                            //    if (commodities != null)
                            //    {
                            //        foreach (COMMODITYCODES commodityCode in commodities)
                            //        {
                            //            steelQty = new STEEL_QUANTITIES();
                            //            steelQty.MainItemId = item.MainItemID;
                            //            steelQty.CodeId = commodityCode.CodeID;
                            //            steelQty.QTY = 0.0;
                            //            steelQty.UserID = user.USERID;
                            //            steelQty.CreationDate = DateTime.UtcNow;
                            //            steelQty.LastModified = DateTime.UtcNow;
                            //            _context.STEEL_QUANTITIES.Add(steelQty);
                            //        }
                            //    }
                            //}

                            result = _context.SaveChanges(true);

                            dbContextTransaction.Commit();
                            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_CREATED);
                        }
                        catch (Exception ex)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED, ex.Message);
                            dbContextTransaction.Rollback();
                            return msg;
                        }
                    }
                }
                else
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> ReplaceElementManual(
            string projectCode,
            string itemtoreplace,
            string area,
            string wp,
            string tagdescription,
            string tagclient,
            string tagtype,
            string material,
            bool materialChecked,
            string sequenceNumber,
            string objectcode,
            string lot)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                // Get configuration settings
                int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");
                int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                // Get current Project
                if (String.IsNullOrEmpty(projectCode))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                int projectId = project.ProjectID;

                // Values
                var selectedTagType = await _context.TAGTYPES.FirstOrDefaultAsync(x => x.Description == tagtype);
                var selectedPbs = await _context.PBS.FirstOrDefaultAsync(x => x.Area == area && x.ProjectID == projectId);
                var currentLot = await _context.LOTS.Where(l => l.NAME == lot).FirstOrDefaultAsync();
                if (currentLot == null)
                {
                    currentLot = new LOTS();
                    currentLot.CreationDate = DateTime.UtcNow;
                    currentLot.LastModified = DateTime.UtcNow;
                    currentLot.NAME = lot;
                    currentLot.ProjectID = project.ProjectID;
                    currentLot.UserID = user.USERID.Value;

                    _context.LOTS.Add(currentLot);
                    await _context.SaveChangesAsync();
                }

                var currentObjectCode = await _context.OBJECTCODES.Where(l => l.Code == objectcode).FirstOrDefaultAsync();
                var currentWp = await _context.WORKINGPACKAGES.Where(l => l.NAME == wp).FirstOrDefaultAsync();
                var currentMaterial = await _context.MATERIALWORKGROUPS.Where(m => m.GroupCode == objectcode).FirstOrDefaultAsync();
                var selectedVendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                var selectedPO = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                var selectedMR = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();


                // Get Main Item to Replace
                var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES).Include(m => m.LOTS).Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                var mainItemToReplace = mainItems.Where(x => x.Description == itemtoreplace).FirstOrDefault();
                if (mainItemToReplace == null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND);
                    return msg;
                }

                // Old quantity
                var oldQtyCE = await _context.MAIN_ITEM_QUANTITY.Where(m => m.MainItemId == mainItemToReplace.MainItemID).FirstOrDefaultAsync();
                double qtyCE = 0.0;
                if (oldQtyCE != null && oldQtyCE.QTY_NEXT_CE != null && oldQtyCE.QTY_NEXT_CE.HasValue)
                    qtyCE = oldQtyCE.QTY_NEXT_CE.Value;

                // Get Main Item that Replace
                MAINITEMS item = new MAINITEMS();
                item.PBS = selectedPbs;
                item.PBSID = item.PBS.PBSID;
                item.TAGTYPES = selectedTagType;
                item.TagTypeID = selectedTagType.TagTypeID;
                item.TagDescription = tagdescription;
                item.TagClient = tagclient;
                item.AddedManually = 1;
                item.WORKINGPACKAGESID = currentWp?.IDWP;
                item.LV01_Object_CodeID = currentObjectCode.ProjectID;
                item.LV01_Object_Code = currentObjectCode;
                item.LV01_Material_Work_GroupID = currentMaterial?.GroupID;
                item.BALANCE = 0;
                item.VENDORSID = mainItemToReplace.VENDORSID;
                item.LOTSID = mainItemToReplace.LOTSID;
                item.MATERIALREQUESTSID = mainItemToReplace.MATERIALREQUESTSID;
                item.PURCHASEORDERSID = mainItemToReplace.PURCHASEORDERSID;

                item.DrawNo = mainItemToReplace.DrawNo;
                if (string.IsNullOrEmpty(item.DrawNo))
                    item.DrawNo = "0";
                item.ElDrawNo = mainItemToReplace.ElDrawNo;
                if (string.IsNullOrEmpty(item.ElDrawNo))
                    item.ElDrawNo = "0";
                item.OPTRATIO = mainItemToReplace.OPTRATIO;
                if (item.OPTRATIO == null)
                    item.OPTRATIO = 0;
                item.BASESURFACEAREA = mainItemToReplace.BASESURFACEAREA;
                if (item.BASESURFACEAREA == null)
                    item.BASESURFACEAREA = 0;
                item.VOLUME = mainItemToReplace.VOLUME;
                if (item.VOLUME == null)
                    item.VOLUME = 0;
                item.MAINFLOORS = mainItemToReplace.MAINFLOORS;
                if (item.MAINFLOORS == null)
                    item.MAINFLOORS = 0;
                item.MODULES = mainItemToReplace.MODULES;
                if (item.MODULES == null)
                    item.MODULES = 0;

                item.UserID = user.USERID;
                item.CreationDate = DateTime.UtcNow;
                item.LastModified = DateTime.UtcNow;
                item.MainItemTag = item.CalculateMainTag(sequenceNumber, materialChecked);
                bool existing = ContainsItem(item, sequenceNumber, lot, mainItems, materialChecked);
                if (!existing)
                    _context.MAINITEMS.Add(item);
                else
                {
                    item = mainItems.Where(m => m.MainItemTag.ToUpper() == item.MainItemTag &&
                        item.TagTypeID == selectedTagType.TagTypeID &&
                        m.LOTS.NAME == lot).FirstOrDefault();
                }


                bool isSteel = selectedTagType.TagTypeID == tagTypeSteel;
                if (isSteel)
                {
                    item.VENDORSID = selectedVendor.IDVENDOR;
                    item.MATERIALREQUESTSID = selectedMR.IDMR;
                    item.PURCHASEORDERSID = selectedPO.IDPO;
                    item.LOTSID = currentLot.IDLOT;
                }
                else
                {
                    item.LOTSID = currentLot.IDLOT;
                }

                var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();
                PLANNINGS pLANNINGS = null;
                STEELPLANNINGS steelPlannings = null;
                MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                MAINITEMDRAWINGS mainItemDrawing = null;
                HOLDS mainItemHold = null;
                STEEL_QUANTITIES steelQty = null;
                STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;
                using (var dbContextTransaction = _context.Database.BeginTransaction())
                {
                    try
                    {
                        mainItemToReplace.MAINITEMSTATUSID = MainItemsCostants.REPLACED;
                        item.MAINITEMSTATUSID = MainItemsCostants.REPLACER;
                        item.PARENTID = mainItemToReplace.MainItemID;

                        int result = _context.SaveChanges(true);
                        var mainItemAdded = item;

                        // Add parameter if existing
                        if (parameters != null && parameters.Count > 0)
                        {
                            foreach (MAINITEMPARAMETERS parameter in parameters)
                            {
                                MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                mAINITEMPARAMETERVALUES.MainItemsID = mainItemAdded.MainItemID;
                                mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                            }
                            await _context.SaveChangesAsync();
                        }

                        // Transfer planning dates
                        var planningToReplace = await _context.PLANNINGS.Where(p => p.MainItemId == mainItemToReplace.MainItemID).FirstOrDefaultAsync();
                        if (planningToReplace != null)
                        {
                            var newPlanning = new PLANNINGS(planningToReplace);
                            newPlanning.MainItemId = mainItemAdded.MainItemID;

                            var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == mainItemToReplace.MainItemID).ToListAsync();
                            if (values != null)
                            {
                                foreach (MAINITEMPARAMETERVALUES currentValue in values)
                                {
                                    MAINITEMPARAMETERVALUES mAINITEMDATEVALUES = new MAINITEMPARAMETERVALUES();
                                    mAINITEMDATEVALUES.CreationDate = DateTime.UtcNow;
                                    mAINITEMDATEVALUES.LastModified = DateTime.UtcNow;
                                    mAINITEMDATEVALUES.UserID = user.USERID;
                                    mAINITEMDATEVALUES.MainItemParametersID = currentValue.MainItemParametersID;
                                    mAINITEMDATEVALUES.MainItemsID = mainItemAdded.MainItemID;
                                    mAINITEMDATEVALUES.PARAMETERDATE = currentValue.PARAMETERDATE;
                                    _context.MAINITEMPARAMETERVALUES.Add(mAINITEMDATEVALUES);
                                }
                            }

                            _context.PLANNINGS.Add(newPlanning);
                            await _context.SaveChangesAsync();
                        }

                        if (!isSteel)
                        {
                            var planningItemReplaced = await _context.PLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainItemToReplace.MainItemID);
                            if (mainItemAdded != null && planningItemReplaced != null)
                            {
                                // Add empty planning
                                pLANNINGS = new PLANNINGS(planningItemReplaced);
                                pLANNINGS.MainItemId = mainItemAdded.MainItemID;
                                // Set User and Date
                                pLANNINGS.UserID = user.USERID;
                                pLANNINGS.CreationDate = DateTime.UtcNow;
                                pLANNINGS.LastModified = DateTime.UtcNow;
                                _context.PLANNINGS.Add(pLANNINGS);

                                mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                mAIN_ITEM_QUANTITY.MainItemId = mainItemAdded.MainItemID;
                                // Set User and Date
                                mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                                mAIN_ITEM_QUANTITY.QTY_NEXT_CE = qtyCE;
                                oldQtyCE.QTY_NEXT_CE = 0.0;
                                _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                mainItemDrawing = new MAINITEMDRAWINGS();
                                mainItemDrawing.UserID = user.USERID;
                                mainItemDrawing.CreationDate = DateTime.UtcNow;
                                mainItemDrawing.LastModified = DateTime.UtcNow;
                                mainItemDrawing.MainItemID = item.MainItemID;
                                _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);
                                //_context.HOLDS.Add(mainItemHold);

                                result = _context.SaveChanges(true);
                            }
                        }
                        else
                        {
                            var planningSteelItemReplaced = await _context.STEELPLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainItemToReplace.MainItemID);
                            if (mainItemAdded != null && planningSteelItemReplaced != null)
                            {
                                // Add empty planning
                                steelPlannings = new STEELPLANNINGS(planningSteelItemReplaced);
                                steelPlannings.MainItemId = mainItemAdded.MainItemID;
                                // Set User and Date
                                steelPlannings.UserID = user.USERID;
                                steelPlannings.CreationDate = DateTime.UtcNow;
                                steelPlannings.LastModified = DateTime.UtcNow;
                                _context.STEELPLANNINGS.Add(steelPlannings);

                                mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                mAIN_ITEM_QUANTITY.MainItemId = mainItemAdded.MainItemID;
                                // Set User and Date
                                mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                                mAIN_ITEM_QUANTITY.QTY_NEXT_CE = qtyCE;
                                oldQtyCE.QTY_NEXT_CE = 0.0;
                                _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                steelEstimateQty.MainItemId = mainItemAdded.MainItemID;
                                steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                steelEstimateQty.IFF_E_QTY = 0.0;
                                steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                steelEstimateQty.IFP_E_QTY = 0.0;
                                steelEstimateQty.PO_E_QTY = 0.0;
                                steelEstimateQty.UserID = user.USERID;
                                steelEstimateQty.CreationDate = DateTime.UtcNow;
                                steelEstimateQty.LastModified = DateTime.UtcNow;
                                _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                mainItemDrawing = new MAINITEMDRAWINGS();
                                mainItemDrawing.UserID = user.USERID;
                                mainItemDrawing.CreationDate = DateTime.UtcNow;
                                mainItemDrawing.LastModified = DateTime.UtcNow;
                                mainItemDrawing.MainItemID = item.MainItemID;
                                _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                if (commodities != null)
                                {
                                    foreach (COMMODITYCODES commodityCode in commodities)
                                    {
                                        steelQty = new STEEL_QUANTITIES();
                                        steelQty.MainItemId = mainItemAdded.MainItemID;
                                        steelQty.CodeId = commodityCode.CodeID;
                                        steelQty.QTY = 0.0;
                                        steelQty.UserID = user.USERID;
                                        steelQty.CreationDate = DateTime.UtcNow;
                                        steelQty.LastModified = DateTime.UtcNow;
                                        _context.STEEL_QUANTITIES.Add(steelQty);
                                    }
                                }

                                result = _context.SaveChanges(true);
                            }
                        }

                        // Add parameter values

                        dbContextTransaction.Commit();
                        msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_REPLACED);
                    }
                    catch (Exception ex)
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_REPLACED, ex.Message);
                        dbContextTransaction.Rollback();
                        return ex.Message;
                    }
                }


                //if (mainItemToAdd != null)
                //{
                //    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_ALREADY_EXISTING);
                //    return msg;
                //}

                //PLANNINGS pLANNINGS = null;
                //STEELPLANNINGS steelPlannings = null;
                //MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                //HOLDS mainItemHold = null;
                //STEEL_QUANTITIES steelQty = null;
                //STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

                //int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                //int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");
                //int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                //string lotNameCivil = _configuration.GetValue<string>("Items:DefaultLotNameCivil");
                //string lotNameSteel = _configuration.GetValue<string>("Steel:DefaultLotNameSteel");
                //string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                //var lotCivil = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameCivil).FirstOrDefaultAsync();
                //var lotSteel = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameSteel).FirstOrDefaultAsync();
                //var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                //var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                //var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                //var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();
                //var wpItem = await _context.WORKINGPACKAGES.Where(w => w.NAME == wp && w.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                //bool isSteel = false;

                //if (project != null && tagType != null && pbs != null)
                //{
                //    isSteel = tagType.TagTypeID == tagTypeSteel;

                //    MAINITEMS item = new MAINITEMS();
                //    item.PBS = selectedpbs;
                //    item.PBSID = item.PBS.PBSID;
                //    item.TAGTYPES = tagType;
                //    item.TagTypeID = tagType.TagTypeID;
                //    item.MainItemTag = tcmtag;
                //    item.TagDescription = tagdescription;
                //    item.TagClient = tagclient;
                //    item.AddedManually = 1;
                //    item.WORKINGPACKAGESID = wpItem?.IDWP;
                //    item.LV01_Object_CodeID = null;
                //    item.LV01_Material_Work_GroupID = null;
                //    item.PARENTID = mainItemToReplace.MainItemID;

                //    // Set User and Date
                //    item.UserID = user.USERID;
                //    item.CreationDate = DateTime.UtcNow;
                //    item.LastModified = DateTime.UtcNow;

                //    if (isSteel)
                //    {
                //        item.VENDORSID = vendor.IDVENDOR;
                //        item.MATERIALREQUESTSID = mr.IDMR;
                //        item.PURCHASEORDERSID = po.IDPO;
                //        item.LOTSID = lotSteel.IDLOT;
                //    }
                //    else
                //    {
                //        item.LOTSID = lotCivil.IDLOT;
                //    }

                //    _context.MAINITEMS.Add(item);

                //    mainItemToReplace.DELETED = 1;

                //    using (var dbContextTransaction = _context.Database.BeginTransaction())
                //    {
                //        try
                //        {
                //            int result = _context.SaveChanges(true);
                //            var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item.MainItemTag);
                //            if (!isSteel)
                //            {
                //                var planningItemReplaced = await _context.PLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainItemToReplace.MainItemID);
                //                if (mainItemAdded != null && planningItemReplaced != null)
                //                {
                //                    // Add empty planning
                //                    pLANNINGS = new PLANNINGS(planningItemReplaced);
                //                    pLANNINGS.MainItemId = mainItemAdded.MainItemID;
                //                    // Set User and Date
                //                    pLANNINGS.UserID = user.USERID;
                //                    pLANNINGS.CreationDate = DateTime.UtcNow;
                //                    pLANNINGS.LastModified = DateTime.UtcNow;
                //                    _context.PLANNINGS.Add(pLANNINGS);

                //                    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                //                    mAIN_ITEM_QUANTITY.MainItemId = mainItemAdded.MainItemID;
                //                    // Set User and Date
                //                    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                //                    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                //                    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                //                    mAIN_ITEM_QUANTITY.QTY_CE = 0.0;
                //                    mAIN_ITEM_QUANTITY.QTY_WR = 0.0;
                //                    mAIN_ITEM_QUANTITY.QTY_BUDGET = 0.0;
                //                    mAIN_ITEM_QUANTITY.QTY_HOLD = 0.0;
                //                    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                //                    mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);
                //                    _context.HOLDS.Add(mainItemHold);

                //                    result = _context.SaveChanges(true);
                //                }
                //            }
                //            else
                //            {
                //                var planningSteelItemReplaced = await _context.STEELPLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainItemToReplace.MainItemID);
                //                if (mainItemAdded != null && planningSteelItemReplaced != null)
                //                {
                //                    // Add empty planning
                //                    steelPlannings = new STEELPLANNINGS(planningSteelItemReplaced);
                //                    steelPlannings.MainItemId = mainItemAdded.MainItemID;
                //                    // Set User and Date
                //                    steelPlannings.UserID = user.USERID;
                //                    steelPlannings.CreationDate = DateTime.UtcNow;
                //                    steelPlannings.LastModified = DateTime.UtcNow;
                //                    _context.STEELPLANNINGS.Add(steelPlannings);

                //                    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                //                    steelEstimateQty.MainItemId = mainItemAdded.MainItemID;
                //                    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                //                    steelEstimateQty.IFF_E_QTY = 0.0;
                //                    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                //                    steelEstimateQty.IFP_E_QTY = 0.0;
                //                    steelEstimateQty.PO_E_QTY = 0.0;
                //                    steelEstimateQty.UserID = user.USERID;
                //                    steelEstimateQty.CreationDate = DateTime.UtcNow;
                //                    steelEstimateQty.LastModified = DateTime.UtcNow;
                //                    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                //                    if (commodities != null)
                //                    {
                //                        foreach (COMMODITYCODES commodityCode in commodities)
                //                        {
                //                            steelQty = new STEEL_QUANTITIES();
                //                            steelQty.MainItemId = mainItemAdded.MainItemID;
                //                            steelQty.CodeId = commodityCode.CodeID;
                //                            steelQty.QTY = 0.0;
                //                            steelQty.UserID = user.USERID;
                //                            steelQty.CreationDate = DateTime.UtcNow;
                //                            steelQty.LastModified = DateTime.UtcNow;
                //                            _context.STEEL_QUANTITIES.Add(steelQty);
                //                        }
                //                    }

                //                    result = _context.SaveChanges(true);
                //                }
                //            }
                //            dbContextTransaction.Commit();
                //            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_REPLACED);
                //        }
                //        catch (Exception ex)
                //        {
                //            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_REPLACED, ex.Message);
                //            dbContextTransaction.Rollback();
                //            return ex.Message;
                //        }
                //    }
                //}
                //else
                //{
                //    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED);
                //}
            }
            return msg;
        }

        [HttpGet]
        public async Task<List<string>> GetAllItemsForReplace(
            string projectCode,
            string itemtoreplace)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                // Get current Project
                if (String.IsNullOrEmpty(projectCode))
                    return null;
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return null;
                int projectId = project.ProjectID;


                // Get Main Item to Replace
                var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES).Include(m => m.LOTS).Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                var mainItemToReplace = mainItems.Where(x => x.CompleteDescription == itemtoreplace).FirstOrDefault();
                if (mainItemToReplace == null)
                    return null;

                var compatibleMainItems = mainItems.Where(t => t.TagTypeID == mainItemToReplace.TagTypeID &&
                    t.MainItemID != mainItemToReplace.MainItemID && !t.IsDeleted && !t.IsReplaced && !t.IsBalance).ToList();
                if (compatibleMainItems != null && compatibleMainItems.Count > 0)
                    return compatibleMainItems.Select(m => m.CompleteDescription).ToList();
            }
            return null;
        }


        [HttpGet]
        public async Task<List<string>> GetAllItemsForCombine(
            string projectCode,
            string itemtocombinestr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                // Get current Project
                if (String.IsNullOrEmpty(projectCode))
                    return null;
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return null;
                int projectId = project.ProjectID;
                string[] itemNames = Utils.SplitText(itemtocombinestr);

                // Get Main Item to Combine
                var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES).Include(m => m.LOTS).Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                List<MAINITEMS> itemsToCombine = new List<MAINITEMS>();
                if (itemNames != null)
                {
                    foreach (string currentName in itemNames)
                    {
                        var currentItem = mainItems.Where(x => x.CompleteDescription == currentName).FirstOrDefault();
                        if (currentItem != null)
                            itemsToCombine.Add(currentItem);
                    }
                }
                int countTagTypes = itemsToCombine.Select(m => m.TagTypeID).Distinct().ToList().Count;
                if (countTagTypes != 1)
                    return null;

                List<int> ids = itemsToCombine.Select(m => m.MainItemID).ToList();
                var compatibleMainItems = mainItems.Where(t => t.TagTypeID == itemsToCombine[0].TagTypeID &&
                    !ids.Contains(t.MainItemID) && !t.IsDeleted && !t.IsReplaced && !t.IsBalance).ToList();
                if (compatibleMainItems != null && compatibleMainItems.Count > 0)
                    return compatibleMainItems.Select(m => m.CompleteDescription).ToList();
            }
            return null;
        }

        [HttpPost]
        public async Task<string> ReplaceElement(
            string projectCode,
            string itemtoreplace,
            string newItem)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (itemtoreplace == newItem)
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_EQUALS);

                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                // Get current Project
                if (String.IsNullOrEmpty(projectCode))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                int projectId = project.ProjectID;


                // Get Main Item to Replace
                var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES).Include(m => m.PBS).Include(m => m.LOTS).Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                var mainItemToReplace = mainItems.Where(x => x.CompleteDescription == itemtoreplace).FirstOrDefault();
                if (mainItemToReplace == null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND);
                    return msg;
                }

                // Get Main Item 
                var itemReplaceWith = mainItems.Where(x => x.CompleteDescription == newItem).FirstOrDefault();
                if (itemReplaceWith == null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND);
                    return msg;
                }

                // Old quantity
                var oldQtyCE = await _context.MAIN_ITEM_QUANTITY.Where(m => m.MainItemId == mainItemToReplace.MainItemID).FirstOrDefaultAsync();
                double qtyCE = 0.0;
                if (oldQtyCE != null && oldQtyCE.QTY_NEXT_CE != null && oldQtyCE.QTY_NEXT_CE.HasValue)
                    qtyCE = oldQtyCE.QTY_NEXT_CE.Value;

                itemReplaceWith.UserID = user.USERID;
                itemReplaceWith.CreationDate = DateTime.UtcNow;
                itemReplaceWith.LastModified = DateTime.UtcNow;

                var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();
                using (var dbContextTransaction = _context.Database.BeginTransaction())
                {
                    try
                    {
                        mainItemToReplace.MAINITEMSTATUSID = MainItemsCostants.REPLACED;
                        itemReplaceWith.MAINITEMSTATUSID = MainItemsCostants.REPLACER;
                        itemReplaceWith.PARENTID = mainItemToReplace.MainItemID;

                        int result = _context.SaveChanges(true);
                        var mainItemAdded = itemReplaceWith;

                        // Transfer planning dates
                        var planningToReplace = await _context.PLANNINGS.Where(p => p.MainItemId == mainItemToReplace.MainItemID).FirstOrDefaultAsync();
                        if (planningToReplace != null)
                        {
                            var newPlanning = new PLANNINGS(planningToReplace);
                            newPlanning.MainItemId = mainItemAdded.MainItemID;
                            _context.PLANNINGS.Add(newPlanning);
                            await _context.SaveChangesAsync();
                        }

                        // Change Qty
                        if (qtyCE > 0.0)
                        {
                            var newQtyCE = await _context.MAIN_ITEM_QUANTITY.Where(m => m.MainItemId == itemReplaceWith.MainItemID).FirstOrDefaultAsync();
                            if (newQtyCE != null)
                            {
                                oldQtyCE.QTY_NEXT_CE = 0.0;
                                if (newQtyCE.QTY_NEXT_CE == null)
                                    newQtyCE.QTY_NEXT_CE = 0.0;
                                newQtyCE.QTY_NEXT_CE += qtyCE;
                                await _context.SaveChangesAsync();
                            }
                        }

                        dbContextTransaction.Commit();
                        msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_REPLACED);
                    }
                    catch (Exception ex)
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_REPLACED, ex.Message);
                        dbContextTransaction.Rollback();
                        return ex.Message;
                    }
                }

                // Add to deleted items of BIM360
                var missingItem = await _context.ITEMSLISTCHECKS.Where(m => m.MainItemID == mainItemToReplace.MainItemID).FirstOrDefaultAsync();
                if (missingItem != null)
                {
                    _context.ITEMSLISTCHECKS.Remove(missingItem);
                    await _context.SaveChangesAsync();
                }

                if ((mainItemToReplace.AddedFromBIM360 != null && mainItemToReplace.AddedFromBIM360.HasValue && mainItemToReplace.AddedFromBIM360.Value > 0) ||
                    !string.IsNullOrEmpty(mainItemToReplace.ModelName))
                {
                    DELETEDITEMSLISTCHECKS item = new DELETEDITEMSLISTCHECKS();
                    item.CreationDate = DateTime.UtcNow;
                    item.LastModified = DateTime.UtcNow;
                    item.UserID = user.USERID;
                    item.MainItemTag = mainItemToReplace.MainItemTag;
                    if (mainItemToReplace.IsDeleted)
                        item.Status = "Deleted";
                    else
                        item.Status = "Replaced";
                    item.Lot = mainItemToReplace.LOTS.NAME;
                    item.TagType = mainItemToReplace.TAGTYPES.Description;
                    item.ModelName = mainItemToReplace.ModelName;
                    item.ProjectID = mainItemToReplace.PBS.ProjectID;
                    _context.DELETEDITEMSLISTCHECKS.Add(item);
                }


                // Move holds to item replace
                List<HOLDS> holds = await _context.HOLDS.Where(h => h.MainItemId == mainItemToReplace.MainItemID).ToListAsync();
                List<HOLDS> holdReplacerList = await _context.HOLDS.Where(h => h.MainItemId == itemReplaceWith.MainItemID).ToListAsync();
                List<HOLDS> toBeDeleted = new List<HOLDS>();
                if (holds != null && holds.Count > 0)
                {
                    foreach (HOLDS hold in holds)
                    {
                        HOLDS newHold = null;
                        if (holdReplacerList != null)
                            newHold = holdReplacerList.Where(h => h.HOLDTYPESID.Value == hold.HOLDTYPESID.Value).FirstOrDefault();
                        if (newHold == null)
                            hold.MainItemId = itemReplaceWith.MainItemID;
                        else
                        {
                            if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue)
                                newHold.QTYHOLD += hold.QTYHOLD;
                            toBeDeleted.Add(hold);
                        }
                    }
                    if (toBeDeleted.Count > 0)
                        _context.HOLDS.RemoveRange(toBeDeleted);
                    await _context.SaveChangesAsync();
                }

                // Delete existing drawing
                List<DRAWINGS> drawings = new List<DRAWINGS>();
                var currentDrawings = await _context.DRAWINGS.Where(h => h.ProjectID == project.ProjectID && h.MainItemTag == mainItemToReplace.MainItemTag).ToListAsync();
                if (currentDrawings != null && currentDrawings.Count > 0)
                    drawings.AddRange(currentDrawings);
                if (drawings.Count > 0)
                {
                    _context.DRAWINGS.RemoveRange(drawings);
                    await _context.SaveChangesAsync();
                }
            }
            return msg;
        }

        private bool ContainsItem(MAINITEMS item, int id, List<MAINITEMS> items, bool considerMaterial)
        {
            string value = item.CalculateMainTag(id, considerMaterial);
            foreach (MAINITEMS currentItem in items)
                if (currentItem.MainItemTagWithoutMaterial.ToUpper() == value.ToUpper() && item.TagTypeID == currentItem.TagTypeID)
                    return true;
            return false;
        }

        private bool ContainsItem(MAINITEMS item, string sequence, string lot, List<MAINITEMS> items, bool considerMaterial)
        {
            string value = item.CalculateMainTag(sequence, considerMaterial);
            foreach (MAINITEMS currentItem in items)
                if (currentItem.MainItemTag.ToUpper() == value.ToUpper() && item.TagTypeID == currentItem.TagTypeID &&
                    currentItem.LOTS.NAME == lot)
                    return true;
            return false;
        }

        [HttpGet]
        public async Task<IActionResult> GetTemplate(string code)
        {
            try
            {
                if (string.IsNullOrEmpty(code))
                    return NotFound();

                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                if (project == null)
                    return NotFound();
                _context.ProjectID = project.ProjectID;

                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
                string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "TemplateCIL.xlsx");

                string excelSheet = _configuration.GetValue<string>("Excel:MainItemsListSheetName");
                int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
                int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
                int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
                int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
                List<string> columnNames = ParsingUtils.ParseString(_configuration.GetValue<string>("Excel:ItemColumns"));

                System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
                ExcelPackage Ep = new ExcelPackage(baseFile);
                ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

                var parameters = _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToList();
                if (parameters != null && parameters.Count > 0)
                {
                    parameters = parameters.OrderBy(p => p.MAINITEMPARAMETERCATEGORIESID).ToList();
                    int startIndex = columnNames.Count;
                    var colBlue = System.Drawing.ColorTranslator.FromHtml("#4472C4");
                    var colWhite = System.Drawing.ColorTranslator.FromHtml("#ffffff");

                    foreach (var parameter in parameters)
                    {
                        Sheet.Cells[startRow - 1, startIndex + 1].Value = parameter.PARAMETERNAME.ToUpperInvariant();
                        Sheet.Cells[startRow - 1, startIndex + 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        Sheet.Cells[startRow - 1, startIndex + 1].Style.Fill.BackgroundColor.SetColor(colBlue);
                        Sheet.Cells[startRow - 1, startIndex + 1].Style.Font.Color.SetColor(colWhite);
                        Sheet.Cells[startRow - 1, startIndex + 1].Style.Font.Bold = true;
                        Sheet.Cells[startRow - 1, startIndex + 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        startIndex++;
                    }
                }

                //Save the file to server temp folder            
                System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
                Ep.SaveAs(fi);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpGet]
        public IActionResult GetTemplateSize()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsSizeTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpGet]
        public IActionResult GetTemplateParameters()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:MainItemsTemplateParameters");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }
    }
}