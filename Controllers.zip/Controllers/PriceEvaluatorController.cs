﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Models;
using CivilMasterData.Models.PriceList;
using CivilMasterData.Models.PriceList.Base;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;

namespace CivilMasterData.Controllers
{
    public class PriceEvaluatorController : Controller
    {
        private readonly PriceEvaluatorContext _context;
        private IWebHostEnvironment _env;
        string tempfolder = "temp";
        private IConfiguration _configuration;

        public PriceEvaluatorController(PriceEvaluatorContext context, IWebHostEnvironment env, IConfiguration configuration)
        {
            _context = context;
            _env = env;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            PriceEvaluator priceEvaluator = new PriceEvaluator();
            var project = await _context.PROJECTS.Where(m => m.Code == code).FirstOrDefaultAsync();
            int projectId = project.ProjectID;
            var priceDefinitions = await _context.PRICECODEDEFINITIONS.Where(m => m.ProjectID == projectId).ToListAsync();
            var priceCodes = await _context.PRICECODES.Where(m => m.ProjectID == projectId).ToListAsync();
            var priceFamilies = await _context.PRICEFAMILIESVALUES.Where(m => m.ProjectID == projectId).ToListAsync();
            var pbs = await _context.PBS.Where(m => m.ProjectID == projectId).ToListAsync();
            var tagtypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();

            var result = pbs.Select(id => id).ToList();

            if (priceDefinitions == null || priceDefinitions.Count == 0)
            {
                priceCodes = await _context.PRICECODES.Where(m => m.ProjectID == 0).ToListAsync();
                priceDefinitions = await _context.PRICECODEDEFINITIONS.Where(m => m.ProjectID == 0).ToListAsync();
                priceFamilies = await _context.PRICEFAMILIESVALUES.Where(m => m.ProjectID == 0).ToListAsync();
            }

            priceEvaluator.TagTypes = tagtypes;
            priceEvaluator.PRICECODES = priceCodes;
            priceEvaluator.PRICECODEDEFINITIONS = priceDefinitions;
            priceEvaluator.PRICEFAMILIESVALUES = priceFamilies;
            priceEvaluator.PBS = pbs;
            priceEvaluator.Project = project;

            ViewBag.ProjectID = projectId;
            ViewBag.Project = project.Code;

            return View(priceEvaluator);
        }

        [HttpGet]
        public ActionResult Download(string fileName)
        {
            //Get the temp folder and file path in server
            string fileToSave = System.IO.Path.Combine(_env.WebRootPath, tempfolder, fileName);
            byte[] fileByteArray = System.IO.File.ReadAllBytes(fileToSave);
            System.IO.File.Delete(fileToSave);
            return File(fileByteArray, "application/vnd.ms-excel", fileName);
        }

        protected string[] SplitText(string vector)
        {
            if (String.IsNullOrEmpty(vector))
                return null;
            string values = vector.Replace("[", "");
            values = values.Replace("]", "");
            values = values.Replace("\"", "");
            string[] spittedvalues = values.Split(',');
            return spittedvalues;
        }

        [HttpPost]
        public async Task<IActionResult> ExcelQuantities(string areasstr, string tagtypestr, int? projectId)
        {
            try
            {
                // Read database
                PriceEvaluator priceEvaluator = new PriceEvaluator();
                var project = await _context.PROJECTS.Where(m => m.ProjectID == projectId.Value).FirstOrDefaultAsync();

                var booleans = await _context.BOOLEANOPERATORS.ToListAsync();
                var comparisonType = await _context.COMPARISONTYPES.ToListAsync();
                var conditionTypes = await _context.PRICECONDITIONTYPES.ToListAsync();

                var priceDefinitions = await _context.PRICECODEDEFINITIONS.Where(m => m.ProjectID == projectId.Value).ToListAsync();
                if (priceDefinitions == null || priceDefinitions.Count == 0)
                    priceDefinitions = await _context.PRICECODEDEFINITIONS.Where(m => m.ProjectID == 0).ToListAsync();


                var priceCodes = await _context.PRICECODES.Where(m => m.ProjectID == projectId.Value).ToListAsync();
                if (priceCodes == null || priceCodes.Count == 0)
                    priceCodes = await _context.PRICECODES.Where(m => m.ProjectID == 0).ToListAsync();
                var priceCodesId = priceCodes.Select(x => x.PriceCodeID).ToList();

                var conditions = await _context.PRICECONDITIONS.Where(c => priceCodesId.Contains(c.PRICECODEID.Value)).ToListAsync();
                var priceFamilies = await _context.PRICEFAMILIESVALUES.Where(m => m.ProjectID == projectId.Value).ToListAsync();
                if (priceFamilies == null || priceFamilies.Count == 0)
                    priceFamilies = await _context.PRICEFAMILIESVALUES.Where(m => m.ProjectID == 0).ToListAsync();
                
                string[] areaList = SplitText(areasstr);
                if (areasstr.Length == 0)
                    return null;
                string[] tagtypeList = SplitText(tagtypestr);
                if (tagtypeList.Length == 0)
                    return null;

                var pbs = await _context.PBS.Where(m => m.ProjectID == projectId.Value && areaList.Contains(m.Area)).ToListAsync();
                var tagTypes = await _context.TAGTYPES.Where(m => tagtypeList.Contains(m.Description)).ToListAsync();
                var result = pbs.Select(id => id).ToList();
                var mainItems = await _context.MAINITEMS.Where(m => pbs.Contains(m.PBS) && tagTypes.Contains(m.TAGTYPES)).ToListAsync();
                var mainItemsId = mainItems.Select(x => x.MainItemID).ToList();


                // Get Secondary Items
                var secondaryItems = await _context.SECONDARY_ITEM.Where(m => mainItemsId.Contains(m.MainItemId.Value)).ToListAsync();

                List<ExcelResultValue> results = new List<ExcelResultValue>();
                ExcelResultValue resultExcel = null;
                if (secondaryItems != null)
                {
                    foreach (SECONDARY_ITEM item in secondaryItems)
                    {
                        SECONDARY_ITEM_QUANTITY quantity = await _context.SECONDARY_ITEM_QUANTITY.Where(m => m.Sec_Item_Id == item.Sec_Item_Id).FirstOrDefaultAsync();
                        if (quantity != null)
                        {
                            foreach (PRICEFAMILIESVALUES pRICEFAMILIESVALUES in priceFamilies)
                            {
                                foreach (PRICECODES priceCode in priceCodes)
                                {
                                    resultExcel = item.GetExcelResultValue(pRICEFAMILIESVALUES, conditions, quantity,
                                        pRICEFAMILIESVALUES.PRICECODEDEFINITIONS,
                                        priceCode);
                                    if (resultExcel != null)
                                        results.Add(resultExcel);
                                }
                            }
                        }
                    }
                }

                priceEvaluator.PRICECODES = priceCodes;
                priceEvaluator.PRICECODEDEFINITIONS = priceDefinitions;
                priceEvaluator.PRICEFAMILIESVALUES = priceFamilies;
                priceEvaluator.PBS = pbs;
                priceEvaluator.Project = project;

                ViewBag.ProjectID = projectId.Value;
                ViewBag.Project = project;

                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:QuantitiesTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
                string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, excelTemplate);

                string directory = System.IO.Path.Combine(webRoot, tempfolder);
                if (!System.IO.Directory.Exists(directory))
                    System.IO.Directory.CreateDirectory(directory);

                System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);

                ExcelPackage pck = new ExcelPackage(baseFile);

                string excelSheet = _configuration.GetValue<string>("Excel:QuantitiesSheetName");
                int startColumn = _configuration.GetValue<int>("Excel:QuantitiesStartColumn");
                int startRow = _configuration.GetValue<int>("Excel:QuantitiesStartRow");
                int rowProject = _configuration.GetValue<int>("Excel:QuantitiesProjectRow");
                int columnProject = _configuration.GetValue<int>("Excel:QuantitiesProjectColumn");
                int rowArea = _configuration.GetValue<int>("Excel:QuantitiesAreaRow");
                int columnArea = _configuration.GetValue<int>("Excel:QuantitiesAreaColumn");

                var workbook = pck.Workbook;
                var worksheetData = workbook.Worksheets[excelSheet];

                if (worksheetData != null)
                {
                    // Project Code
                    worksheetData.Cells[rowProject, columnProject].Value = project.Code;

                    // Selected Areas
                    worksheetData.Cells[rowArea, columnArea].Value = string.Join(";", areaList);

                    // Write chart values
                    ResultManager resultManager = new ResultManager(results);
                    List<string> mainPriceCodes = resultManager.GetPriceGroups();

                    int groupIndex = 1;
                    foreach(string mainPrice in mainPriceCodes)
                    {
                        List<string> priceCodesStr = resultManager.GetPriceCodes(mainPrice);

                        foreach (string priceCode in priceCodesStr)
                        {
                            List<ExcelResultValue> values = resultManager.GetExcelResultValues(priceCode);

                            if (values == null || values.Count == 0)
                                continue;

                            // Main GroupCode
                            worksheetData.Cells[startRow, startColumn].Value = groupIndex;
                            worksheetData.Cells[startRow, startColumn + 1].Value = values[0].PriceCode;
                            worksheetData.Cells[startRow, startColumn + 2].Value = values[0].PriceDescription;
                            startRow++;

                            double qty = 0.0;
                            foreach (ExcelResultValue excelResult in values)
                            {
                                worksheetData.Cells[startRow, startColumn].Value = string.Empty;
                                worksheetData.Cells[startRow, startColumn + 1].Value = string.Empty;
                                worksheetData.Cells[startRow, startColumn + 2].Value = excelResult.ItemCode;
                                worksheetData.Cells[startRow, startColumn + 3].Value = excelResult.Unit;
                                worksheetData.Cells[startRow, startColumn + 4].Value = excelResult.Count;
                                worksheetData.Cells[startRow, startColumn + 5].Value = excelResult.Length;
                                worksheetData.Cells[startRow, startColumn + 6].Value = excelResult.Width;
                                worksheetData.Cells[startRow, startColumn + 7].Value = excelResult.Height;
                                worksheetData.Cells[startRow, startColumn + 8].Value = excelResult.Area;
                                worksheetData.Cells[startRow, startColumn + 9].Value = excelResult.Weight;
                                worksheetData.Cells[startRow, startColumn + 10].Value = excelResult.Quantities;

                                qty += excelResult.Quantities;
                                startRow++;
                            }

                            startRow++;
                            worksheetData.Cells[startRow, startColumn].Value = string.Empty;
                            worksheetData.Cells[startRow, startColumn + 1].Value = values[0].PriceCode;
                            worksheetData.Cells[startRow, startColumn + 2].Value = "Total";
                            worksheetData.Cells[startRow, startColumn + 10].Value = qty;
                            startRow++;
                            startRow++;

                            groupIndex++;
                        }
                    }
                }

                //Save the file to server temp folder            
                System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
                pck.SaveAs(fi);
                var errorMessage = "";
                return Json(new { fileName = fi.Name, errorMessage });
            }
            catch
            {
                return null;
            }
        }

    }
}