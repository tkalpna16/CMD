﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Costants;

namespace CivilMasterData
{
    public class STEELPLANNINGSController : Controller
    {
        private readonly STEELPLANNINGSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public STEELPLANNINGSController(STEELPLANNINGSContext context, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            _sharedResource = sharedResource;
            _configuration = configuration;
        }

        // GET: STEELPLANNINGS
        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            var pbs = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(m => m.PBS.ProjectID == project.ProjectID && m.TagTypeID == tagTypeSteel).ToListAsync();

            var plannings = await _context.STEELPLANNINGS.Where(p => p.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            // Check Plannings for main items
            bool added = false;
            if (mainItems != null && mainItems.Count > 0)
            {
                foreach (MAINITEMS mainItem in mainItems)
                {
                    var planning = plannings.Where(p => p.MainItemId == mainItem.MainItemID).FirstOrDefault();
                    if (planning == null)
                    {
                        STEELPLANNINGS steelPlanning = new STEELPLANNINGS();
                        steelPlanning.MainItemId = mainItem.MainItemID;
                        steelPlanning.UserID = user.USERID;
                        steelPlanning.CreationDate = DateTime.UtcNow;
                        steelPlanning.LastModified = DateTime.UtcNow;
                        _context.STEELPLANNINGS.Add(steelPlanning);
                        added = true;
                    }
                }
            }

            if (added)
            {
                await _context.SaveChangesAsync();
                plannings = await _context.STEELPLANNINGS.Where(p => p.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            }

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            plannings = MainItemUtils.OrderSteelPlanning(plannings, projectSettings.BALANCE);
            ViewBag.Project = project.Code;

            return View(plannings);
        }

        // GET: STEELPLANNINGS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sTEELPLANNINGS = await _context.STEELPLANNINGS
                .Include(s => s.MAINITEMS)
                .Include(s => s.USERS)
                .FirstOrDefaultAsync(m => m.PlanningId == id);
            if (sTEELPLANNINGS == null)
            {
                return NotFound();
            }

            return View(sTEELPLANNINGS);
        }

        // GET: STEELPLANNINGS/Create
        public IActionResult Create()
        {
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID");
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID");
            return View();
        }

        // POST: STEELPLANNINGS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlanningId,MainItemId,UserID,CreationDate,LastModified,EngineeringPlanningGroup,DATE_IFP,DATE_IFF,DATE1_AIVD,DATE2_AIVD,DATE3_AIVD,DATE4_AIVD,DATE5_AIVD,DATE6_AIVD,DATE7_AIVD")] STEELPLANNINGS sTEELPLANNINGS)
        {
            if (ModelState.IsValid)
            {
                _context.Add(sTEELPLANNINGS);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID", sTEELPLANNINGS.MainItemId);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", sTEELPLANNINGS.UserID);
            return View(sTEELPLANNINGS);
        }

        // GET: STEELPLANNINGS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sTEELPLANNINGS = await _context.STEELPLANNINGS.FindAsync(id);
            if (sTEELPLANNINGS == null)
            {
                return NotFound();
            }
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID", sTEELPLANNINGS.MainItemId);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", sTEELPLANNINGS.UserID);
            return View(sTEELPLANNINGS);
        }

        [HttpPost]
        public async Task<string> UpdateDates(string code, string mainitemsstr, string lotsstr, string datesstr1, string datesstr2, string datesstr3, string datesstr4, string datesstr5,
            string datesstr6, string datesstr7, string datesstr8, string datesstr9)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var lotDB = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID).ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] lots = Utils.SplitText(lotsstr);
                    DateTime?[] dates1 = Utils.SplitDate(datesstr1);
                    DateTime?[] dates2 = Utils.SplitDate(datesstr2);
                    DateTime?[] dates3 = Utils.SplitDate(datesstr3);
                    DateTime?[] dates4 = Utils.SplitDate(datesstr4);
                    DateTime?[] dates5 = Utils.SplitDate(datesstr5);
                    DateTime?[] dates6 = Utils.SplitDate(datesstr6);
                    DateTime?[] dates7 = Utils.SplitDate(datesstr7);
                    DateTime?[] dates8 = Utils.SplitDate(datesstr8);
                    DateTime?[] dates9 = Utils.SplitDate(datesstr9);
                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainitems)
                    {
                        var mainitem = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item &&
                            m.PBS.ProjectID == project.ProjectID && m.LOTS.NAME == lots[counter]);
                        if (mainitem != null)
                        {
                            var planning = await _context.STEELPLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainitem.MainItemID);
                            if (planning != null)
                            {
                                if (dates1[counter] == null)
                                    planning.DATE_IFP = null;
                                else
                                    planning.DATE_IFP = dates1[counter].Value;

                                if (dates2[counter] == null)
                                    planning.DATE_IFF = null;
                                else
                                    planning.DATE_IFF = dates2[counter].Value;

                                if (dates3[counter] == null)
                                    planning.DATE1_AIVD = null;
                                else
                                    planning.DATE1_AIVD = dates3[counter].Value;

                                if (dates4[counter] == null)
                                    planning.DATE2_AIVD = null;
                                else
                                    planning.DATE2_AIVD = dates4[counter].Value;

                                if (dates5[counter] == null)
                                    planning.DATE3_AIVD = null;
                                else
                                    planning.DATE3_AIVD = dates5[counter].Value;

                                if (dates6[counter] == null)
                                    planning.DATE4_AIVD = null;
                                else
                                    planning.DATE4_AIVD = dates6[counter].Value;

                                if (dates7[counter] == null)
                                    planning.DATE5_AIVD = null;
                                else
                                    planning.DATE5_AIVD = dates7[counter].Value;

                                if (dates8[counter] == null)
                                    planning.DATE6_AIVD = null;
                                else
                                    planning.DATE6_AIVD = dates8[counter].Value;

                                if (dates9[counter] == null)
                                    planning.DATE7_AIVD = null;
                                else
                                    planning.DATE7_AIVD = dates9[counter].Value;

                                planning.UserID = user.USERID;
                                planning.LastModified = DateTime.UtcNow;

                                changed = true;
                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_MAIN_ITEM_NOT_FOUND, item + " ");
                            }
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        // POST: STEELPLANNINGS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlanningId,MainItemId,UserID,CreationDate,LastModified,EngineeringPlanningGroup,DATE_IFP,DATE_IFF,DATE1_AIVD,DATE2_AIVD,DATE3_AIVD,DATE4_AIVD,DATE5_AIVD,DATE6_AIVD,DATE7_AIVD")] STEELPLANNINGS sTEELPLANNINGS)
        {
            if (id != sTEELPLANNINGS.PlanningId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(sTEELPLANNINGS);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!STEELPLANNINGSExists(sTEELPLANNINGS.PlanningId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID", sTEELPLANNINGS.MainItemId);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", sTEELPLANNINGS.UserID);
            return View(sTEELPLANNINGS);
        }

        // GET: STEELPLANNINGS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sTEELPLANNINGS = await _context.STEELPLANNINGS
                .Include(s => s.MAINITEMS)
                .Include(s => s.USERS)
                .FirstOrDefaultAsync(m => m.PlanningId == id);
            if (sTEELPLANNINGS == null)
            {
                return NotFound();
            }

            return View(sTEELPLANNINGS);
        }

        // POST: STEELPLANNINGS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var sTEELPLANNINGS = await _context.STEELPLANNINGS.FindAsync(id);
            _context.STEELPLANNINGS.Remove(sTEELPLANNINGS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool STEELPLANNINGSExists(int id)
        {
            return _context.STEELPLANNINGS.Any(e => e.PlanningId == id);
        }
    }
}
