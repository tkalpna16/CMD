﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using System.Linq;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;
using System;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using CivilMasterData.Models.Logs;
using Microsoft.AspNetCore.Http;
using System.IO;
using OfficeOpenXml;
using System.Collections.Generic;

namespace CivilMasterData
{
    public class PROJECTUSERSController : Controller
    {
        private readonly PROJECTUSERSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PROJECTUSERSController(PROJECTUSERSContext context, ISharedResource sharedResource, IConfiguration configuration,
            IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
            _env = env;
        }

        // GET: USERS
        public async Task<IActionResult> Index(string code)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (string.IsNullOrEmpty(code) || user == null)
                {
                    return NotFound();
                }
                if (user.IsDisabled)
                    return Redirect("~/Home/NoPermission");

                var project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.Code == code);
                if (project == null)
                {
                    project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.GetCompleteDescription == code);
                    if (project == null)
                        return NotFound();
                }

                if (user.ACCESS_LEVEL != Roles.ADMIN)
                {
                    var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    if (userProject == null)
                        return Redirect("~/Home/NoPermission");
                }

                ViewBag.ProjectID = project.ProjectID;
                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;

                int id = project.ProjectID;

                var users = await _context.PROJECTUSERS.Include(u => u.USERS).Where(u => u.ProjectID == project.ProjectID).OrderBy(u => u.USERS.GetCompleteName).ToListAsync();

                // Filter users that can be added
                List<int> ids = new List<int>();
                if (users != null && users.Count > 0)
                    ids = users.Select(u => u.UserID.Value).ToList();
                var allusers = await _context.USERS.Where(u => !ids.Contains(u.USERID.Value) && !u.IsDisabled && u.ACCESS_LEVEL != Roles.ADMIN).ToListAsync();
                PROJECTUSERS.AvailabeUsers = allusers;

                return View(users);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return Redirect("~/Home/NoPermission");
        }

        [HttpPost]
        public async Task<ExcelLogManager> AddNewUser(string projectCode, string[] username)
        {
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                var project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.Code == projectCode);
                if (project == null)
                {
                    project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.GetCompleteDescription == projectCode);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }
                }

                int counter = 1;
                if (username != null && username.Length > 0)
                {
                    foreach (string userCurrent in username)
                    {
                        var userToAdd = await _context.USERS.Where(u => u.GetCompleteName == userCurrent).FirstOrDefaultAsync();
                        if (userToAdd == null)
                        {
                            excelLogManager.AddLog(counter, 0, "User not found " + User);
                            continue;
                        }
                        if (userToAdd.IsDisabled)
                        {
                            excelLogManager.AddLog(counter, 0, "User disabled " + User);
                            continue;
                        }

                        var currentProjectUser = await _context.PROJECTUSERS.Where(u => u.UserID == userToAdd.USERID.Value && u.ProjectID.Value == project.ProjectID).FirstOrDefaultAsync();
                        if (currentProjectUser != null)
                        {
                            excelLogManager.AddLog(counter, 0, "User already added " + User);
                            continue;
                        }

                        PROJECTUSERS pROJECTUSERS = new PROJECTUSERS();
                        pROJECTUSERS.UserID = userToAdd.USERID.Value;
                        pROJECTUSERS.ProjectID = project.ProjectID;
                        _context.PROJECTUSERS.Add(pROJECTUSERS);

                        counter++;
                    }
                    await _context.SaveChangesAsync();
                }

                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
            }
            catch (Exception ex)
            {
                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
            return excelLogManager;
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteUser(int id)
        {
            try
            {
                var user = await _context.PROJECTUSERS.FindAsync(id);
                if (user != null)
                {
                    _context.PROJECTUSERS.Remove(user);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:UserTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    // Read Data
                    List<string> usernames = new List<string>();
                    List<string> usersurnames = new List<string>();
                    bool notEmpty = true;
                    int startRow = _configuration.GetValue<int>("Excel:UserSheetStartRow");
                    int counter = startRow;
                    int startColumn = _configuration.GetValue<int>("Excel:UserSheetStartColumn");

                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == User.Identity.Name.ToUpper());

                    int totalUsers = 0;
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, startColumn];
                            string name = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 1];
                            string surname = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            if (string.IsNullOrEmpty(name) && string.IsNullOrEmpty(surname))
                            {
                                notEmpty = false;
                            }
                            else if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(surname))
                            {
                                excelLogManager.AddLog(counter, startColumn, "Not valid user");
                            }
                            else
                            {
                                usernames.Add(name);
                                usersurnames.Add(surname);
                            }
                            counter++;
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(counter, 0, ex.Message);
                            notEmpty = false;
                        }
                    }

                    for (int i = 0; i < usernames.Count; i++)
                    {
                        // Search existing User
                        var currentUser = await _context.USERS.Where(p => p.FIRST_NAME.ToUpperInvariant() == usernames[i].ToUpperInvariant() &&
                            p.LAST_NAME.ToUpperInvariant() == usersurnames[i].ToUpperInvariant()).FirstOrDefaultAsync();
                        if (currentUser != null)
                        {
                            var projectUser = await _context.PROJECTUSERS.Where(u => u.ProjectID == project.ProjectID &&
                                u.UserID.Value == currentUser.USERID.Value).FirstOrDefaultAsync();
                            if (projectUser == null)
                            {
                                PROJECTUSERS pROJECTUSERS = new PROJECTUSERS();
                                pROJECTUSERS.UserID = currentUser.USERID.Value;
                                pROJECTUSERS.ProjectID = project.ProjectID;
                                _context.PROJECTUSERS.Add(pROJECTUSERS);
                                totalUsers++;
                            }
                            else
                            {
                                excelLogManager.AddLog(startRow + i, startColumn, "User already present");
                            }
                        }
                        else
                        {
                            excelLogManager.AddLog(startRow + i, startColumn, "Not valid user");
                        }
                    }

                    int result = await _context.SaveChangesAsync();

                    excelLogManager.Result = "Imported " + totalUsers.ToString() + " elements";
                }
            }
            catch { }

            return excelLogManager;
        }


        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:UserTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "Users.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:UserSheetName");
            int startRow = _configuration.GetValue<int>("Excel:UserSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:UserSheetStartColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            var projectUsers = await _context.PROJECTUSERS.Include(u => u.USERS).Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            if (projectUsers != null)
            {
                int currentRow = startRow;
                foreach (PROJECTUSERS user in projectUsers)
                {
                    Sheet.Cells[currentRow, startColumn].Value = user.USERS.FIRST_NAME;
                    Sheet.Cells[currentRow, startColumn + 1].Value = user.USERS.LAST_NAME;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }
    }
}
