﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;

namespace CivilMasterData
{
    public class SECONDARY_ITEM_QUANTITYController : Controller
    {
        private readonly SECONDARY_ITEM_QUANTITYContext _context;

        public SECONDARY_ITEM_QUANTITYController(SECONDARY_ITEM_QUANTITYContext context)
        {
            _context = context;
        }

        // GET: SECONDARY_ITEM_QUANTITY
        public async Task<IActionResult> Index()
        {
            return View(await _context.SECONDARY_ITEM_QUANTITY.ToListAsync());
        }

        // GET: SECONDARY_ITEM_QUANTITY/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sECONDARY_ITEM_QUANTITY = await _context.SECONDARY_ITEM_QUANTITY
                .FirstOrDefaultAsync(m => m.Sec_Item_Qty_Id == id);
            if (sECONDARY_ITEM_QUANTITY == null)
            {
                return NotFound();
            }

            return View(sECONDARY_ITEM_QUANTITY);
        }

        // GET: SECONDARY_ITEM_QUANTITY/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SECONDARY_ITEM_QUANTITY/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Sec_Item_Qty_Id,Sec_Item_Id,EngStatusId,FamilyName,TagTypeId,AB_L1,AB_M,AB_P,Area,BarDiameter,BarLength,CutLength,DB_H,DB_L1,DB_L2,DB_PipeArea,Diameter,DT_Length,DT_MdArea,EC_B,EC_H,EC_Perimeter,FB_H1,FB_L1,FilterBy,FL_H1,FoundationThickness,FP_Area,FP_H1,FP_L1,FP_L1a,FP_L1b,FP_L1c,FP_L2,FP_L2a,FP_L2b,FP_L2c,FP_Perimeter,FP_R,FP_R1,FS_Area,FS_H1,FS_L1,FS_L1a,FS_L1b,FS_L1c,FS_L1d,FS_L2,FS_L2a,FS_L2b,FS_L2c,FS_L2d,FS_Perimeter,GR_H1,GR_L1,GR_L2,HorizontalDownSurface,HorizontalUpSurface,Length,Perimeter,PI_H,PI_L1,PI_L2,Pipe_TotalNumb,PK_H1,PK_L1,PK_L2,PL_D1,PL_H1,PL_H2_CUT_OFF,Plate_B,Plate_tp,QTY,QTY_REBAR,Quantity,ReinforcementQuantity,ShapeId,Slope,StructuralMaterial,Thickness,UnconnectedHeight,VerticalSurface,Volume,WeightperMeter,Width")] SECONDARY_ITEM_QUANTITY sECONDARY_ITEM_QUANTITY)
        {
            if (ModelState.IsValid)
            {
                _context.Add(sECONDARY_ITEM_QUANTITY);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(sECONDARY_ITEM_QUANTITY);
        }

        // GET: SECONDARY_ITEM_QUANTITY/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sECONDARY_ITEM_QUANTITY = await _context.SECONDARY_ITEM_QUANTITY.FindAsync(id);
            if (sECONDARY_ITEM_QUANTITY == null)
            {
                return NotFound();
            }
            return View(sECONDARY_ITEM_QUANTITY);
        }

        // POST: SECONDARY_ITEM_QUANTITY/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Sec_Item_Qty_Id,Sec_Item_Id,EngStatusId,FamilyName,TagTypeId,AB_L1,AB_M,AB_P,Area,BarDiameter,BarLength,CutLength,DB_H,DB_L1,DB_L2,DB_PipeArea,Diameter,DT_Length,DT_MdArea,EC_B,EC_H,EC_Perimeter,FB_H1,FB_L1,FilterBy,FL_H1,FoundationThickness,FP_Area,FP_H1,FP_L1,FP_L1a,FP_L1b,FP_L1c,FP_L2,FP_L2a,FP_L2b,FP_L2c,FP_Perimeter,FP_R,FP_R1,FS_Area,FS_H1,FS_L1,FS_L1a,FS_L1b,FS_L1c,FS_L1d,FS_L2,FS_L2a,FS_L2b,FS_L2c,FS_L2d,FS_Perimeter,GR_H1,GR_L1,GR_L2,HorizontalDownSurface,HorizontalUpSurface,Length,Perimeter,PI_H,PI_L1,PI_L2,Pipe_TotalNumb,PK_H1,PK_L1,PK_L2,PL_D1,PL_H1,PL_H2_CUT_OFF,Plate_B,Plate_tp,QTY,QTY_REBAR,Quantity,ReinforcementQuantity,ShapeId,Slope,StructuralMaterial,Thickness,UnconnectedHeight,VerticalSurface,Volume,WeightperMeter,Width")] SECONDARY_ITEM_QUANTITY sECONDARY_ITEM_QUANTITY)
        {
            if (id != sECONDARY_ITEM_QUANTITY.Sec_Item_Qty_Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(sECONDARY_ITEM_QUANTITY);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SECONDARY_ITEM_QUANTITYExists(sECONDARY_ITEM_QUANTITY.Sec_Item_Qty_Id.Value))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(sECONDARY_ITEM_QUANTITY);
        }

        // GET: SECONDARY_ITEM_QUANTITY/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sECONDARY_ITEM_QUANTITY = await _context.SECONDARY_ITEM_QUANTITY
                .FirstOrDefaultAsync(m => m.Sec_Item_Qty_Id == id);
            if (sECONDARY_ITEM_QUANTITY == null)
            {
                return NotFound();
            }

            return View(sECONDARY_ITEM_QUANTITY);
        }

        // POST: SECONDARY_ITEM_QUANTITY/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var sECONDARY_ITEM_QUANTITY = await _context.SECONDARY_ITEM_QUANTITY.FindAsync(id);
            _context.SECONDARY_ITEM_QUANTITY.Remove(sECONDARY_ITEM_QUANTITY);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SECONDARY_ITEM_QUANTITYExists(int id)
        {
            return _context.SECONDARY_ITEM_QUANTITY.Any(e => e.Sec_Item_Qty_Id == id);
        }
    }
}
