﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;

namespace CivilMasterData
{
    public class WORKINGPACKAGESController : Controller
    {
        private readonly WORKINGPACKAGESContext _context;
        protected readonly ISharedResource _sharedResource;

        public WORKINGPACKAGESController(WORKINGPACKAGESContext context, ISharedResource sharedResource)
        {
            _context = context;
            _sharedResource = sharedResource;
        }

        // GET: WORKINGPACKAGES
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            var wORKINGPACKAGESContext = _context.WORKINGPACKAGES.Include(w => w.Project).Where(w => w.ProjectID == project.ProjectID).Include(w => w.USERS);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(await wORKINGPACKAGESContext.ToListAsync());
        }

        // GET: WORKINGPACKAGES/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var wORKINGPACKAGES = await _context.WORKINGPACKAGES
                .Include(w => w.Project)
                .Include(w => w.USERS)
                .FirstOrDefaultAsync(m => m.IDWP == id);
            if (wORKINGPACKAGES == null)
            {
                return NotFound();
            }

            return View(wORKINGPACKAGES);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteWP(int id)
        {
            try
            {
                var wp = await _context.WORKINGPACKAGES.FindAsync(id);
                if (wp != null)
                {
                    var items = await _context.MAINITEMS.Where(m => m.WORKINGPACKAGESID.Value == wp.IDWP).ToListAsync();
                    if (items == null || items.Count == 0)
                    {
                        _context.WORKINGPACKAGES.Remove(wp);
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        return _sharedResource.Message(MESSAGE_CODES.WP_WITH_MAIN_ITEMS);
                    }
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // GET: WORKINGPACKAGES/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View();
        }


        // POST: WORKINGPACKAGES/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IDWP,NAME,NOTES,ProjectID,UserID,CreationDate,LastModified")] WORKINGPACKAGES wORKINGPACKAGES)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == wORKINGPACKAGES.ProjectID);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    var wp = await _context.WORKINGPACKAGES.Where(p => p.ProjectID == project.ProjectID && wORKINGPACKAGES.NAME == p.NAME).FirstOrDefaultAsync();
                    if (wp == null)
                    {
                        if (string.IsNullOrEmpty(wORKINGPACKAGES.NAME))
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.WP_NAME_NOT_CORRECT);
                        }
                        else
                        {
                            wORKINGPACKAGES.UserID = user.USERID;
                            wORKINGPACKAGES.CreationDate = DateTime.UtcNow;
                            wORKINGPACKAGES.LastModified = DateTime.UtcNow;
                            _context.WORKINGPACKAGES.Add(wORKINGPACKAGES);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                        }
                    }
                    else
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(wORKINGPACKAGES);
        }


        [HttpPost]
        public async Task<string> CreateNewWP(string code, string wpname, string wpdescription)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    var wp = await _context.WORKINGPACKAGES.Where(p => p.ProjectID == project.ProjectID && wpname == p.NAME).FirstOrDefaultAsync();
                    if (wp == null)
                    {
                        if (string.IsNullOrEmpty(wpname))
                        {
                            return _sharedResource.Message(MESSAGE_CODES.WP_NAME_NOT_CORRECT);
                        }
                        else
                        {
                            WORKINGPACKAGES wORKINGPACKAGES = new WORKINGPACKAGES();
                            wORKINGPACKAGES.UserID = user.USERID;
                            wORKINGPACKAGES.CreationDate = DateTime.UtcNow;
                            wORKINGPACKAGES.LastModified = DateTime.UtcNow;
                            wORKINGPACKAGES.NAME = wpname;
                            wORKINGPACKAGES.NOTES = wpdescription;
                            wORKINGPACKAGES.ProjectID = project.ProjectID;
                            _context.WORKINGPACKAGES.Add(wORKINGPACKAGES);
                            await _context.SaveChangesAsync();
                            return _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                        }
                    }
                    else
                    {
                        return _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);
                    }
                }
                else
                {
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);
                }
            }
            else
            {
                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
        }

        [HttpPost]
        public async Task<string> UpdateValues(string code,
            string wpidstr,
            string descriptionsstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    ViewBag.Project = project.Code;

                    var wpList = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    int[] wpIds = Utils.SplitIntVector(wpidstr);
                    string[] descriptions = Utils.SplitText(descriptionsstr);

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in wpIds)
                    {
                        var currentWP = wpList.Where(p => p.IDWP == id && p.ProjectID == project.ProjectID).FirstOrDefault();
                        if (currentWP != null)
                        {
                            currentWP.NOTES = descriptions[counter];
                            currentWP.LastModified = DateTime.UtcNow;
                            currentWP.UserID = user.USERID;
                            changed = true;
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, "WP " + id.ToString()) + "; ";
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        // GET: WORKINGPACKAGES/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var wORKINGPACKAGES = await _context.WORKINGPACKAGES.FindAsync(id);
            if (wORKINGPACKAGES == null)
            {
                return NotFound();
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == wORKINGPACKAGES.ProjectID);
            if (project != null)
            {
                ViewBag.ProjectID = project.ProjectID;
                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;
            }

            return View(wORKINGPACKAGES);
        }

        // POST: WORKINGPACKAGES/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IDWP,NAME,NOTES,ProjectID,UserID,CreationDate,LastModified")] WORKINGPACKAGES wORKINGPACKAGES)
        {
            if (id != wORKINGPACKAGES.IDWP)
            {
                return NotFound();
            }

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null)
                {
                    try
                    {
                        bool foundWithDifferentId = false;
                        var list = _context.WORKINGPACKAGES.Where(w => w.NAME == wORKINGPACKAGES.NAME &&
                            w.ProjectID == wORKINGPACKAGES.ProjectID && w.IDWP != wORKINGPACKAGES.IDWP).ToList();
                        if (list != null && list.Count > 0)
                            foundWithDifferentId = true;

                        if (!foundWithDifferentId)
                        {
                            wORKINGPACKAGES.UserID = user.USERID;
                            wORKINGPACKAGES.USERS = user;
                            wORKINGPACKAGES.LastModified = DateTime.UtcNow;

                            _context.Update(wORKINGPACKAGES);
                            await _context.SaveChangesAsync();

                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                        }
                        else
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);
                        }
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);
                        if (!WORKINGPACKAGESExists(wORKINGPACKAGES.IDWP))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                }
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == wORKINGPACKAGES.ProjectID);
            if (project != null)
            {
                ViewBag.ProjectID = project.ProjectID;
                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;
            }
            return View(wORKINGPACKAGES);
        }

        // GET: WORKINGPACKAGES/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var wORKINGPACKAGES = await _context.WORKINGPACKAGES
                .Include(w => w.Project)
                .Include(w => w.USERS)
                .FirstOrDefaultAsync(m => m.IDWP == id);
            if (wORKINGPACKAGES == null)
            {
                return NotFound();
            }

            return View(wORKINGPACKAGES);
        }

        // POST: WORKINGPACKAGES/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var wORKINGPACKAGES = await _context.WORKINGPACKAGES.FindAsync(id);
            _context.WORKINGPACKAGES.Remove(wORKINGPACKAGES);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool WORKINGPACKAGESExists(int id)
        {
            return _context.WORKINGPACKAGES.Any(e => e.IDWP == id);
        }
    }
}
