﻿namespace CivilMasterData.Controllers.Support
{
    public static class ForgeAPI
    {
        public const string FORGE_BASE_URL = "https://developer.api.autodesk.com";
        const string FORGE_MODEL_DERIVATIVE_V2 = "/modelderivative/v2/designdata/";
        
        public static string GetBaseUrlMetadata(string urn)
        {
            return FORGE_MODEL_DERIVATIVE_V2 + urn + "/metadata";
        }
        public static string GetBaseUrlHierarchy(string urn, string guid)
        {
            return FORGE_MODEL_DERIVATIVE_V2 + urn + "/metadata/" + guid;
        }
        public static string GetBaseUrlProperties(string urn, string guid)
        {
            return FORGE_MODEL_DERIVATIVE_V2 + urn + "/metadata/" + guid + "/properties";
        }
    }
}
