﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models.PriceList;
using CivilMasterData.Models;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using OfficeOpenXml;
using CivilMasterData.Models.Costants;

namespace CivilMasterData
{
    public class PRICECODEDEFINITIONSController : Controller
    {
        private readonly PRICECODEDEFINITIONSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PRICECODEDEFINITIONSController(PRICECODEDEFINITIONSContext context,
            IConfiguration configuration, ISharedResource sharedResource, IWebHostEnvironment env)
        {
            _context = context;
            _configuration = configuration;
            this._sharedResource = sharedResource;
            _env = env;
        }

        // GET: PRICECODEDEFINITIONS
        public async Task<IActionResult> Index(string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return NotFound();
                    if (user.IsDisabled)
                        return Redirect("~/Home/NoPermission");

                    if (String.IsNullOrEmpty(code))
                        return NotFound();
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return NotFound();
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;


                    var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).Include(p => p.Project).ToListAsync();

                    return View(pRICECODEDEFINITIONS);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return NotFound();
        }

        // GET: PRICECODEDEFINITIONS/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.PriceCodeDefinitionID == id);
            if (pRICECODEDEFINITIONS == null)
            {
                return NotFound();
            }

            return View(pRICECODEDEFINITIONS);
        }

        // GET: PRICECODEDEFINITIONS/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View();
        }

        // POST: PRICECODEDEFINITIONS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PriceCodeDefinitionID,ProjectID,GroupCode,PriceGroupDescription")] PRICECODEDEFINITIONS pRICECODEDEFINITIONS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICECODEDEFINITIONS.ProjectID);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    if (String.IsNullOrEmpty(pRICECODEDEFINITIONS.GroupCode) || string.IsNullOrEmpty(pRICECODEDEFINITIONS.PriceGroupDescription))
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_GROUP_NOT_VALID);
                    }
                    else
                    {
                        var pricecode = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == pRICECODEDEFINITIONS.ProjectID &&
                        p.GroupCode.ToUpperInvariant() == pRICECODEDEFINITIONS.GroupCode.ToUpperInvariant()).FirstOrDefaultAsync();
                        if (pricecode == null)
                        {
                            _context.Add(pRICECODEDEFINITIONS);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_GROUP_CREATED);
                        }
                        else
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_GROUP_EXISTING);
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_GROUP_NOT_VALID);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pRICECODEDEFINITIONS);
        }

        // GET: PRICECODEDEFINITIONS/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS.FindAsync(id);
            if (pRICECODEDEFINITIONS == null)
            {
                return NotFound();
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICECODEDEFINITIONS.ProjectID);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(pRICECODEDEFINITIONS);
        }

        // POST: PRICECODEDEFINITIONS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PriceCodeDefinitionID,ProjectID,GroupCode,PriceGroupDescription")] PRICECODEDEFINITIONS pRICECODEDEFINITIONS)
        {
            if (id != pRICECODEDEFINITIONS.PriceCodeDefinitionID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pRICECODEDEFINITIONS);
                    await _context.SaveChangesAsync();
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PRICECODEDEFINITIONSExists(pRICECODEDEFINITIONS.PriceCodeDefinitionID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);
                        throw;
                    }
                }
            }
            else
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICECODEDEFINITIONS.ProjectID);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(pRICECODEDEFINITIONS);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteMultipleGroups(string idStr)
        {
            try
            {
                int[] pbsList = Utils.SplitIntVector(idStr);
                if (pbsList != null && pbsList.Length > 0)
                {
                    foreach (int id in pbsList)
                    {
                        var group = await _context.PRICECODEDEFINITIONS.FindAsync(id);
                        if (group != null)
                            _context.PRICECODEDEFINITIONS.Remove(group);
                    }
                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
            return string.Empty;
        }


        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteGroup(int id)
        {
            try
            {
                var group = await _context.PRICECODEDEFINITIONS.FindAsync(id);
                if (group != null)
                {
                    _context.PRICECODEDEFINITIONS.Remove(group);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // GET: PRICECODEDEFINITIONS/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.PriceCodeDefinitionID == id);
            if (pRICECODEDEFINITIONS == null)
            {
                return NotFound();
            }

            return View(pRICECODEDEFINITIONS);
        }

        // POST: PRICECODEDEFINITIONS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS.FindAsync(id);
            _context.PRICECODEDEFINITIONS.Remove(pRICECODEDEFINITIONS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<string> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            string lfcr = "\r\n";
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                        return "Project not found";

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var groups = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    List<string> names = new List<string>();
                    if (groups != null)
                        names = groups.Select(c => c.GroupCode.ToUpperInvariant()).ToList();

                    // Read Data
                    List<string> groupList = new List<string>();
                    List<string> descriptionList = new List<string>();
                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            string groupCode = worksheet.Cells[counter, 1].Value != null ? worksheet.Cells[counter, 1].Value.ToString() : string.Empty;
                            string description = worksheet.Cells[counter, 2].Value != null ? worksheet.Cells[counter, 2].Value.ToString() : string.Empty;

                            if (string.IsNullOrEmpty(groupCode))
                                notEmpty = false;
                            else
                            {
                                groupList.Add(groupCode);
                                descriptionList.Add(description);
                            }
                            counter++;
                        }
                        catch
                        {
                            notEmpty = false;
                        }
                    }

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            for (int i = 0; i < groupList.Count; i++)
                            {
                                if (names.Contains(groupList[i].ToUpperInvariant()))
                                {
                                    msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, groupList[i]) + lfcr;
                                    continue;
                                }

                                PRICECODEDEFINITIONS pRICECODEDEFINITIONS = new PRICECODEDEFINITIONS();
                                pRICECODEDEFINITIONS.ProjectID = project.ProjectID;
                                pRICECODEDEFINITIONS.GroupCode = groupList[i];
                                pRICECODEDEFINITIONS.PriceGroupDescription = descriptionList[i];
                                _context.PRICECODEDEFINITIONS.Add(pRICECODEDEFINITIONS);
                                await _context.SaveChangesAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message) + lfcr;
                        }
                    }
                    else
                    {
                        msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED) + lfcr;
                    }
                }
            }
            catch { }

            return string.IsNullOrEmpty(msg) ? "Imported" : msg;
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:PriceCodeDefinitionsTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        private bool PRICECODEDEFINITIONSExists(int? id)
        {
            return _context.PRICECODEDEFINITIONS.Any(e => e.PriceCodeDefinitionID == id);
        }
    }
}
