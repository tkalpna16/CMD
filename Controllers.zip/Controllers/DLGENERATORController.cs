﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Models;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Helpers;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;

namespace CivilMasterData.Controllers
{
    public class DLGENERATORController : Controller
    {
        #region Private members
        private readonly DLGENERATORContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;
        #endregion

        #region Constructor
        public DLGENERATORController(DLGENERATORContext context,
            ISharedResource sharedResource,
            IConfiguration configuration,
            IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
            _env = env;
        }
        #endregion

        #region View
        public async Task<IActionResult> Index(string code, int revision)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER))
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }
            ViewBag.Role = user.ACCESS_LEVEL;

            DLGENERATOR dLGENERATOR = new DLGENERATOR();

            var revisions = await _context.REVISIONS.Where(d => d.ProjectID == project.ProjectID)
                .OrderByDescending(d => d.RevisionNumber)
                .ToListAsync();

            if (revisions != null && revisions.Count > 0)
            {
                var currentRevision = revisions.Where(r => r.RevisionNumber == revision).FirstOrDefault();
                if (currentRevision == null)
                    currentRevision = revisions[0];

                var drawings = await _context.DRAWINGS.Where(d => d.ProjectID == project.ProjectID && d.RevisionsID.Value == currentRevision.RevisionID)
                    .OrderBy(d => d.TCMDrawingNumber)
                    .ToListAsync();
                dLGENERATOR.Drawings = drawings;

                ViewBag.Revisions = revisions.Select(r => r.GetDescription).ToList();

                ViewBag.CurrentRevision = currentRevision.GetDescription;
            }
            else
            {
                ViewBag.Revisions = new List<string>();
                dLGENERATOR.Drawings = new List<DRAWINGS>(); // Init List
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            ViewBag.MaxDoc = projectSettings.DRAWING_MAX_MANUAL_NDOCS;

            return View(dLGENERATOR);
        }
        public async Task<List<Document>> GetDrawingList(string code, string revision)
        {
            List<Document> drawings = new List<Document>();

            if (String.IsNullOrEmpty(code))
                return null;

            DLGENERATOR dLGENERATOR = new DLGENERATOR();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return null;

            var revisions = await _context.REVISIONS.Where(d => d.ProjectID == project.ProjectID)
                .OrderByDescending(d => d.GetDescription == revision)
                .FirstOrDefaultAsync();

            if (revisions != null)
            {
                var drawingList = await _context.DRAWINGS.Where(d => d.ProjectID == project.ProjectID && d.RevisionsID.Value == revisions.RevisionID)
                    .Include(d => d.DOCUMENTTYPE).ToListAsync();
                if (drawingList != null && drawingList.Count > 0)
                {
                    foreach (var drawing in drawingList)
                    {
                        Document doc = new Document();
                        doc.Code = drawing.TCMDrawingNumber;
                        doc.Description = drawing.DrawingDescription;
                        drawings.Add(doc);
                    }
                }
            }
            else
                drawings = new List<Document>(); // Init List


            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return drawings;
        }
        public async Task<IActionResult> Edit(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            DLGENERATOR dLGENERATOR = new DLGENERATOR();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

            var drawingSize = await _context.DRAWINGSIZES.ToListAsync();
            var drawingScale = await _context.DRAWINGSCALES.ToListAsync();
            var docType = await _context.DOCUMENTTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            var pbsList = pbs.Select(p => p.PBSID).Distinct().ToList();
            var objectCodes = await _context.OBJECTCODES.ToListAsync();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var aadcFactors = await _context.AADCFACTORS.ToListAsync();
            var aiduFactors = await _context.AIDUFACTORS.ToListAsync();
            var importanceStatus = await _context.IMPORTANCESTATUS.ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LV01_Object_Code)
                .Include(m => m.IMPORTANCESTATUS).Where(m => m.PBS.ProjectID == project.ProjectID)
                .ToListAsync();

            REVISIONS lastRevision = await _context.REVISIONS.Where(r => r.ProjectID == project.ProjectID).OrderByDescending(r => r.RevisionNumber).FirstOrDefaultAsync();

            List<string> itemsList = new List<string>();
            List<MAINITEMS> itemsCleaned = new List<MAINITEMS>();
            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    bool found = false;
                    if (item.IsReplaced)
                        continue;
                    if (item.IsDeleted)
                        continue;
                    foreach (MAINITEMS item2 in itemsCleaned)
                    {
                        if (item2.MainItemTag == item.MainItemTag && item.TagTypeID == item2.TagTypeID)
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        itemsCleaned.Add(item);
                }
            }
            mainItems = itemsCleaned;

            List<int> mainItemsIds = mainItems.Select(m => m.MainItemID).ToList();
            var itemDocuments = await _context.DOCUMENTSETTINGS.Where(d => d.ProjectID == project.ProjectID).ToListAsync();
            var pbsDocuments = await _context.PBSDRAWINGS.Where(d => pbsList.Contains(d.PBSID.Value)).ToListAsync();
            List<MAINITEMDRAWINGS> mainItemDrawings = new List<MAINITEMDRAWINGS>();

            if (mainItemsIds.Count < Utils.MAX_ORACLE_QUERY_LIST)
                mainItemDrawings = await _context.MAINITEMDRAWINGS.Where(m => mainItemsIds.Contains(m.MainItemID.Value)).ToListAsync();
            else
            {
                IEnumerable<IEnumerable<int>> splitted = Utils.Chunk<int>(mainItemsIds, Utils.USED_ORACLE_QUERY_LIST);
                if (splitted != null)
                {
                    List<MAINITEMDRAWINGS> drawings;
                    foreach (IEnumerable<int> split in splitted)
                    {
                        List<int> currentIds = split.ToList();
                        drawings = await _context.MAINITEMDRAWINGS.Where(m => currentIds.Contains(m.MainItemID.Value)).ToListAsync();
                        if (drawings != null && drawings.Count > 0)
                        {
                            mainItemDrawings.AddRange(drawings);
                        }
                    }
                }
            }
            // Settings
            var aadaSettings = await _context.AADASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var aadcSettings = await _context.AADCSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var aacsSettings = await _context.AACSSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var aiduSettings = await _context.AIDUSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var aidaSettings = await _context.AIDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var aicsSettings = await _context.AICSSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var aqdaSettings = await _context.AQDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var apdaSettings = await _context.APDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            var ardaSettings = await _context.ARDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();

            int tagTypeFoundation = _configuration.GetValue<int>("Items:TagTypeFoundationConcrete");
            int tagTypeElevation = _configuration.GetValue<int>("Items:TagTypeElevationConcrete");
            int tagTypePiles = _configuration.GetValue<int>("Items:TagTypePiles");
            int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");

            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    item.AADCSETTINGS = aadcSettings;
                    item.AIDUSETTINGS = aiduSettings;
                    item.UpdateDrawingFactors(aadcFactors, aiduFactors, tagTypeFoundation, tagTypeElevation, tagTypeSteel);
                    item.CalculateNumberOfDocuments(tagTypeFoundation, tagTypeElevation, tagTypeSteel);
                }
            }
            if (mainItemDrawings != null)
                foreach (MAINITEMDRAWINGS mAINITEMDRAWINGS in mainItemDrawings)
                {
                    mAINITEMDRAWINGS.PROJECTSETTINGS = projectSettings;

                    mAINITEMDRAWINGS.AACSSETTINGS = aacsSettings;
                    mAINITEMDRAWINGS.AADASETTINGS = aadaSettings;
                    mAINITEMDRAWINGS.AICSSETTINGS = aicsSettings;

                    int totalAACS = 0;
                    int totalAADA = 0;
                    int totalAICS = 0;
                    int totalAADC = 0;
                    if (lastRevision != null)
                    {
                        var drawingsAACS = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                            d.MainItemTag == mAINITEMDRAWINGS.MAINITEM.MainItemTag && d.DOCUMENTTYPE.TCMCode == "AA-CS").ToListAsync();
                        if (drawingsAACS != null)
                            totalAACS = drawingsAACS.Count;
                        mAINITEMDRAWINGS.AACSNumDocsRevision = totalAACS;

                        var drawingsAADA = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                            d.MainItemTag == mAINITEMDRAWINGS.MAINITEM.MainItemTag && d.DOCUMENTTYPE.TCMCode == "AA-DA").ToListAsync();
                        if (drawingsAADA != null)
                            totalAADA = drawingsAADA.Count;
                        mAINITEMDRAWINGS.AADANumDocsRevision = totalAADA;

                        var drawingsAICS = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                            d.MainItemTag == mAINITEMDRAWINGS.MAINITEM.MainItemTag && d.DOCUMENTTYPE.TCMCode == "AI-CS").ToListAsync();
                        if (drawingsAICS != null)
                            totalAICS = drawingsAICS.Count;
                        mAINITEMDRAWINGS.AICSNumDocsRevision = totalAICS;

                        var drawingsAADC = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                            d.MainItemTag == mAINITEMDRAWINGS.MAINITEM.MainItemTag && d.DOCUMENTTYPE.TCMCode == "AA-DC").ToListAsync();
                        if (drawingsAADC != null)
                            totalAADC = drawingsAACS.Count;
                        mAINITEMDRAWINGS.AADCNumDocsRevision = totalAADC;
                    }
                }
            if (pbsDocuments != null)
            {
                foreach (var doc in pbsDocuments)
                {
                    doc.APDASETTINGS = apdaSettings;
                    doc.AQDASETTINGS = aqdaSettings;
                    doc.ARDASETTINGS = ardaSettings;

                    doc.PROJECTSETTINGS = projectSettings;

                    if (lastRevision != null)
                    {
                        int totalAPDA = 0;
                        var drawingsAPDA = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                                d.CWA == doc.PBS.CWA && d.DOCUMENTTYPE.TCMCode == "AP-DA").ToListAsync();
                        if (drawingsAPDA != null)
                            totalAPDA = drawingsAPDA.Count;
                        doc.APDANumDocsRevision = totalAPDA;

                        int totalAQDA = 0;
                        var drawingsAQDA = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                                d.CWA == doc.PBS.CWA && d.DOCUMENTTYPE.TCMCode == "AQ-DA").ToListAsync();
                        if (drawingsAQDA != null)
                            totalAQDA = drawingsAQDA.Count;
                        doc.AQDANumDocsRevision = totalAQDA;

                        int totalARDA = 0;
                        var drawingsARDA = await _context.DRAWINGS.Where(d => d.RevisionsID.Value == lastRevision.RevisionID &&
                                d.CWA == doc.PBS.CWA && d.DOCUMENTTYPE.TCMCode == "AR-DA").ToListAsync();
                        if (drawingsARDA != null)
                            totalARDA = drawingsARDA.Count;
                        doc.ARDANumDocsRevision = totalARDA;
                    }
                }
            }

            dLGENERATOR.Pbs = pbs;
            dLGENERATOR.MainItems = mainItems;
            dLGENERATOR.DrawingSizes = drawingSize;
            dLGENERATOR.DrawingScales = drawingScale;
            dLGENERATOR.DocumentSettings = itemDocuments;
            dLGENERATOR.MainItemDrawings = mainItemDrawings;
            dLGENERATOR.PBSDrawings = pbsDocuments;

            // Init items sublist
            dLGENERATOR.FoundationElevations = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                m.MAINITEM.TagTypeID == tagTypeElevation) && !m.MAINITEM.IsBalance).ToList();
            if (mainItemDrawings != null)
            {
                foreach (var item in mainItemDrawings)
                {
                    if (item.MAINITEM.TagTypeID == tagTypeFoundation && item.MAINITEM.IsBalance)
                    {
                        if (dLGENERATOR.FoundationElevations == null)
                            dLGENERATOR.FoundationElevations = new List<MAINITEMDRAWINGS>();
                        dLGENERATOR.FoundationElevations.Add(item);
                    }
                }
            }

            dLGENERATOR.PilesAndFoundationBalance = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                m.MAINITEM.TagTypeID == tagTypePiles) && m.MAINITEM.IsBalance).ToList();

            dLGENERATOR.PilesFoundationElevationConcrete = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                m.MAINITEM.TagTypeID == tagTypeElevation || m.MAINITEM.TagTypeID == tagTypePiles) && !m.MAINITEM.IsBalance).ToList();
            if (mainItemDrawings != null)
            {
                foreach (var item in mainItemDrawings)
                {
                    if (item.MAINITEM.TagTypeID == tagTypeFoundation && item.MAINITEM.IsBalance)
                    {
                        if (dLGENERATOR.PilesFoundationElevationConcrete == null)
                            dLGENERATOR.PilesFoundationElevationConcrete = new List<MAINITEMDRAWINGS>();
                        dLGENERATOR.PilesFoundationElevationConcrete.Add(item);
                    }
                }
            }

            dLGENERATOR.Piles = mainItemDrawings.Where(m => m.MAINITEM.TagTypeID == tagTypePiles).ToList();

            dLGENERATOR.Steel = mainItemDrawings.Where(m => m.MAINITEM.TagTypeID == tagTypeSteel && !m.MAINITEM.IsBalance).ToList();
            if (mainItemDrawings != null)
            {
                foreach (var item in mainItemDrawings)
                {
                    if (item.MAINITEM.TagTypeID == tagTypeSteel && item.MAINITEM.IsBalance)
                    {
                        if (dLGENERATOR.Steel == null)
                            dLGENERATOR.Steel = new List<MAINITEMDRAWINGS>();
                        dLGENERATOR.Steel.Add(item);
                    }
                }
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            // AADA
            ViewBag.AADADrawingScale = aadaSettings.SCALE.Description;
            ViewBag.AADADrawingSize = aadaSettings.SIZE.Description;
            ViewBag.AADADrawingNum = aadaSettings.MinimumDrawing;
            ViewBag.AADAArea = aadaSettings.ReferenceArea;

            // AADC
            ViewBag.AADCFoundationPR_FP = aadcSettings.FoundPipeMinimumDrwFP;
            ViewBag.AADCFoundationST_FP = aadcSettings.FoundProcessMinimumDrwFP;
            ViewBag.AADCFoundationEQ_FP = aadcSettings.FoundEquipmentMinimumDrwFP;
            ViewBag.AADCFoundationBL_FP = aadcSettings.FoundBuildingMinimumDrwFP;
            ViewBag.AADCFoundationBS_FP = aadcSettings.FoundBasinMinimumDrwFP;
            ViewBag.AADCFoundationOther_FP = aadcSettings.FoundOtherMinimumDrwFP;

            ViewBag.AADCFoundationPR_FW = aadcSettings.FoundPipeMinimumDrwFW;
            ViewBag.AADCFoundationST_FW = aadcSettings.FoundProcessMinimumDrwFW;
            ViewBag.AADCFoundationEQ_FW = aadcSettings.FoundEquipmentMinimumDrwFW;
            ViewBag.AADCFoundationBL_FW = aadcSettings.FoundBuildingMinimumDrwFW;
            ViewBag.AADCFoundationBS_FW = aadcSettings.FoundBasinMinimumDrwFW;
            ViewBag.AADCFoundationOther_FW = aadcSettings.FoundOtherMinimumDrwFW;

            ViewBag.AADCFoundationPR_RF = aadcSettings.FoundPipeMinimumDrwRF;
            ViewBag.AADCFoundationST_RF = aadcSettings.FoundProcessMinimumDrwRF;
            ViewBag.AADCFoundationEQ_RF = aadcSettings.FoundEquipmentMinimumDrwRF;
            ViewBag.AADCFoundationBL_RF = aadcSettings.FoundBuildingMinimumDrwRF;
            ViewBag.AADCFoundationBS_RF = aadcSettings.FoundBasinMinimumDrwRF;
            ViewBag.AADCFoundationOther_RF = aadcSettings.FoundOtherMinimumDrwRF;

            ViewBag.AADCFoundationPR_BBS = aadcSettings.FoundPipeMinimumDrwBBS;
            ViewBag.AADCFoundationST_BBS = aadcSettings.FoundProcessMinimumDrwBBS;
            ViewBag.AADCFoundationEQ_BBS = aadcSettings.FoundEquipmentMinimumDrwBBS;
            ViewBag.AADCFoundationBL_BBS = aadcSettings.FoundBuildingMinimumDrwBBS;
            ViewBag.AADCFoundationBS_BBS = aadcSettings.FoundBasinMinimumDrwBBS;
            ViewBag.AADCFoundationOther_BBS = aadcSettings.FoundOtherMinimumDrwBBS;


            ViewBag.AADCElevationPR_EP = aadcSettings.ElePipeMinimumDrwEP;
            ViewBag.AADCElevationST_EP = aadcSettings.EleProcessMinimumDrwEP;
            ViewBag.AADCElevationOther_EP = aadcSettings.EleOtherMinimumDrwEP;

            ViewBag.AADCElevationPR_FW = aadcSettings.ElePipeMinimumDrwFW;
            ViewBag.AADCElevationST_FW = aadcSettings.EleProcessMinimumDrwFW;
            ViewBag.AADCElevationOther_FW = aadcSettings.EleOtherMinimumDrwFW;

            ViewBag.AADCElevationEQ = aadcSettings.EleEquipmentMinimumDrw;
            ViewBag.AADCElevationBL = aadcSettings.EleBuildingMinimumDrw;

            ViewBag.AADCElevationPR_BBS = aadcSettings.ElePipeMinimumDrwBBS;
            ViewBag.AADCElevationST_BBS = aadcSettings.EleProcessMinimumDrwBBS;
            ViewBag.AADCElevationOther_BBS = aadcSettings.EleOtherMinimumDrwBBS;

            ViewBag.AADCElevationPR_RF = aadcSettings.ElePipeMinimumDrwRF;
            ViewBag.AADCElevationST_RF = aadcSettings.EleProcessMinimumDrwRF;
            ViewBag.AADCElevationOther_RF = aadcSettings.EleOtherMinimumDrwRF;

            // AACS
            ViewBag.AACSMinimumDrawing = aacsSettings.MinimumDrawing;

            // AIDU
            ViewBag.AIDUPipeStructureMinimumDrw = aiduSettings.PipeStructureMinimumDrw;
            ViewBag.AIDUFoundProcessRefArea = aiduSettings.FoundProcessRefArea;
            ViewBag.AIDUFoundBuildingMinimumDrw = aiduSettings.FoundBuildingMinimumDrw;
            ViewBag.AIDUFoundOtherMinimumDrw = aiduSettings.FoundOtherMinimumDrw;

            // AIDA
            ViewBag.AIDAMinimumDrawing = aidaSettings.MinimumDrawing;

            // AICS
            ViewBag.AICSMinimumDrawing = aicsSettings.MinimumDrawing;

            // AQDA SETTINGS
            ViewBag.AQDADrawingScale = aqdaSettings.SCALE.Description;
            ViewBag.AQDADrawingSize = aqdaSettings.SIZE.Description;
            ViewBag.AQDADrawingNum = aqdaSettings.MinimumDrawing;
            ViewBag.AQDAArea = aqdaSettings.ReferenceArea;

            // APDA SETTINGS
            ViewBag.APDADrawingScale = apdaSettings.SCALE.Description;
            ViewBag.APDADrawingSize = apdaSettings.SIZE.Description;
            ViewBag.APDADrawingNum = apdaSettings.MinimumDrawing;
            ViewBag.APDAArea = apdaSettings.ReferenceArea;

            // ARDA SETTINGS
            ViewBag.ARDADrawingScale = ardaSettings.SCALE.Description;
            ViewBag.ARDADrawingSize = ardaSettings.SIZE.Description;
            ViewBag.ARDADrawingNum = ardaSettings.MinimumDrawing;
            ViewBag.ARDAArea = ardaSettings.ReferenceArea;

            ViewBag.MaxDoc = projectSettings.DRAWING_MAX_MANUAL_NDOCS;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(dLGENERATOR);
        }
        #endregion

        #region Common Documents
        [HttpPost]
        public async Task<string> UpdateCommonDocuments(string code, string documentstr, string descrstr, string numberstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var docTypesList = await _context.DOCUMENTTYPES.ToListAsync();

                    string[] docList = Utils.SplitText(documentstr);
                    string[] descrList = Utils.SplitTextWithComma(descrstr);
                    int[] numList = Utils.SplitIntVector(numberstr);

                    bool changed = false;
                    int counter = -1;
                    foreach (string item in docList)
                    {
                        counter++;
                        if (string.IsNullOrEmpty(item))
                            continue;
                        var docSettings = docSettingsList.Where(d => d.DOCUMENTTYPE.TCMCode == item &&
                            d.DOCUMENTTYPE.Description == descrList[counter]).FirstOrDefault();
                        if (docSettings == null)
                        {
                            // Add Messge
                            continue;
                        }
                        docSettings.NUMBEROFDOCUMENTS = numList[counter];
                        changed = true;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg = _sharedResource.Message(MESSAGE_CODES.COMMON_DOCUMENTS_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }
        #endregion

        #region AADA
        [HttpPost]
        public async Task<string> UpdateAADASettings(string code, string scale, string size,
            int numdrw, double area)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var drawingScale = await _context.DRAWINGSCALES.Where(d => d.Description == scale).FirstOrDefaultAsync();
                    var drawingSize = await _context.DRAWINGSIZES.Where(d => d.Description == size).FirstOrDefaultAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aadaSetting = await _context.AADASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (drawingScale != null && drawingSize != null)
                    {
                        aadaSetting.ScaleID = drawingScale.ScaleID;
                        aadaSetting.SizeID = drawingSize.SizeID;

                        if (numdrw > projectSettings.DRAWING_MAX_MANUAL_NDOCS)
                            numdrw = projectSettings.DRAWING_MAX_MANUAL_NDOCS;

                        aadaSetting.MinimumDrawing = numdrw;
                        aadaSetting.ReferenceArea = area;
                        aadaSetting.LastModified = DateTime.UtcNow;
                        aadaSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        [HttpPost]
        public async Task<string> UpdateAADA(string code, string itemTagsStr, string tagTypesStr, string drawingsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aadaSetting = await _context.AADASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] itemTagTypes = Utils.SplitText(tagTypesStr);
                    string[] drawingsCount = Utils.SplitText(drawingsStr);

                    int counter = 0;
                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                        {
                            counter++;
                            continue;
                        }

                        var tagType = await _context.TAGTYPES.Where(t => t.Description == itemTagTypes[counter]).FirstOrDefaultAsync();
                        if (tagType == null)
                        {
                            counter++;
                            continue;
                        }

                        var pbs = await _context.PBS.Where(i => i.Area == item && i.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                        if (pbs == null)
                        {
                            counter++;
                            continue;
                        }

                        var mainItemDrawing = await _context.MAINITEMDRAWINGS.Where(d => d.MAINITEM.PBS.PBSID == pbs.PBSID &&
                            d.MAINITEM.TagTypeID == tagType.TagTypeID).ToListAsync();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        int drawingNum = 0;
                        bool valid = int.TryParse(drawingsCount[counter], out drawingNum);


                        if (mainItemDrawing != null)
                        {
                            if (drawingNum > projectSettings.DRAWING_MAX_MANUAL_NDOCS)
                                drawingNum = projectSettings.DRAWING_MAX_MANUAL_NDOCS;
                            foreach (var drawing in mainItemDrawing)
                            {
                                if (valid)
                                    drawing.AADANumDocs = drawingNum;
                                else
                                    drawing.AADANumDocs = null;
                            }
                        }

                        counter++;
                    }

                    int resultVal = await _context.SaveChangesAsync();
                    msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region AADC
        [HttpPost]
        public async Task<string> UpdateAADCSettings(string code,
            int foundationPR_FP,
            int foundationST_FP,
            int foundationEQ_FP,
            int foundationBL_FP,
            int foundationBS_FP,
            int foundationOther_FP,
            int foundationPR_FW,
            int foundationST_FW,
            int foundationEQ_FW,
            int foundationBL_FW,
            int foundationBS_FW,
            int foundationOther_FW,
            int foundationPR_RF,
            int foundationST_RF,
            int foundationEQ_RF,
            int foundationBL_RF,
            int foundationBS_RF,
            int foundationOther_RF,
            int foundationPR_BBS,
            int foundationST_BBS,
            int foundationEQ_BBS,
            int foundationBL_BBS,
            int foundationBS_BBS,
            int foundationOther_BBS,
            int elevationPR_EP,
            int elevationST_EP,
            int elevationOther_EP,
            int elevationPR_FW,
            int elevationST_FW,
            int elevationOther_FW,
            int elevationPR_RF,
            int elevationST_RF,
            int elevationOther_RF,
            int elevationPR_BBS,
            int elevationST_BBS,
            int elevationOther_BBS,
            int elevationEQ,
            int elevationBL)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    // Foundation FP
                    aadcSetting.FoundPipeMinimumDrwFP = foundationPR_FP;
                    aadcSetting.FoundProcessMinimumDrwFP = foundationST_FP;
                    aadcSetting.FoundEquipmentMinimumDrwFP = foundationEQ_FP;
                    aadcSetting.FoundBuildingMinimumDrwFP = foundationBL_FP;
                    aadcSetting.FoundBasinMinimumDrwFP = foundationBS_FP;
                    aadcSetting.FoundOtherMinimumDrwFP = foundationOther_FP;

                    // Foundation FW
                    aadcSetting.FoundPipeMinimumDrwFW = foundationPR_FW;
                    aadcSetting.FoundProcessMinimumDrwFW = foundationST_FW;
                    aadcSetting.FoundEquipmentMinimumDrwFW = foundationEQ_FW;
                    aadcSetting.FoundBuildingMinimumDrwFW = foundationBL_FW;
                    aadcSetting.FoundBasinMinimumDrwFW = foundationBS_FW;
                    aadcSetting.FoundOtherMinimumDrwFW = foundationOther_FW;

                    // Foundation RF
                    aadcSetting.FoundPipeMinimumDrwRF = foundationPR_RF;
                    aadcSetting.FoundProcessMinimumDrwRF = foundationST_RF;
                    aadcSetting.FoundEquipmentMinimumDrwRF = foundationEQ_RF;
                    aadcSetting.FoundBuildingMinimumDrwRF = foundationBL_RF;
                    aadcSetting.FoundBasinMinimumDrwRF = foundationBS_RF;
                    aadcSetting.FoundOtherMinimumDrwRF = foundationOther_RF;

                    // Foundation BBS
                    aadcSetting.FoundPipeMinimumDrwBBS = foundationPR_BBS;
                    aadcSetting.FoundProcessMinimumDrwBBS = foundationST_BBS;
                    aadcSetting.FoundEquipmentMinimumDrwBBS = foundationEQ_BBS;
                    aadcSetting.FoundBuildingMinimumDrwBBS = foundationBL_BBS;
                    aadcSetting.FoundBasinMinimumDrwBBS = foundationBS_BBS;
                    aadcSetting.FoundOtherMinimumDrwBBS = foundationOther_BBS;

                    // Elevation EP
                    aadcSetting.ElePipeMinimumDrwEP = elevationPR_EP;
                    aadcSetting.EleProcessMinimumDrwEP = elevationST_EP;
                    aadcSetting.EleOtherMinimumDrwEP = elevationOther_EP;

                    // Elevation FW
                    aadcSetting.ElePipeMinimumDrwFW = elevationPR_FW;
                    aadcSetting.EleProcessMinimumDrwFW = elevationST_FW;
                    aadcSetting.EleOtherMinimumDrwFW = elevationOther_FW;

                    // Elevation RF
                    aadcSetting.ElePipeMinimumDrwRF = elevationPR_RF;
                    aadcSetting.EleProcessMinimumDrwRF = elevationST_RF;
                    aadcSetting.EleOtherMinimumDrwRF = elevationOther_RF;

                    // Elevation BBS
                    aadcSetting.ElePipeMinimumDrwBBS = elevationPR_BBS;
                    aadcSetting.EleProcessMinimumDrwBBS = elevationST_BBS;
                    aadcSetting.EleOtherMinimumDrwBBS = elevationOther_BBS;

                    // Elevation
                    aadcSetting.EleEquipmentMinimumDrw = elevationEQ;
                    aadcSetting.EleBuildingMinimumDrw = elevationBL;

                    aadcSetting.LastModified = DateTime.UtcNow;
                    aadcSetting.UserID = user.USERID;

                    int resultVal = await _context.SaveChangesAsync();
                    if (resultVal >= 0)
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                    else
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAADC(string code, string itemTagsStr, string tagTypesStr, string docsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    string[] docs = Utils.SplitText(docsStr);

                    bool changed = false;
                    int counter = 0;
                    int tagTypeFoundation = _configuration.GetValue<int>("Items:TagTypeFoundationConcrete");

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItems = await _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).ToListAsync();


                        if (mainItems != null)
                        {
                            foreach (MAINITEMS mainItem in mainItems)
                            {
                                var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                                if (mainItemDrawing == null)
                                {
                                    continue;
                                }


                                int value = 0;
                                bool valid = int.TryParse(docs[counter], out value);

                                if (value > projectSettings.DRAWING_MAX_MANUAL_NDOCS)
                                    value = projectSettings.DRAWING_MAX_MANUAL_NDOCS;

                                if (valid)
                                    mainItemDrawing.AADCNumDocs = value;
                                else
                                    mainItemDrawing.AADCNumDocs = null;

                            }
                        }

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<DocumentResult> UpdateAADCFoundationPlan(string code, string itemTagsStr, string tagTypesStr, string areasStr)
        {
            DocumentResult result = new DocumentResult();
            result.Documents = new List<int>();
            result.Valid = false;
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        result.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                        return result;
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        result.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                        return result;
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                    {
                        result.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                        return result;
                    }

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] areas = Utils.SplitVectorWithNull(areasStr);

                    bool changed = false;
                    int counter = 0;
                    int tagTypeFoundation = _configuration.GetValue<int>("Items:TagTypeFoundationConcrete");

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        int drawingNum = 0;
                        if (mainItem.TagTypeID == tagTypeFoundation && areas[counter] != null && areas[counter].HasValue)
                        {
                            if (aadcSetting != null && aadcSetting.FoundationReferenceArea > 0)
                                drawingNum = (int)Math.Ceiling(areas[counter].Value / aadcSetting.FoundationReferenceArea.Value);
                            drawingNum = Math.Max(drawingNum, aadcSetting.FoundationMinDrw.Value);
                        }

                        mainItemDrawing.AADCFoundationPlanNumDocs = drawingNum;
                        mainItemDrawing.AADCFoundationPlanArea = areas[counter];
                        result.Documents.Add(drawingNum);

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            result.Valid = true;
                            result.Message = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            result.Message = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    result.Message = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                result.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return result;
        }

        [HttpPost]
        public async Task<string> UpdateAADCFactorsPipesStructures(string code,
            string itemTagsStr, string tagTypesStr,
            string foundationFactorsStr, string elevationFactorsStr, string numOfFloorsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] pipesFoundationFactors = Utils.SplitVectorWithNull(foundationFactorsStr);
                    double?[] pipesElevationFactors = Utils.SplitVectorWithNull(elevationFactorsStr);
                    int?[] pipesNumOfFloors = Utils.SplitIntVectorWithNull(numOfFloorsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AADCPipeFoundationFactor = pipesFoundationFactors[counter];
                        mainItemDrawing.AADCPipeElevationFactor = pipesElevationFactors[counter];
                        mainItemDrawing.AADCPipeFloor = pipesNumOfFloors[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAADCFactorsEquipment(string code,
            string itemTagsStr, string tagTypesStr,
            string foundationFactorsStr, string elevationFactorsStr, string numOfFloorsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] foundationFactors = Utils.SplitVectorWithNull(foundationFactorsStr);
                    double?[] elevationFactors = Utils.SplitVectorWithNull(elevationFactorsStr);
                    int?[] numOfFloors = Utils.SplitIntVectorWithNull(numOfFloorsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AADCEquipmentFoundationFactor = foundationFactors[counter];
                        mainItemDrawing.AADCEquipmentElevationFactor = elevationFactors[counter];
                        mainItemDrawing.AADCEquipmentFloor = numOfFloors[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAADCBuilding(string code,
            string itemTagsStr, string tagTypesStr,
            string foundationFactorsStr, string elevationFactorsStr, string numOfFloorsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] foundationFactors = Utils.SplitVectorWithNull(foundationFactorsStr);
                    double?[] elevationFactors = Utils.SplitVectorWithNull(elevationFactorsStr);
                    int?[] numOfFloors = Utils.SplitIntVectorWithNull(numOfFloorsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AADCBuildingFoundationFactor = foundationFactors[counter];
                        mainItemDrawing.AADCBuildingElevationFactor = elevationFactors[counter];
                        mainItemDrawing.AADCBuildingFloor = numOfFloors[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAADCBasin(string code,
            string itemTagsStr, string tagTypesStr,
            string foundationFactorsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] foundationFactors = Utils.SplitVectorWithNull(foundationFactorsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AADCBasinFoundationFactor = foundationFactors[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAADCOther(string code,
            string itemTagsStr, string tagTypesStr,
            string foundationDocsStr, string elevationDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aadcSetting = await _context.AADCSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    int?[] foundationDocs = Utils.SplitIntVectorWithNull(foundationDocsStr);
                    int?[] elevationDocs = Utils.SplitIntVectorWithNull(elevationDocsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter]).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AADCNumDocsOthersFoundation = foundationDocs[counter];
                        mainItemDrawing.AADCNumDocsOthersElevation = elevationDocs[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region AACS
        [HttpPost]
        public async Task<string> UpdateAACSSettings(string code, int numdrw)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aacsSetting = await _context.AACSSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (aacsSetting != null)
                    {
                        aacsSetting.MinimumDrawing = numdrw;
                        aacsSetting.LastModified = DateTime.UtcNow;
                        aacsSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        [HttpPost]
        public async Task<string> UpdateAACS(string code,
            string itemTagsStr, string tagTypesStr, string numOfDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aacsSetting = await _context.AADASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    string[] numDocs = Utils.SplitText(numOfDocsStr);

                    bool changed = false;
                    int counter = 0;

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        int docs = 0;
                        bool valid = int.TryParse(numDocs[counter], out docs);
                        if (docs > projectSettings.DRAWING_MAX_MANUAL_NDOCS)
                            docs = projectSettings.DRAWING_MAX_MANUAL_NDOCS;
                        if (valid && docs >= 0)
                            mainItemDrawing.AACSNumDocs = docs;
                        else
                            mainItemDrawing.AACSNumDocs = null;

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region AIDU
        [HttpPost]
        public async Task<string> UpdateAIDUSettings(string code,
            int pipemindocs, double refarea, int bldgmindocs, int otherdocs)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aiduSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    aiduSetting.PipeStructureMinimumDrw = pipemindocs;
                    aiduSetting.FoundProcessRefArea = refarea;
                    aiduSetting.FoundBuildingMinimumDrw = bldgmindocs;
                    aiduSetting.FoundOtherMinimumDrw = otherdocs;
                    aiduSetting.LastModified = DateTime.UtcNow;
                    aiduSetting.UserID = user.USERID;

                    int resultVal = await _context.SaveChangesAsync();
                    if (resultVal >= 0)
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                    else
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAIDUFactorsPipesStructures(string code,
            string itemTagsStr, string tagTypesStr,
            string pipesFactorsStr, string pipesNumOfFloorsStr, string pipesNumOfModulesStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aiduSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] pipesFactors = Utils.SplitVectorWithNull(pipesFactorsStr);
                    int?[] pipesNumOfFloors = Utils.SplitIntVectorWithNull(pipesNumOfFloorsStr);
                    int?[] pipesNumOfModules = Utils.SplitIntVectorWithNull(pipesNumOfModulesStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AIDUPipeFactorDocs = pipesFactors[counter];
                        mainItemDrawing.AIDUPipeFloors = pipesNumOfFloors[counter];
                        mainItemDrawing.AIDUPipeModules = pipesNumOfModules[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAIDUProcessStructures(string code,
            string itemTagsStr, string tagTypesStr,
            string areaStr, string structureNumOfFloorsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aiduSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] areas = Utils.SplitVectorWithNull(areaStr);
                    int?[] numOfFloors = Utils.SplitIntVectorWithNull(structureNumOfFloorsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AIDUProcessArea = areas[counter];
                        mainItemDrawing.AIDUProcessFloor = numOfFloors[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAIDUShelter(string code,
            string itemTagsStr, string tagTypesStr,
            string shelterFactorStr, string structureNumOfFloorsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aiduSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    double?[] factors = Utils.SplitVectorWithNull(shelterFactorStr);
                    int?[] numOfFloors = Utils.SplitIntVectorWithNull(structureNumOfFloorsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AIDUShelterFactor = factors[counter];
                        mainItemDrawing.AIDUShelterFloor = numOfFloors[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAIDUPipeSupport(string code,
            string itemTagsStr, string tagTypesStr,
            string numOfDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aiduSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    int?[] numOfDocs = Utils.SplitIntVectorWithNull(numOfDocsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AIDUPipeSupportNumDocs = numOfDocs[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAIDUOthers(string code,
            string itemTagsStr, string tagTypesStr,
            string numOfDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aiduSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    bool changed = false;
                    int counter = 0;

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    int?[] numOfDocs = Utils.SplitIntVectorWithNull(numOfDocsStr);

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AIDUPipeSupportNumDocs = numOfDocs[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region AIDA
        [HttpPost]
        public async Task<string> UpdateAIDASettings(string code, int numdrw)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aidaSetting = await _context.AIDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (aidaSetting != null)
                    {
                        aidaSetting.MinimumDrawing = numdrw;
                        aidaSetting.LastModified = DateTime.UtcNow;
                        aidaSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        [HttpPost]
        public async Task<string> UpdateAIDAFireproofing(string code,
            string itemTagsStr, string tagTypesStr, string numOfDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aidaSetting = await _context.AADASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] tagTypes = Utils.SplitText(tagTypesStr);
                    int[] numDocs = Utils.SplitIntVector(numOfDocsStr);

                    bool changed = false;
                    int counter = 0;

                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TAGTYPES.Description == tagTypes[counter] &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        mainItemDrawing.AIDANumDocs = numDocs[counter];

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region AICS
        [HttpPost]
        public async Task<string> UpdateAICSSettings(string code, int numdrw)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aicsSetting = await _context.AICSSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (aicsSetting != null)
                    {
                        aicsSetting.MinimumDrawing = numdrw;
                        aicsSetting.LastModified = DateTime.UtcNow;
                        aicsSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        [HttpPost]
        public async Task<string> UpdateAICS(string code,
            string itemTagsStr, string numOfDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aidaSetting = await _context.AADASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] numDocs = Utils.SplitText(numOfDocsStr);

                    bool changed = false;
                    int counter = 0;

                    int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TagTypeID == tagTypeSteel &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        int num = 0;
                        bool valid = int.TryParse(numDocs[counter], out num);

                        if (valid)
                            mainItemDrawing.AICSNumDocs = num;
                        else
                            mainItemDrawing.AICSNumDocs = null;

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAIDU(string code, string itemTagsStr, string numOfDocsStr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aidaSetting = await _context.AIDUSETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] itemTags = Utils.SplitText(itemTagsStr);
                    string[] numDocs = Utils.SplitText(numOfDocsStr);

                    bool changed = false;
                    int counter = 0;

                    int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");
                    foreach (string item in itemTags)
                    {
                        if (string.IsNullOrEmpty(item))
                            continue;

                        var mainItem = _context.MAINITEMS.Include(m => m.PBS).Where(i => i.MainItemTag == item && i.TagTypeID == tagTypeSteel &&
                            i.PBS.ProjectID == project.ProjectID).FirstOrDefault();
                        if (mainItem == null)
                        {
                            // Add Message
                            continue;
                        }

                        var mainItemDrawing = _context.MAINITEMDRAWINGS.Where(d => d.MainItemID.Value == mainItem.MainItemID).FirstOrDefault();
                        if (mainItemDrawing == null)
                        {
                            continue;
                        }

                        int num = 0;
                        bool valid = int.TryParse(numDocs[counter], out num);

                        if (valid)
                            mainItemDrawing.AIDUNumDocs = num;
                        else
                            mainItemDrawing.AIDUNumDocs = null;

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region AQDA
        [HttpPost]
        public async Task<string> UpdateAQDASettings(string code, string scale, string size,
            double area)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var drawingScale = await _context.DRAWINGSCALES.Where(d => d.Description == scale).FirstOrDefaultAsync();
                    var drawingSize = await _context.DRAWINGSIZES.Where(d => d.Description == size).FirstOrDefaultAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var aqdaSetting = await _context.AQDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (drawingScale != null && drawingSize != null)
                    {
                        aqdaSetting.ScaleID = drawingScale.ScaleID;
                        aqdaSetting.SizeID = drawingSize.SizeID;
                        aqdaSetting.MinimumDrawing = 1;
                        aqdaSetting.ReferenceArea = area;
                        aqdaSetting.LastModified = DateTime.UtcNow;
                        aqdaSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAPDASettings(string code, string scale, string size,
            double area)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var drawingScale = await _context.DRAWINGSCALES.Where(d => d.Description == scale).FirstOrDefaultAsync();
                    var drawingSize = await _context.DRAWINGSIZES.Where(d => d.Description == size).FirstOrDefaultAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var apdaSetting = await _context.APDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (drawingScale != null && drawingSize != null)
                    {
                        apdaSetting.ScaleID = drawingScale.ScaleID;
                        apdaSetting.SizeID = drawingSize.SizeID;
                        apdaSetting.MinimumDrawing = 1;
                        apdaSetting.ReferenceArea = area;
                        apdaSetting.LastModified = DateTime.UtcNow;
                        apdaSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateARDASettings(string code, string scale, string size,
            double area)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var docType = await _context.DOCUMENTTYPES.ToListAsync();
                    var drawingScale = await _context.DRAWINGSCALES.Where(d => d.Description == scale).FirstOrDefaultAsync();
                    var drawingSize = await _context.DRAWINGSIZES.Where(d => d.Description == size).FirstOrDefaultAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var ardaSetting = await _context.ARDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();


                    if (drawingScale != null && drawingSize != null)
                    {
                        ardaSetting.ScaleID = drawingScale.ScaleID;
                        ardaSetting.SizeID = drawingSize.SizeID;
                        ardaSetting.MinimumDrawing = 1;
                        ardaSetting.ReferenceArea = area;
                        ardaSetting.LastModified = DateTime.UtcNow;
                        ardaSetting.UserID = user.USERID;

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_UPDATED);
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                    else
                    {
                        msg = _sharedResource.Message(MESSAGE_CODES.SETTINGS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> UpdateAQDA(string code, string unitstr, string areastr, string drawingstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var aqdaSetting = await _context.AQDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] unitList = Utils.SplitText(unitstr);
                    string[] areaList = Utils.SplitText(areastr);
                    string[] docNums = Utils.SplitText(drawingstr);

                    bool changed = false;
                    int counter = 0;

                    foreach (string unitStr in unitList)
                    {
                        if (string.IsNullOrEmpty(unitStr))
                            continue;

                        var pbs = _context.PBS.Where(i => i.Unit == unitStr && i.Area == areaList[counter] && i.ProjectID == project.ProjectID).FirstOrDefault();
                        if (pbs == null)
                        {
                            // Add Message
                            continue;
                        }

                        var pbsDrawing = _context.PBSDRAWINGS.Where(d => d.PBSID.Value == pbs.PBSID).FirstOrDefault();
                        if (pbsDrawing == null)
                        {
                            continue;
                        }

                        int drawingNum = 0;
                        bool valid = int.TryParse(docNums[counter], out drawingNum);

                        if (valid)
                            pbsDrawing.AQDANumDocs = drawingNum;
                        else
                            pbsDrawing.AQDANumDocs = null;

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        [HttpPost]
        public async Task<string> UpdateAPDA(string code, string unitstr, string areastr, string drawingstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }

                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var apdaSetting = await _context.APDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] unitList = Utils.SplitText(unitstr);
                    string[] areaList = Utils.SplitText(areastr);
                    string[] docNums = Utils.SplitText(drawingstr);

                    bool changed = false;
                    int counter = 0;

                    foreach (string unitStr in unitList)
                    {
                        if (string.IsNullOrEmpty(unitStr))
                            continue;

                        var pbs = _context.PBS.Where(i => i.Unit == unitStr && i.Area == areaList[counter] && i.ProjectID == project.ProjectID).FirstOrDefault();
                        if (pbs == null)
                        {
                            // Add Message
                            continue;
                        }

                        var pbsDrawing = _context.PBSDRAWINGS.Where(d => d.PBSID.Value == pbs.PBSID).FirstOrDefault();
                        if (pbsDrawing == null)
                        {
                            continue;
                        }

                        int drawingNum = 0;
                        bool valid = int.TryParse(docNums[counter], out drawingNum);

                        if (valid)
                            pbsDrawing.APDANumDocs = drawingNum;
                        else
                            pbsDrawing.APDANumDocs = null;

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        [HttpPost]
        public async Task<string> UpdateARDA(string code, string unitstr, string areastr, string drawingstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                    }

                    if (String.IsNullOrEmpty(code))
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    }
                    var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    var ardaSetting = await _context.ARDASETTINGS.Where(a => a.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                    string[] unitList = Utils.SplitText(unitstr);
                    string[] areaList = Utils.SplitText(areastr);
                    string[] docNums = Utils.SplitText(drawingstr);

                    bool changed = false;
                    int counter = 0;

                    foreach (string unitStr in unitList)
                    {
                        if (string.IsNullOrEmpty(unitStr))
                            continue;

                        var pbs = _context.PBS.Where(i => i.Unit == unitStr && i.Area == areaList[counter] && i.ProjectID == project.ProjectID).FirstOrDefault();
                        if (pbs == null)
                        {
                            // Add Message
                            continue;
                        }

                        var pbsDrawing = _context.PBSDRAWINGS.Where(d => d.PBSID.Value == pbs.PBSID).FirstOrDefault();
                        if (pbsDrawing == null)
                        {
                            continue;
                        }

                        int drawingNum = 0;
                        bool valid = int.TryParse(docNums[counter], out drawingNum);

                        if (valid)
                            pbsDrawing.ARDANumDocs = drawingNum;
                        else
                            pbsDrawing.ARDANumDocs = null;

                        changed = true;
                        counter++;
                    }
                    if (changed)
                    {
                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_UPDATED);
                        }
                        else
                            msg = _sharedResource.Message(MESSAGE_CODES.DOCUMENTS_NOT_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
        #endregion

        #region Drawing methods
        [HttpGet]
        public async Task<bool> CreateDrawingList(string code)
        {
            string msg = string.Empty;
            bool valid = false;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    // Get current user
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return false;

                    // Get current Project
                    if (string.IsNullOrEmpty(code))
                        return false;
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return false;

                    // Read project elements
                    var projectSettings = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    var pbs = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    var pbsList = pbs.Select(p => p.PBSID).Distinct().ToList();
                    var documentTypes = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES)
                        .Include(m => m.PBS)
                        .Include(m => m.LV01_Object_Code)
                        .Include(m => m.IMPORTANCESTATUS)
                        .Where(m => m.PBS.ProjectID == project.ProjectID && !m.IsDeleted && !m.IsReplaced).ToListAsync();


                    // Settings
                    DrawingCodeSettings drawingCodeSettings = GetDrawingCodeSettings();
                    var aadcFactors = await _context.AADCFACTORS.Include(a => a.LV01_Object_Code).Include(a => a.TAGTYPES).ToListAsync();
                    var aiduFactors = await _context.AIDUFACTORS.Include(a => a.LV01_Object_Code).Include(a => a.TAGTYPES).ToListAsync();
                    var aadaSettings = await _context.AADASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aadcSettings = await _context.AADCSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aacsSettings = await _context.AACSSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aiduSettings = await _context.AIDUSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aidaSettings = await _context.AIDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aicsSettings = await _context.AICSSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aqdaSettings = await _context.AQDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var apdaSettings = await _context.APDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var ardaSettings = await _context.ARDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    int objectCodePR = _configuration.GetValue<int>("ObjectCode:PR");
                    int objectCodeSS = _configuration.GetValue<int>("ObjectCode:SS");
                    int objectCodeST = _configuration.GetValue<int>("ObjectCode:ST");
                    int objectCodeBL = _configuration.GetValue<int>("ObjectCode:BL");
                    int objectCodeSL = _configuration.GetValue<int>("ObjectCode:SL");
                    int objectCodeEQ = _configuration.GetValue<int>("ObjectCode:EQ");
                    int objectCodeBS = _configuration.GetValue<int>("ObjectCode:BS");

                    // Tag types
                    int tagTypeFoundation = _configuration.GetValue<int>("Items:TagTypeFoundationConcrete");
                    int tagTypeElevation = _configuration.GetValue<int>("Items:TagTypeElevationConcrete");
                    int tagTypePiles = _configuration.GetValue<int>("Items:TagTypePiles");
                    int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");

                    // Delete all existing drawings and make backup
                    var revisions = await _context.REVISIONS.Where(d => d.ProjectID == project.ProjectID)
                            .OrderByDescending(d => d.RevisionNumber)
                            .ToListAsync();
                    int revisionId = 1;
                    if (revisions != null && revisions.Count > 0)
                        revisionId = revisions[0].RevisionNumber.Value + 1;
                    REVISIONS newRevision = new REVISIONS();
                    newRevision.ProjectID = project.ProjectID;
                    newRevision.RevisionNumber = revisionId;
                    newRevision.UserID = user.USERID;
                    newRevision.CreationDate = DateTime.UtcNow;
                    newRevision.LastModified = DateTime.UtcNow;
                    _context.REVISIONS.Add(newRevision);
                    int result = await _context.SaveChangesAsync();
                    valid = result > 0;

                    List<DRAWINGS> drawings = new List<DRAWINGS>();

                    REVISIONS lastRevision = null;
                    if (revisions != null && revisions.Count > 0)
                        lastRevision = revisions[0];

                    List<REVISIONS> previousRevisions = new List<REVISIONS>();
                    for (int i = 1; i < revisions.Count; i++)
                        previousRevisions.Add(revisions[i]);

                    int maxDoc = projectSettings.DRAWING_MAX_NDOCS;

                    if (valid)
                    {
                        List<string> analyzedDocumentCode = new List<string>();
                        List<DRAWINGS> currentDrawings = null;

                        var mainItemDrawings = await _context.MAINITEMDRAWINGS.Where(m => m.MAINITEM.PBS.ProjectID == project.ProjectID &&
                            !m.MAINITEM.IsReplaced && !m.MAINITEM.IsDeleted).ToListAsync();
                        var pbsDrawings = await _context.PBSDRAWINGS.Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                        // Generate Common Documents
                        if (docSettingsList != null)
                        {
                            foreach (DOCUMENTSETTINGS docSetting in docSettingsList)
                            {
                                if (!docSetting.DOCUMENTTYPE.IsVisible)
                                    continue;
                                if (!docSetting.DOCUMENTTYPE.TCMCode.StartsWith("AX"))
                                    continue;
                                if (!docSetting.NUMBEROFDOCUMENTS.HasValue || docSetting.NUMBEROFDOCUMENTS.Value == 0)
                                    continue;
                                string currentCode = docSetting.DOCUMENTTYPE.TCMCode;
                                if (analyzedDocumentCode.Contains(currentCode))
                                    continue;
                                var docTypes = docSettingsList.Where(d => d.DOCUMENTTYPE.TCMCode == currentCode).ToList();
                                currentDrawings = await DRAWINGS.GetCommonDrawingList(_context, docTypes, user.USERID.Value, project,
                                    projectSettings, drawingCodeSettings, newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                                analyzedDocumentCode.Add(currentCode);
                            }
                        }

                        if (mainItems != null)
                        {
                            foreach (MAINITEMS item in mainItems)
                            {
                                if (item.IsBalance)
                                    continue;
                                item.AADCSETTINGS = aadcSettings;
                                item.AIDUSETTINGS = aiduSettings;
                                item.UpdateDrawingFactors(aadcFactors, aiduFactors, tagTypeFoundation, tagTypeElevation, tagTypeSteel);
                                item.CalculateNumberOfDocuments(tagTypeFoundation, tagTypeElevation, tagTypeSteel);
                            }
                        }
                        if (mainItemDrawings != null)
                            foreach (MAINITEMDRAWINGS mAINITEMDRAWINGS in mainItemDrawings)
                            {
                                mAINITEMDRAWINGS.AACSSETTINGS = aacsSettings;
                                mAINITEMDRAWINGS.AADASETTINGS = aadaSettings;
                                mAINITEMDRAWINGS.AICSSETTINGS = aicsSettings;
                            }

                        if (pbsDrawings != null)
                        {
                            foreach (var doc in pbsDrawings)
                            {
                                doc.APDASETTINGS = apdaSettings;
                                doc.AQDASETTINGS = aqdaSettings;
                                doc.ARDASETTINGS = ardaSettings;
                            }
                        }

                        List<string> computedMainItem = new List<string>();
                        if (mainItemDrawings != null && mainItemDrawings.Count > 0)
                        {
                            // Init items sublist
                            var foundationElevations = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                                m.MAINITEM.TagTypeID == tagTypeElevation) && !m.MAINITEM.IsBalance).ToList();
                            if (mainItemDrawings != null)
                            {
                                foreach (var item in mainItemDrawings)
                                {
                                    if (item.MAINITEM.TagTypeID == tagTypeFoundation && item.MAINITEM.IsBalance)
                                    {
                                        if (foundationElevations == null)
                                            foundationElevations = new List<MAINITEMDRAWINGS>();
                                        foundationElevations.Add(item);
                                    }
                                }
                            }

                            var pilesAndFoundationBalance = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                                m.MAINITEM.TagTypeID == tagTypePiles) && m.MAINITEM.IsBalance).ToList();

                            var pilesFoundationElevationConcrete = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                                m.MAINITEM.TagTypeID == tagTypeElevation || m.MAINITEM.TagTypeID == tagTypePiles) && !m.MAINITEM.IsBalance).ToList();
                            if (mainItemDrawings != null)
                            {
                                foreach (var item in mainItemDrawings)
                                {
                                    if (item.MAINITEM.TagTypeID == tagTypeFoundation && item.MAINITEM.IsBalance)
                                    {
                                        if (pilesFoundationElevationConcrete == null)
                                            pilesFoundationElevationConcrete = new List<MAINITEMDRAWINGS>();
                                        pilesFoundationElevationConcrete.Add(item);
                                    }
                                }
                            }

                            var piles = mainItemDrawings.Where(m => m.MAINITEM.TagTypeID == tagTypePiles).ToList();

                            var steel = mainItemDrawings.Where(m => m.MAINITEM.TagTypeID == tagTypeSteel && !m.MAINITEM.IsBalance).ToList();
                            if (mainItemDrawings != null)
                            {
                                foreach (var item in mainItemDrawings)
                                {
                                    if (item.MAINITEM.TagTypeID == tagTypeSteel && item.MAINITEM.IsBalance)
                                    {
                                        if (steel == null)
                                            steel = new List<MAINITEMDRAWINGS>();
                                        steel.Add(item);
                                    }
                                }
                            }


                            #region AA
                            // AACS
                            if (pilesFoundationElevationConcrete != null && pilesFoundationElevationConcrete.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(pilesFoundationElevationConcrete, "AA-CS", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }

                            // AADA
                            if (pilesAndFoundationBalance != null && pilesAndFoundationBalance.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(pilesAndFoundationBalance, "AA-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }

                            // AADC
                            if (foundationElevations != null && foundationElevations.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(foundationElevations, "AA-DC", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }

                            // AA Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AA", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AG
                            // AG
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AG", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AI
                            // AICS
                            if (steel != null && steel.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(steel, "AI-CS", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AIDU
                            if (steel != null && steel.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(steel, "AI-DU", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AI Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AI", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AP
                            // APDA
                            if (pbsDrawings != null && pbsDrawings.Count > 0)
                            {
                                currentDrawings = GetPBSDrawings(pbsDrawings, "AP-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AP Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AP", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AQ
                            // AQDA
                            if (pbsDrawings != null && pbsDrawings.Count > 0)
                            {
                                currentDrawings = GetPBSDrawings(pbsDrawings, "AQ-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AQ Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AQ", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AR
                            // ARDA
                            if (pbsDrawings != null && pbsDrawings.Count > 0)
                            {
                                currentDrawings = GetPBSDrawings(pbsDrawings, "AR-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AR Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AR", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                        }

                        if (drawings != null && drawings.Count > 0)
                        {
                            var drawingMaxId = await _context.DRAWINGS.OrderByDescending(d => d.DrawingID).FirstOrDefaultAsync();
                            int id = 1;
                            int startId = drawingMaxId != null ? drawingMaxId.DrawingID + 1 : 1;
                            foreach (DRAWINGS d in drawings)
                            {
                                d.DrawingID = startId;
                                d.ProjectDrawingID = id;
                                id++;
                                startId++;
                                _context.DRAWINGS.Add(d);
                            }
                        }

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            valid = true;
                        }
                        else
                            valid = false;
                    }
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                    valid = false;
                }
            }
            else
            {
                valid = false;
            }
            return valid;
        }
        [HttpGet]
        public async Task<bool> CreateDrawingListOld(string code)
        {
            string msg = string.Empty;
            bool valid = false;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    // Get current user
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return false;

                    // Get current Project
                    if (string.IsNullOrEmpty(code))
                        return false;
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    if (project == null)
                        return false;

                    // Read project elements
                    var projectSettings = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    var pbs = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    var pbsList = pbs.Select(p => p.PBSID).Distinct().ToList();
                    var documentTypes = await _context.DOCUMENTTYPES.ToListAsync();
                    var docSettingsList = await _context.DOCUMENTSETTINGS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var mainItems = await _context.MAINITEMS.Include(m => m.TAGTYPES)
                        .Include(m => m.PBS)
                        .Include(m => m.LV01_Object_Code)
                        .Include(m => m.IMPORTANCESTATUS)
                        .Where(m => m.PBS.ProjectID == project.ProjectID && !m.IsDeleted && !m.IsReplaced).ToListAsync();


                    // Settings
                    DrawingCodeSettings drawingCodeSettings = GetDrawingCodeSettings();
                    var aadcFactors = await _context.AADCFACTORS.Include(a => a.LV01_Object_Code).Include(a => a.TAGTYPES).ToListAsync();
                    var aiduFactors = await _context.AIDUFACTORS.Include(a => a.LV01_Object_Code).Include(a => a.TAGTYPES).ToListAsync();
                    var aadaSettings = await _context.AADASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aadcSettings = await _context.AADCSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aacsSettings = await _context.AACSSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aiduSettings = await _context.AIDUSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aidaSettings = await _context.AIDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aicsSettings = await _context.AICSSETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var aqdaSettings = await _context.AQDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var apdaSettings = await _context.APDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    var ardaSettings = await _context.ARDASETTINGS.Where(s => s.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    int objectCodePR = _configuration.GetValue<int>("ObjectCode:PR");
                    int objectCodeSS = _configuration.GetValue<int>("ObjectCode:SS");
                    int objectCodeST = _configuration.GetValue<int>("ObjectCode:ST");
                    int objectCodeBL = _configuration.GetValue<int>("ObjectCode:BL");
                    int objectCodeSL = _configuration.GetValue<int>("ObjectCode:SL");
                    int objectCodeEQ = _configuration.GetValue<int>("ObjectCode:EQ");
                    int objectCodeBS = _configuration.GetValue<int>("ObjectCode:BS");

                    // Tag types
                    int tagTypeFoundation = _configuration.GetValue<int>("Items:TagTypeFoundationConcrete");
                    int tagTypeElevation = _configuration.GetValue<int>("Items:TagTypeElevationConcrete");
                    int tagTypePiles = _configuration.GetValue<int>("Items:TagTypePiles");
                    int tagTypeSteel = _configuration.GetValue<int>("Items:TagTypeSteel");

                    // Delete all existing drawings and make backup
                    var revisions = await _context.REVISIONS.Where(d => d.ProjectID == project.ProjectID)
                            .OrderByDescending(d => d.RevisionNumber)
                            .ToListAsync();
                    int revisionId = 1;
                    if (revisions != null && revisions.Count > 0)
                        revisionId = revisions[0].RevisionNumber.Value + 1;
                    REVISIONS newRevision = new REVISIONS();
                    newRevision.ProjectID = project.ProjectID;
                    newRevision.RevisionNumber = revisionId;
                    newRevision.UserID = user.USERID;
                    newRevision.CreationDate = DateTime.UtcNow;
                    newRevision.LastModified = DateTime.UtcNow;
                    _context.REVISIONS.Add(newRevision);
                    int result = await _context.SaveChangesAsync();
                    valid = result > 0;

                    //valid = await DeleteAllDrawings(project.ProjectID);

                    List<DRAWINGS> drawings = new List<DRAWINGS>();

                    REVISIONS lastRevision = null;
                    if (revisions != null && revisions.Count > 0)
                        lastRevision = revisions[0];

                    List<REVISIONS> previousRevisions = new List<REVISIONS>();
                    for (int i = 1; i < revisions.Count; i++)
                        previousRevisions.Add(revisions[i]);

                    int maxDoc = projectSettings.DRAWING_MAX_NDOCS;

                    if (valid)
                    {
                        List<string> analyzedDocumentCode = new List<string>();
                        List<DRAWINGS> currentDrawings = null;

                        var mainItemDrawings = await _context.MAINITEMDRAWINGS.Where(m => m.MAINITEM.PBS.ProjectID == project.ProjectID).ToListAsync();
                        var pbsDrawings = await _context.PBSDRAWINGS.Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                        // Generate Common Documents
                        if (docSettingsList != null)
                        {
                            foreach (DOCUMENTSETTINGS docSetting in docSettingsList)
                            {
                                if (!docSetting.DOCUMENTTYPE.IsVisible)
                                    continue;
                                if (!docSetting.DOCUMENTTYPE.TCMCode.StartsWith("AX"))
                                    continue;
                                if (!docSetting.NUMBEROFDOCUMENTS.HasValue || docSetting.NUMBEROFDOCUMENTS.Value == 0)
                                    continue;
                                string currentCode = docSetting.DOCUMENTTYPE.TCMCode;
                                if (analyzedDocumentCode.Contains(currentCode))
                                    continue;
                                var docTypes = docSettingsList.Where(d => d.DOCUMENTTYPE.TCMCode == currentCode).ToList();
                                currentDrawings = await DRAWINGS.GetCommonDrawingList(_context, docTypes, user.USERID.Value, project,
                                    projectSettings, drawingCodeSettings, newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                                analyzedDocumentCode.Add(currentCode);
                            }
                        }

                        if (mainItems != null)
                        {
                            foreach (MAINITEMS item in mainItems)
                            {
                                if (item.IsBalance)
                                    continue;
                                item.AADCSETTINGS = aadcSettings;
                                item.AIDUSETTINGS = aiduSettings;
                                item.UpdateDrawingFactors(aadcFactors, aiduFactors, tagTypeFoundation, tagTypeElevation, tagTypeSteel);
                                item.CalculateNumberOfDocuments(tagTypeFoundation, tagTypeElevation, tagTypeSteel);
                            }
                        }
                        if (mainItemDrawings != null)
                            foreach (MAINITEMDRAWINGS mAINITEMDRAWINGS in mainItemDrawings)
                            {
                                mAINITEMDRAWINGS.AACSSETTINGS = aacsSettings;
                                mAINITEMDRAWINGS.AADASETTINGS = aadaSettings;
                                mAINITEMDRAWINGS.AICSSETTINGS = aicsSettings;
                            }

                        if (pbsDrawings != null)
                        {
                            foreach (var doc in pbsDrawings)
                            {
                                doc.APDASETTINGS = apdaSettings;
                                doc.AQDASETTINGS = aqdaSettings;
                                doc.ARDASETTINGS = ardaSettings;
                            }
                        }

                        List<string> computedMainItem = new List<string>();
                        if (mainItemDrawings != null && mainItemDrawings.Count > 0)
                        {
                            // Init items sublist
                            var foundationElevations = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                                m.MAINITEM.TagTypeID == tagTypeElevation) && !m.MAINITEM.IsBalance).ToList();
                            if (mainItemDrawings != null)
                            {
                                foreach (var item in mainItemDrawings)
                                {
                                    if (item.MAINITEM.TagTypeID == tagTypeFoundation && item.MAINITEM.IsBalance)
                                    {
                                        if (foundationElevations == null)
                                            foundationElevations = new List<MAINITEMDRAWINGS>();
                                        foundationElevations.Add(item);
                                    }
                                }
                            }

                            var pilesAndFoundationBalance = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                                m.MAINITEM.TagTypeID == tagTypePiles) && m.MAINITEM.IsBalance).ToList();

                            var pilesFoundationElevationConcrete = mainItemDrawings.Where(m => (m.MAINITEM.TagTypeID == tagTypeFoundation ||
                                m.MAINITEM.TagTypeID == tagTypeElevation || m.MAINITEM.TagTypeID == tagTypePiles) && !m.MAINITEM.IsBalance).ToList();
                            if (mainItemDrawings != null)
                            {
                                foreach (var item in mainItemDrawings)
                                {
                                    if (item.MAINITEM.TagTypeID == tagTypeFoundation && item.MAINITEM.IsBalance)
                                    {
                                        if (pilesFoundationElevationConcrete == null)
                                            pilesFoundationElevationConcrete = new List<MAINITEMDRAWINGS>();
                                        pilesFoundationElevationConcrete.Add(item);
                                    }
                                }
                            }

                            var piles = mainItemDrawings.Where(m => m.MAINITEM.TagTypeID == tagTypePiles).ToList();

                            var steel = mainItemDrawings.Where(m => m.MAINITEM.TagTypeID == tagTypeSteel && !m.MAINITEM.IsBalance).ToList();
                            if (mainItemDrawings != null)
                            {
                                foreach (var item in mainItemDrawings)
                                {
                                    if (item.MAINITEM.TagTypeID == tagTypeSteel && item.MAINITEM.IsBalance)
                                    {
                                        if (steel == null)
                                            steel = new List<MAINITEMDRAWINGS>();
                                        steel.Add(item);
                                    }
                                }
                            }


                            #region AA
                            // AACS
                            if (pilesFoundationElevationConcrete != null && pilesFoundationElevationConcrete.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(pilesFoundationElevationConcrete, "AA-CS", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }

                            // AADA
                            if (pilesAndFoundationBalance != null && pilesAndFoundationBalance.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(pilesAndFoundationBalance, "AA-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }

                            // AADC
                            if (foundationElevations != null && foundationElevations.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(foundationElevations, "AA-DC", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }

                            // AA Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AA", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AG
                            // AG
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AG", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AI
                            // AICS
                            if (steel != null && steel.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(steel, "AI-CS", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AIDU
                            if (steel != null && steel.Count > 0)
                            {
                                currentDrawings = GetItemsDrawings(steel, "AI-DU", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, tagTypes, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AI Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AI", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AP
                            // APDA
                            if (pbsDrawings != null && pbsDrawings.Count > 0)
                            {
                                currentDrawings = GetPBSDrawings(pbsDrawings, "AP-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AP Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AP", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AQ
                            // AQDA
                            if (pbsDrawings != null && pbsDrawings.Count > 0)
                            {
                                currentDrawings = GetPBSDrawings(pbsDrawings, "AQ-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AQ Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AQ", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                            #region AR
                            // ARDA
                            if (pbsDrawings != null && pbsDrawings.Count > 0)
                            {
                                currentDrawings = GetPBSDrawings(pbsDrawings, "AR-DA", documentTypes,
                                    project, projectSettings, drawingCodeSettings, user, newRevision.RevisionID, lastRevision);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            // AR Others
                            if (docSettingsList != null)
                            {
                                currentDrawings = await GetDocumentSettingsDrawings(project, projectSettings, drawingCodeSettings,
                                    docSettingsList, user, "AR", newRevision.RevisionID, lastRevision, previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                            #endregion

                        }

                        if (drawings != null && drawings.Count > 0)
                        {
                            var drawingMaxId = await _context.DRAWINGS.OrderByDescending(d => d.DrawingID).FirstOrDefaultAsync();
                            int id = 1;
                            int startId = drawingMaxId != null ? drawingMaxId.DrawingID + 1 : 1;
                            foreach (DRAWINGS d in drawings)
                            {
                                d.DrawingID = startId;
                                d.ProjectDrawingID = id;
                                id++;
                                startId++;
                                _context.DRAWINGS.Add(d);
                            }
                        }

                        int resultVal = await _context.SaveChangesAsync();
                        if (resultVal >= 0)
                        {
                            valid = true;
                        }
                        else
                            valid = false;
                    }
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                    valid = false;
                }
            }
            else
            {
                valid = false;
            }
            return valid;
        }

        private DrawingCodeSettings GetDrawingCodeSettings()
        {
            DrawingCodeSettings drawingCodeSettings = new DrawingCodeSettings();
            drawingCodeSettings.ProjectCode = _configuration.GetValue<string>("Drawings:ProjectCode");
            drawingCodeSettings.TcmCode = _configuration.GetValue<string>("Drawings:TcmCode");
            drawingCodeSettings.CWA = _configuration.GetValue<string>("Drawings:CWA");
            drawingCodeSettings.Object = _configuration.GetValue<string>("Drawings:Object");
            drawingCodeSettings.ObjectCodeDescription = _configuration.GetValue<string>("Drawings:ObjectCodeDescription");
            drawingCodeSettings.DocumentTypeName = _configuration.GetValue<string>("Drawings:DocumentTypeName");
            drawingCodeSettings.DocumentTypeDescription = _configuration.GetValue<string>("Drawings:DocumentTypeDescription");
            drawingCodeSettings.DocumentTypeAdditionalDescription = _configuration.GetValue<string>("Drawings:DocumentTypeAddDescription");
            drawingCodeSettings.Sequence = _configuration.GetValue<string>("Drawings:Sequence");
            drawingCodeSettings.ItemTag = _configuration.GetValue<string>("Drawings:ItemTag");
            return drawingCodeSettings;
        }

        private List<DRAWINGS> GetItemsDrawings(
            List<MAINITEMDRAWINGS> mainItemDrawings,
            string tcmCode,
            List<DOCUMENTTYPES> documentTypes,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DrawingCodeSettings drawingCodeSettings,
            USERS user,
            List<TAGTYPES> tagTypes,
            int revisionId,
            REVISIONS lastRevision)
        {
            List<DRAWINGS> currentDrawings = new List<DRAWINGS>();
            if (mainItemDrawings != null && mainItemDrawings.Count > 0)
            {
                List<string> computedMainItem = new List<string>();
                foreach (var mainItemDrawing in mainItemDrawings)
                {
                    if (computedMainItem.Contains(mainItemDrawing.MAINITEM.MainItemTag))
                        continue;
                    List<MAINITEMDRAWINGS> mainItemDrawingSimilar = null;
                    int totalDrawings = 0;
                    if (tcmCode != "AA-DA" && tcmCode != "AA-DC")
                    {
                        mainItemDrawingSimilar = mainItemDrawings.Where(m => m.MAINITEM.MainItemTag == mainItemDrawing.MAINITEM.MainItemTag).ToList();
                        if (mainItemDrawingSimilar != null && mainItemDrawingSimilar.Count > 0)
                        {
                            foreach (var item in mainItemDrawingSimilar)
                            {
                                int drawing = item.CalculateDrawing(tcmCode);
                                if (drawing > 0)
                                    totalDrawings += drawing;
                            }
                            if (totalDrawings > 0)
                            {
                                var docType = documentTypes.Where(d => d.TCMCode == tcmCode).FirstOrDefault();

                                if (totalDrawings > projectSettings.DRAWING_MAX_FOR_TYPE)
                                    totalDrawings = projectSettings.DRAWING_MAX_FOR_TYPE;

                                var drawings = DRAWINGS.GetDrawingListMainItem(
                                    tcmCode,
                                    drawingCodeSettings,
                                    project,
                                    projectSettings,
                                    docType,
                                    1,
                                    totalDrawings,
                                    mainItemDrawing.MAINITEM,
                                    user.USERID.Value,
                                    revisionId);
                                if (drawings != null && drawings.Count > 0)
                                {
                                    currentDrawings.AddRange(drawings);
                                }
                            }
                        }
                    }
                    else
                    {
                        int startIndex = 1;
                        foreach (var tagType in tagTypes)
                        {
                            totalDrawings = 0;
                            mainItemDrawingSimilar = mainItemDrawings.Where(m => m.MAINITEM.MainItemTag == mainItemDrawing.MAINITEM.MainItemTag &&
                                m.MAINITEM.TagTypeID == tagType.TagTypeID).ToList();
                            if (mainItemDrawingSimilar != null && mainItemDrawingSimilar.Count > 0)
                            {
                                foreach (var item in mainItemDrawingSimilar)
                                {
                                    int drawing = item.CalculateDrawing(tcmCode);
                                    if (drawing > 0)
                                        totalDrawings += drawing;
                                }
                                if (totalDrawings > 0)
                                {
                                    var docType = documentTypes.Where(d => d.TCMCode == tcmCode && d.TagTypeID != null && d.TagTypeID.HasValue && d.TagTypeID.Value == tagType.TagTypeID).FirstOrDefault();
                                    if (docType != null)
                                    {
                                        var drawings = DRAWINGS.GetDrawingListMainItem(
                                            tcmCode,
                                            drawingCodeSettings,
                                            project,
                                            projectSettings,
                                            docType,
                                            startIndex,
                                            totalDrawings,
                                            mainItemDrawing.MAINITEM,
                                            user.USERID.Value,
                                            revisionId);
                                        if (drawings != null && drawings.Count > 0)
                                        {
                                            currentDrawings.AddRange(drawings);
                                            startIndex += currentDrawings.Count;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    computedMainItem.Add(mainItemDrawing.MAINITEM.MainItemTag);
                }
            }
            return currentDrawings;
        }

        private List<DRAWINGS> GetPBSDrawings(List<PBSDRAWINGS> pbsDrawings,
            string tcmCode,
            List<DOCUMENTTYPES> documentTypes,
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DrawingCodeSettings drawingCodeSettings,
            USERS user,
            int revisionId,
            REVISIONS lastRevision)
        {
            List<DRAWINGS> currentDrawings = new List<DRAWINGS>();
            if (pbsDrawings != null && pbsDrawings.Count > 0)
            {
                foreach (var pbsDrawing in pbsDrawings)
                {
                    int drawing = pbsDrawing.CalculateDrawing(tcmCode);
                    if (drawing > 0)
                    {
                        var docType = documentTypes.Where(d => d.TCMCode == tcmCode).FirstOrDefault();
                        var drawings = DRAWINGS.GetDrawingListPBS(
                            tcmCode,
                            drawingCodeSettings,
                            project,
                            projectSettings,
                            docType,
                            1,
                            drawing,
                            pbsDrawing.PBS,
                            user.USERID.Value,
                            revisionId,
                            lastRevision);
                        if (drawings != null && drawings.Count > 0)
                        {
                            currentDrawings.AddRange(drawings);
                        }
                    }
                }
            }
            return currentDrawings;
        }

        private async Task<List<DRAWINGS>> GetDocumentSettingsDrawings(
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            DrawingCodeSettings drawingCodeSettings,
            List<DOCUMENTSETTINGS> docSettingsList,
            USERS user,
            string filterTCMCode,
            int revisionId,
            REVISIONS lastRevision,
            List<REVISIONS> previousRevisions)
        {
            List<DRAWINGS> drawings = new List<DRAWINGS>();
            List<string> computedTCMCode = new List<string>();
            foreach (var docSetting in docSettingsList)
            {
                var docType = docSetting.DOCUMENTTYPE;
                if (docType.Visible.HasValue && docType.Visible.Value > 0 && docType.TCMCode.StartsWith(filterTCMCode))
                {
                    if (computedTCMCode.Contains(docType.TCMCode))
                        continue;
                    var similarDoc = docSettingsList.Where(d => d.DOCUMENTTYPE.TCMCode == docType.TCMCode).ToList();
                    int startIndex = 1;
                    if (similarDoc != null && similarDoc.Count > 0)
                    {
                        foreach (var doc in similarDoc)
                        {
                            int drawing = 0;
                            if (MustBeProcessed(docSetting.NUMBEROFDOCUMENTS))
                                drawing = docSetting.NUMBEROFDOCUMENTS.Value;
                            if (drawing > 0)
                            {
                                var currentDrawings = await DRAWINGS.GetDrawingListFromDocumentType(
                                    _context,
                                    doc.DOCUMENTTYPE.TCMCode,
                                    drawingCodeSettings,
                                    project,
                                    projectSettings,
                                    doc.DOCUMENTTYPE,
                                    startIndex,
                                    drawing,
                                    user.USERID.Value,
                                    revisionId,
                                    lastRevision,
                                    previousRevisions);
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                {
                                    startIndex += currentDrawings.Count;
                                    drawings.AddRange(currentDrawings);
                                }
                            }
                        }
                    }
                }
                computedTCMCode.Add(docType.TCMCode);
            }
            return drawings;
        }

        private bool MustBeProcessed(int? value)
        {
            return value != null && value.HasValue && value.Value > 0;
        }

        private async Task<bool> DeleteAllDrawings(int projectId)
        {
            var itemDrawings = await _context.DRAWINGS.Where(d => d.ProjectID == projectId).ToListAsync();
            if (itemDrawings != null)
            {
                foreach (DRAWINGS dr in itemDrawings)
                    _context.Remove(dr);
            }
            return true;
        }
        #endregion

        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code, string revision)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:DLTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "DL.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:DLSheetName");
            int startRow = _configuration.GetValue<int>("Excel:DLSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:DLSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:DLProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:DLProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            //// Insert data
            //Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;

            var revisions = await _context.REVISIONS.Where(d => d.ProjectID == project.ProjectID)
                .OrderByDescending(d => d.RevisionNumber)
                .ToListAsync();
            if (revisions != null && revisions.Count > 0)
            {
                var currentRevision = revisions.Where(r => r.GetDescription == revision).FirstOrDefault();
                if (currentRevision == null)
                    currentRevision = revisions[0];
                var drawings = await _context.DRAWINGS.Include(d => d.DOCUMENTTYPE).Where(d => d.ProjectID == project.ProjectID && d.RevisionsID.Value == currentRevision.RevisionID)
                    .Include(d => d.DOCUMENTTYPE).ToListAsync();
                if (drawings != null)
                {
                    drawings = drawings.OrderBy(m => m.MainItemTag).ToList();
                    int currentRow = startRow;
                    foreach (var drawing in drawings)
                    {
                        Sheet.Cells[currentRow, startColumn].Value = project.Code;
                        Sheet.Cells[currentRow, startColumn + 1].Value = drawing.GetKeyLevel;
                        Sheet.Cells[currentRow, startColumn + 2].Value = drawing.GetDepartmentCode;
                        Sheet.Cells[currentRow, startColumn + 3].Value = drawing.GetTCMCode;
                        Sheet.Cells[currentRow, startColumn + 4].Value = drawing.TCMDrawingNumber;
                        Sheet.Cells[currentRow, startColumn + 5].Value = drawing.GetDocumentClassification;
                        Sheet.Cells[currentRow, startColumn + 6].Value = drawing.GetDocumentTypology;
                        Sheet.Cells[currentRow, startColumn + 7].Value = drawing.GetDocumentNumber;
                        Sheet.Cells[currentRow, startColumn + 8].Value = string.Empty;
                        Sheet.Cells[currentRow, startColumn + 9].Value = drawing.DrawingDescription;
                        Sheet.Cells[currentRow, startColumn + 10].Value = string.Empty;
                        Sheet.Cells[currentRow, startColumn + 11].Value = string.Empty;
                        Sheet.Cells[currentRow, startColumn + 12].Value = drawing.MainItemTag;
                        Sheet.Cells[currentRow, startColumn + 13].Value = drawing.CWA;
                        Sheet.Cells[currentRow, startColumn + 14].Value = string.Empty;
                        currentRow++;
                    }
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }


        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteRevision(string code, string revisionstr)
        {
            try
            {
                if (string.IsNullOrEmpty(code))
                    return "Project not correct";

                var project = await _context.PROJECTS
                    .FirstOrDefaultAsync(m => m.Code == code);
                if (project == null)
                    return "Project not found";

                REVISIONS revision = await _context.REVISIONS.Where(d => d.ProjectID == project.ProjectID && d.GetDescription == revisionstr)
                    .FirstOrDefaultAsync();

                if (revision != null)
                {
                    _context.REVISIONS.Remove(revision);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }
    }
}