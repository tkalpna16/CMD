﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Costants;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using OfficeOpenXml;
using System.Collections.Generic;
using CivilMasterData.Models.Logs;
using Microsoft.AspNetCore.Http;
using System.IO;
using CivilMasterData.Models.BIM360.Parameters;

namespace CivilMasterData
{
    public class PLANNINGSController : Controller
    {
        private readonly PLANNINGSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PLANNINGSController(PLANNINGSContext context, ISharedResource sharedResource,
             IConfiguration configuration, IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            this._configuration = configuration;
            this._env = env;
        }

        // GET: PLANNINGS
        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }
            ViewBag.Role = user.ACCESS_LEVEL;

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();
            var plannings = await _context.PLANNINGS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID && !x.MAINITEMS.IsBalance).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Include(x => x.MAINITEMS).Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            plannings = MainItemUtils.OrderMainitemsPlannings(plannings, projectSettings.BALANCE);

            int dateType = _configuration.GetValue<int>("Items:ParameterDateID");
            var planningParameters = await _context.MAINITEMPARAMETERS.Where(d => d.PROJECTID == project.ProjectID
                && d.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(d => d.ParameterID).ToListAsync();
            int totalParameters = planningParameters != null ? planningParameters.Count : 0;

            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    var holds = await _context.HOLDS.Where(x => x.MainItemId == item.MainItemID).ToListAsync();
                    item.HOLDS = holds;
                }
            }

            if (totalParameters > 0 && mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    bool update = false;
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID
                        && m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(p => p.MainItemParametersID).ToListAsync();
                    foreach (MAINITEMPARAMETERS currentParameter in planningParameters)
                    {
                        MAINITEMPARAMETERVALUES date = null;
                        if (values != null)
                            date = values.Where(d => d.MainItemParametersID == currentParameter.ParameterID).FirstOrDefault();
                        if (date == null) // Add date
                        {
                            MAINITEMPARAMETERVALUES newVal = new MAINITEMPARAMETERVALUES();
                            newVal.MainItemParametersID = currentParameter.ParameterID;
                            newVal.MainItemsID = item.MainItemID;
                            newVal.UserID = user.USERID;
                            newVal.CreationDate = DateTime.UtcNow;
                            newVal.LastModified = DateTime.UtcNow;
                            _context.MAINITEMPARAMETERVALUES.Add(newVal);
                            update = true;
                        }
                    }


                    // Search invalid dates
                    List<int> valueIds = planningParameters.Select(v => v.ParameterID).ToList();
                    foreach (var val in values)
                        if (!valueIds.Contains(val.MainItemParametersID))
                        {
                            _context.Remove(val);
                            update = true;
                        }

                    if (update)
                    {
                        await _context.SaveChangesAsync();
                    }
                }
            }

            SetViewBagParameters(planningParameters);

            // Assign the qty to every planning
            if (plannings != null && mainItemsQty != null)
            {
                foreach (PLANNINGS planning in plannings)
                {
                    planning.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == planning.MainItemId).OrderByDescending(q => q.QuantityId).FirstOrDefault();
                    planning.MAINITEMS.PROJECTSETTINGS = projectSettings;
                    planning.ITEM_QUANTITY = planning.ITEM_QUANTITY;

                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == planning.MAINITEMS.MainItemID
                        && m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(m => m.MainItemParametersID).ToListAsync();
                    planning.MAINITEMDATEVALUES = values;
                }
            }

            ViewBag.Project = project.Code;

            List<string> dates1 = PLANNINGS.GetDates1();
            List<string> dates2 = PLANNINGS.GetDates2();
            if (totalParameters > 0)
            {
                var paramDates = planningParameters.Select(p => p.PARAMETERNAME).ToList();
                if (paramDates != null && paramDates.Count > 0)
                {
                    dates1.AddRange(paramDates);
                    dates2.AddRange(paramDates);
                }
            }
            ViewBag.Dates1 = dates1;
            ViewBag.Dates2 = dates2;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(plannings);
        }

        public async Task<IActionResult> PlanningView(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }
            ViewBag.Role = user.ACCESS_LEVEL;

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();
            var plannings = await _context.PLANNINGS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID && !x.MAINITEMS.IsBalance).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Include(x => x.MAINITEMS).Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            plannings = MainItemUtils.OrderMainitemsPlannings(plannings, projectSettings.BALANCE);

            int dateType = _configuration.GetValue<int>("Items:ParameterDateID");
            var planningParameters = await _context.MAINITEMPARAMETERS.Where(d => d.PROJECTID == project.ProjectID
                && d.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(d => d.ParameterID).ToListAsync();
            int totalParameters = planningParameters != null ? planningParameters.Count : 0;

            if (mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    var holds = await _context.HOLDS.Where(x => x.MainItemId == item.MainItemID).ToListAsync();
                    item.HOLDS = holds;
                }
            }

            if (totalParameters > 0 && mainItems != null)
            {
                foreach (MAINITEMS item in mainItems)
                {
                    bool update = false;
                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == item.MainItemID
                        && m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(p => p.MainItemParametersID).ToListAsync();
                    foreach (MAINITEMPARAMETERS currentParameter in planningParameters)
                    {
                        MAINITEMPARAMETERVALUES date = null;
                        if (values != null)
                            date = values.Where(d => d.MainItemParametersID == currentParameter.ParameterID).FirstOrDefault();
                        if (date == null) // Add date
                        {
                            MAINITEMPARAMETERVALUES newVal = new MAINITEMPARAMETERVALUES();
                            newVal.MainItemParametersID = currentParameter.ParameterID;
                            newVal.MainItemsID = item.MainItemID;
                            newVal.UserID = user.USERID;
                            newVal.CreationDate = DateTime.UtcNow;
                            newVal.LastModified = DateTime.UtcNow;
                            _context.MAINITEMPARAMETERVALUES.Add(newVal);
                            update = true;
                        }
                    }


                    // Search invalid dates
                    List<int> valueIds = planningParameters.Select(v => v.ParameterID).ToList();
                    foreach (var val in values)
                        if (!valueIds.Contains(val.MainItemParametersID))
                        {
                            _context.Remove(val);
                            update = true;
                        }

                    if (update)
                    {
                        await _context.SaveChangesAsync();
                    }
                }
            }

            SetViewBagParameters(planningParameters);

            // Assign the qty to every planning
            if (plannings != null && mainItemsQty != null)
            {
                foreach (PLANNINGS planning in plannings)
                {
                    planning.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == planning.MainItemId).OrderByDescending(q => q.QuantityId).FirstOrDefault();
                    planning.MAINITEMS.PROJECTSETTINGS = projectSettings;
                    planning.ITEM_QUANTITY = planning.ITEM_QUANTITY;

                    var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == planning.MAINITEMS.MainItemID
                        && m.MainItemParameters.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(m => m.MainItemParametersID).ToListAsync();
                    planning.MAINITEMDATEVALUES = values;
                }
            }

            List<string> dates1 = PLANNINGS.GetDates1();
            List<string> dates2 = PLANNINGS.GetDates2();
            if (totalParameters > 0)
            {
                var paramDates = planningParameters.Select(p => p.PARAMETERNAME).ToList();
                if (paramDates != null && paramDates.Count > 0)
                {
                    dates1.AddRange(paramDates);
                    dates2.AddRange(paramDates);
                }
            }
            ViewBag.Dates1 = dates1;
            ViewBag.Dates2 = dates2;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            return View(plannings);
        }

        public async Task<IActionResult> Baseline(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID && !x.IsBalance).ToListAsync();
            var plannings = await _context.PLANNINGS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Include(x => x.MAINITEMS).Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID && !x.MAINITEMS.IsBalance).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            plannings = MainItemUtils.OrderMainitemsPlannings(plannings, projectSettings.BALANCE);

            // Assign the qty to every planning
            if (plannings != null && mainItemsQty != null)
            {
                foreach (PLANNINGS planning in plannings)
                {
                    planning.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == planning.MainItemId).OrderByDescending(q => q.QuantityId).FirstOrDefault();
                    planning.MAINITEMS.PROJECTSETTINGS = projectSettings;
                    planning.ITEM_QUANTITY = planning.ITEM_QUANTITY;
                }
            }

            ViewBag.Project = project.Code;

            return View(plannings);
        }

        // GET: PLANNINGS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pLANNINGS = await _context.PLANNINGS
                .Include(p => p.MAINITEMS)
                .FirstOrDefaultAsync(m => m.PlanningId == id);
            if (pLANNINGS == null)
            {
                return NotFound();
            }

            return View(pLANNINGS);
        }

        // GET: PLANNINGS/Create
        public IActionResult Create()
        {
            ViewData["MainItemId"] = new SelectList(_context.Set<MAINITEMS>(), "MainItemID", "MainItemID");
            return View();
        }

        // POST: PLANNINGS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlanningId,MainItemId,EngineeringPlanningGroup,DATE_FORE_IP,DATE_FORE_INT,DATE_ACT_INT,DATE_BASE_IFR,DATE_BASE_IFR_ENG,DATE_FORE_IFR,DATE_ACT_IFR,DATE_BASE_IFC,DATE_BASE_IFC_ENG,DATE_FORE_IFC,DATE_ACT_IFC,HOLD_DATE_FORE_INPUT")] PLANNINGS pLANNINGS)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pLANNINGS);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MainItemId"] = new SelectList(_context.Set<MAINITEMS>(), "MainItemID", "MainItemID", pLANNINGS.MainItemId);
            return View(pLANNINGS);
        }

        [HttpPost]
        public async Task<string> UpdateDates(string code, string mainitemsstr, string tagtypesstr, string lotstr, string datesstr1, string datesstr2, string datesstr3, string datesstr4, string datesstr5,
            string datesstr6, string datesstr7, string datesstr8, string datesstr9, string datesstr10, string datesstr11,
            string param1ValuesStr,
            string param2ValuesStr,
            string param3ValuesStr,
            string param4ValuesStr,
            string param5ValuesStr,
            string param6ValuesStr,
            string param7ValuesStr,
            string param8ValuesStr,
            string param9ValuesStr,
            string param10ValuesStr)
        {
            string msg = string.Empty;
            bool updateDate = false;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] tagtypes = Utils.SplitText(tagtypesstr);
                    string[] lots = Utils.SplitText(lotstr);
                    DateTime?[] dates1 = Utils.SplitDate(datesstr1);
                    DateTime?[] dates2 = Utils.SplitDate(datesstr2);
                    DateTime?[] dates3 = Utils.SplitDate(datesstr3);
                    DateTime?[] dates4 = Utils.SplitDate(datesstr4);
                    DateTime?[] dates5 = Utils.SplitDate(datesstr5);
                    DateTime?[] dates6 = Utils.SplitDate(datesstr6);
                    DateTime?[] dates7 = Utils.SplitDate(datesstr7);
                    DateTime?[] dates8 = Utils.SplitDate(datesstr8);
                    DateTime?[] dates9 = Utils.SplitDate(datesstr9);
                    DateTime?[] dates10 = Utils.SplitDate(datesstr10);
                    DateTime?[] dates11 = Utils.SplitDate(datesstr11);

                    DateTime?[] param1Values = Utils.SplitDate(param1ValuesStr);
                    DateTime?[] param2Values = Utils.SplitDate(param2ValuesStr);
                    DateTime?[] param3Values = Utils.SplitDate(param3ValuesStr);
                    DateTime?[] param4Values = Utils.SplitDate(param4ValuesStr);
                    DateTime?[] param5Values = Utils.SplitDate(param5ValuesStr);
                    DateTime?[] param6Values = Utils.SplitDate(param6ValuesStr);
                    DateTime?[] param7Values = Utils.SplitDate(param7ValuesStr);
                    DateTime?[] param8Values = Utils.SplitDate(param8ValuesStr);
                    DateTime?[] param9Values = Utils.SplitDate(param9ValuesStr);
                    DateTime?[] param10Values = Utils.SplitDate(param10ValuesStr);

                    int dateType = _configuration.GetValue<int>("Items:ParameterDateID");
                    var planningParameters = await _context.MAINITEMPARAMETERS.Where(d => d.PROJECTID == project.ProjectID
                        && d.MAINITEMPARAMETERCATEGORIESID == dateType).OrderBy(d => d.ParameterID).ToListAsync();
                    int totalParameters = planningParameters != null ? planningParameters.Count : 0;

                    int itemCounter = 0;
                    bool changed = false;
                    foreach (string item in mainitems)
                    {
                        var mainitem = await _context.MAINITEMS.Include(m => m.LOTS).FirstOrDefaultAsync(m => m.MainItemTag == item &&
                            m.PBS.ProjectID == project.ProjectID && m.TAGTYPES.Description == tagtypes[itemCounter] &&
                            m.LOTS.NAME == lots[itemCounter]);
                        if (mainitem != null)
                        {
                            var planning = await _context.PLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainitem.MainItemID);
                            if (planning != null)
                            {
                                if (dates1[itemCounter] == null)
                                    planning.DATE_INPUT_FORE = null;
                                else
                                    planning.DATE_INPUT_FORE = dates1[itemCounter].Value;

                                if (dates2[itemCounter] == null)
                                    planning.DATE_IFR_CHECK_FORE = null;
                                else
                                    planning.DATE_IFR_CHECK_FORE = dates2[itemCounter].Value;

                                if (dates3[itemCounter] == null)
                                    planning.DATE_IFR_CHECK_ACTUAL = null;
                                else
                                    planning.DATE_IFR_CHECK_ACTUAL = dates3[itemCounter].Value;

                                if (dates4[itemCounter] == null)
                                    planning.DATE_IFR_FORE = null;
                                else
                                    planning.DATE_IFR_FORE = dates4[itemCounter].Value;

                                if (dates5[itemCounter] == null)
                                    planning.DATE_IFR_ACTUAL = null;
                                else
                                    planning.DATE_IFR_ACTUAL = dates5[itemCounter].Value;

                                if (dates6[itemCounter] == null)
                                    planning.DATE_IFC_CHECK_FORE = null;
                                else
                                    planning.DATE_IFC_CHECK_FORE = dates6[itemCounter].Value;

                                if (dates7[itemCounter] == null)
                                    planning.DATE_IFC_CHECK_ACTUAL = null;
                                else
                                    planning.DATE_IFC_CHECK_ACTUAL = dates7[itemCounter].Value;

                                if (dates8[itemCounter] == null)
                                    planning.DATE_IFC_FORE = null;
                                else
                                    planning.DATE_IFC_FORE = dates8[itemCounter].Value;

                                if (dates9[itemCounter] == null)
                                    planning.DATE_IFC_ACTUAL = null;
                                else
                                    planning.DATE_IFC_ACTUAL = dates9[itemCounter].Value;

                                if (dates10[itemCounter] == null)
                                    planning.DATE_IFR_BASE_ENG = null;
                                else
                                    planning.DATE_IFR_BASE_ENG = dates10[itemCounter].Value;

                                if (dates11[itemCounter] == null)
                                    planning.DATE_IFC_BASE_ENG = null;
                                else
                                    planning.DATE_IFC_BASE_ENG = dates11[itemCounter].Value;

                                planning.UserID = user.USERID;
                                planning.LastModified = DateTime.UtcNow;

                                bool updated = planning.UpdateDate();
                                if (updated)
                                    updateDate = true;

                                changed = true;
                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_MAIN_ITEM_NOT_FOUND, item + " ");
                            }

                            if (totalParameters > 0)
                            {
                                var values = await _context.MAINITEMPARAMETERVALUES.Where(m => m.MainItemsID == mainitem.MainItemID).ToListAsync();
                                if (values != null)
                                {
                                    int counter = 0;
                                    foreach (var parameter in planningParameters)
                                    {
                                        var value = values.Where(v => v.MainItemParametersID == parameter.ParameterID).FirstOrDefault();
                                        if (value != null)
                                        {
                                            if (counter == 0)
                                                value.PARAMETERDATE = param1Values[itemCounter];
                                            else if (counter == 1)
                                                value.PARAMETERDATE = param2Values[itemCounter];
                                            else if (counter == 2)
                                                value.PARAMETERDATE = param3Values[itemCounter];
                                            else if (counter == 3)
                                                value.PARAMETERDATE = param4Values[itemCounter];
                                            else if (counter == 4)
                                                value.PARAMETERDATE = param5Values[itemCounter];
                                            else if (counter == 5)
                                                value.PARAMETERDATE = param6Values[itemCounter];
                                            else if (counter == 6)
                                                value.PARAMETERDATE = param7Values[itemCounter];
                                            else if (counter == 7)
                                                value.PARAMETERDATE = param8Values[itemCounter];
                                            else if (counter == 8)
                                                value.PARAMETERDATE = param9Values[itemCounter];
                                            else if (counter == 9)
                                                value.PARAMETERDATE = param10Values[itemCounter];
                                        }
                                        counter++;
                                    }
                                }
                            }
                        }
                        itemCounter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    if (!updateDate)
                        msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED);
                    else
                        msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED_WITH_CHANGES);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        [HttpPost]
        public async Task<string> UpdateDateBaseline(string code, string mainitemsstr, string tagtypesstr, string lotstr, string datesstr1, string datesstr2, string datesstr3, string datesstr4)
        {
            string msg = string.Empty;
            bool updateDate = false;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    ViewBag.Project = project.Code;

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] tagtypes = Utils.SplitText(tagtypesstr);
                    string[] lots = Utils.SplitText(lotstr);
                    DateTime?[] dates1 = Utils.SplitDate(datesstr1);
                    DateTime?[] dates2 = Utils.SplitDate(datesstr2);
                    DateTime?[] dates3 = Utils.SplitDate(datesstr3);
                    DateTime?[] dates4 = Utils.SplitDate(datesstr4);
                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainitems)
                    {
                        var mainitem = await _context.MAINITEMS.Include(m => m.LOTS).FirstOrDefaultAsync(m => m.MainItemTag == item &&
                            m.PBS.ProjectID == project.ProjectID && m.TAGTYPES.Description == tagtypes[counter] &&
                            m.LOTS.NAME == lots[counter]);
                        if (mainitem != null)
                        {
                            var planning = await _context.PLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainitem.MainItemID);
                            if (planning != null)
                            {
                                if (dates1[counter] == null)
                                    planning.DATE_IFR_BASE_LEV3 = null;
                                else
                                    planning.DATE_IFR_BASE_LEV3 = dates1[counter].Value;

                                if (dates2[counter] == null)
                                    planning.DATE_IFR_BASE_ENG = null;
                                else
                                    planning.DATE_IFR_BASE_ENG = dates2[counter].Value;

                                if (dates3[counter] == null)
                                    planning.DATE_IFC_BASE_LEV3 = null;
                                else
                                    planning.DATE_IFC_BASE_LEV3 = dates3[counter].Value;

                                if (dates4[counter] == null)
                                    planning.DATE_IFC_BASE_ENG = null;
                                else
                                    planning.DATE_IFC_BASE_ENG = dates4[counter].Value;


                                planning.UserID = user.USERID;
                                planning.LastModified = DateTime.UtcNow;

                                bool updated = planning.UpdateDate();
                                if (updated)
                                    updateDate = true;

                                changed = true;
                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_MAIN_ITEM_NOT_FOUND, item + " ");
                            }
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    if (!updateDate)
                        msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED);
                    else
                        msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED_WITH_CHANGES);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }



            return msg;
        }

        // GET: PLANNINGS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pLANNINGS = await _context.PLANNINGS.FindAsync(id);
            if (pLANNINGS == null)
            {
                return NotFound();
            }
            ViewData["MainItemId"] = new SelectList(_context.Set<MAINITEMS>(), "MainItemID", "MainItemID", pLANNINGS.MainItemId);
            return View(pLANNINGS);
        }

        // POST: PLANNINGS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlanningId,MainItemId,EngineeringPlanningGroup,DATE_FORE_IP,DATE_FORE_INT,DATE_ACT_INT,DATE_BASE_IFR,DATE_BASE_IFR_ENG,DATE_FORE_IFR,DATE_ACT_IFR,DATE_BASE_IFC,DATE_BASE_IFC_ENG,DATE_FORE_IFC,DATE_ACT_IFC,HOLD_DATE_FORE_INPUT")] PLANNINGS pLANNINGS)
        {
            if (id != pLANNINGS.PlanningId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pLANNINGS);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PLANNINGSExists(pLANNINGS.PlanningId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MainItemId"] = new SelectList(_context.Set<MAINITEMS>(), "MainItemID", "MainItemID", pLANNINGS.MainItemId);
            return View(pLANNINGS);
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:PlanningsTemplateBaseline");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "Plannings.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:PlanningsBaselineSheetName");
            int startRow = _configuration.GetValue<int>("Excel:PlanningsSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:PlanningsSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:PlanningsProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:PlanningsProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID).ToListAsync();
            var plannings = await _context.PLANNINGS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Include(x => x.MAINITEMS).Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            plannings = MainItemUtils.OrderMainitemsPlannings(plannings, projectSettings.BALANCE);

            // Assign the qty to every planning
            if (plannings != null && mainItemsQty != null)
            {
                foreach (PLANNINGS planning in plannings)
                {
                    planning.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == planning.MainItemId).OrderByDescending(q => q.QuantityId).FirstOrDefault();
                    planning.MAINITEMS.PROJECTSETTINGS = projectSettings;
                    planning.ITEM_QUANTITY = planning.ITEM_QUANTITY;
                }
            }

            if (plannings != null && mainItems != null)
            {
                // Update Main Items
                foreach (MAINITEMS item in mainItems)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItems.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }
                }

                int currentRow = startRow;
                plannings = plannings.OrderBy(p => p.MAINITEMS.MainItemTag).ToList();
                foreach (PLANNINGS item in plannings)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.MAINITEMS.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.MAINITEMS.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MAINITEMS.LOTS.NAME;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.DATE_IFR_BASE_LEV3 != null && item.DATE_IFR_BASE_LEV3.HasValue ? item.DATE_IFR_BASE_LEV3.Value.ToShortDateString() : null;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.DATE_IFR_BASE_ENG != null && item.DATE_IFR_BASE_ENG.HasValue ? item.DATE_IFR_BASE_ENG.Value.ToShortDateString() : null;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.DATE_IFC_BASE_LEV3 != null && item.DATE_IFC_BASE_LEV3.HasValue ? item.DATE_IFC_BASE_LEV3.Value.ToShortDateString() : null;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.DATE_IFC_BASE_ENG != null && item.DATE_IFC_BASE_ENG.HasValue ? item.DATE_IFC_BASE_ENG.Value.ToShortDateString() : null;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            DatabaseCostants.InitValues(_configuration);

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:PlanningsViewTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "Plannings.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:PlanningsSheetName");
            int startRow = _configuration.GetValue<int>("Excel:MainItemsListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:MainItemsListSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:MainItemsListProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:MainItemsListProjectColumn");
            List<string> columnNames = ParsingUtils.ParseString(_configuration.GetValue<string>("Excel:ItemColumns"));

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            Sheet.Cells[projectRow, projectColumn].Value = project.GetCompleteDescription;
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsList = await _context.MAINITEMS.Include(m => m.PBS)
                .Include(m => m.LOTS)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.TAGTYPES)
                .Include(m => m.USERS)
                .Where(p => p.PBS.ProjectID == project.ProjectID).ToListAsync();

            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            if (mainItemsList != null)
            {
                mainItemsList = mainItemsList.OrderBy(p => p.MainItemTag).ToList();

                // Update Main Items
                foreach (MAINITEMS item in mainItemsList)
                {
                    if (item.PARENTID.HasValue)
                    {
                        var parent = mainItemsList.Where(m => m.MainItemID == item.PARENTID.Value).FirstOrDefault();
                        if (parent != null)
                            item.PARENT_TAG = parent.MainItemTag;
                    }

                    var holds = await _context.HOLDS.Where(x => x.MainItemId == item.MainItemID).ToListAsync();
                    item.HOLDS = holds;

                    item.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == item.MainItemID).FirstOrDefault();
                }

                int currentRow = startRow;
                foreach (MAINITEMS item in mainItemsList)
                {
                    Sheet.Cells[currentRow, startColumn].Value = item.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = item.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = item.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = item.TagClient;
                    Sheet.Cells[currentRow, startColumn + 4].Value = item.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 5].Value = item.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 6].Value = item.LOTS != null ? item.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 7].Value = item.Status;
                    Sheet.Cells[currentRow, startColumn + 8].Value = item.PARENT_TAG;
                    Sheet.Cells[currentRow, startColumn + 9].Value = item.GetEngStatus;
                    Sheet.Cells[currentRow, startColumn + 10].Value = item.DrawNo;
                    Sheet.Cells[currentRow, startColumn + 11].Value = item.DRAWREV;
                    Sheet.Cells[currentRow, startColumn + 12].Value = item.QtyUnits;
                    Sheet.Cells[currentRow, startColumn + 13].Value = item.ITEM_QUANTITY.GetLastCEQty;

                    if (item.TAGTYPES.TagTypeID != DatabaseCostants.TagType_Steel_ID)
                    {
                        var planning = await _context.PLANNINGS.Where(p => p.MainItemId == item.MainItemID).FirstOrDefaultAsync();
                        if (planning != null)
                        {
                            Sheet.Cells[currentRow, startColumn + 14].Value = planning.DayToNextIssue;
                            Sheet.Cells[currentRow, startColumn + 15].Value = planning.DateInputForeGUI;
                            Sheet.Cells[currentRow, startColumn + 16].Value = planning.DateIfrBaseLev3GUI;
                            Sheet.Cells[currentRow, startColumn + 17].Value = planning.DateIfrBaseEngGUI;
                            Sheet.Cells[currentRow, startColumn + 18].Value = planning.DateIfrCheckForeGUI;
                            Sheet.Cells[currentRow, startColumn + 19].Value = planning.DateIfrCheckActualGUI;
                            Sheet.Cells[currentRow, startColumn + 20].Value = planning.DateIfrForeGUI;
                            Sheet.Cells[currentRow, startColumn + 21].Value = planning.DateIfrActualGUI;
                            Sheet.Cells[currentRow, startColumn + 22].Value = planning.DateIfcBaseLev3GUI;
                            Sheet.Cells[currentRow, startColumn + 23].Value = planning.DateIfcBaseEngGUI;
                            Sheet.Cells[currentRow, startColumn + 24].Value = planning.DateIfcCheckForeGUI;
                            Sheet.Cells[currentRow, startColumn + 25].Value = planning.DateIfcCheckActualGUI;
                            Sheet.Cells[currentRow, startColumn + 26].Value = planning.DateIfcForeGUI;
                            Sheet.Cells[currentRow, startColumn + 27].Value = planning.DateIfcActualGUI;
                        }
                    }
                    else
                    {
                    }
                    Sheet.Cells[currentRow, startColumn + 28].Value = item.GetHoldStatus;
                    Sheet.Cells[currentRow, startColumn + 29].Value = item.DateLastModify;
                    Sheet.Cells[currentRow, startColumn + 30].Value = item.LastModifyUser;

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        // GET: PLANNINGS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pLANNINGS = await _context.PLANNINGS
                .Include(p => p.MAINITEMS)
                .FirstOrDefaultAsync(m => m.PlanningId == id);
            if (pLANNINGS == null)
            {
                return NotFound();
            }

            return View(pLANNINGS);
        }

        // POST: PLANNINGS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pLANNINGS = await _context.PLANNINGS.FindAsync(id);
            _context.PLANNINGS.Remove(pLANNINGS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PLANNINGSExists(int id)
        {
            return _context.PLANNINGS.Any(e => e.PlanningId == id);
        }

        [HttpGet]
        public async Task<List<string>> GetDateList(string code)
        {
            if (string.IsNullOrEmpty(code))
                return null;

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return null;
            _context.ProjectID = project.ProjectID;

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            List<string> dates = new List<string>();



            return dates;
        }

        private void SetViewBagParameters(List<MAINITEMPARAMETERS> parameters)
        {
            if (parameters == null)
                return;
            int index = 0;
            ViewBag.TotalParameters = parameters != null ? parameters.Count : 0;

            ViewBag.ParameterName1 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName2 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName3 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName4 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName5 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName6 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName7 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName8 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName9 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
            index++; ViewBag.ParameterName10 = parameters.Count > index ? parameters[index].PARAMETERNAME : string.Empty;
        }


        [HttpPost]
        public async Task<string> SaveDeliveryTime(string code,
            string mainitemsstr,
            string tagtypesstr,
            string lotstr,
            string datesstr1a,
            string datesstr2a,
            string datesstr3a,
            string datesstr4a,
            string datesstr5a,
            string datesstr6a,
            string datesstr7a,
            string datesstr8a,
            string datesstr9a,
            string datesstr10a,
            string datesstr11a,
            string datesstr12a,
            string datesstr13a,
            string datesstr14a,
            string datesstr15a,
            string datesstr1b,
            string datesstr2b,
            string datesstr3b,
            string datesstr4b,
            string datesstr5b,
            string datesstr6b,
            string datesstr7b,
            string datesstr8b,
            string datesstr9b,
            string datesstr10b,
            string datesstr11b,
            string datesstr12b,
            string datesstr13b,
            string datesstr14b,
            string datesstr15b,
            string param1ValuesStr,
            string param2ValuesStr,
            string param3ValuesStr,
            string param4ValuesStr,
            string param5ValuesStr,
            string param6ValuesStr,
            string param7ValuesStr,
            string param8ValuesStr,
            string param9ValuesStr,
            string param10ValuesStr,
            string param11ValuesStr,
            string param12ValuesStr,
            string param13ValuesStr,
            string param14ValuesStr,
            string param15ValuesStr)
        {
            string msg = string.Empty;
            bool updateDate = false;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    ViewBag.Project = project.Code;

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] tagtypes = Utils.SplitText(tagtypesstr);
                    string[] lots = Utils.SplitText(lotstr);

                    string[] dates1a = Utils.SplitText(datesstr1a);
                    string[] dates2a = Utils.SplitText(datesstr2a);
                    string[] dates3a = Utils.SplitText(datesstr3a);
                    string[] dates4a = Utils.SplitText(datesstr4a);
                    string[] dates5a = Utils.SplitText(datesstr5a);
                    string[] dates6a = Utils.SplitText(datesstr6a);
                    string[] dates7a = Utils.SplitText(datesstr7a);
                    string[] dates8a = Utils.SplitText(datesstr8a);
                    string[] dates9a = Utils.SplitText(datesstr9a);
                    string[] dates10a = Utils.SplitText(datesstr10a);
                    string[] dates11a = Utils.SplitText(datesstr11a);
                    string[] dates12a = Utils.SplitText(datesstr12a);
                    string[] dates13a = Utils.SplitText(datesstr13a);
                    string[] dates14a = Utils.SplitText(datesstr14a);
                    string[] dates15a = Utils.SplitText(datesstr15a);

                    string[] dates1b = Utils.SplitText(datesstr1b);
                    string[] dates2b = Utils.SplitText(datesstr2b);
                    string[] dates3b = Utils.SplitText(datesstr3b);
                    string[] dates4b = Utils.SplitText(datesstr4b);
                    string[] dates5b = Utils.SplitText(datesstr5b);
                    string[] dates6b = Utils.SplitText(datesstr6b);
                    string[] dates7b = Utils.SplitText(datesstr7b);
                    string[] dates8b = Utils.SplitText(datesstr8b);
                    string[] dates9b = Utils.SplitText(datesstr9b);
                    string[] dates10b = Utils.SplitText(datesstr10b);
                    string[] dates11b = Utils.SplitText(datesstr11b);
                    string[] dates12b = Utils.SplitText(datesstr12b);
                    string[] dates13b = Utils.SplitText(datesstr13b);
                    string[] dates14b = Utils.SplitText(datesstr14b);
                    string[] dates15b = Utils.SplitText(datesstr15b);

                    int?[] days1 = Utils.SplitIntVectorWithNull(param1ValuesStr);
                    int?[] days2 = Utils.SplitIntVectorWithNull(param2ValuesStr);
                    int?[] days3 = Utils.SplitIntVectorWithNull(param3ValuesStr);
                    int?[] days4 = Utils.SplitIntVectorWithNull(param4ValuesStr);
                    int?[] days5 = Utils.SplitIntVectorWithNull(param5ValuesStr);
                    int?[] days6 = Utils.SplitIntVectorWithNull(param6ValuesStr);
                    int?[] days7 = Utils.SplitIntVectorWithNull(param7ValuesStr);
                    int?[] days8 = Utils.SplitIntVectorWithNull(param8ValuesStr);
                    int?[] days9 = Utils.SplitIntVectorWithNull(param9ValuesStr);
                    int?[] days10 = Utils.SplitIntVectorWithNull(param10ValuesStr);
                    int?[] days11 = Utils.SplitIntVectorWithNull(param11ValuesStr);
                    int?[] days12 = Utils.SplitIntVectorWithNull(param12ValuesStr);
                    int?[] days13 = Utils.SplitIntVectorWithNull(param13ValuesStr);
                    int?[] days14 = Utils.SplitIntVectorWithNull(param14ValuesStr);
                    int?[] days15 = Utils.SplitIntVectorWithNull(param15ValuesStr);

                    int quantityType = _configuration.GetValue<int>("Items:ParameterQuantityID");

                    int counter = 0;
                    bool changed = false;
                    foreach (string item in mainitems)
                    {
                        var mainitem = await _context.MAINITEMS.Include(m => m.LOTS).FirstOrDefaultAsync(m => m.MainItemTag == item &&
                            m.PBS.ProjectID == project.ProjectID && m.TAGTYPES.Description == tagtypes[counter] &&
                            m.LOTS.NAME == lots[counter]);
                        if (mainitem != null)
                        {
                            var planning = await _context.PLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainitem.MainItemID);
                            if (planning != null)
                            {
                                var values = await _context.MAINITEMPARAMETERVALUES.Include(m => m.MainItemParameters).Where(m => m.MainItemsID == mainitem.MainItemID
                                    && m.MainItemParametersID == quantityType).ToListAsync();

                                if (days1[counter] != null && days1[counter].HasValue)
                                    UpdateDateByName(planning, dates1a[counter], dates1b[counter], values, days1[counter].Value);
                                if (days2[counter] != null && days2[counter].HasValue)
                                    UpdateDateByName(planning, dates2a[counter], dates2b[counter], values, days2[counter].Value);
                                if (days3[counter] != null && days3[counter].HasValue)
                                    UpdateDateByName(planning, dates3a[counter], dates3b[counter], values, days3[counter].Value);
                                if (days4[counter] != null && days4[counter].HasValue)
                                    UpdateDateByName(planning, dates4a[counter], dates4b[counter], values, days4[counter].Value);
                                if (days5[counter] != null && days5[counter].HasValue)
                                    UpdateDateByName(planning, dates5a[counter], dates5b[counter], values, days5[counter].Value);
                                if (days6[counter] != null && days6[counter].HasValue)
                                    UpdateDateByName(planning, dates6a[counter], dates6b[counter], values, days6[counter].Value);
                                if (days7[counter] != null && days7[counter].HasValue)
                                    UpdateDateByName(planning, dates7a[counter], dates7b[counter], values, days7[counter].Value);
                                if (days8[counter] != null && days8[counter].HasValue)
                                    UpdateDateByName(planning, dates8a[counter], dates8b[counter], values, days8[counter].Value);
                                if (days9[counter] != null && days9[counter].HasValue)
                                    UpdateDateByName(planning, dates9a[counter], dates9b[counter], values, days9[counter].Value);
                                if (days10[counter] != null && days10[counter].HasValue)
                                    UpdateDateByName(planning, dates10a[counter], dates10b[counter], values, days10[counter].Value);
                                if (days11[counter] != null && days11[counter].HasValue)
                                    UpdateDateByName(planning, dates11a[counter], dates11b[counter], values, days11[counter].Value);
                                if (days12[counter] != null && days12[counter].HasValue)
                                    UpdateDateByName(planning, dates12a[counter], dates12b[counter], values, days12[counter].Value);
                                if (days13[counter] != null && days13[counter].HasValue)
                                    UpdateDateByName(planning, dates13a[counter], dates13b[counter], values, days13[counter].Value);
                                if (days14[counter] != null && days14[counter].HasValue)
                                    UpdateDateByName(planning, dates14a[counter], dates14b[counter], values, days14[counter].Value);
                                if (days15[counter] != null && days15[counter].HasValue)
                                    UpdateDateByName(planning, dates15a[counter], dates15b[counter], values, days15[counter].Value);

                                planning.UserID = user.USERID;
                                planning.LastModified = DateTime.UtcNow;

                                bool updated = planning.UpdateDate();
                                if (updated)
                                    updateDate = true;

                                changed = true;
                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_MAIN_ITEM_NOT_FOUND, item + " ");
                            }
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    if (!updateDate)
                        msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED);
                    else
                        msg += _sharedResource.Message(MESSAGE_CODES.PLANNING_DATES_UPDATED_WITH_CHANGES);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }



            return msg;
        }

        private DateTime? GetDateByName(PLANNINGS planning, string name, List<MAINITEMPARAMETERVALUES> values)
        {
            if (name == MainItemsCostants.DATE_IFC_FORE)
                return planning.DATE_IFC_FORE;
            else if (name == MainItemsCostants.DATE_IFC_CHECK_FORE)
                return planning.DATE_IFC_CHECK_FORE;
            else if (name == MainItemsCostants.DATE_IFR_CHECK_FORE)
                return planning.DATE_IFR_CHECK_FORE;
            else if (name == MainItemsCostants.DATE_INP_FORE)
                return planning.DATE_INPUT_FORE;
            else if (name == MainItemsCostants.DATE_IFC_CHECK_ACTUAL)
                return planning.DATE_IFC_CHECK_ACTUAL;
            else if (name == MainItemsCostants.DATE_IFR_CHECK_ACTUAL)
                return planning.DATE_IFR_CHECK_ACTUAL;
            else if (name == MainItemsCostants.DATE_IFR_BASE_LEV3)
                return planning.DATE_IFR_BASE_LEV3;
            else if (name == MainItemsCostants.DATE_IFR_BASE_ENG)
                return planning.DATE_IFR_BASE_ENG;
            else if (name == MainItemsCostants.DATE_IFC_BASE_LEV3)
                return planning.DATE_IFC_BASE_LEV3;
            else if (name == MainItemsCostants.DATE_IFC_BASE_ENG)
                return planning.DATE_IFC_BASE_ENG;
            else if (name == MainItemsCostants.DATE_IFR_ACT)
                return planning.DATE_IFR_ACTUAL;
            else if (name == MainItemsCostants.DATE_IFC_ACT)
                return planning.DATE_IFC_ACTUAL;
            else // Search on additional parameters
            {
                if (values != null)
                {
                    var valCurrent = values.Where(v => v.MainItemParameters.PARAMETERNAME == name).FirstOrDefault();
                    if (valCurrent != null)
                        return valCurrent.PARAMETERDATE;
                }
            }

            return null;
        }

        private void UpdateDateByName(PLANNINGS planning,
            string name1,
            string name2,
            List<MAINITEMPARAMETERVALUES> values,
            int days)
        {
            if (string.IsNullOrEmpty(name1) || string.IsNullOrEmpty(name2))
                return;
            DateTime? date1 = GetDateByName(planning, name1, values);
            if (date1 != null && date1.Value != null && date1.HasValue)
            {
                DateTime? date2 = GetDateTime(date1, days);
                if (date2 != null && date2.Value != null && date2.HasValue)
                {
                    if (name2 == MainItemsCostants.DATE_IFC_FORE)
                        planning.DATE_IFC_FORE = date2;
                    else if (name2 == MainItemsCostants.DATE_IFC_CHECK_FORE)
                        planning.DATE_IFC_CHECK_FORE = date2;
                    else if (name2 == MainItemsCostants.DATE_IFR_CHECK_FORE)
                        planning.DATE_IFR_CHECK_FORE = date2;
                    else if (name2 == MainItemsCostants.DATE_INP_FORE)
                        planning.DATE_INPUT_FORE = date2;
                    else if (name2 == MainItemsCostants.DATE_IFC_CHECK_ACTUAL)
                    {
                        planning.DATE_IFC_CHECK_ACTUAL = date2;
                        planning.DATE_IFC_CHECK_FORE = date2;
                    }
                    else if (name2 == MainItemsCostants.DATE_IFR_CHECK_ACTUAL)
                    {
                        planning.DATE_IFR_CHECK_ACTUAL = date2;
                        planning.DATE_IFR_CHECK_FORE = date2;
                    }
                    else if (name2 == MainItemsCostants.DATE_IFR_BASE_LEV3)
                        planning.DATE_IFR_BASE_LEV3 = date2;
                    else if (name2 == MainItemsCostants.DATE_IFR_BASE_ENG)
                        planning.DATE_IFR_BASE_ENG = date2;
                    else if (name2 == MainItemsCostants.DATE_IFC_BASE_LEV3)
                        planning.DATE_IFC_BASE_LEV3 = date2;
                    else if (name2 == MainItemsCostants.DATE_IFC_BASE_ENG)
                        planning.DATE_IFC_BASE_ENG = date2;
                    else if (name2 == MainItemsCostants.DATE_IFR_ACT)
                    {
                        planning.DATE_IFR_ACTUAL = date2;
                        planning.DATE_IFR_FORE = date2;
                    }
                    else if (name2 == MainItemsCostants.DATE_IFC_ACT)
                    {
                        planning.DATE_IFC_ACTUAL = date2;
                        planning.DATE_IFC_FORE = date2;
                    }
                    else // Search on additional parameters
                    {
                        if (values != null)
                        {
                            var valCurrent = values.Where(v => v.MainItemParameters.PARAMETERNAME == name2).FirstOrDefault();
                            if (valCurrent != null)
                                valCurrent.PARAMETERDATE = date2;
                        }
                    }
                }
            }
        }

        private DateTime? GetDateTime(DateTime? baseDate, int days)
        {
            if (baseDate == null || !baseDate.HasValue)
                return null;
            return baseDate.Value.AddDays(days);
        }

        [HttpGet]
        public async Task<DELIVERYTIMES> GetProjectDeliveryTimes(string code)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;
            if (project == null)
                return null;

            DELIVERYTIMES develiryTimes = await _context.DELIVERYTIMES.Where(d => d.ProjectID == project.ProjectID).FirstOrDefaultAsync();
            return develiryTimes;
        }

        [HttpPost]
        public async Task<string> SaveProjectDeliveryTimes(string code, string datesstr, string daysstr)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;
            if (project == null)
                return null;

            DELIVERYTIMES develiryTimes = await _context.DELIVERYTIMES.Where(d => d.ProjectID == project.ProjectID).FirstOrDefaultAsync();

            if (develiryTimes != null)
            {
                string[] dates = Utils.SplitText(datesstr);
                int[] days = Utils.SplitIntVector(daysstr);

                develiryTimes.Date11 = dates[0];
                develiryTimes.Date21 = dates[1];
                develiryTimes.Value1 = days[0];

                develiryTimes.Date12 = dates[2];
                develiryTimes.Date22 = dates[3];
                develiryTimes.Value2 = days[1];

                develiryTimes.Date13 = dates[4];
                develiryTimes.Date23 = dates[5];
                develiryTimes.Value3 = days[2];

                develiryTimes.Date14 = dates[6];
                develiryTimes.Date24 = dates[7];
                develiryTimes.Value4 = days[3];

                develiryTimes.Date15 = dates[8];
                develiryTimes.Date25 = dates[9];
                develiryTimes.Value5 = days[4];

                develiryTimes.Date16 = dates[10];
                develiryTimes.Date26 = dates[11];
                develiryTimes.Value6 = days[5];

                develiryTimes.Date17 = dates[12];
                develiryTimes.Date27 = dates[13];
                develiryTimes.Value7 = days[6];

                develiryTimes.Date18 = dates[14];
                develiryTimes.Date28 = dates[15];
                develiryTimes.Value8 = days[7];

                develiryTimes.Date19 = dates[16];
                develiryTimes.Date29 = dates[17];
                develiryTimes.Value9 = days[8];

                develiryTimes.Date110 = dates[18];
                develiryTimes.Date210 = dates[19];
                develiryTimes.Value10 = days[9];

                develiryTimes.Date111 = dates[20];
                develiryTimes.Date211 = dates[21];
                develiryTimes.Value11 = days[10];

                develiryTimes.Date112 = dates[22];
                develiryTimes.Date212 = dates[23];
                develiryTimes.Value12 = days[11];

                develiryTimes.Date113 = dates[24];
                develiryTimes.Date213 = dates[25];
                develiryTimes.Value13 = days[12];

                develiryTimes.Date114 = dates[26];
                develiryTimes.Date214 = dates[27];
                develiryTimes.Value14 = days[13];

                develiryTimes.Date115 = dates[28];
                develiryTimes.Date215 = dates[29];
                develiryTimes.Value15 = days[14];

                await _context.SaveChangesAsync();
            }

            return "Settings Saved";
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:PlanningsTemplateBaseline");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportBaselineExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();

                    // Read Data
                    List<string> mainItemTagList = new List<string>();
                    List<TAGTYPES> tagTypeList = new List<TAGTYPES>();
                    List<string> lotList = new List<string>();

                    List<DateTime?> date1List = new List<DateTime?>();
                    List<DateTime?> date2List = new List<DateTime?>();
                    List<DateTime?> date3List = new List<DateTime?>();
                    List<DateTime?> date4List = new List<DateTime?>();

                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, 1];
                            string tag = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 2];
                            string tagtype = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            var currentTag = tagTypes.Where(t => t.Description == tagtype).FirstOrDefault();
                            bool validTagType = currentTag != null;
                            tagTypeList.Add(currentTag);

                            cell = worksheet.Cells[counter, 3];
                            string lot = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 4];
                            DateTime? date1 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date1 = tempdt;
                            }

                            cell = worksheet.Cells[counter, 5];
                            DateTime? date2 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date2 = tempdt;
                            }

                            cell = worksheet.Cells[counter, 6];
                            DateTime? date3 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date3 = tempdt;
                            }

                            cell = worksheet.Cells[counter, 7];
                            DateTime? date4 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date4 = tempdt;
                            }


                            if (string.IsNullOrEmpty(tag))
                                notEmpty = false;
                            else
                            {
                                if (string.IsNullOrEmpty(tag))
                                    excelLogManager.AddLog(counter, 1, "Tag");
                                else if (string.IsNullOrEmpty(tag))
                                    excelLogManager.AddLog(counter, 2, "Tag Type");
                                else if (string.IsNullOrEmpty(tag))
                                    excelLogManager.AddLog(counter, 3, "Lot");
                                else if (!validTagType)
                                    excelLogManager.AddLog(counter, 2, "Invalid Tag Type");
                                else
                                {
                                    mainItemTagList.Add(tag);
                                    lotList.Add(lot);
                                    date1List.Add(date1);
                                    date2List.Add(date2);
                                    date3List.Add(date3);
                                    date4List.Add(date4);
                                }
                            }
                            counter++;
                        }
                        catch (Exception ex)
                        {
                            notEmpty = false;
                        }
                    }

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                            {
                                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                                return excelLogManager;
                            }

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;
                            ViewBag.ProjectDescription = project.GetCompleteDescription;

                            bool changed = false;
                            for (int i = 0; i < mainItemTagList.Count; i++)
                            {
                                var mainItem = await _context.MAINITEMS.Where(m => m.MainItemTag == mainItemTagList[i] &&
                                    m.PBS.ProjectID == project.ProjectID && m.LOTS.NAME == lotList[i] &&
                                    m.TAGTYPES.TagTypeID == tagTypeList[i].TagTypeID).FirstOrDefaultAsync();
                                if (mainItem != null)
                                {
                                    var planning = await _context.PLANNINGS.Where(p => p.MainItemId == mainItem.MainItemID).FirstOrDefaultAsync();
                                    if (planning != null)
                                    {
                                        planning.DATE_IFR_BASE_LEV3 = date1List[i];
                                        planning.DATE_IFR_BASE_ENG = date2List[i];
                                        planning.DATE_IFC_BASE_LEV3 = date3List[i];
                                        planning.DATE_IFC_BASE_ENG = date4List[i];
                                        changed = true;
                                    }
                                }
                                counter++;
                            }
                            if (changed)
                                await _context.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR) + " " + ex.Message);
                        }
                    }
                    else
                    {
                        excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED));
                    }
                }
            }
            catch { }

            excelLogManager.Result = "Completed";
            return excelLogManager;
        }
    }

}
