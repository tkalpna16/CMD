﻿using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;

using CivilMasterData.Models;
using CivilMasterData.Models.Users;

namespace CivilMasterData.Controllers
{
    public class ADMINController : Controller
    {
        private readonly ADMINContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public ADMINController(ADMINContext context, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        // GET: PBS
        public IActionResult Index(string code)
        {
            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN))
                return Redirect("~/Home/NoPermission");

            return View();
        }
        
    }
}
