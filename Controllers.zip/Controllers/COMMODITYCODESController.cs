﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.IO;
using OfficeOpenXml;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;

using CivilMasterData.Models.Users;
using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Utilities;

namespace CivilMasterData
{
    public class COMMODITYCODESController : Controller
    {
        private readonly COMMODITYCODESContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public COMMODITYCODESController(COMMODITYCODESContext context, IConfiguration configuration, ISharedResource sharedResource,
            IWebHostEnvironment env)
        {
            _context = context;
            _configuration = configuration;
            this._sharedResource = sharedResource;
            _env = env;
        }

        // GET: COMMODITYCODES
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
            {
                project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
                if (project == null)
                    return NotFound();
            }
            _context.ProjectID = project.ProjectID;

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID).ToListAsync();
            return View(commodities);
        }

        // GET: COMMODITYCODES/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cOMMODITYCODES = await _context.COMMODITYCODES
                .FirstOrDefaultAsync(m => m.CodeID == id);
            if (cOMMODITYCODES == null)
            {
                return NotFound();
            }

            return View(cOMMODITYCODES);
        }

        // GET: COMMODITYCODES/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: COMMODITYCODES/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CodeID,Code,CodeDescription,DetailedDescription,SubCode,ItemType,UoM,ProjectID")] COMMODITYCODES cOMMODITYCODES)
        {
            if (ModelState.IsValid)
            {
                _context.Add(cOMMODITYCODES);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cOMMODITYCODES);
        }

        // GET: COMMODITYCODES/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cOMMODITYCODES = await _context.COMMODITYCODES.FindAsync(id);
            if (cOMMODITYCODES == null)
            {
                return NotFound();
            }
            return View(cOMMODITYCODES);
        }

        // POST: COMMODITYCODES/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CodeID,Code,CodeDescription,DetailedDescription,SubCode,ItemType,UoM,ProjectID")] COMMODITYCODES cOMMODITYCODES)
        {
            if (id != cOMMODITYCODES.CodeID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cOMMODITYCODES);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!COMMODITYCODESExists(cOMMODITYCODES.CodeID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cOMMODITYCODES);
        }

        // GET: COMMODITYCODES/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cOMMODITYCODES = await _context.COMMODITYCODES
                .FirstOrDefaultAsync(m => m.CodeID == id);
            if (cOMMODITYCODES == null)
            {
                return NotFound();
            }

            return View(cOMMODITYCODES);
        }

        // POST: COMMODITYCODES/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cOMMODITYCODES = await _context.COMMODITYCODES.FindAsync(id);
            _context.COMMODITYCODES.Remove(cOMMODITYCODES);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool COMMODITYCODESExists(int id)
        {
            return _context.COMMODITYCODES.Any(e => e.CodeID == id);
        }

        [HttpPost]
        public async Task<string> UpdateSettings(string projectcode,
            string codesstr,
            string checkedstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(projectcode))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectcode);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    var commodityList = await _context.COMMODITYCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    string[] codes = Utils.SplitText(codesstr);
                    bool[] values = Utils.SplitBoolean(checkedstr);

                    if (codes != null && values != null)
                    {
                        int counter = 0;
                        foreach (string item in codes)
                        {
                            var commodity = commodityList.Where(c => c.SubCode == item).FirstOrDefault();
                            if (commodity != null)
                                commodity.Selected = values[counter];
                            counter++;
                        }
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.COMMODITYCODE_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        #region Excel
        [HttpPost]
        public async Task<string> ImportCommodities(IFormFile excelFile, string projectcode)
        {
            if (excelFile == null || excelFile.Length <= 0)
                return _sharedResource.Message(MESSAGE_CODES.EXCEL_FILE_NOT_CORRECT);
            if (!Path.GetExtension(excelFile.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                return _sharedResource.Message(MESSAGE_CODES.EXCEL_FILE_NOT_CORRECT);
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(projectcode))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectcode);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    int globalProject = _configuration.GetValue<int>("Oracle:GlobalProjectId");
                    var defaultCommodity = await _context.COMMODITYCODES.Where(x => x.ProjectID == globalProject).ToListAsync();
                    var existingCommodityList = await _context.COMMODITYCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    bool added = false;
                    bool existing = false;
                    using (var stream = new MemoryStream())
                    {
                        await excelFile.CopyToAsync(stream);

                        using (var package = new ExcelPackage(stream))
                        {
                            ExcelWorksheet worksheet = package.Workbook.Worksheets[0];
                            var rowCount = worksheet.Dimension.Rows;

                            for (int row = 3; row <= rowCount; row++)
                            {
                                try
                                {
                                    string code = (string)worksheet.Cells[row, 1].Value;
                                    string itemType = (string)worksheet.Cells[row, 2].Value;
                                    string subCode = (string)worksheet.Cells[row, 3].Value;
                                    string uom = (string)worksheet.Cells[row, 4].Value;
                                    string description = (string)worksheet.Cells[row, 5].Value;
                                    string detailed = (string)worksheet.Cells[row, 6].Value;
                                    if (!String.IsNullOrEmpty(code) && !String.IsNullOrEmpty(itemType) &&
                                        !String.IsNullOrEmpty(subCode) && !String.IsNullOrEmpty(uom) &&
                                        !String.IsNullOrEmpty(description) && !String.IsNullOrEmpty(detailed))
                                    {
                                        var commodity = defaultCommodity.Where(c => c.SubCode == subCode).FirstOrDefault();
                                        if (commodity != null)
                                        {
                                            existing = true;
                                            continue;
                                        }
                                        commodity = existingCommodityList.Where(c => c.SubCode == subCode).FirstOrDefault();
                                        if (commodity != null)
                                        {
                                            existing = true;
                                            continue;
                                        }
                                        COMMODITYCODES newCommodity = new COMMODITYCODES();
                                        newCommodity.Code = code;
                                        newCommodity.CodeDescription = description;
                                        newCommodity.CreationDate = DateTime.UtcNow;
                                        newCommodity.DetailedDescription = detailed;
                                        newCommodity.ItemType = itemType;
                                        newCommodity.LastModified = DateTime.UtcNow;
                                        newCommodity.ProjectID = project.ProjectID;
                                        newCommodity.Selected = false;
                                        newCommodity.SubCode = subCode;
                                        newCommodity.UoM = uom;
                                        newCommodity.UserID = user.USERID;

                                        _context.COMMODITYCODES.Add(newCommodity);
                                        added = true;
                                    }
                                }
                                catch { }
                            }
                        }

                        if (added)
                        {
                            await _context.SaveChangesAsync();
                            msg = _sharedResource.Message(MESSAGE_CODES.COMMODITIES_ADDED);
                        }
                        else if (existing)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.COMMODITIES_EXISTING);
                        }
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:CommoditiesTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }
        #endregion
    }
}
