﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models.PriceList;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using OfficeOpenXml;
using CivilMasterData.Models.Costants;

namespace CivilMasterData
{
    public class PRICECONDITIONSController : Controller
    {
        private readonly PRICECONDITIONSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PRICECONDITIONSController(PRICECONDITIONSContext context,
            IConfiguration configuration, ISharedResource sharedResource, IWebHostEnvironment env)
        {
            _context = context;
            _configuration = configuration;
            this._sharedResource = sharedResource;
            _env = env;
        }

        // GET: PRICECONDITIONS
        public async Task<IActionResult> Index(string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return NotFound();
                    if (user.IsDisabled)
                        return Redirect("~/Home/NoPermission");

                    if (String.IsNullOrEmpty(code))
                        return NotFound();
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return NotFound();
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;


                    var priceCodes = await _context.PRICECODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    var comparisonTypes = await _context.COMPARISONTYPES.ToListAsync();
                    var conditionTypes = await _context.PRICECONDITIONTYPES.ToListAsync();
                    var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).Include(p => p.Project).ToListAsync();
                    var priceConditions = await _context.PRICECONDITIONS.Where(p => p.PRICECODE.ProjectID == project.ProjectID).Include(p => p.PRICECONDITIONTYPE).Include(p => p.BOOLEANOPERATOR).Include(p => p.COMPARISONTYPE).ToListAsync();

                    return View(priceConditions);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return NotFound();
        }

        // GET: PRICECONDITIONS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICECONDITIONS = await _context.PRICECONDITIONS
                .Include(p => p.BOOLEANOPERATOR)
                .Include(p => p.COMPARISONTYPE)
                .Include(p => p.PRICECODE)
                .Include(p => p.PRICECONDITIONTYPE)
                .FirstOrDefaultAsync(m => m.CONDITIONID == id);
            if (pRICECONDITIONS == null)
            {
                return NotFound();
            }

            return View(pRICECONDITIONS);
        }

        // GET: PRICECONDITIONS/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            bool valid = await InitData(project.ProjectID);

            return View();
        }

        private async Task<bool> InitData(int projectId)
        {
            var codes = await _context.PRICECODES.Where(p => p.ProjectID == projectId).ToListAsync();
            ViewBag.PriceCodes = codes.Select(p => p.Code);
            var comparisonTypes = await _context.COMPARISONTYPES.ToListAsync();
            ViewBag.ComparisonTypes = comparisonTypes.Select(p => p.Description);
            var booleanTypes = await _context.BOOLEANOPERATORS.ToListAsync();
            ViewBag.operatorTypes = booleanTypes.Select(p => p.Description);
            var conditionTypes = await _context.PRICECONDITIONTYPES.ToListAsync();
            ViewBag.ConditionTypes = conditionTypes.Select(p => p.Description);
            return true;
        }

        // POST: PRICECONDITIONS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("CONDITIONID,PRICECODEID,CONDITIONTYPEID,CONDITIONPARAMETER,COMPARISONTYPEID,CONDITIONVALUE,BOOLEANOPERATORID")] PRICECONDITIONS pRICECONDITIONS,
            string priceCode, string comparisonType, string conditionType, string operatorType, int projectId)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == projectId);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    if (project != null)
                    {
                        bool valid = await InitData(project.ProjectID);
                        ViewBag.ProjectID = project.ProjectID;
                        ViewBag.Project = project.Code;
                        PRICECODES priceCodeEl = await _context.PRICECODES.Where(p => p.Code == priceCode && p.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                        PRICECONDITIONTYPES CONDITION = await _context.PRICECONDITIONTYPES.Where(c => c.Description == conditionType).FirstOrDefaultAsync();
                        COMPARISONTYPES comparisonTypeEl = await _context.COMPARISONTYPES.Where(c => c.Description == comparisonType).FirstOrDefaultAsync();
                        BOOLEANOPERATORS bOOLEANOPERATORSEl = await _context.BOOLEANOPERATORS.Where(c => c.Description == operatorType).FirstOrDefaultAsync();

                        if (priceCodeEl == null || comparisonTypeEl == null || bOOLEANOPERATORSEl == null || CONDITION == null)
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CONDITION_NOT_VALID);
                        }
                        else
                        {
                            pRICECONDITIONS.BOOLEANOPERATORID = bOOLEANOPERATORSEl.OperatorID;
                            pRICECONDITIONS.COMPARISONTYPEID = comparisonTypeEl.ComparisonTypeID;
                            pRICECONDITIONS.PRICECODEID = priceCodeEl.PriceCodeID;
                            pRICECONDITIONS.CONDITIONTYPEID = CONDITION.ConditionTypeID;

                            _context.Add(pRICECONDITIONS);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CONDITION_CREATED);
                        }
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CONDITION_NOT_VALID);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pRICECONDITIONS);
        }

        // GET: PRICECONDITIONS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICECONDITIONS = await _context.PRICECONDITIONS.FindAsync(id);
            if (pRICECONDITIONS == null)
            {
                return NotFound();
            }
            ViewData["BOOLEANOPERATORID"] = new SelectList(_context.Set<BOOLEANOPERATORS>(), "OperatorID", "OperatorID", pRICECONDITIONS.BOOLEANOPERATORID);
            ViewData["COMPARISONTYPEID"] = new SelectList(_context.Set<COMPARISONTYPES>(), "ComparisonTypeID", "ComparisonTypeID", pRICECONDITIONS.COMPARISONTYPEID);
            ViewData["PRICECODEID"] = new SelectList(_context.PRICECODES, "PriceCodeID", "PriceCodeID", pRICECONDITIONS.PRICECODEID);
            ViewData["CONDITIONTYPEID"] = new SelectList(_context.Set<PRICECONDITIONTYPES>(), "ConditionTypeID", "ConditionTypeID", pRICECONDITIONS.CONDITIONTYPEID);
            return View(pRICECONDITIONS);
        }

        // POST: PRICECONDITIONS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, [Bind("CONDITIONID,PRICECODEID,CONDITIONTYPEID,CONDITIONPARAMETER,COMPARISONTYPEID,CONDITIONVALUE,BOOLEANOPERATORID")] PRICECONDITIONS pRICECONDITIONS)
        {
            if (id != pRICECONDITIONS.CONDITIONID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pRICECONDITIONS);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PRICECONDITIONSExists(pRICECONDITIONS.CONDITIONID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BOOLEANOPERATORID"] = new SelectList(_context.Set<BOOLEANOPERATORS>(), "OperatorID", "OperatorID", pRICECONDITIONS.BOOLEANOPERATORID);
            ViewData["COMPARISONTYPEID"] = new SelectList(_context.Set<COMPARISONTYPES>(), "ComparisonTypeID", "ComparisonTypeID", pRICECONDITIONS.COMPARISONTYPEID);
            ViewData["PRICECODEID"] = new SelectList(_context.PRICECODES, "PriceCodeID", "PriceCodeID", pRICECONDITIONS.PRICECODEID);
            ViewData["CONDITIONTYPEID"] = new SelectList(_context.Set<PRICECONDITIONTYPES>(), "ConditionTypeID", "ConditionTypeID", pRICECONDITIONS.CONDITIONTYPEID);
            return View(pRICECONDITIONS);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteConditions(string idStr)
        {
            try
            {
                int[] pbsList = Utils.SplitIntVector(idStr);
                if (pbsList != null && pbsList.Length > 0)
                {
                    foreach (int id in pbsList)
                    {
                        var group = await _context.PRICECONDITIONS.FindAsync(id);
                        if (group != null)
                            _context.PRICECONDITIONS.Remove(group);
                    }
                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
            return string.Empty;
        }


        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteCondition(int id)
        {
            try
            {
                var group = await _context.PRICECONDITIONS.FindAsync(id);
                if (group != null)
                {
                    _context.PRICECONDITIONS.Remove(group);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // GET: PRICECONDITIONS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICECONDITIONS = await _context.PRICECONDITIONS
                .Include(p => p.BOOLEANOPERATOR)
                .Include(p => p.COMPARISONTYPE)
                .Include(p => p.PRICECODE)
                .Include(p => p.PRICECONDITIONTYPE)
                .FirstOrDefaultAsync(m => m.CONDITIONID == id);
            if (pRICECONDITIONS == null)
            {
                return NotFound();
            }

            return View(pRICECONDITIONS);
        }

        [HttpPost]
        public async Task<string> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            string lfcr = "\r\n";
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                        return "Project not found";

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var codes = await _context.PRICECODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    List<string> names = new List<string>();
                    if (codes != null)
                        names = codes.Select(c => c.Code).ToList();

                    // Read Data
                    List<string> codeList = new List<string>();
                    List<string> nameList = new List<string>();
                    List<string> conditionTypeList = new List<string>();
                    List<string> comparisonList = new List<string>();
                    List<string> valueList = new List<string>();
                    List<string> booleanList = new List<string>();

                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            string priceCode = worksheet.Cells[counter, 1].Value != null ? worksheet.Cells[counter, 1].Value.ToString() : string.Empty;
                            string name = worksheet.Cells[counter, 2].Value != null ? worksheet.Cells[counter, 2].Value.ToString() : string.Empty;
                            string condition = worksheet.Cells[counter, 3].Value != null ? worksheet.Cells[counter, 3].Value.ToString() : string.Empty;
                            string comparison = worksheet.Cells[counter, 4].Value != null ? worksheet.Cells[counter, 4].Value.ToString() : string.Empty;
                            string value = worksheet.Cells[counter, 5].Value != null ? worksheet.Cells[counter, 5].Value.ToString() : string.Empty;
                            string boolean = worksheet.Cells[counter, 6].Value != null ? worksheet.Cells[counter, 6].Value.ToString() : string.Empty;

                            if (string.IsNullOrEmpty(priceCode) || string.IsNullOrEmpty(name) || string.IsNullOrEmpty(condition))
                                notEmpty = false;
                            else
                            {
                                codeList.Add(priceCode);
                                nameList.Add(name);
                                conditionTypeList.Add(condition);
                                comparisonList.Add(comparison);
                                valueList.Add(value);
                                booleanList.Add(boolean);
                            }
                            counter++;
                        }
                        catch
                        {
                            notEmpty = false;
                        }
                    }

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            PRICECODES pRICECODES = null;
                            for (int i = 0; i < codeList.Count; i++)
                            {
                                if (codes != null)
                                    pRICECODES = codes.Where(g => g.Code == codeList[i]).FirstOrDefault();
                                var conditionType = await _context.PRICECONDITIONTYPES.Where(c => c.Description == conditionTypeList[i]).FirstOrDefaultAsync();
                                var comparisonType = await _context.COMPARISONTYPES.Where(c => c.Description == comparisonList[i]).FirstOrDefaultAsync();
                                var booleanType = await _context.BOOLEANOPERATORS.Where(c => c.Description == booleanList[i]).FirstOrDefaultAsync();
                                if (pRICECODES == null || comparisonType == null || booleanType == null)
                                {
                                    msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, "Row " + (i + 1).ToString()) + lfcr;
                                    continue;
                                }

                                PRICECONDITIONS pRICECONDITIONS = new PRICECONDITIONS();
                                pRICECONDITIONS.PRICECODEID = pRICECODES.PriceCodeID;
                                pRICECONDITIONS.CONDITIONPARAMETER = nameList[i];
                                pRICECONDITIONS.CONDITIONTYPEID = conditionType.ConditionTypeID;
                                pRICECONDITIONS.COMPARISONTYPEID = comparisonType.ComparisonTypeID;
                                pRICECONDITIONS.CONDITIONVALUE = valueList[i];
                                pRICECONDITIONS.BOOLEANOPERATORID = booleanType.OperatorID;

                                _context.PRICECONDITIONS.Add(pRICECONDITIONS);
                                await _context.SaveChangesAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message) + lfcr;
                        }
                    }
                    else
                    {
                        msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED) + lfcr;
                    }
                }
            }
            catch { }

            return string.IsNullOrEmpty(msg) ? "Imported" : msg;
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:PriceConditionTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        // POST: PRICECONDITIONS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            var pRICECONDITIONS = await _context.PRICECONDITIONS.FindAsync(id);
            _context.PRICECONDITIONS.Remove(pRICECONDITIONS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PRICECONDITIONSExists(int? id)
        {
            return _context.PRICECONDITIONS.Any(e => e.CONDITIONID == id);
        }
    }
}
