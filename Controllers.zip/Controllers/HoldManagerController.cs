﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Data;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Logs;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;

namespace CivilMasterData.Controllers
{
    public class HoldManagerController : Controller
    {
        private readonly HoldManagerContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public HoldManagerController(HoldManagerContext context, ISharedResource sharedResource,
            IConfiguration configuration, IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
            _env = env;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            HoldsManager holdsManager = new HoldsManager();
            var holdTypes = await _context.HOLDTYPES.ToListAsync();
            var holdDepts = await _context.HOLDDEPTS.ToListAsync();
            var pbs = await _context.PBS.Where(m => m.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID &&
                !x.IsDeleted && !x.IsReplaced).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            DatabaseCostants.InitValues(_configuration);

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            if (mainItems != null)
            {
                foreach (MAINITEMS mAINITEMS in mainItems)
                {
                    mAINITEMS.PROJECTSETTINGS = projectSettings;
                    mAINITEMS.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == mAINITEMS.MainItemID).FirstOrDefault();
                }
            }

            // Update Main Items
            if (mainItems != null)
            {
                double totalQtyHold = 0.0;
                foreach (MAINITEMS item in mainItems)
                {
                    totalQtyHold = 0.0;
                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;
                    bool openHoldPresent = false;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                                if (hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    openHoldPresent = true;
                            }
                        }
                    }
                    else
                    {
                        item.ValidHoldModelConnectorClosed = false;
                        item.ValidHoldModelConnectorOpen = false;
                    }
                    if (openHoldPresent)
                    {
                        item.ValidHoldModelConnectorClosed = true;
                        item.ValidHoldModelConnectorOpen = item.Qty3dHold != 0.0;
                    }
                    else
                    {
                        item.ValidHoldModelConnectorOpen = true;
                        item.ValidHoldModelConnectorClosed = item.Qty3dHold == 0.0;
                    }

                    item.TotalQtyHold = totalQtyHold;
                }
            }

            holdsManager.MainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);
            holdsManager.Project = project;
            holdsManager.TagTypes = tagTypes;
            holdsManager.HOLDTYPES = holdTypes;
            holdsManager.HOLDDEPTS = holdDepts;
            holdsManager.HOLDS = MainItemUtils.OrderMainitemsHolds(holds, projectSettings.BALANCE);
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            ViewBag.ItemTags = mainItems.Where(m => !m.IsBalance && !m.IsDeleted && !m.IsReplaced).Select(m => m.CompleteDescription).Distinct().ToList();
            ViewBag.TagTypes = tagTypes.Select(m => m.Description).ToList();
            ViewBag.Lots = lots.Select(m => m.NAME).ToList();
            ViewBag.HoldTypes = holdTypes.Select(m => m.Description).ToList();

            return View(holdsManager);
        }

        public async Task<IActionResult> HoldView(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER) && !User.HasClaim(Roles.ROLE, Roles.SPECIALIST))
                return Redirect("~/Home/NoPermission");

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            HoldsManager holdsManager = new HoldsManager();
            var holdTypes = await _context.HOLDTYPES.ToListAsync();
            var holdDepts = await _context.HOLDDEPTS.ToListAsync();
            var pbs = await _context.PBS.Where(m => m.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Include(m => m.LOTS).Where(x => x.PBS.ProjectID == project.ProjectID &&
                !x.IsDeleted && !x.IsReplaced).ToListAsync();
            var holds = await _context.HOLDS.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var tagTypes = await _context.TAGTYPES.Where(t => t.VALIDFORMAINITEMS > 0).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            DatabaseCostants.InitValues(_configuration);

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }
            if (mainItems != null)
            {
                foreach (MAINITEMS mAINITEMS in mainItems)
                {
                    mAINITEMS.PROJECTSETTINGS = projectSettings;
                    mAINITEMS.ITEM_QUANTITY = mainItemsQty.Where(q => q.MainItemId == mAINITEMS.MainItemID).FirstOrDefault();
                }
            }

            // Update Main Items
            if (mainItems != null)
            {
                double totalQtyHold = 0.0;
                foreach (MAINITEMS item in mainItems)
                {
                    totalQtyHold = 0.0;
                    var bimStatus = await _context.BIM360ITEMSTATUS.Where(b => b.ProjectID == project.ProjectID &&
                        b.MainItemTag == item.MainItemTag && item.TAGTYPES.Description ==
                        b.TagType && Utils.EqualString(item.LOTS.NAME, b.Lot)).ToListAsync();
                    item.BIM360ITEMSTATUS = bimStatus;
                    bool openHoldPresent = false;
                    if (holds != null)
                    {
                        var currentHolds = holds.Where(h => h.MainItemId == item.MainItemID).ToList();
                        if (currentHolds != null)
                        {
                            foreach (var hold in currentHolds)
                            {
                                if (hold.QTYHOLD != null && hold.QTYHOLD.HasValue && hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    totalQtyHold += hold.QTYHOLD.Value;
                                if (hold.GetHoldStatus == MainItemsCostants.HOLD_OPEN)
                                    openHoldPresent = true;
                            }
                        }
                    }
                    else
                    {
                        item.ValidHoldModelConnectorClosed = false;
                        item.ValidHoldModelConnectorOpen = false;
                    }
                    if (openHoldPresent)
                    {
                        item.ValidHoldModelConnectorClosed = true;
                        item.ValidHoldModelConnectorOpen = item.Qty3dHold != 0.0;
                    }
                    else
                    {
                        item.ValidHoldModelConnectorOpen = true;
                        item.ValidHoldModelConnectorClosed = item.Qty3dHold == 0.0;
                    }

                    item.TotalQtyHold = totalQtyHold;
                }
            }

            holdsManager.MainItems = MainItemUtils.OrderMainitems(mainItems, projectSettings.BALANCE);
            holdsManager.Project = project;
            holdsManager.TagTypes = tagTypes;
            holdsManager.HOLDTYPES = holdTypes;
            holdsManager.HOLDDEPTS = holdDepts;
            holdsManager.HOLDS = MainItemUtils.OrderMainitemsHolds(holds, projectSettings.BALANCE);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            ViewBag.ItemTags = mainItems.Where(m => !m.IsBalance).Select(m => m.CompleteDescription).Distinct().ToList();
            ViewBag.TagTypes = tagTypes.Select(m => m.Description).ToList();
            ViewBag.Lots = lots.Select(m => m.NAME).ToList();
            ViewBag.HoldTypes = holdTypes.Select(m => m.Description).ToList();

            return View(holdsManager);
        }

        [HttpPost]
        public async Task<string> UpdateHolds(string code,
            string holdIdsstr,
            string qtystr,
            string typesstr,
            string foredatestr,
            string foreactualstr,
            string actualdatestr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();
                    var mainItems = await _context.MAINITEMS.Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                    int[] holdids = Utils.SplitIntVector(holdIdsstr);
                    double[] qty = Utils.SplitVector(qtystr);
                    string[] types = Utils.SplitText(typesstr);
                    DateTime?[] foredate = Utils.SplitDate(foredatestr);
                    DateTime?[] foreactual = Utils.SplitDate(foreactualstr);
                    DateTime?[] actualdate = Utils.SplitDate(actualdatestr);

                    var holdTypes = await _context.HOLDTYPES.ToListAsync();
                    var holdDepts = await _context.HOLDDEPTS.ToListAsync();

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in holdids)
                    {
                        var hold = await _context.HOLDS.Where(h => h.HoldId == id).FirstOrDefaultAsync();
                        if (hold != null)
                        {
                            hold.QTYHOLD = qty[counter];

                            var holdType = holdTypes.Where(d => d.Description == types[counter]).FirstOrDefault();
                            if (holdType != null)
                                hold.HOLDTYPESID = holdType.HoldTypeID;

                            if (foredate[counter] == null)
                                hold.ForeDateInput = null;
                            else
                                hold.ForeDateInput = foredate[counter].Value;
                            if (foreactual[counter] == null)
                                hold.ForeDateRemoval = null;
                            else
                                hold.ForeDateRemoval = foreactual[counter].Value;
                            if (actualdate[counter] == null)
                                hold.ActualDateRemoval = null;
                            else
                                hold.ActualDateRemoval = actualdate[counter].Value;

                            hold.UserID = user.USERID;
                            hold.LastModified = DateTime.UtcNow;

                            changed = true;
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.HOLDS_MAIN_ITEM_NOT_FOUND);
                        }
                        counter++;
                    }
                    if (changed)
                        await _context.SaveChangesAsync();
                    msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        [HttpPost]
        public async Task<string> CreateHolds(string code,
            string mainitemsstr,
            //string tagtypesstr,
            //string lotsstr,
            double holdQty,
            string holdType)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();
                    var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Include(m => m.LOTS).Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    //string[] types = Utils.SplitText(tagtypesstr);
                    //string[] lots = Utils.SplitText(lotsstr);


                    var currentHoldType = await _context.HOLDTYPES.Include(h => h.HOLDDEPTS).Where(h => h.Description == holdType).FirstOrDefaultAsync();
                    if (currentHoldType == null)
                        return "Hold Type not valid";

                    int counter = 0;
                    bool changed = false;


                    int holdIndex = 0;
                    var holdList = await _context.HOLDS.Include(h => h.MAINITEMS).Include(h => h.MAINITEMS.PBS)
                            .Where(h => h.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
                    if (holdList != null && holdList.Count > 0)
                        holdIndex = holdList.Select(h => h.HoldItemIndex).Max();
                    else
                        holdIndex = 0;

                    foreach (string item in mainitems)
                    {
                        var mainitem = mainItems.Where(m => m.CompleteDescription == item).FirstOrDefault();
                        if (mainitem != null)
                        {
                            var holdListByType = await _context.HOLDS.Include(h => h.MAINITEMS).Where(h => h.MAINITEMS.MainItemID == mainitem.MainItemID
                                && h.HOLDTYPESID == currentHoldType.HoldTypeID).ToListAsync();
                            if (holdListByType != null && holdListByType.Count > 0)
                            {
                                holdListByType[0].CreationDate = DateTime.UtcNow;
                                holdListByType[0].UserID = user.USERID;
                                holdListByType[0].LastModified = DateTime.UtcNow;
                                holdListByType[0].QTYHOLD = holdQty;
                            }
                            else
                            {
                                HOLDS newHold = new HOLDS();
                                newHold.CreationDate = DateTime.UtcNow;
                                newHold.UserID = user.USERID;
                                newHold.LastModified = DateTime.UtcNow;
                                newHold.MainItemId = mainitem.MainItemID;
                                newHold.QTYHOLD = holdQty;
                                newHold.HOLDTYPESID = currentHoldType.HoldTypeID;
                                newHold.HoldItemIndex = holdIndex + 1;
                                holdIndex++;

                                _context.HOLDS.Add(newHold);
                            }
                            changed = true;
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.HOLDS_ADDED);
                    }
                    else
                    {
                        msg += _sharedResource.Message(MESSAGE_CODES.HOLDS_INCORRECT_TAG_TYPE);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:HoldTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "HoldList.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:HoldSheetName");
            int startRow = _configuration.GetValue<int>("Excel:HoldListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:HoldListSheetStartColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            var holds = await _context.HOLDS
                .Include(m => m.MAINITEMS)
                .Include(m => m.HOLDTYPES)
                .Include(m => m.MAINITEMS.LOTS)
                .Include(m => m.MAINITEMS.TAGTYPES)
                .Where(m => m.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            if (holds != null)
            {
                int currentRow = startRow;
                holds = holds.OrderBy(h => h.MAINITEMS.MainItemTag).ToList();
                foreach (HOLDS hold in holds)
                {
                    Sheet.Cells[currentRow, startColumn].Value = hold.MAINITEMS.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 1].Value = hold.MAINITEMS.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 2].Value = hold.MAINITEMS.LOTS.NAME;
                    Sheet.Cells[currentRow, startColumn + 3].Value = hold.HoldItemIndex;
                    Sheet.Cells[currentRow, startColumn + 4].Value = hold.QTYHOLD;
                    Sheet.Cells[currentRow, startColumn + 5].Value = hold.HOLDTYPES.Description;
                    if (hold.ForeDateInput != null && hold.ForeDateInput.HasValue)
                        Sheet.Cells[currentRow, startColumn + 6].Value = hold.ForeDateInput.Value;
                    if (hold.ForeDateRemoval != null && hold.ForeDateRemoval.HasValue)
                        Sheet.Cells[currentRow, startColumn + 7].Value = hold.ForeDateRemoval.Value;
                    if (hold.ActualDateRemoval != null && hold.ActualDateRemoval.HasValue)
                        Sheet.Cells[currentRow, startColumn + 8].Value = hold.ActualDateRemoval.Value;

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:HoldViewTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "Holds.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:HoldSheetName");
            int startRow = _configuration.GetValue<int>("Excel:HoldListSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:HoldListSheetStartColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            var holds = await _context.HOLDS
                .Include(m => m.MAINITEMS)
                .Include(m => m.HOLDTYPES)
                .Include(m => m.MAINITEMS.LOTS)
                .Include(m => m.MAINITEMS.PBS)
                .Include(m => m.MAINITEMS.TAGTYPES)
                .Include(m => m.HOLDTYPES.HOLDDEPTS)
                .Where(m => m.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            if (holds != null)
            {
                int currentRow = startRow;
                holds = holds.OrderBy(h => h.MAINITEMS.MainItemTag).ToList();
                foreach (HOLDS hold in holds)
                {
                    var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MainItemId == hold.MainItemId).FirstOrDefaultAsync();
                    hold.MAINITEMS.ITEM_QUANTITY = mainItemsQty;

                    Sheet.Cells[currentRow, startColumn].Value = hold.MAINITEMS.PBS.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = hold.MAINITEMS.PBS.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = hold.MAINITEMS.MainItemTag;
                    Sheet.Cells[currentRow, startColumn + 3].Value = hold.MAINITEMS.TagClient;
                    Sheet.Cells[currentRow, startColumn + 4].Value = hold.MAINITEMS.TagDescription;
                    Sheet.Cells[currentRow, startColumn + 5].Value = hold.MAINITEMS.TAGTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 6].Value = hold.MAINITEMS.LOTS != null ? hold.MAINITEMS.LOTS.NAME : string.Empty;
                    Sheet.Cells[currentRow, startColumn + 7].Value = hold.MAINITEMS.GetEngStatus;
                    Sheet.Cells[currentRow, startColumn + 8].Value = hold.MAINITEMS.DrawNo;
                    Sheet.Cells[currentRow, startColumn + 9].Value = hold.MAINITEMS.DRAWREV;
                    Sheet.Cells[currentRow, startColumn + 10].Value = hold.MAINITEMS.QtyUnits;
                    Sheet.Cells[currentRow, startColumn + 11].Value = hold.MAINITEMS.ITEM_QUANTITY.QTY_LAST_ISSUE;

                    Sheet.Cells[currentRow, startColumn + 12].Value = hold.MAINITEMS.Qty3dHold;
                    Sheet.Cells[currentRow, startColumn + 13].Value = hold.HoldItemIndex;
                    Sheet.Cells[currentRow, startColumn + 14].Value = hold.QTYHOLD;
                    Sheet.Cells[currentRow, startColumn + 15].Value = string.Empty;
                    Sheet.Cells[currentRow, startColumn + 16].Value = hold.HOLDTYPES.Description;
                    Sheet.Cells[currentRow, startColumn + 17].Value = hold.HOLDTYPES.HOLDDEPTS.Description;
                    if (hold.ForeDateInput != null && hold.ForeDateInput.HasValue)
                        Sheet.Cells[currentRow, startColumn + 18].Value = hold.ForeDateInput.Value;
                    if (hold.ForeDateRemoval != null && hold.ForeDateRemoval.HasValue)
                        Sheet.Cells[currentRow, startColumn + 19].Value = hold.ForeDateRemoval.Value;
                    if (hold.ActualDateRemoval != null && hold.ActualDateRemoval.HasValue)
                        Sheet.Cells[currentRow, startColumn + 20].Value = hold.ActualDateRemoval.Value;

                    Sheet.Cells[currentRow, startColumn + 21].Value = hold.MAINITEMS.GetHoldStatus;
                    Sheet.Cells[currentRow, startColumn + 22].Value = hold.MAINITEMS.ModelName;
                    Sheet.Cells[currentRow, startColumn + 23].Value = hold.DateLastModify;
                    Sheet.Cells[currentRow, startColumn + 24].Value = hold.LastModifyUser;

                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:HoldTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var holdTypes = await _context.HOLDTYPES.Include(h => h.HOLDDEPTS).ToListAsync();

                    // Read Data
                    List<string> itemTagList = new List<string>();
                    List<string> tagTypesList = new List<string>();
                    List<string> lotList = new List<string>();
                    List<string> holdDescr = new List<string>();
                    List<int?> holdIdList = new List<int?>();
                    List<double?> qtyHoldList = new List<double?>();
                    List<DateTime?> date1List = new List<DateTime?>();
                    List<DateTime?> date2List = new List<DateTime?>();
                    List<DateTime?> date3List = new List<DateTime?>();

                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, 1];
                            string itemtag = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 2];
                            string tagtype = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 3];
                            string lot = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            cell = worksheet.Cells[counter, 4];
                            int? currentId = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                currentId = Convert.ToInt32((double)cell.Value);

                            cell = worksheet.Cells[counter, 5];
                            double? qty = null;
                            if (cell != null && cell.Value != null && cell.Value is double)
                                qty = (double)cell.Value;

                            cell = worksheet.Cells[counter, 6];
                            string descr = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            var holdTypeCurrent = holdTypes.Where(h => h.Description == descr).FirstOrDefault();
                            bool validHoldType = holdTypeCurrent != null;

                            cell = worksheet.Cells[counter, 7];
                            DateTime? date1 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date1 = tempdt;
                            }

                            cell = worksheet.Cells[counter, 8];
                            DateTime? date2 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date2 = tempdt;
                            }

                            cell = worksheet.Cells[counter, 9];
                            DateTime? date3 = null;
                            if (cell != null && !string.IsNullOrEmpty(cell.Text))
                            {
                                DateTime tempdt;
                                if (DateTime.TryParse(cell.Text, out tempdt))
                                    date3 = tempdt;
                            }


                            if (string.IsNullOrEmpty(itemtag) && string.IsNullOrEmpty(tagtype) && string.IsNullOrEmpty(lot))
                                notEmpty = false;
                            else
                            {
                                if (string.IsNullOrEmpty(itemtag))
                                    excelLogManager.AddLog(counter, 1, "Empty main item tag");
                                else if (string.IsNullOrEmpty(tagtype))
                                    excelLogManager.AddLog(counter, 2, "Empty tag type");
                                else if (string.IsNullOrEmpty(lot))
                                    excelLogManager.AddLog(counter, 3, "Empty lot");
                                else if (currentId == null || !currentId.HasValue)
                                    excelLogManager.AddLog(counter, 7, "Empty holdId");
                                else if (!validHoldType)
                                    excelLogManager.AddLog(counter, 5, "Invalid Hold Type");
                                else
                                {
                                    itemTagList.Add(itemtag);
                                    tagTypesList.Add(tagtype);
                                    lotList.Add(lot);
                                    holdIdList.Add(currentId);
                                    holdDescr.Add(descr);
                                    qtyHoldList.Add(qty);
                                    date1List.Add(date1);
                                    date2List.Add(date2);
                                    date3List.Add(date3);
                                }
                            }
                            counter++;
                        }
                        catch
                        {
                            notEmpty = false;
                        }
                    }

                    // Configuration
                    string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                            {
                                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                                return excelLogManager;
                            }

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;
                            ViewBag.ProjectDescription = project.GetCompleteDescription;

                            var tagtypesdb = await _context.TAGTYPES.ToListAsync();
                            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                            List<int> idHolds = new List<int>();
                            for (int i = 0; i < itemTagList.Count; i++)
                            {
                                string itemTag = itemTagList[i];
                                string tagType = tagTypesList[i];
                                string lot = lotList[i];
                                int holdItemID = holdIdList[i].Value;

                                var mainItem = await _context.MAINITEMS.Include(m => m.LOTS).Where(m => m.MainItemTag == itemTag &&
                                    m.TAGTYPES.Description == tagType && m.LOTS.NAME == lot && m.PBS.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                                if (mainItem != null)
                                {
                                    if (mainItem.IsDeleted)
                                    {
                                        excelLogManager.AddLog(i, 1, "Main Item deleted " + mainItem.MainItemTag + "-" + mainItem.TAGTYPES.Description + "-" + mainItem.LOTS.NAME);
                                        continue;
                                    }
                                    if (mainItem.IsReplaced)
                                    {
                                        excelLogManager.AddLog(i, 1, "Main Item replaced " + mainItem.MainItemTag + "-" + mainItem.TAGTYPES.Description + "-" + mainItem.LOTS.NAME);
                                        continue;
                                    }
                                    HOLDS currentHold = await _context.HOLDS.Where(h => h.MainItemId == mainItem.MainItemID &&
                                        h.HoldItemIndex == holdItemID).FirstOrDefaultAsync();
                                    if (currentHold == null)
                                    {
                                        currentHold = new HOLDS();
                                        currentHold.CreationDate = DateTime.UtcNow;
                                        currentHold.LastModified = DateTime.UtcNow;
                                        currentHold.MainItemId = mainItem.MainItemID;
                                        currentHold.UserID = user.USERID;
                                        currentHold.HoldItemIndex = holdItemID;
                                        currentHold.QTYHOLD = qtyHoldList[i];
                                        currentHold.ForeDateInput = date1List[i];
                                        currentHold.ForeDateRemoval = date2List[i];
                                        currentHold.ActualDateRemoval = date3List[i];

                                        var holdTypeCurrent = holdTypes.Where(h => h.Description == holdDescr[i]).FirstOrDefault();
                                        if (holdTypeCurrent != null)
                                            currentHold.HOLDTYPESID = holdTypeCurrent.HoldTypeID;
                                        else
                                        {
                                            excelLogManager.AddLog(i, 5, "Hold Type not found");
                                        }
                                        _context.HOLDS.Add(currentHold);
                                    }

                                    if (currentHold != null)
                                    {
                                        if (idHolds.Contains(currentHold.HoldId))
                                        {
                                            excelLogManager.AddLog(i, 1, "Multiple Hold - Please Check Hold ID" + mainItem.MainItemTag + "-" + mainItem.TAGTYPES.Description + "-" + mainItem.LOTS.NAME);
                                            continue;
                                        }

                                        if (!idHolds.Contains(currentHold.HoldId))
                                            idHolds.Add(currentHold.HoldId);

                                        currentHold.QTYHOLD = qtyHoldList[i];
                                        currentHold.ForeDateInput = date1List[i];
                                        currentHold.ForeDateRemoval = date2List[i];
                                        currentHold.ActualDateRemoval = date3List[i];

                                        var holdTypeCurrent = holdTypes.Where(h => h.Description == holdDescr[i]).FirstOrDefault();
                                        if (holdTypeCurrent != null)
                                            currentHold.HOLDTYPESID = holdTypeCurrent.HoldTypeID;
                                        else
                                        {
                                            excelLogManager.AddLog(i, 5, "Hold Type not found");
                                        }
                                        idHolds.Add(currentHold.HoldId);
                                    }
                                }
                                else
                                {
                                    excelLogManager.AddLog(i, 0, "Main item not found");
                                }
                            }
                            await _context.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR) + " " + ex.Message);
                        }
                    }
                    else
                    {
                        excelLogManager.AddLog(-1, -1, _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED));
                    }
                }
            }
            catch { }

            excelLogManager.Result = "Completed";
            return excelLogManager;
        }

        [HttpPost]
        public async Task<string> DeleteHold(int id)
        {
            try
            {
                var hold = await _context.HOLDS.FindAsync(id);
                if (hold != null)
                {
                    _context.HOLDS.Remove(hold);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }
    }
}
