﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;

namespace CivilMasterData
{
    public class MATERIALREQUESTSController : Controller
    {
        private readonly MATERIALREQUESTSContext _context;
        protected readonly ISharedResource _sharedResource;

        public MATERIALREQUESTSController(MATERIALREQUESTSContext context, ISharedResource sharedResource)
        {
            _context = context;
            this._sharedResource = sharedResource;
        }

        // GET: MATERIALREQUESTS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var mATERIALREQUESTSContext = _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID).Include(m => m.Project).Include(m => m.USERS);
            return View(await mATERIALREQUESTSContext.ToListAsync());
        }

        // GET: MATERIALREQUESTS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mATERIALREQUESTS = await _context.MATERIALREQUESTS
                .Include(m => m.Project)
                .Include(m => m.USERS)
                .FirstOrDefaultAsync(m => m.IDMR == id);
            if (mATERIALREQUESTS == null)
            {
                return NotFound();
            }

            return View(mATERIALREQUESTS);
        }

        // GET: MATERIALREQUESTS/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View();
        }

        // POST: MATERIALREQUESTS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IDMR,NAME,NOTES,ProjectID,UserID,CreationDate,LastModified")] MATERIALREQUESTS mATERIALREQUESTS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (string.IsNullOrEmpty(mATERIALREQUESTS.NAME))
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                }
                else
                {
                    if (ModelState.IsValid && user != null)
                    {
                        var vendor = await _context.MATERIALREQUESTS.FirstOrDefaultAsync(m => m.ProjectID == mATERIALREQUESTS.ProjectID && m.NAME.ToUpper() == mATERIALREQUESTS.NAME.ToUpper());

                        if (vendor == null)
                        {
                            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == mATERIALREQUESTS.ProjectID);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            try
                            {
                                mATERIALREQUESTS.UserID = user.USERID;
                                mATERIALREQUESTS.CreationDate = DateTime.UtcNow;
                                mATERIALREQUESTS.LastModified = DateTime.UtcNow;
                                mATERIALREQUESTS.IsVisible = true;
                                _context.MATERIALREQUESTS.Add(mATERIALREQUESTS);
                                await _context.SaveChangesAsync();

                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.MR_CREATED);
                            }
                            catch (Exception ex)
                            {
                                ViewBag.Message = ex.Message;
                            }
                        }
                        else
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.MR_EXISTING);
                        }
                    }
                    else
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.MR_NOT_CREATED);
                    }
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return View(mATERIALREQUESTS);
        }

        // GET: MATERIALREQUESTS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mATERIALREQUESTS = await _context.MATERIALREQUESTS.FindAsync(id);
            if (mATERIALREQUESTS == null)
            {
                return NotFound();
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == mATERIALREQUESTS.ProjectID);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            return View(mATERIALREQUESTS);
        }

        // POST: MATERIALREQUESTS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IDMR,NAME,NOTES,ProjectID,UserID,CreationDate,LastModified")] MATERIALREQUESTS mATERIALREQUESTS)
        {
            if (id != mATERIALREQUESTS.IDMR)
            {
                return NotFound();
            }
            
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null)
                {
                    try
                    {
                        // Set user and creation date
                        mATERIALREQUESTS.UserID = user.USERID;
                        mATERIALREQUESTS.LastModified = DateTime.UtcNow;
                        mATERIALREQUESTS.IsVisible = true;

                        _context.Update(mATERIALREQUESTS);
                        await _context.SaveChangesAsync();

                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.MR_UPDATED);
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.MR_NOT_UPDATED, ex.Message);
                    }
                }
                else
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            var project = await _context.PROJECTS.Where(p => p.ProjectID == mATERIALREQUESTS.ProjectID).FirstOrDefaultAsync();
            ViewData["Project"] = project.Code;
            ViewData["ProjectID"] = mATERIALREQUESTS.ProjectID;
            return View(mATERIALREQUESTS);
        }

        // GET: MATERIALREQUESTS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mATERIALREQUESTS = await _context.MATERIALREQUESTS
                .Include(m => m.Project)
                .Include(m => m.USERS)
                .FirstOrDefaultAsync(m => m.IDMR == id);
            if (mATERIALREQUESTS == null)
            {
                return NotFound();
            }

            return View(mATERIALREQUESTS);
        }

        // POST: MATERIALREQUESTS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var mATERIALREQUESTS = await _context.MATERIALREQUESTS.FindAsync(id);
            _context.MATERIALREQUESTS.Remove(mATERIALREQUESTS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MATERIALREQUESTSExists(int id)
        {
            return _context.MATERIALREQUESTS.Any(e => e.IDMR == id);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteMR(int id)
        {
            try
            {
                var vendor = await _context.MATERIALREQUESTS.FindAsync(id);
                if (vendor != null)
                {
                    _context.MATERIALREQUESTS.Remove(vendor);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.MR_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }
    }
}
