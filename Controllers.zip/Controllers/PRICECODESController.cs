﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models.PriceList;
using CivilMasterData.Models;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using OfficeOpenXml;
using CivilMasterData.Models.Costants;

namespace CivilMasterData
{
    public class PRICECODESController : Controller
    {
        private readonly PRICECODESContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PRICECODESController(PRICECODESContext context,
            IConfiguration configuration, ISharedResource sharedResource, IWebHostEnvironment env)
        {
            _context = context;
            _configuration = configuration;
            this._sharedResource = sharedResource;
            _env = env;
        }

        // GET: PRICECODES
        public async Task<IActionResult> Index(string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return NotFound();
                    if (user.IsDisabled)
                        return Redirect("~/Home/NoPermission");

                    if (String.IsNullOrEmpty(code))
                        return NotFound();
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return NotFound();
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;


                    var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).Include(p => p.Project).ToListAsync();
                    var priceCodes = await _context.PRICECODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();

                    return View(priceCodes);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return NotFound();
        }

        // GET: PRICECODES/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICECODES = await _context.PRICECODES
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.PriceCodeID == id);
            if (pRICECODES == null)
            {
                return NotFound();
            }

            return View(pRICECODES);
        }

        // GET: PRICECODES/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var groups = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();

            ViewData["PriceGroups"] = groups.Select(p => p.GroupCode);
            return View();
        }

        // POST: PRICECODES/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PriceCodeID,ProjectID,PriceCodeDefinitionID,Code,PriceDescription,Unit")] PRICECODES pRICECODES, string groupCode)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICECODES.ProjectID);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    var groups = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    ViewData["PriceGroups"] = new SelectList(groups.Select(p => p.GroupCode));
                    PRICECODEDEFINITIONS group = null;

                    if (String.IsNullOrEmpty(pRICECODES.Code) || string.IsNullOrEmpty(pRICECODES.Unit) || string.IsNullOrEmpty(groupCode))
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CODE_NOT_VALID);
                    }
                    else
                    {
                        if (groups != null)
                            group = groups.Where(g => g.GroupCode.ToUpperInvariant() == groupCode.ToUpperInvariant()).FirstOrDefault();
                        if (group == null)
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_GROUP_NOT_VALID);
                        }
                        else
                        {

                            var pricecode = await _context.PRICECODES.Where(p => p.ProjectID == pRICECODES.ProjectID &&
                                p.Code.ToUpperInvariant() == pRICECODES.Code.ToUpperInvariant()).FirstOrDefaultAsync();
                            if (pricecode == null)
                            {
                                pRICECODES.PriceCodeDefinitionID = group.PriceCodeDefinitionID.Value;
                                _context.Add(pRICECODES);
                                await _context.SaveChangesAsync();
                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CODE_CREATED);
                            }
                            else
                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CODE_EXISTING);
                        }
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PRICE_CODE_NOT_VALID);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pRICECODES);
        }

        // GET: PRICECODES/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICECODES = await _context.PRICECODES.FindAsync(id);
            if (pRICECODES == null)
            {
                return NotFound();
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICECODES.ProjectID);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(pRICECODES);
        }

        // POST: PRICECODES/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PriceCodeID,ProjectID,PriceCodeDefinitionID,Code,PriceDescription,Unit")] PRICECODES pRICECODES)
        {
            if (id != pRICECODES.PriceCodeID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pRICECODES);
                    await _context.SaveChangesAsync();
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PRICECODESExists(pRICECODES.PriceCodeID.Value))
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED);
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICECODES.ProjectID);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(pRICECODES);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteMultipleCodes(string idStr)
        {
            try
            {
                int[] pbsList = Utils.SplitIntVector(idStr);
                if (pbsList != null && pbsList.Length > 0)
                {
                    foreach (int id in pbsList)
                    {
                        var group = await _context.PRICECODES.FindAsync(id);
                        if (group != null)
                            _context.PRICECODES.Remove(group);
                    }
                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
            return string.Empty;
        }


        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteCode(int id)
        {
            try
            {
                var group = await _context.PRICECODES.FindAsync(id);
                if (group != null)
                {
                    _context.PRICECODES.Remove(group);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // GET: PRICECODES/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICECODES = await _context.PRICECODES
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.PriceCodeID == id);
            if (pRICECODES == null)
            {
                return NotFound();
            }

            return View(pRICECODES);
        }

        // POST: PRICECODES/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pRICECODES = await _context.PRICECODES.FindAsync(id);
            _context.PRICECODES.Remove(pRICECODES);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<string> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            string lfcr = "\r\n";
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                        return "Project not found";

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var groups = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    List<string> groupNames = new List<string>();
                    if (groups != null)
                        groupNames = groups.Select(c => c.GroupCode).ToList();
                    var codes = await _context.PRICECODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    List<string> names = new List<string>();
                    if (codes != null)
                        names = codes.Select(c => c.Code.ToUpperInvariant()).ToList();

                    // Read Data
                    List<string> groupList = new List<string>();
                    List<string> codeList = new List<string>();
                    List<string> descriptionList = new List<string>();
                    List<string> units = new List<string>();
                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            string groupCode = worksheet.Cells[counter, 1].Value != null ? worksheet.Cells[counter, 1].Value.ToString() : string.Empty;
                            string codeDef = worksheet.Cells[counter, 2].Value != null ? worksheet.Cells[counter, 2].Value.ToString() : string.Empty;
                            string description = worksheet.Cells[counter, 3].Value != null ? worksheet.Cells[counter, 3].Value.ToString() : string.Empty;
                            string unit = worksheet.Cells[counter, 4].Value != null ? worksheet.Cells[counter, 4].Value.ToString() : string.Empty;

                            if (string.IsNullOrEmpty(groupCode) || string.IsNullOrEmpty(codeDef) || string.IsNullOrEmpty(unit))
                                notEmpty = false;
                            else
                            {
                                groupList.Add(groupCode);
                                codeList.Add(codeDef);
                                descriptionList.Add(description);
                                units.Add(unit);
                            }
                            counter++;
                        }
                        catch
                        {
                            notEmpty = false;
                        }
                    }

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            PRICECODEDEFINITIONS pRICECODEDEFINITIONS = null;
                            for (int i = 0; i < groupList.Count; i++)
                            {
                                if (groups != null)
                                    pRICECODEDEFINITIONS = groups.Where(g => g.GroupCode == groupList[i]).FirstOrDefault();
                                if (pRICECODEDEFINITIONS == null || names.Contains(codeList[i].ToUpperInvariant()))
                                {
                                    msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, groupList[i]) + lfcr;
                                    continue;
                                }
                                PRICECODES pRICECODES = new PRICECODES();
                                pRICECODES.ProjectID = project.ProjectID;
                                pRICECODES.Code = codeList[i];
                                pRICECODES.PriceDescription = descriptionList[i];
                                pRICECODES.PriceCodeDefinitionID = pRICECODEDEFINITIONS.PriceCodeDefinitionID.Value;
                                pRICECODES.Unit = units[i];
                                _context.PRICECODES.Add(pRICECODES);
                                await _context.SaveChangesAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message) + lfcr;
                        }
                    }
                    else
                    {
                        msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED) + lfcr;
                    }
                }
            }
            catch { }

            return string.IsNullOrEmpty(msg) ? "Imported" : msg;
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:PriceCodeTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        private bool PRICECODESExists(int id)
        {
            return _context.PRICECODES.Any(e => e.PriceCodeID == id);
        }
    }
}
