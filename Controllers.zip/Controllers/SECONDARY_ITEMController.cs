﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;

namespace CivilMasterData
{
    public class SECONDARY_ITEMController : Controller
    {
        private readonly SECONDARY_ITEMContext _context;

        public SECONDARY_ITEMController(SECONDARY_ITEMContext context)
        {
            _context = context;
        }

        // GET: SECONDARY_ITEM
        public async Task<IActionResult> Index()
        {
            return View(await _context.SECONDARY_ITEM.ToListAsync());
        }

        // GET: SECONDARY_ITEM/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sECONDARY_ITEM = await _context.SECONDARY_ITEM
                .FirstOrDefaultAsync(m => m.Sec_Item_Id == id);
            if (sECONDARY_ITEM == null)
            {
                return NotFound();
            }

            return View(sECONDARY_ITEM);
        }

        // GET: SECONDARY_ITEM/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SECONDARY_ITEM/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Sec_Item_Id,MainItemTag,ItemTag,TagTypeId,LV01_Object_Code,LV01_Sequence_Number,LV01_Material_Work_Group,Object_Code_Description,LV02_Object_Code,LV02_Sequence_Number,LV02_Material_Work_Group")] SECONDARY_ITEM sECONDARY_ITEM)
        {
            if (ModelState.IsValid)
            {
                _context.Add(sECONDARY_ITEM);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(sECONDARY_ITEM);
        }

        // GET: SECONDARY_ITEM/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sECONDARY_ITEM = await _context.SECONDARY_ITEM.FindAsync(id);
            if (sECONDARY_ITEM == null)
            {
                return NotFound();
            }
            return View(sECONDARY_ITEM);
        }

        // POST: SECONDARY_ITEM/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Sec_Item_Id,MainItemTag,ItemTag,TagTypeId,LV01_Object_Code,LV01_Sequence_Number,LV01_Material_Work_Group,Object_Code_Description,LV02_Object_Code,LV02_Sequence_Number,LV02_Material_Work_Group")] SECONDARY_ITEM sECONDARY_ITEM)
        {
            if (id != sECONDARY_ITEM.Sec_Item_Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(sECONDARY_ITEM);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SECONDARY_ITEMExists(sECONDARY_ITEM.Sec_Item_Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(sECONDARY_ITEM);
        }

        // GET: SECONDARY_ITEM/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sECONDARY_ITEM = await _context.SECONDARY_ITEM
                .FirstOrDefaultAsync(m => m.Sec_Item_Id == id);
            if (sECONDARY_ITEM == null)
            {
                return NotFound();
            }

            return View(sECONDARY_ITEM);
        }

        // POST: SECONDARY_ITEM/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var sECONDARY_ITEM = await _context.SECONDARY_ITEM.FindAsync(id);
            _context.SECONDARY_ITEM.Remove(sECONDARY_ITEM);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SECONDARY_ITEMExists(int id)
        {
            return _context.SECONDARY_ITEM.Any(e => e.Sec_Item_Id == id);
        }
    }
}
