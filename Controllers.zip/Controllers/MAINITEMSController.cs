﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using System.Linq;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Costants;
using System.Collections.Generic;
using CivilMasterData.Models.BIM360;
using CivilMasterData.Models.Logs;

namespace CivilMasterData.Controllers
{
    [UnAuthorized]
    public class MAINITEMSController : Controller
    {
        private readonly MAINITEMSContext _context;
        protected readonly ISharedResource _sharedResource;

        public MAINITEMSController(MAINITEMSContext context, ISharedResource sharedResource)
        {
            _context = context;
            this._sharedResource = sharedResource;
        }

        // GET: MAINITEMS
        public async Task<IActionResult> Index(string code)
        {
            if (!string.IsNullOrEmpty(code))
            {
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                if (project == null)
                    return NotFound();

                var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                if (projectSettings == null)
                {
                    projectSettings = await _context.PROJECTSETTINGS
                    .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                }

                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
                if (user == null)
                    return Redirect("~/Home/NoPermission");
                if (user.IsDisabled)
                    return Redirect("~/Home/NoPermission");

                if (user.ACCESS_LEVEL != Roles.ADMIN)
                {
                    var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    if (userProject == null)
                        return Redirect("~/Home/NoPermission");
                }

                var items = await _context.MAINITEMS.Where(i => i.PBS.Project.Code == code).ToListAsync();
                items = MainItemUtils.OrderMainitems(items, projectSettings.BALANCE);
                ViewBag.Project = code;
                return View(items);
            }
            else
            {
                return View(NotFound());
            }
        }

        // GET: MAINITEMS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMS = await _context.MAINITEMS
                .Include(m => m.LV01_Material_Work_Group)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.PBS)
                .Include(m => m.TAGTYPES)
                .FirstOrDefaultAsync(m => m.MainItemID == id);
            if (mAINITEMS == null)
            {
                return NotFound();
            }

            return View(mAINITEMS);
        }

        // GET: MAINITEMS/Create
        public IActionResult Create()
        {
            ViewData["LV01_Material_Work_GroupID"] = new SelectList(_context.Set<MATERIALWORKGROUPS>(), "GroupID", "GroupID");
            ViewData["LV01_Object_CodeID"] = new SelectList(_context.Set<OBJECTCODES>(), "CodeID", "CodeID");
            ViewData["PBSID"] = new SelectList(_context.Set<PBS>(), "PBSID", "PBSID");
            ViewData["TagTypeID"] = new SelectList(_context.Set<TAGTYPES>(), "TagTypeID", "TagTypeID");
            return View();
        }

        // POST: MAINITEMS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MainItemID,PBSID,LV01_Object_CodeID,LV01_Material_Work_GroupID,TagTypeID,MainItemTag,WP")] MAINITEMS mAINITEMS)
        {
            if (ModelState.IsValid)
            {
                mAINITEMS.AddedManually = 0;
                _context.Add(mAINITEMS);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["LV01_Material_Work_GroupID"] = new SelectList(_context.Set<MATERIALWORKGROUPS>(), "GroupID", "GroupID", mAINITEMS.LV01_Material_Work_GroupID);
            ViewData["LV01_Object_CodeID"] = new SelectList(_context.Set<OBJECTCODES>(), "CodeID", "CodeID", mAINITEMS.LV01_Object_CodeID);
            ViewData["PBSID"] = new SelectList(_context.Set<PBS>(), "PBSID", "PBSID", mAINITEMS.PBSID);
            ViewData["TagTypeID"] = new SelectList(_context.Set<TAGTYPES>(), "TagTypeID", "TagTypeID", mAINITEMS.TagTypeID);
            return View(mAINITEMS);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateManual([Bind("MainItemID,PBSID,TagTypeID,TCMTag,WP,TagDescription,TagClient")] MAINITEMS mAINITEMS)
        {
            if (ModelState.IsValid)
            {
                mAINITEMS.AddedManually = 1;
                _context.Add(mAINITEMS);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PBSID"] = new SelectList(_context.Set<PBS>(), "PBSID", "PBSID", mAINITEMS.PBSID);
            ViewData["TagTypeID"] = new SelectList(_context.Set<TAGTYPES>(), "TagTypeID", "TagTypeID", mAINITEMS.TagTypeID);
            return View(mAINITEMS);
        }

        // GET: MAINITEMS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMS = await _context.MAINITEMS.FindAsync(id);
            if (mAINITEMS == null)
            {
                return NotFound();
            }
            ViewData["LV01_Material_Work_GroupID"] = new SelectList(_context.Set<MATERIALWORKGROUPS>(), "GroupID", "GroupID", mAINITEMS.LV01_Material_Work_GroupID);
            ViewData["LV01_Object_CodeID"] = new SelectList(_context.Set<OBJECTCODES>(), "CodeID", "CodeID", mAINITEMS.LV01_Object_CodeID);
            ViewData["PBSID"] = new SelectList(_context.Set<PBS>(), "PBSID", "PBSID", mAINITEMS.PBSID);
            ViewData["TagTypeID"] = new SelectList(_context.Set<TAGTYPES>(), "TagTypeID", "TagTypeID", mAINITEMS.TagTypeID);
            return View(mAINITEMS);
        }

        // POST: MAINITEMS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MainItemID,PBSID,LV01_Object_CodeID,LV01_Material_Work_GroupID,TagTypeID,MainItemTag,WP")] MAINITEMS mAINITEMS)
        {
            if (id != mAINITEMS.MainItemID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(mAINITEMS);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MAINITEMSExists(mAINITEMS.MainItemID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["LV01_Material_Work_GroupID"] = new SelectList(_context.Set<MATERIALWORKGROUPS>(), "GroupID", "GroupID", mAINITEMS.LV01_Material_Work_GroupID);
            ViewData["LV01_Object_CodeID"] = new SelectList(_context.Set<OBJECTCODES>(), "CodeID", "CodeID", mAINITEMS.LV01_Object_CodeID);
            ViewData["PBSID"] = new SelectList(_context.Set<PBS>(), "PBSID", "PBSID", mAINITEMS.PBSID);
            ViewData["TagTypeID"] = new SelectList(_context.Set<TAGTYPES>(), "TagTypeID", "TagTypeID", mAINITEMS.TagTypeID);
            return View(mAINITEMS);
        }

        // GET: MAINITEMS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMS = await _context.MAINITEMS
                .Include(m => m.LV01_Material_Work_Group)
                .Include(m => m.LV01_Object_Code)
                .Include(m => m.PBS)
                .Include(m => m.TAGTYPES)
                .FirstOrDefaultAsync(m => m.MainItemID == id);
            if (mAINITEMS == null)
            {
                return NotFound();
            }

            return View(mAINITEMS);
        }

        // POST: MAINITEMS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var mAINITEMS = await _context.MAINITEMS.FindAsync(id);
            _context.MAINITEMS.Remove(mAINITEMS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<string> DeleteItem(int id)
        {
            try
            {
                var mainItems = await _context.MAINITEMS.Include(m => m.PBS).FirstOrDefaultAsync(m => m.MainItemID == id);
                if (mainItems != null)
                {
                    _context.MAINITEMS.Remove(mainItems);

                    var currentDrawings = await _context.DRAWINGS.Where(h => h.ProjectID == mainItems.PBS.ProjectID && h.MainItemTag == mainItems.MainItemTag).ToListAsync();
                    if (currentDrawings != null && currentDrawings.Count > 0)
                        _context.DRAWINGS.RemoveRange(currentDrawings);

                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_DELETED);
                }
                else
                {
                    return _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_NOT_FOUND);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        [HttpPost]
        public async Task<ExcelLogManager> DeleteMultipleItems(string idStr)
        {
            ExcelLogManager excelLogManager = new ExcelLogManager();

            try
            {
                bool deleted = false;
                int[] ids = Utils.SplitIntVector(idStr);
                List<DRAWINGS> drawings = new List<DRAWINGS>();

                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (user == null)
                {
                    excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                    return excelLogManager;
                }
                bool notDeleted = false;
                if (ids != null && ids.Length > 0)
                {
                    foreach (int id in ids)
                    {
                        var mainItems = await _context.MAINITEMS
                            .Include(m => m.PBS)
                            .Include(m => m.TAGTYPES)
                            .Include(m => m.LOTS)
                            .FirstOrDefaultAsync(m => m.MainItemID == id);
                        if (mainItems != null)
                        {
                            if (mainItems.IsReplaced)
                            {
                                excelLogManager.AddLog(0, 0, "Main item replaced not deleted - " + mainItems.MainItemTag + "-" +
                                    mainItems.TAGTYPES.Description + "-" + mainItems.LOTS.NAME);
                                continue;
                            }
                            var projectSettins = await _context.PROJECTSETTINGS.Where(s => s.ProjectID == mainItems.PBS.ProjectID).FirstOrDefaultAsync();

                            if (projectSettins != null)
                            {
                                mainItems.MAINITEMSTATUSID = MainItemsCostants.DELETED;
                                deleted = true;

                                excelLogManager.AddLog(0, 0, "Main item deleted - " + mainItems.MainItemTag + "-" +
                                    mainItems.TAGTYPES.Description + "-" + mainItems.LOTS.NAME);

                                // Add to deleted items of BIM360
                                var missingItem = await _context.ITEMSLISTCHECKS.Where(m => m.MainItemID == mainItems.MainItemID).FirstOrDefaultAsync();
                                if (missingItem != null)
                                {
                                    _context.ITEMSLISTCHECKS.Remove(missingItem);
                                    await _context.SaveChangesAsync();
                                }

                                // Add to deleted items of BIM360
                                if ((mainItems.AddedFromBIM360 != null && mainItems.AddedFromBIM360.HasValue && mainItems.AddedFromBIM360.Value > 0) ||
                                    !string.IsNullOrEmpty(mainItems.ModelName))
                                {
                                    DELETEDITEMSLISTCHECKS item = new DELETEDITEMSLISTCHECKS();
                                    item.CreationDate = DateTime.UtcNow;
                                    item.LastModified = DateTime.UtcNow;
                                    item.UserID = user.USERID;
                                    item.MainItemTag = mainItems.MainItemTag;
                                    if (mainItems.IsDeleted)
                                        item.Status = "Deleted";
                                    else
                                        item.Status = "Replaced";
                                    item.Lot = mainItems.LOTS.NAME;
                                    item.TagType = mainItems.TAGTYPES.Description;
                                    item.ModelName = mainItems.ModelName;
                                    item.ProjectID = mainItems.PBS.ProjectID;
                                    _context.DELETEDITEMSLISTCHECKS.Add(item);
                                }

                                string balanceTag = projectSettins.GetBalanceMainItemTag(mainItems.PBS.Area);

                                // Update quantities
                                var balance = await _context.MAINITEMS
                                    .Include(m => m.PBS)
                                    .Include(m => m.LOTS).Where(m => m.PBS.ProjectID == mainItems.PBS.ProjectID
                                    && m.TagTypeID == mainItems.TagTypeID && m.IsBalance &&
                                    m.LOTS.NAME == mainItems.LOTS.NAME &&
                                    m.MainItemTag == balanceTag).FirstOrDefaultAsync();
                                if (balance != null)
                                {
                                    // Update next CE
                                    var ceBalance = await _context.MAIN_ITEM_QUANTITY.Where(q => q.MainItemId == balance.MainItemID).FirstOrDefaultAsync();
                                    var ceMainItem = await _context.MAIN_ITEM_QUANTITY.Where(q => q.MainItemId == mainItems.MainItemID).FirstOrDefaultAsync();
                                    if (ceMainItem.QTY_NEXT_CE != null && ceMainItem.QTY_NEXT_CE.HasValue)
                                    {
                                        if (ceBalance.QTY_NEXT_CE != null && ceBalance.QTY_NEXT_CE.HasValue)
                                            ceBalance.QTY_NEXT_CE += ceMainItem.QTY_NEXT_CE;
                                        else
                                            ceBalance.QTY_NEXT_CE = ceMainItem.QTY_NEXT_CE;
                                    }
                                    ceMainItem.QTY_NEXT_CE = 0.0;
                                }

                                // Delete hold
                                var holds = await _context.HOLDS.Include(h => h.MAINITEMS).Where(h => h.MainItemId == id).ToListAsync();
                                if (holds != null && holds.Count > 0)
                                    _context.HOLDS.RemoveRange(holds);

                                var currentDrawings = await _context.DRAWINGS.Where(h => h.ProjectID == mainItems.PBS.ProjectID && h.MainItemTag == mainItems.MainItemTag).ToListAsync();
                                if (currentDrawings != null && currentDrawings.Count > 0)
                                    drawings.AddRange(currentDrawings);
                            }
                        }
                        else
                        {
                            excelLogManager.AddLog(0, 0, "Main item not found - " + id.ToString());
                            notDeleted = true;
                        }
                    }
                }
                if (deleted)
                {
                    if (drawings.Count > 0)
                        _context.DRAWINGS.RemoveRange(drawings);
                    await _context.SaveChangesAsync();
                }
                if (!notDeleted)
                    excelLogManager.Result = "Operation completed";
                else
                    excelLogManager.Result = "Operation completed with Errors";
                return excelLogManager;
            }
            catch (Exception ex)
            {
                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                return excelLogManager;
            }
        }

        private bool MAINITEMSExists(int id)
        {
            return _context.MAINITEMS.Any(e => e.MainItemID == id);
        }
    }
}
