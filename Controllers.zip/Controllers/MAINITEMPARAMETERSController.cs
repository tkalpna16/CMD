﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using System;
using CivilMasterData.Models.Utilities;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using CivilMasterData.Models.BIM360.Parameters;

namespace CivilMasterData
{
    public class MAINITEMPARAMETERSController : Controller
    {
        private readonly MAINITEMPARAMETERSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public MAINITEMPARAMETERSController(MAINITEMPARAMETERSContext context,
            ISharedResource sharedResource,
            IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        // GET: MAINITEMPARAMETERS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
            {
                project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
                if (project == null)
                    return NotFound();
            }

            var categories = await _context.MAINITEMPARAMETERCATEGORIES.Select(m => m.CATEGORIESNAME).ToListAsync();

            ViewBag.Categories = categories;
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            try
            {
                var categoris = await _context.MAINITEMPARAMETERCATEGORIES.OrderBy(c => c.CATEGORIESNAME).ToListAsync();

            }
            catch(Exception ex)
            {
                string a = ex.Message;
            }
            var parameters = await _context.MAINITEMPARAMETERS.Include(c => c.MAINITEMPARAMETERCATEGORIES).Where(c => c.PROJECTID == project.ProjectID).OrderBy(p => p.PARAMETERNAME).ToListAsync();
            return View(parameters);
        }

        // GET: OBJECTCODES/Create
        public async Task<IActionResult> Create(string projectcode)
        {
            if (string.IsNullOrEmpty(projectcode))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectcode);
            var categories = await _context.MAINITEMPARAMETERCATEGORIES.Select(m => m.CATEGORIESNAME).ToListAsync();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.Categories = categories;

            return View();
        }

        // GET: MAINITEMPARAMETERS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMPARAMETERS = await _context.MAINITEMPARAMETERS
                .Include(m => m.Project)
                .Include(m => m.USERS)
                .FirstOrDefaultAsync(m => m.ParameterID == id);
            if (mAINITEMPARAMETERS == null)
            {
                return NotFound();
            }

            return View(mAINITEMPARAMETERS);
        }

        // POST: MAINITEMPARAMETERS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PROJECTID,PARAMETERNAME")] MAINITEMPARAMETERS mAINITEMPARAMETERS, string CATEGORYNAME)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == mAINITEMPARAMETERS.PROJECTID);
            var categoryNames = await _context.MAINITEMPARAMETERCATEGORIES.Select(c => c.CATEGORIESNAME).ToListAsync();
            MAINITEMPARAMETERCATEGORIES categories = null;
            if (!string.IsNullOrEmpty(CATEGORYNAME))
                categories = await _context.MAINITEMPARAMETERCATEGORIES.Where(c => c.CATEGORIESNAME == CATEGORYNAME).FirstAsync();
            else
                ViewBag.Message = "Category not correct";

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.Categories = categoryNames;

            if (!string.IsNullOrEmpty(mAINITEMPARAMETERS.PARAMETERNAME) && categories != null)
            {
                if (User.Identity.IsAuthenticated)
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    if (ModelState.IsValid && user != null)
                    {
                        // Check if Object Code exist
                        var obj = await _context.MAINITEMPARAMETERS.Where(o => o.PARAMETERNAME.ToUpperInvariant() == mAINITEMPARAMETERS.PARAMETERNAME.ToUpperInvariant()).FirstOrDefaultAsync();
                        if (obj == null)
                        {
                            mAINITEMPARAMETERS.UserID = user.USERID;
                            mAINITEMPARAMETERS.CreationDate = DateTime.UtcNow;
                            mAINITEMPARAMETERS.LastModified = DateTime.UtcNow;
                            mAINITEMPARAMETERS.MAINITEMPARAMETERCATEGORIESID = categories.CategoriesID;
                            _context.Add(mAINITEMPARAMETERS);
                            await _context.SaveChangesAsync();

                            // Add parameter values for every main items in the project
                            var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
                            if (mainItems != null)
                            {
                                foreach(MAINITEMS mainItem in mainItems)
                                {
                                    MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                    mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                    mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                    mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                    mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                                    mAINITEMPARAMETERVALUES.MainItemParametersID = mAINITEMPARAMETERS.ParameterID;

                                    _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                    await _context.SaveChangesAsync();
                                }
                            }

                            ViewBag.Message = "Parameter created";
                        }
                        else
                        {
                            ViewBag.Message = "Existing Parameter";
                        }
                    }
                }
            }
            return View(mAINITEMPARAMETERS);
        }


        [HttpPost]
        public async Task<string> CreateAttribute(string projectCode, string parameterName, string categoryName)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
            if (project == null)
                return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

            var categoryNames = await _context.MAINITEMPARAMETERCATEGORIES.Select(c => c.CATEGORIESNAME).ToListAsync();
            MAINITEMPARAMETERCATEGORIES categories = null;
            if (!string.IsNullOrEmpty(categoryName))
                categories = await _context.MAINITEMPARAMETERCATEGORIES.Where(c => c.CATEGORIESNAME == categoryName).FirstAsync();
            else
                return "Category not correct";

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.Categories = categoryNames;

            if (!string.IsNullOrEmpty(parameterName) && categories != null)
            {
                if (User.Identity.IsAuthenticated)
                {

                    string values = _configuration.GetValue<string>("Items:InvalidCustomAttributes");
                    List<string> notValidValues = ParsingUtils.ParseString(values);
                    if (notValidValues != null)
                    {
                        foreach (string currentVal in notValidValues)
                        {
                            if (currentVal.ToUpperInvariant() == parameterName.ToUpperInvariant())
                                return "Invalid Attribute name";
                        }
                    }

                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    if (ModelState.IsValid && user != null)
                    {
                        // Check if Object Code exist
                        var obj = await _context.MAINITEMPARAMETERS.Where(o => o.PARAMETERNAME.ToUpperInvariant() == parameterName.ToUpperInvariant()
                            && o.PROJECTID == project.ProjectID).FirstOrDefaultAsync();
                        if (obj == null)
                        {
                            MAINITEMPARAMETERS mAINITEMPARAMETERS = new MAINITEMPARAMETERS();
                            mAINITEMPARAMETERS.UserID = user.USERID;
                            mAINITEMPARAMETERS.PROJECTID = project.ProjectID;
                            mAINITEMPARAMETERS.CreationDate = DateTime.UtcNow;
                            mAINITEMPARAMETERS.LastModified = DateTime.UtcNow;
                            mAINITEMPARAMETERS.PARAMETERNAME = parameterName;
                            mAINITEMPARAMETERS.MAINITEMPARAMETERCATEGORIESID = categories.CategoriesID;
                            _context.Add(mAINITEMPARAMETERS);
                            await _context.SaveChangesAsync();

                            // Add parameter values for every main items in the project
                            var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
                            if (mainItems != null)
                            {
                                foreach (MAINITEMS mainItem in mainItems)
                                {
                                    MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                    mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                    mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                    mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                    mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                                    mAINITEMPARAMETERVALUES.MainItemParametersID = mAINITEMPARAMETERS.ParameterID;

                                    _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                    await _context.SaveChangesAsync();
                                }
                            }

                            return "Parameter created";
                        }
                        else
                        {
                            return "Existing Parameter";
                        }
                    }
                }
            }
            return "Parameter not created";
        }

        // GET: MAINITEMPARAMETERS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMPARAMETERS = await _context.MAINITEMPARAMETERS.FindAsync(id);
            if (mAINITEMPARAMETERS == null)
            {
                return NotFound();
            }

            ViewData["PROJECTID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", mAINITEMPARAMETERS.PROJECTID);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", mAINITEMPARAMETERS.UserID);
            return View(mAINITEMPARAMETERS);
        }

        // POST: MAINITEMPARAMETERS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PARAMETERID,PROJECTID,PARAMETERNAME,UserID,CreationDate,LastModified")] MAINITEMPARAMETERS mAINITEMPARAMETERS)
        {
            if (id != mAINITEMPARAMETERS.ParameterID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(mAINITEMPARAMETERS);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MAINITEMPARAMETERSExists(mAINITEMPARAMETERS.ParameterID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PROJECTID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", mAINITEMPARAMETERS.PROJECTID);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", mAINITEMPARAMETERS.UserID);
            return View(mAINITEMPARAMETERS);
        }

        // GET: MAINITEMPARAMETERS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMPARAMETERS = await _context.MAINITEMPARAMETERS
                .Include(m => m.Project)
                .Include(m => m.USERS)
                .FirstOrDefaultAsync(m => m.ParameterID == id);
            if (mAINITEMPARAMETERS == null)
            {
                return NotFound();
            }

            return View(mAINITEMPARAMETERS);
        }


        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            if (id == null)
                return NotFound();

            var mAINITEMPARAMETERS = await _context.MAINITEMPARAMETERS.Include(m => m.Project).Where(m => m.ParameterID == id.Value).FirstOrDefaultAsync();
            string projectCode = mAINITEMPARAMETERS.Project.Code;
            _context.MAINITEMPARAMETERS.Remove(mAINITEMPARAMETERS);
            await _context.SaveChangesAsync();
            return Redirect("/MAINITEMPARAMETERS/" + nameof(Index) + "?code=" + projectCode);
        }

        public async Task<string> DeleteParameter(int id)
        {
            try
            {
                var mAINITEMPARAMETERS = await _context.MAINITEMPARAMETERS.Include(m => m.Project).Where(m => m.ParameterID == id).FirstOrDefaultAsync();
                string projectCode = mAINITEMPARAMETERS.Project.Code;
                _context.MAINITEMPARAMETERS.Remove(mAINITEMPARAMETERS);
                await _context.SaveChangesAsync();
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
            return "Deleted";
        }

        private bool MAINITEMPARAMETERSExists(int id)
        {
            return _context.MAINITEMPARAMETERS.Any(e => e.ParameterID == id);
        }

        [HttpPost]
        public async Task<string> Rename(string projectCode, string oldname, string newname)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
            if (project == null)
                return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);


            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            if (!string.IsNullOrEmpty(oldname) && !string.IsNullOrEmpty(newname))
            {
                if (User.Identity.IsAuthenticated)
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    if (ModelState.IsValid && user != null)
                    {
                        // Check if Object Code exist
                        var oldAttribute = await _context.MAINITEMPARAMETERS.Where(o => o.PARAMETERNAME.ToUpperInvariant() == oldname.ToUpperInvariant() &&
                            o.PROJECTID == project.ProjectID).FirstOrDefaultAsync();
                        if (oldAttribute == null)
                            return "Not existing attribute";
                        var newAttribute = await _context.MAINITEMPARAMETERS.Where(o => o.PARAMETERNAME.ToUpperInvariant() == newname.ToUpperInvariant() &&
                            o.PROJECTID == project.ProjectID).FirstOrDefaultAsync();
                        if (newAttribute != null)
                            return "Already existing attribute";

                        string values = _configuration.GetValue<string>("Items:InvalidCustomAttributes");
                        List<string> notValidValues = ParsingUtils.ParseString(values);
                        if (notValidValues != null)
                        {
                            foreach(string currentVal in notValidValues)
                            {
                                if (currentVal.ToUpperInvariant() == newname.ToUpperInvariant())
                                    return "Invalid Attribute name";
                            }
                        }

                        oldAttribute.PARAMETERNAME = newname;
                        await _context.SaveChangesAsync();
                    }
                }
            }
            return "Parameter updated";
        }
    }
}
