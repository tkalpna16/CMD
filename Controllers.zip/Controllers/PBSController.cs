﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Drawing;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Steel;
using System.Collections.Generic;
using Microsoft.AspNetCore.Hosting;
using OfficeOpenXml;
using Microsoft.AspNetCore.Http;
using System.IO;
using CivilMasterData.Models.Logs;

namespace CivilMasterData.Controllers
{
    public class PBSController : Controller
    {
        private readonly PBSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PBSController(PBSContext context, ISharedResource sharedResource, IConfiguration configuration,
            IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
            _env = env;
        }

        // GET: PBS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN) && !User.HasClaim(Roles.ROLE, Roles.DISCIPLINE_LEADER))
                return Redirect("~/Home/NoPermission");

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            if (pbs != null)
            {
                var areas = pbs.Select(p => p.Area).
                    Distinct().
                    Where(s => !string.IsNullOrEmpty(s)).ToList();
                if (areas != null)
                    ViewBag.AreaList = areas;
            }

            ViewBag.CommonArea = project.CommonArea;
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == project.ProjectID);
            if (pROJECTSETTINGS == null)
                pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);

            if (pROJECTSETTINGS != null)
            {
                ViewBag.DASSetting = AppCostants.CleanSubstitutionString(pROJECTSETTINGS.SUBAREA);
                ViewBag.CWASetting = AppCostants.CleanSubstitutionString(pROJECTSETTINGS.CWA);
            }

            return View(pbs);
        }

        public async Task<IActionResult> ViewList(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            if (pbs != null)
            {
                var areas = pbs.Select(p => p.Area).
                    Distinct().
                    Where(s => !string.IsNullOrEmpty(s)).ToList();
                if (areas != null)
                    ViewBag.AreaList = areas;
            }

            ViewBag.CommonArea = project.CommonArea;
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;

            var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == project.ProjectID);
            if (pROJECTSETTINGS == null)
                pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);

            if (pROJECTSETTINGS != null)
            {
                ViewBag.DASSetting = AppCostants.CleanSubstitutionString(pROJECTSETTINGS.SUBAREA);
                ViewBag.CWASetting = AppCostants.CleanSubstitutionString(pROJECTSETTINGS.CWA);
            }

            return View(pbs);
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcel(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:PBSTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "PBS.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:PBSSheetName");
            int startRow = _configuration.GetValue<int>("Excel:PBSSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:PBSSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:PBSProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:PBSProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            var pbsList = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            if (pbsList != null)
            {
                int currentRow = startRow;
                foreach (PBS pbs in pbsList)
                {
                    Sheet.Cells[currentRow, startColumn].Value = pbs.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = pbs.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = pbs.CWA;
                    Sheet.Cells[currentRow, startColumn + 3].Value = pbs.AreaDescription;
                    Sheet.Cells[currentRow, startColumn + 4].Value = pbs.AreaValue;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcelView(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:PBSTemplateView");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "PBSView.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:PBSSheetName");
            int startRow = _configuration.GetValue<int>("Excel:PBSSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:PBSSheetStartColumn");
            int projectRow = _configuration.GetValue<int>("Excel:PBSProjectRow");
            int projectColumn = _configuration.GetValue<int>("Excel:PBSProjectColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            var pbsList = await _context.PBS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            if (pbsList != null)
            {
                int currentRow = startRow;
                foreach (PBS pbs in pbsList)
                {
                    Sheet.Cells[currentRow, startColumn].Value = pbs.Unit;
                    Sheet.Cells[currentRow, startColumn + 1].Value = pbs.Area;
                    Sheet.Cells[currentRow, startColumn + 2].Value = pbs.CWA;
                    Sheet.Cells[currentRow, startColumn + 3].Value = pbs.AreaDescription;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            ViewBag.Project = project.Code;
            return Json(new { fileName = fileToSave, errorMessage });
        }

        // GET: PBS/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == project.ProjectID);
            if (pROJECTSETTINGS == null)
                pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;
            ViewBag.ProjectDescription = project.GetCompleteDescription;
            if (pROJECTSETTINGS != null)
            {
                ViewBag.DASSetting = AppCostants.CleanSubstitutionString(pROJECTSETTINGS.SUBAREA);
                ViewBag.CWASetting = AppCostants.CleanSubstitutionString(pROJECTSETTINGS.CWA);
            }

            return View();
        }

        // POST: PBS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind("Unit,Area,AreaDescription,DAS,CWA,AreaValue,ProjectID,AutoDAS,AutoCWA")] PBS pBS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pBS.ProjectID);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    ViewBag.ProjectDescription = project.GetCompleteDescription;

                    // Check data
                    if (string.IsNullOrEmpty(pBS.Unit) || string.IsNullOrEmpty(pBS.Area))
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                        return View(pBS);
                    }

                    // Search equal pbs
                    var existingPBS = await _context.PBS.Where(p => p.Unit.ToUpperInvariant() == pBS.Unit.ToUpperInvariant() &&
                        p.Area.ToUpperInvariant() == pBS.Area.ToUpperInvariant()).ToListAsync();
                    if (existingPBS != null && existingPBS.Count > 0)
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);
                        return View(pBS);
                    }


                    var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pBS.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }
                    if (projectSettings != null)
                    {
                        ViewBag.DASSetting = projectSettings.SUBAREA;
                        ViewBag.CWASetting = projectSettings.CWA;
                    }
                    pBS.UpdateValues(projectSettings, user);

                    int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                    string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
                    string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                    var lotDefault = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameDefault).FirstOrDefaultAsync();
                    var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                    var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                    var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                    var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

                    var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();

                    using (var dbContextTransaction = _context.Database.BeginTransaction())
                    {
                        try
                        {
                            // Set user and creation date
                            pBS.UserID = user.USERID;
                            pBS.USERS = user;
                            pBS.CreationDate = DateTime.UtcNow;
                            pBS.LastModified = DateTime.UtcNow;

                            _context.PBS.Add(pBS);
                            await _context.SaveChangesAsync();

                            // Add PBS drawing
                            PBSDRAWINGS pbsDrawing = new PBSDRAWINGS();
                            pbsDrawing.PBSID = pBS.PBSID;
                            pbsDrawing.UserID = user.USERID;
                            pbsDrawing.CreationDate = DateTime.UtcNow;
                            pbsDrawing.LastModified = DateTime.UtcNow;
                            _context.PBSDRAWINGS.Add(pbsDrawing);
                            await _context.SaveChangesAsync();

                            // Create a Balance Main Item for Every Tag Types
                            var tagTypes = await _context.TAGTYPES.ToListAsync();
                            bool added = false;
                            if (tagTypes != null)
                            {
                                PLANNINGS pLANNINGS = null;
                                STEELPLANNINGS steelPlanning = null;
                                MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                                STEEL_QUANTITIES steelQty = null;
                                STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

                                HOLDS mainItemHold = null;
                                int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                                int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

                                foreach (TAGTYPES tagtype in tagTypes)
                                {
                                    if (tagtype.VALIDFORMAINITEMS > 0)
                                    {
                                        MAINITEMS mainItem = new MAINITEMS();
                                        mainItem.MainItemTag = projectSettings.GetBalanceMainItemTag(pBS.Area);
                                        mainItem.TagTypeID = tagtype.TagTypeID;
                                        mainItem.TagDescription = projectSettings.BALANCE;
                                        mainItem.TagClient = projectSettings.BALANCE;
                                        mainItem.PBSID = pBS.PBSID;
                                        mainItem.UserID = user.USERID;
                                        mainItem.USERS = user;
                                        mainItem.CreationDate = DateTime.UtcNow;
                                        mainItem.LastModified = DateTime.UtcNow;
                                        mainItem.AddedManually = 0;
                                        mainItem.BALANCE = 1;
                                        mainItem.MAINITEMSTATUSID = MainItemsCostants.NONE;

                                        if (tagtype.TagTypeID == tagTypeSteel)
                                        {
                                            mainItem.VENDORSID = vendor.IDVENDOR;
                                            mainItem.MATERIALREQUESTSID = mr.IDMR;
                                            mainItem.PURCHASEORDERSID = po.IDPO;
                                            mainItem.LOTSID = lotDefault.IDLOT;
                                        }
                                        else
                                        {
                                            mainItem.LOTSID = lotDefault.IDLOT;
                                        }
                                        _context.MAINITEMS.Add(mainItem);


                                        int result = _context.SaveChanges(true);
                                        var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == mainItem.MainItemTag && m.PBSID == pBS.PBSID);

                                        // Add parameter if existing
                                        if (parameters != null && parameters.Count > 0)
                                        {
                                            foreach (MAINITEMPARAMETERS parameter in parameters)
                                            {
                                                MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                                mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                                mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                                mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                                mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                                                mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                                _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                            }
                                            await _context.SaveChangesAsync();
                                        }

                                        // Add empty planning
                                        pLANNINGS = new PLANNINGS();
                                        pLANNINGS.MainItemId = mainItem.MainItemID;
                                        pLANNINGS.UserID = user.USERID;
                                        pLANNINGS.CreationDate = DateTime.UtcNow;
                                        pLANNINGS.LastModified = DateTime.UtcNow;

                                        mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                        mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                        mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                        mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                        mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                        //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                        _context.PLANNINGS.Add(pLANNINGS);
                                        //_context.HOLDS.Add(mainItemHold);
                                        _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                        added = true;

                                        //if (tagtype.TagTypeID != tagTypeSteel)
                                        //{

                                        //    // Add empty planning
                                        //    pLANNINGS = new PLANNINGS();
                                        //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                        //    pLANNINGS.UserID = user.USERID;
                                        //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                        //    pLANNINGS.LastModified = DateTime.UtcNow;

                                        //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                        //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                        //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                        //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                        //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                        //    //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                        //    _context.PLANNINGS.Add(pLANNINGS);
                                        //    //_context.HOLDS.Add(mainItemHold);
                                        //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                        //    added = true;
                                        //}
                                        //else
                                        //{
                                        //    // Add empty planning
                                        //    pLANNINGS = new PLANNINGS();
                                        //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                        //    pLANNINGS.UserID = user.USERID;
                                        //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                        //    pLANNINGS.LastModified = DateTime.UtcNow;
                                        //    _context.PLANNINGS.Add(pLANNINGS);

                                        //    steelPlanning = new STEELPLANNINGS();
                                        //    steelPlanning.MainItemId = mainItem.MainItemID;
                                        //    steelPlanning.UserID = user.USERID;
                                        //    steelPlanning.CreationDate = DateTime.UtcNow;
                                        //    steelPlanning.LastModified = DateTime.UtcNow;
                                        //    _context.STEELPLANNINGS.Add(steelPlanning);
                                        //    added = true;

                                        //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                        //    steelEstimateQty.MainItemId = mainItem.MainItemID;
                                        //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                        //    steelEstimateQty.IFF_E_QTY = 0.0;
                                        //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                        //    steelEstimateQty.IFP_E_QTY = 0.0;
                                        //    steelEstimateQty.PO_E_QTY = 0.0;
                                        //    steelEstimateQty.UserID = user.USERID;
                                        //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                                        //    steelEstimateQty.LastModified = DateTime.UtcNow;
                                        //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                        //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                        //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                        //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                        //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                        //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                        //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                        //    if (commodities != null)
                                        //    {
                                        //        foreach (COMMODITYCODES code in commodities)
                                        //        {
                                        //            steelQty = new STEEL_QUANTITIES();
                                        //            steelQty.MainItemId = mainItem.MainItemID;
                                        //            steelQty.CodeId = code.CodeID;
                                        //            steelQty.QTY = 0.0;
                                        //            steelQty.UserID = user.USERID;
                                        //            steelQty.CreationDate = DateTime.UtcNow;
                                        //            steelQty.LastModified = DateTime.UtcNow;
                                        //            _context.STEEL_QUANTITIES.Add(steelQty);
                                        //        }
                                        //    }
                                        //}

                                        // Add Main Item Drawing
                                        MAINITEMDRAWINGS mainItemDrawing = new MAINITEMDRAWINGS();
                                        mainItemDrawing.UserID = user.USERID;
                                        mainItemDrawing.CreationDate = DateTime.UtcNow;
                                        mainItemDrawing.LastModified = DateTime.UtcNow;
                                        mainItemDrawing.MainItemID = mainItem.MainItemID;

                                        _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                        // Add CE Revision

                                    }
                                }
                            }
                            if (added)
                                await _context.SaveChangesAsync();

                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PBS_CREATED);
                            dbContextTransaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            ViewBag.Message = ex.Message;
                            dbContextTransaction.Rollback();
                        }
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PBS_NOT_CREATED);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PBS_CREATED);
            }


            return View(pBS);
        }

        [HttpPost]
        public async Task<string> CreateNewPBS(
            string projectCode,
            string unit,
            string area,
            bool autoCWA,
            string cwa,
            double areasize,
            string areadescription)
        {
            if (User.Identity.IsAuthenticated)
            {
                if (string.IsNullOrEmpty(projectCode))
                    return "Invalid project";

                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectCode);
                _context.ProjectID = project.ProjectID;

                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;
                    ViewBag.ProjectDescription = project.GetCompleteDescription;

                    // Check data
                    if (string.IsNullOrEmpty(unit) || string.IsNullOrEmpty(area))
                    {
                        return _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                    }

                    // Search equal pbs
                    var existingPBS = await _context.PBS.Where(p => p.Unit.ToUpperInvariant() == unit.ToUpperInvariant() &&
                        p.Area.ToUpperInvariant() == area.ToUpperInvariant() && p.ProjectID == project.ProjectID).ToListAsync();
                    if (existingPBS != null && existingPBS.Count > 0)
                    {
                        return _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);
                    }


                    var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }
                    if (projectSettings != null)
                    {
                        ViewBag.DASSetting = projectSettings.SUBAREA;
                        ViewBag.CWASetting = projectSettings.CWA;
                    }

                    await AddPBS(project, projectSettings, user, unit, area, autoCWA, cwa, areasize, areadescription);
                }
                else
                {
                    return _sharedResource.Message(MESSAGE_CODES.PBS_NOT_CREATED);
                }
            }
            else
            {
                return _sharedResource.Message(MESSAGE_CODES.PBS_CREATED);
            }
            return "PBS created";
        }

        private void CreatePBS(
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            USERS user,
            string unit,
            string area,
            bool autoCWA,
            string cwa,
            double areasize,
            string areadescription,
            List<TAGTYPES> tagTypes,
            List<MAINITEMPARAMETERS> parameters,
            VENDORS vendor,
            MATERIALREQUESTS mr,
            PURCHASEORDERS po,
            LOTS defaultLot,
            List<COMMODITYCODES> commodities)
        {
            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");

            PLANNINGS pLANNINGS = null;
            STEELPLANNINGS steelPlanning = null;
            MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
            STEEL_QUANTITIES steelQty = null;
            STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

            PBS pBS = new PBS();
            pBS.Area = area;
            pBS.Unit = unit;
            pBS.ProjectID = project.ProjectID;
            pBS.AreaValue = areasize;
            pBS.AreaDescription = areadescription;
            pBS.AutoCWA = autoCWA;
            pBS.CWA = cwa;
            pBS.UserID = user.USERID;
            pBS.USERS = user;
            pBS.CreationDate = DateTime.UtcNow;
            pBS.LastModified = DateTime.UtcNow;

            pBS.UpdateValues(projectSettings, user);
            _context.PBS.Add(pBS);

            PBSDRAWINGS pbsDrawing = new PBSDRAWINGS();
            pbsDrawing.PBSID = pBS.PBSID;
            pbsDrawing.UserID = user.USERID;
            pbsDrawing.CreationDate = DateTime.UtcNow;
            pbsDrawing.LastModified = DateTime.UtcNow;
            _context.PBSDRAWINGS.Add(pbsDrawing);

            foreach (TAGTYPES tagtype in tagTypes)
            {
                if (tagtype.VALIDFORMAINITEMS > 0)
                {
                    MAINITEMS mainItem = new MAINITEMS();
                    mainItem.MainItemTag = projectSettings.GetBalanceMainItemTag(pBS.Area);
                    mainItem.TagTypeID = tagtype.TagTypeID;
                    mainItem.TagDescription = projectSettings.BALANCE;
                    mainItem.TagClient = projectSettings.BALANCE;
                    mainItem.PBSID = pBS.PBSID;
                    mainItem.UserID = user.USERID;
                    mainItem.USERS = user;
                    mainItem.CreationDate = DateTime.UtcNow;
                    mainItem.LastModified = DateTime.UtcNow;
                    mainItem.AddedManually = 0;
                    mainItem.BALANCE = 1;
                    mainItem.MAINITEMSTATUSID = MainItemsCostants.NONE;

                    if (tagtype.TagTypeID == tagTypeSteel)
                    {
                        mainItem.VENDORSID = vendor.IDVENDOR;
                        mainItem.MATERIALREQUESTSID = mr.IDMR;
                        mainItem.PURCHASEORDERSID = po.IDPO;
                        mainItem.LOTSID = defaultLot.IDLOT;
                    }
                    else
                    {
                        mainItem.LOTSID = defaultLot.IDLOT;
                    }
                    _context.MAINITEMS.Add(mainItem);


                    // Add parameter if existing
                    if (parameters != null && parameters.Count > 0)
                    {
                        foreach (MAINITEMPARAMETERS parameter in parameters)
                        {
                            MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                            mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                            mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                            mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                            mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                            mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                            _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                        }
                    }

                    // Add empty planning
                    pLANNINGS = new PLANNINGS();
                    pLANNINGS.MainItemId = mainItem.MainItemID;
                    pLANNINGS.UserID = user.USERID;
                    pLANNINGS.CreationDate = DateTime.UtcNow;
                    pLANNINGS.LastModified = DateTime.UtcNow;

                    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                    _context.PLANNINGS.Add(pLANNINGS);
                    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                    //if (tagtype.TagTypeID != tagTypeSteel)
                    //{
                    //    // Add empty planning
                    //    pLANNINGS = new PLANNINGS();
                    //    pLANNINGS.MainItemId = mainItem.MainItemID;
                    //    pLANNINGS.UserID = user.USERID;
                    //    pLANNINGS.CreationDate = DateTime.UtcNow;
                    //    pLANNINGS.LastModified = DateTime.UtcNow;

                    //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                    //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                    //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                    //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                    //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                    //    _context.PLANNINGS.Add(pLANNINGS);
                    //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                    //}
                    //else
                    //{
                    //    // Add empty planning
                    //    pLANNINGS = new PLANNINGS();
                    //    pLANNINGS.MainItemId = mainItem.MainItemID;
                    //    pLANNINGS.UserID = user.USERID;
                    //    pLANNINGS.CreationDate = DateTime.UtcNow;
                    //    pLANNINGS.LastModified = DateTime.UtcNow;
                    //    _context.PLANNINGS.Add(pLANNINGS);

                    //    steelPlanning = new STEELPLANNINGS();
                    //    steelPlanning.MainItemId = mainItem.MainItemID;
                    //    steelPlanning.UserID = user.USERID;
                    //    steelPlanning.CreationDate = DateTime.UtcNow;
                    //    steelPlanning.LastModified = DateTime.UtcNow;
                    //    _context.STEELPLANNINGS.Add(steelPlanning);

                    //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                    //    steelEstimateQty.MainItemId = mainItem.MainItemID;
                    //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                    //    steelEstimateQty.IFF_E_QTY = 0.0;
                    //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                    //    steelEstimateQty.IFP_E_QTY = 0.0;
                    //    steelEstimateQty.PO_E_QTY = 0.0;
                    //    steelEstimateQty.UserID = user.USERID;
                    //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                    //    steelEstimateQty.LastModified = DateTime.UtcNow;
                    //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                    //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                    //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                    //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                    //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                    //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                    //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                    //    if (commodities != null)
                    //    {
                    //        foreach (COMMODITYCODES code in commodities)
                    //        {
                    //            steelQty = new STEEL_QUANTITIES();
                    //            steelQty.MainItemId = mainItem.MainItemID;
                    //            steelQty.CodeId = code.CodeID;
                    //            steelQty.QTY = 0.0;
                    //            steelQty.UserID = user.USERID;
                    //            steelQty.CreationDate = DateTime.UtcNow;
                    //            steelQty.LastModified = DateTime.UtcNow;
                    //            _context.STEEL_QUANTITIES.Add(steelQty);
                    //        }
                    //    }
                    //}

                    // Add Main Item Drawing
                    MAINITEMDRAWINGS mainItemDrawing = new MAINITEMDRAWINGS();
                    mainItemDrawing.UserID = user.USERID;
                    mainItemDrawing.CreationDate = DateTime.UtcNow;
                    mainItemDrawing.LastModified = DateTime.UtcNow;
                    mainItemDrawing.MainItemID = mainItem.MainItemID;

                    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                }
            }

            //int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            //string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
            //string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");


            //using (var dbContextTransaction = _context.Database.BeginTransaction())
            //{
            //    try
            //    {
            //        // Set user and creation date
            //        pBS.UserID = user.USERID;
            //        pBS.USERS = user;
            //        pBS.CreationDate = DateTime.UtcNow;
            //        pBS.LastModified = DateTime.UtcNow;

            //        _context.PBS.Add(pBS);
            //        await _context.SaveChangesAsync();

            //        // Add PBS drawing
            //        PBSDRAWINGS pbsDrawing = new PBSDRAWINGS();
            //        pbsDrawing.PBSID = pBS.PBSID;
            //        pbsDrawing.UserID = user.USERID;
            //        pbsDrawing.CreationDate = DateTime.UtcNow;
            //        pbsDrawing.LastModified = DateTime.UtcNow;
            //        _context.PBSDRAWINGS.Add(pbsDrawing);
            //        await _context.SaveChangesAsync();

            //        // Create a Balance Main Item for Every Tag Types
            //        var tagTypes = await _context.TAGTYPES.ToListAsync();
            //        bool added = false;
            //        if (tagTypes != null)
            //        {
            //            PLANNINGS pLANNINGS = null;
            //            STEELPLANNINGS steelPlanning = null;
            //            MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
            //            STEEL_QUANTITIES steelQty = null;
            //            STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

            //            HOLDS mainItemHold = null;
            //            int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
            //            int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

            //            foreach (TAGTYPES tagtype in tagTypes)
            //            {
            //                if (tagtype.VALIDFORMAINITEMS > 0)
            //                {
            //                    MAINITEMS mainItem = new MAINITEMS();
            //                    mainItem.MainItemTag = projectSettings.GetBalanceMainItemTag(pBS.Area);
            //                    mainItem.TagTypeID = tagtype.TagTypeID;
            //                    mainItem.TagDescription = projectSettings.BALANCE;
            //                    mainItem.TagClient = projectSettings.BALANCE;
            //                    mainItem.PBSID = pBS.PBSID;
            //                    mainItem.UserID = user.USERID;
            //                    mainItem.USERS = user;
            //                    mainItem.CreationDate = DateTime.UtcNow;
            //                    mainItem.LastModified = DateTime.UtcNow;
            //                    mainItem.AddedManually = 0;
            //                    mainItem.BALANCE = 1;
            //                    mainItem.MAINITEMSTATUSID = MainItemsCostants.NONE;

            //                    if (tagtype.TagTypeID == tagTypeSteel)
            //                    {
            //                        mainItem.VENDORSID = vendor.IDVENDOR;
            //                        mainItem.MATERIALREQUESTSID = mr.IDMR;
            //                        mainItem.PURCHASEORDERSID = po.IDPO;
            //                        mainItem.LOTSID = lotDefault.IDLOT;
            //                    }
            //                    else
            //                    {
            //                        mainItem.LOTSID = lotDefault.IDLOT;
            //                    }
            //                    _context.MAINITEMS.Add(mainItem);


            //                    int result = _context.SaveChanges(true);
            //                    var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == mainItem.MainItemTag && m.PBSID == pBS.PBSID);

            //                    // Add parameter if existing
            //                    if (parameters != null && parameters.Count > 0)
            //                    {
            //                        foreach (MAINITEMPARAMETERS parameter in parameters)
            //                        {
            //                            MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
            //                            mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
            //                            mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
            //                            mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
            //                            mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
            //                            mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

            //                            _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
            //                        }
            //                        await _context.SaveChangesAsync();
            //                    }

            //                    if (tagtype.TagTypeID != tagTypeSteel)
            //                    {

            //                        // Add empty planning
            //                        pLANNINGS = new PLANNINGS();
            //                        pLANNINGS.MainItemId = mainItem.MainItemID;
            //                        pLANNINGS.UserID = user.USERID;
            //                        pLANNINGS.CreationDate = DateTime.UtcNow;
            //                        pLANNINGS.LastModified = DateTime.UtcNow;

            //                        mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
            //                        mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
            //                        mAIN_ITEM_QUANTITY.UserID = user.USERID;
            //                        mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
            //                        mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


            //                        //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

            //                        _context.PLANNINGS.Add(pLANNINGS);
            //                        //_context.HOLDS.Add(mainItemHold);
            //                        _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
            //                        added = true;
            //                    }
            //                    else
            //                    {
            //                        // Add empty planning
            //                        pLANNINGS = new PLANNINGS();
            //                        pLANNINGS.MainItemId = mainItem.MainItemID;
            //                        pLANNINGS.UserID = user.USERID;
            //                        pLANNINGS.CreationDate = DateTime.UtcNow;
            //                        pLANNINGS.LastModified = DateTime.UtcNow;
            //                        _context.PLANNINGS.Add(pLANNINGS);

            //                        steelPlanning = new STEELPLANNINGS();
            //                        steelPlanning.MainItemId = mainItem.MainItemID;
            //                        steelPlanning.UserID = user.USERID;
            //                        steelPlanning.CreationDate = DateTime.UtcNow;
            //                        steelPlanning.LastModified = DateTime.UtcNow;
            //                        _context.STEELPLANNINGS.Add(steelPlanning);
            //                        added = true;

            //                        steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
            //                        steelEstimateQty.MainItemId = mainItem.MainItemID;
            //                        steelEstimateQty.IFF_DELTA_QTY = 0.0;
            //                        steelEstimateQty.IFF_E_QTY = 0.0;
            //                        steelEstimateQty.IFP_DELTA_QTY = 0.0;
            //                        steelEstimateQty.IFP_E_QTY = 0.0;
            //                        steelEstimateQty.PO_E_QTY = 0.0;
            //                        steelEstimateQty.UserID = user.USERID;
            //                        steelEstimateQty.CreationDate = DateTime.UtcNow;
            //                        steelEstimateQty.LastModified = DateTime.UtcNow;
            //                        _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

            //                        mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
            //                        mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
            //                        mAIN_ITEM_QUANTITY.UserID = user.USERID;
            //                        mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
            //                        mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
            //                        _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

            //                        if (commodities != null)
            //                        {
            //                            foreach (COMMODITYCODES code in commodities)
            //                            {
            //                                steelQty = new STEEL_QUANTITIES();
            //                                steelQty.MainItemId = mainItem.MainItemID;
            //                                steelQty.CodeId = code.CodeID;
            //                                steelQty.QTY = 0.0;
            //                                steelQty.UserID = user.USERID;
            //                                steelQty.CreationDate = DateTime.UtcNow;
            //                                steelQty.LastModified = DateTime.UtcNow;
            //                                _context.STEEL_QUANTITIES.Add(steelQty);
            //                            }
            //                        }
            //                    }

            //                    // Add Main Item Drawing
            //                    MAINITEMDRAWINGS mainItemDrawing = new MAINITEMDRAWINGS();
            //                    mainItemDrawing.UserID = user.USERID;
            //                    mainItemDrawing.CreationDate = DateTime.UtcNow;
            //                    mainItemDrawing.LastModified = DateTime.UtcNow;
            //                    mainItemDrawing.MainItemID = mainItem.MainItemID;

            //                    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

            //                    // Add CE Revision

            //                }
            //            }
            //        }
            //        if (added)
            //        {
            //            await _context.SaveChangesAsync();
            //            dbContextTransaction.Commit();
            //        }
            //        else
            //        {
            //            dbContextTransaction.Rollback();
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        dbContextTransaction.Rollback();
            //        return false;
            //    }
            //}
            //return true;
        }

        private async Task<bool> AddPBS(
            PROJECTS project,
            PROJECTSETTINGS projectSettings,
            USERS user,
            string unit,
            string area,
            bool autoCWA,
            string cwa,
            double areasize,
            string areadescription)
        {
            PBS pBS = new PBS();
            pBS.Area = area;
            pBS.Unit = unit;
            pBS.ProjectID = project.ProjectID;
            pBS.AreaValue = areasize;
            pBS.AreaDescription = areadescription;
            pBS.AutoCWA = autoCWA;
            pBS.CWA = cwa;

            pBS.UpdateValues(projectSettings, user);

            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
            string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

            var lotDefault = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameDefault).FirstOrDefaultAsync();
            var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
            var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
            var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

            var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();

            using (var dbContextTransaction = _context.Database.BeginTransaction())
            {
                try
                {
                    // Set user and creation date
                    pBS.UserID = user.USERID;
                    pBS.USERS = user;
                    pBS.CreationDate = DateTime.UtcNow;
                    pBS.LastModified = DateTime.UtcNow;

                    _context.PBS.Add(pBS);
                    await _context.SaveChangesAsync();

                    // Add PBS drawing
                    PBSDRAWINGS pbsDrawing = new PBSDRAWINGS();
                    pbsDrawing.PBSID = pBS.PBSID;
                    pbsDrawing.UserID = user.USERID;
                    pbsDrawing.CreationDate = DateTime.UtcNow;
                    pbsDrawing.LastModified = DateTime.UtcNow;
                    _context.PBSDRAWINGS.Add(pbsDrawing);
                    await _context.SaveChangesAsync();

                    // Create a Balance Main Item for Every Tag Types
                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    bool added = false;
                    if (tagTypes != null)
                    {
                        PLANNINGS pLANNINGS = null;
                        STEELPLANNINGS steelPlanning = null;
                        MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                        STEEL_QUANTITIES steelQty = null;
                        STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

                        HOLDS mainItemHold = null;
                        int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                        int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");

                        foreach (TAGTYPES tagtype in tagTypes)
                        {
                            if (tagtype.VALIDFORMAINITEMS > 0)
                            {
                                MAINITEMS mainItem = new MAINITEMS();
                                mainItem.MainItemTag = projectSettings.GetBalanceMainItemTag(pBS.Area);
                                mainItem.TagTypeID = tagtype.TagTypeID;
                                mainItem.TagDescription = projectSettings.BALANCE;
                                mainItem.TagClient = projectSettings.BALANCE;
                                mainItem.PBSID = pBS.PBSID;
                                mainItem.UserID = user.USERID;
                                mainItem.USERS = user;
                                mainItem.CreationDate = DateTime.UtcNow;
                                mainItem.LastModified = DateTime.UtcNow;
                                mainItem.AddedManually = 0;
                                mainItem.BALANCE = 1;
                                mainItem.MAINITEMSTATUSID = MainItemsCostants.NONE;

                                if (tagtype.TagTypeID == tagTypeSteel)
                                {
                                    mainItem.VENDORSID = vendor.IDVENDOR;
                                    mainItem.MATERIALREQUESTSID = mr.IDMR;
                                    mainItem.PURCHASEORDERSID = po.IDPO;
                                    mainItem.LOTSID = lotDefault.IDLOT;
                                }
                                else
                                {
                                    mainItem.LOTSID = lotDefault.IDLOT;
                                }
                                _context.MAINITEMS.Add(mainItem);


                                int result = _context.SaveChanges(true);
                                var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == mainItem.MainItemTag && m.PBSID == pBS.PBSID);

                                // Add parameter if existing
                                if (parameters != null && parameters.Count > 0)
                                {
                                    foreach (MAINITEMPARAMETERS parameter in parameters)
                                    {
                                        MAINITEMPARAMETERVALUES mAINITEMPARAMETERVALUES = new MAINITEMPARAMETERVALUES();
                                        mAINITEMPARAMETERVALUES.CreationDate = DateTime.UtcNow;
                                        mAINITEMPARAMETERVALUES.LastModified = DateTime.UtcNow;
                                        mAINITEMPARAMETERVALUES.UserID = user.USERID.Value;
                                        mAINITEMPARAMETERVALUES.MainItemsID = mainItem.MainItemID;
                                        mAINITEMPARAMETERVALUES.MainItemParametersID = parameter.ParameterID;

                                        _context.MAINITEMPARAMETERVALUES.Add(mAINITEMPARAMETERVALUES);
                                    }
                                    await _context.SaveChangesAsync();
                                }

                                // Add empty planning
                                pLANNINGS = new PLANNINGS();
                                pLANNINGS.MainItemId = mainItem.MainItemID;
                                pLANNINGS.UserID = user.USERID;
                                pLANNINGS.CreationDate = DateTime.UtcNow;
                                pLANNINGS.LastModified = DateTime.UtcNow;

                                mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                _context.PLANNINGS.Add(pLANNINGS);
                                //_context.HOLDS.Add(mainItemHold);
                                _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                added = true;

                                //if (tagtype.TagTypeID != tagTypeSteel)
                                //{

                                //    // Add empty planning
                                //    pLANNINGS = new PLANNINGS();
                                //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                //    pLANNINGS.UserID = user.USERID;
                                //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                //    pLANNINGS.LastModified = DateTime.UtcNow;

                                //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;


                                //    //mainItemHold = new HOLDS(mainItem, user.USERID.Value, holdType, holdDept);

                                //    _context.PLANNINGS.Add(pLANNINGS);
                                //    //_context.HOLDS.Add(mainItemHold);
                                //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                //    added = true;
                                //}
                                //else
                                //{
                                //    // Add empty planning
                                //    pLANNINGS = new PLANNINGS();
                                //    pLANNINGS.MainItemId = mainItem.MainItemID;
                                //    pLANNINGS.UserID = user.USERID;
                                //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                //    pLANNINGS.LastModified = DateTime.UtcNow;
                                //    _context.PLANNINGS.Add(pLANNINGS);

                                //    steelPlanning = new STEELPLANNINGS();
                                //    steelPlanning.MainItemId = mainItem.MainItemID;
                                //    steelPlanning.UserID = user.USERID;
                                //    steelPlanning.CreationDate = DateTime.UtcNow;
                                //    steelPlanning.LastModified = DateTime.UtcNow;
                                //    _context.STEELPLANNINGS.Add(steelPlanning);
                                //    added = true;

                                //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                //    steelEstimateQty.MainItemId = mainItem.MainItemID;
                                //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                //    steelEstimateQty.IFF_E_QTY = 0.0;
                                //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                //    steelEstimateQty.IFP_E_QTY = 0.0;
                                //    steelEstimateQty.PO_E_QTY = 0.0;
                                //    steelEstimateQty.UserID = user.USERID;
                                //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                                //    steelEstimateQty.LastModified = DateTime.UtcNow;
                                //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                //    mAIN_ITEM_QUANTITY.MainItemId = mainItem.MainItemID;
                                //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                //    if (commodities != null)
                                //    {
                                //        foreach (COMMODITYCODES code in commodities)
                                //        {
                                //            steelQty = new STEEL_QUANTITIES();
                                //            steelQty.MainItemId = mainItem.MainItemID;
                                //            steelQty.CodeId = code.CodeID;
                                //            steelQty.QTY = 0.0;
                                //            steelQty.UserID = user.USERID;
                                //            steelQty.CreationDate = DateTime.UtcNow;
                                //            steelQty.LastModified = DateTime.UtcNow;
                                //            _context.STEEL_QUANTITIES.Add(steelQty);
                                //        }
                                //    }
                                //}

                                // Add Main Item Drawing
                                MAINITEMDRAWINGS mainItemDrawing = new MAINITEMDRAWINGS();
                                mainItemDrawing.UserID = user.USERID;
                                mainItemDrawing.CreationDate = DateTime.UtcNow;
                                mainItemDrawing.LastModified = DateTime.UtcNow;
                                mainItemDrawing.MainItemID = mainItem.MainItemID;

                                _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                // Add CE Revision

                            }
                        }
                    }
                    if (added)
                    {
                        await _context.SaveChangesAsync();
                        dbContextTransaction.Commit();
                    }
                    else
                    {
                        dbContextTransaction.Rollback();
                    }
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return false;
                }
            }
            return true;
        }

        [HttpPost]
        public async Task<string> UpdateValues(string code,
            string pbsidstr,
            string cwasstr,
            string sizesstr,
            string descriptionsstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    ViewBag.Project = project.Code;

                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var tagtypesDB = await _context.TAGTYPES.ToListAsync();

                    int[] pbsIds = Utils.SplitIntVector(pbsidstr);
                    string[] cwas = Utils.SplitText(cwasstr);
                    double[] sizes = Utils.SplitVector(sizesstr);
                    string[] descriptions = Utils.SplitText(descriptionsstr);

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in pbsIds)
                    {
                        var currentPBS = await _context.PBS.Where(p => p.PBSID == id && p.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                        if (currentPBS != null)
                        {
                            currentPBS.CWA = cwas[counter];
                            currentPBS.AreaValue = sizes[counter];
                            currentPBS.AreaDescription = descriptions[counter];
                            changed = true;
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, "PBS " + id.ToString()) + "; ";
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.PBS_SAVED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }


        // GET: PBS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pBS = await _context.PBS.FindAsync(id);
            if (pBS == null)
            {
                return NotFound();
            }
            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.ProjectID == pBS.ProjectID);
            if (project != null)
            {
                ViewBag.ProjectID = project.ProjectID;
                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;
            }
            return View(pBS);
        }

        // POST: PBS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, [Bind("PBSID,CreationDate,ProjectID,Unit,CA,Area,AreaDescription,AreaValue,DAS,CWA")] PBS pBS)
        {
            if (id != pBS.PBSID)
                return NotFound();

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null && !string.IsNullOrEmpty(pBS.Area) && !string.IsNullOrEmpty(pBS.Unit))
                {
                    try
                    {
                        // Check if there is a similar
                        bool found = false;
                        var pbsList = await _context.PBS.Where(p => p.Area.ToUpperInvariant() == pBS.Area.ToUpperInvariant() &&
                            p.Unit.ToUpperInvariant() == pBS.Unit.ToUpperInvariant()).ToListAsync();
                        if (pbsList != null && pbsList.Count == 1)
                            found = true;

                        if (found)
                        {
                            // Set user and creation date
                            pbsList[0].AreaValue = pBS.AreaValue;
                            pbsList[0].CWA = pBS.CWA;
                            pbsList[0].DAS = pBS.DAS;
                            pbsList[0].AreaDescription = pBS.AreaDescription;
                            pbsList[0].UserID = user.USERID;
                            pbsList[0].USERS = user;
                            pbsList[0].LastModified = DateTime.UtcNow;

                            _context.Update(pbsList[0]);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PBS_SAVED);
                        }
                        else
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PBS_NOT_SAVED);
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PBS_NOT_SAVED, ex.Message);
                    }
                }
                else
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pBS.ProjectID);
            ViewBag.Project = project.Code;
            return View(pBS);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeletePBS(int id)
        {
            try
            {
                var pBS = await _context.PBS.FindAsync(id);
                if (pBS != null)
                {
                    _context.PBS.Remove(pBS);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.PBS_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteMultiplePBS(string idStr)
        {
            try
            {
                int[] pbsList = Utils.SplitIntVector(idStr);
                if (pbsList != null && pbsList.Length > 0)
                {
                    foreach (int id in pbsList)
                    {
                        var pBS = await _context.PBS.FindAsync(id);
                        if (pBS != null)
                            _context.PBS.Remove(pBS);
                    }
                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.PBS_DELETED);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
            return string.Empty;
        }

        // POST: PBS/SaveCommonArea
        [HttpPost]
        public async Task<string> SaveCommonArea(string projectCode, string commonArea)
        {
            try
            {
                var project = await _context.PROJECTS
                    .FirstOrDefaultAsync(m => m.Code == projectCode);
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                _context.ProjectID = project.ProjectID;

                project.CommonArea = commonArea;

                _context.Update(project);
                await _context.SaveChangesAsync();

                ViewBag.CommonArea = commonArea;
                ViewBag.ProjectID = project.ProjectID;
                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;

                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // POST: PBS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pBS = await _context.PBS.FindAsync(id);
            _context.PBS.Remove(pBS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PBSExists(int id)
        {
            return _context.PBS.Any(e => e.PBSID == id);
        }


        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:PBSTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                    {
                        excelLogManager.Result = "Project not found";
                        return excelLogManager;
                    }

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    // Read Data
                    List<string> unitList = new List<string>();
                    List<string> areaList = new List<string>();
                    List<string> cwaList = new List<string>();
                    List<double> areaSizeList = new List<double>();
                    List<string> areaDescriptionList = new List<string>();
                    bool notEmpty = true;
                    int counter = _configuration.GetValue<int>("Excel:PBSSheetStartRow");
                    int startColumn = _configuration.GetValue<int>("Excel:PBSSheetStartColumn");

                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }
                    if (projectSettings != null)
                    {
                        ViewBag.DASSetting = projectSettings.SUBAREA;
                        ViewBag.CWASetting = projectSettings.CWA;
                    }

                    int totalPBS = 0;
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, startColumn];
                            string unit = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 1];
                            string area = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 2];
                            string cwa = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, 4];
                            string description = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, 5];
                            double areaSize = cell != null && cell.Value != null ? (double)cell.Value : 0.0;
                            if (areaSize < 0.0)
                            {
                                areaSize = 0.0;
                                excelLogManager.AddLog(counter, 4, "Negative area size");
                            }

                            if (string.IsNullOrEmpty(unit))
                            {
                                notEmpty = false;
                                continue;
                            }
                            if (string.IsNullOrEmpty(area))
                            {
                                excelLogManager.AddLog(counter, startColumn + 1, "Not valid area");
                            }
                            else
                            {
                                unitList.Add(unit);
                                areaList.Add(area);
                                areaDescriptionList.Add(description);
                                cwaList.Add(cwa);
                                areaSizeList.Add(areaSize);

                                //// Search existing PBS
                                //var currentPBS = await _context.PBS.Where(p => p.ProjectID == project.ProjectID &&
                                //    p.Area.ToUpperInvariant() == area.ToUpperInvariant()).FirstOrDefaultAsync();
                                //if (currentPBS != null)
                                //{
                                //    currentPBS.Unit = unit;
                                //    currentPBS.AreaDescription = description;
                                //    currentPBS.CWA = cwa;
                                //    currentPBS.AreaValue = areaSize;
                                //    await _context.SaveChangesAsync();
                                //}
                                //else
                                //{
                                //    await AddPBS(project, projectSettings, user, unit, area, false, cwa, areaSize, description);
                                //}
                                //totalPBS++;
                            }
                            counter++;
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(counter, 0, ex.Message);
                            notEmpty = false;
                        }
                    }

                    int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                    string lotNameDefault = _configuration.GetValue<string>("Items:DefaultLotName");
                    string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");


                    var tagTypes = await _context.TAGTYPES.ToListAsync();
                    var lotDefault = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotNameDefault).FirstOrDefaultAsync();
                    var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                    var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                    var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                    var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

                    var parameters = await _context.MAINITEMPARAMETERS.Where(p => p.PROJECTID == project.ProjectID).OrderBy(p => p.ParameterID).ToListAsync();


                    for (int i = 0; i < unitList.Count; i++)
                    {
                        // Search existing PBS
                        var currentPBS = await _context.PBS.Where(p => p.ProjectID == project.ProjectID &&
                            p.Area.ToUpperInvariant() == areaList[i].ToUpperInvariant()).FirstOrDefaultAsync();
                        if (currentPBS != null)
                        {
                            currentPBS.Unit = unitList[i];
                            currentPBS.AreaDescription = areaDescriptionList[i];
                            currentPBS.CWA = cwaList[i];
                            currentPBS.AreaValue = areaSizeList[i];
                        }
                        else
                        {
                            CreatePBS(project, projectSettings, user,
                                unitList[i], areaList[i], false,
                                cwaList[i], areaSizeList[i], areaDescriptionList[i], tagTypes,
                                parameters, vendor, mr, po, lotDefault,
                                commodities);
                        }
                        totalPBS++;
                    }

                    int result = await _context.SaveChangesAsync();

                    excelLogManager.Result = "Imported " + totalPBS.ToString() + " elements";
                }
            }
            catch { }

            return excelLogManager;
        }
    }
}
