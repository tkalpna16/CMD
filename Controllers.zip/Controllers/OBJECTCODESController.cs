﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.BIM360.Parameters;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Logs;
using Newtonsoft.Json;

namespace CivilMasterData
{
    public class OBJECTCODESController : Controller
    {
        private readonly OBJECTCODESContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public OBJECTCODESController(OBJECTCODESContext context, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        // GET: OBJECTCODES
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == pROJECTS.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            var oBJECTCODESContext = _context.OBJECTCODES.Where(o => o.ProjectID == pROJECTS.ProjectID).Include(o => o.USERS);

            string values = _configuration.GetValue<string>("Items:ObjectCodeBehaviours");
            ViewBag.Behaviours = ParsingUtils.ParseString(values);

            return View(await oBJECTCODESContext.ToListAsync());
        }

        // GET: OBJECTCODES/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oBJECTCODES = await _context.OBJECTCODES
                .Include(o => o.USERS)
                .FirstOrDefaultAsync(m => m.CodeID == id);
            if (oBJECTCODES == null)
            {
                return NotFound();
            }

            return View(oBJECTCODES);
        }

        // GET: OBJECTCODES/Create
        public async Task<IActionResult> Create(string projectcode)
        {
            if (string.IsNullOrEmpty(projectcode))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectcode);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View();
        }

        // POST: OBJECTCODES/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Code,CodeDescription,DisciplineCode,SubDisciplineCode,DisciplineName,SubDisciplineName,ProjectID")] OBJECTCODES oBJECTCODES)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == oBJECTCODES.ProjectID);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    // Check if Object Code exist
                    var obj = await _context.OBJECTCODES.Where(o => o.Code == oBJECTCODES.Code && o.ProjectID == oBJECTCODES.ProjectID).FirstOrDefaultAsync();
                    if (obj == null)
                    {
                        oBJECTCODES.UserID = user.USERID;
                        oBJECTCODES.CreationDate = DateTime.UtcNow;
                        oBJECTCODES.LastModified = DateTime.UtcNow;
                        _context.Add(oBJECTCODES);
                        await _context.SaveChangesAsync();
                        ViewBag.Message = "Object Code created";
                    }
                    else
                    {
                        ViewBag.Message = "Existing Code";
                    }
                }
            }
            return View(oBJECTCODES);
        }

        [HttpPost]
        public async Task<string> CreateObjectCode(string projectstr,
            string code,
            string description,
            string disciplineCode,
            string subDisciplineCode,
            string disciplineName,
            string subDisciplineName,
            string behaviour)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectstr);
            if (project == null)
                return "Project not found";
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            string values = _configuration.GetValue<string>("Items:ObjectCodeBehaviours");
            ViewBag.Behaviours = ParsingUtils.ParseString(values);

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    // Check if Object Code exist
                    var obj = await _context.OBJECTCODES.Where(o => o.Code == code && o.ProjectID == project.ProjectID).FirstOrDefaultAsync();
                    if (obj == null)
                    {
                        OBJECTCODES oBJECTCODES = new OBJECTCODES();
                        oBJECTCODES.UserID = user.USERID;
                        oBJECTCODES.CreationDate = DateTime.UtcNow;
                        oBJECTCODES.LastModified = DateTime.UtcNow;
                        oBJECTCODES.Code = code;
                        oBJECTCODES.CodeDescription = description;
                        oBJECTCODES.DisciplineCode = disciplineCode;
                        oBJECTCODES.SubDisciplineCode = subDisciplineCode;
                        oBJECTCODES.DisciplineName = disciplineName;
                        oBJECTCODES.SubDisciplineName = subDisciplineName;
                        oBJECTCODES.ProjectID = project.ProjectID;

                        if (!string.IsNullOrEmpty(behaviour) && values.Contains(behaviour))
                            oBJECTCODES.Behaviour = behaviour;
                        else
                            oBJECTCODES.Behaviour = null;

                        _context.Add(oBJECTCODES);
                        await _context.SaveChangesAsync();
                        return "Object Code created";
                    }
                    else
                    {
                        return "Existing Code";
                    }
                }
            }
            return "User not authenticated";
        }

        // GET: OBJECTCODES/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oBJECTCODES = await _context.OBJECTCODES.FindAsync(id);
            if (oBJECTCODES == null)
            {
                return NotFound();
            }

            var project = await _context.PROJECTS.Where(p => p.ProjectID == oBJECTCODES.ProjectID).FirstOrDefaultAsync();
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(oBJECTCODES);
        }

        // POST: OBJECTCODES/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CodeID,Code,CodeDescription,DisciplineCode,SubDisciplineCode,DisciplineName,SubDisciplineName,ProjectID,UserID,CreationDate")] OBJECTCODES oBJECTCODES)
        {
            var project = await _context.PROJECTS.Where(p => p.ProjectID == oBJECTCODES.ProjectID).FirstOrDefaultAsync();
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            if (id != oBJECTCODES.CodeID)
            {
                return NotFound();
            }

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid)
                {
                    try
                    {
                        // Check if Object Code exist
                        var obj = await _context.OBJECTCODES.Where(o => o.Code == oBJECTCODES.Code && o.ProjectID == oBJECTCODES.ProjectID).FirstOrDefaultAsync();
                        if (obj == null || obj.CodeID != oBJECTCODES.CodeID)
                        {
                            oBJECTCODES.LastModified = DateTime.UtcNow;
                            oBJECTCODES.UserID = user.USERID;
                            _context.Update(oBJECTCODES);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = "Object Code updated";
                        }
                        else
                        {
                            ViewBag.Message = "Existing Code";
                        }
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!OBJECTCODESExists(oBJECTCODES.CodeID))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                }
            }
            return View(oBJECTCODES);
        }

        // GET: OBJECTCODES/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oBJECTCODES = await _context.OBJECTCODES
                .Include(o => o.USERS)
                .FirstOrDefaultAsync(m => m.CodeID == id);
            if (oBJECTCODES == null)
            {
                return NotFound();
            }

            return View(oBJECTCODES);
        }

        // POST: OBJECTCODES/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oBJECTCODES = await _context.OBJECTCODES.FindAsync(id);
            _context.OBJECTCODES.Remove(oBJECTCODES);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OBJECTCODESExists(int id)
        {
            return _context.OBJECTCODES.Any(e => e.CodeID == id);
        }

        [HttpPost]
        public async Task<string> UpdateValues(string code,
            string codeidstr,
            string descriptionstr,
            string disccodestr,
            string subdisccodestr,
            string discnamestr,
            string subdiscnamestr,
            string behavioursstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    ViewBag.Project = project.Code;

                    var objectCodes = await _context.OBJECTCODES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    int[] codeids = Utils.SplitIntVector(codeidstr);
                    string[] descriptions = JsonConvert.DeserializeObject<string[]>(descriptionstr);
                    string[] disccodes = JsonConvert.DeserializeObject<string[]>(disccodestr);
                    string[] subdisccodes = JsonConvert.DeserializeObject<string[]>(subdisccodestr);
                    string[] discnames = JsonConvert.DeserializeObject<string[]>(discnamestr);
                    string[] subdiscnames = JsonConvert.DeserializeObject<string[]>(subdiscnamestr);
                    string[] behaviours = JsonConvert.DeserializeObject<string[]>(behavioursstr);

                    string values = _configuration.GetValue<string>("Items:ObjectCodeBehaviours");
                    ViewBag.Behaviours = ParsingUtils.ParseString(values);

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in codeids)
                    {
                        var currentCode = objectCodes.Where(p => p.CodeID == id).FirstOrDefault();
                        if (currentCode != null)
                        {
                            string description = descriptions[counter];
                            if (!string.IsNullOrEmpty(description))
                            {
                                description = description.Replace("\\", "\"");
                                description = Utils.Truncate(description, 500);
                            }
                            currentCode.CodeDescription = description;
                            currentCode.DisciplineCode = disccodes[counter];
                            currentCode.SubDisciplineCode = subdisccodes[counter];
                            currentCode.DisciplineName = discnames[counter];
                            currentCode.SubDisciplineName = subdiscnames[counter];
                            if (values.Contains(behaviours[counter]))
                                currentCode.Behaviour = behaviours[counter];
                            else
                                currentCode.Behaviour = null;
                            changed = true;
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, "Object Code " + id.ToString()) + "; ";
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_SAVED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteObjectCode(int id)
        {
            try
            {
                var objectCode = await _context.OBJECTCODES.FindAsync(id);
                if (objectCode != null)
                {
                    var mainItems = await _context.MAINITEMS.Include(p => p.PBS).Where(m => m.PBS.ProjectID == objectCode.ProjectID).ToListAsync();
                    if (mainItems != null && mainItems.Count > 0)
                        return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
                    else
                    {
                        _context.OBJECTCODES.Remove(objectCode);
                        await _context.SaveChangesAsync();
                    }
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<ExcelLogManager> DeleteMultipleObjectCodes(string idStr)
        {
            ExcelLogManager logManager = new ExcelLogManager();
            try
            {
                bool deleted = false;
                int[] codeList = Utils.SplitIntVector(idStr);
                int warning = 0;
                if (codeList != null && codeList.Length > 0)
                {
                    int counter = 0;
                    foreach (int id in codeList)
                    {
                        var objectCode = await _context.OBJECTCODES.FindAsync(id);
                        if (objectCode != null)
                        {
                            var mainItems = await _context.MAINITEMS.Include(p => p.PBS).Where(m => m.PBS.ProjectID == objectCode.ProjectID &&
                                m.LV01_Object_CodeID.HasValue && m.LV01_Object_CodeID.Value == objectCode.CodeID).ToListAsync();
                            if (mainItems != null && mainItems.Count > 0)
                            {
                                logManager.AddLog(counter, 0, objectCode.Code + " not deleted");
                                warning++;
                            }
                            else
                            {
                                _context.OBJECTCODES.Remove(objectCode);
                                deleted = true;
                            }
                        }
                        counter++;
                    }
                    if (warning > 0)
                        logManager.Result = "Completed with warnings";
                    else
                        logManager.Result = "Completed";
                    if (deleted)
                        await _context.SaveChangesAsync();
                    return logManager;
                }
            }
            catch (Exception ex)
            {
                logManager.Result = ex.Message;
                return logManager;
            }
            return logManager;
        }
    }
}
