﻿using Microsoft.AspNetCore.Mvc;

namespace CivilMasterData.Controllers.Base
{
    public class LocalizedController : Controller
    {
        protected readonly ISharedResource _sharedResource;

        public LocalizedController(ISharedResource sharedResource)
        {
            _sharedResource = sharedResource;
        }
    }
}
