﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;

namespace CivilMasterData
{
    public class VENDORSController : Controller
    {
        private readonly VENDORSContext _context;
        
        protected readonly ISharedResource _sharedResource;

        public VENDORSController(VENDORSContext context, ISharedResource sharedResource)
        {
            _context = context;
            this._sharedResource = sharedResource;
        }

        // GET: VENDORS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var vENDORSContext = _context.VENDORS.Where(v => v.ProjectID == project.ProjectID).Include(v => v.NATIONS).Include(v => v.Project).Include(v => v.USERS);
            return View(await vENDORSContext.ToListAsync());
        }

        // GET: VENDORS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vENDORS = await _context.VENDORS
                .Include(v => v.NATIONS)
                .Include(v => v.Project)
                .Include(v => v.USERS)
                .FirstOrDefaultAsync(m => m.IDVENDOR == id);
            if (vENDORS == null)
            {
                return NotFound();
            }

            return View(vENDORS);
        }

        // GET: VENDORS/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            ViewData["NATIONS"] = new SelectList(_context.Set<NATIONS>().OrderBy(n => n.DESCRIPTION_EN), "DESCRIPTION_EN", "DESCRIPTION_EN");
            
            return View();
        }

        // POST: VENDORS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IDVENDOR,COMPANYNAME,ADDRESS,CAP,CITY,PROVINCE,TELEPHONE,FAX,EMAIL,WEBSITE,NOTES,RERERENCEPEOPLE,ProjectID")] VENDORS vENDORS, string NATIONS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (string.IsNullOrEmpty(vENDORS.COMPANYNAME))
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                }
                else
                {
                    if (ModelState.IsValid && user != null)
                    {
                        var vendor = await _context.VENDORS.FirstOrDefaultAsync(m => m.ProjectID == vENDORS.ProjectID && m.COMPANYNAME.ToUpper() == vENDORS.COMPANYNAME.ToUpper());

                        if (vendor == null)
                        {
                            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == vENDORS.ProjectID);
                            var nations = await _context.NATIONS.FirstOrDefaultAsync(n => n.DESCRIPTION_EN == NATIONS);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            try
                            {
                                vENDORS.UserID = user.USERID;
                                vENDORS.CreationDate = DateTime.UtcNow;
                                vENDORS.LastModified = DateTime.UtcNow;
                                vENDORS.NATIONSID = nations.IDNATION;
                                vENDORS.NATIONS = nations;
                                vENDORS.IsVisible = true;
                                _context.VENDORS.Add(vENDORS);
                                await _context.SaveChangesAsync();

                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.VENDOR_CREATED);
                            }
                            catch (Exception ex)
                            {
                                ViewBag.Message = ex.Message;
                            }
                        }
                        else
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.VENDOR_EXISTING);
                        }
                    }
                    else
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.VENDOR_NOT_CREATED);
                    }
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            ViewData["NATIONS"] = new SelectList(_context.Set<NATIONS>().OrderBy(n => n.DESCRIPTION_EN), "DESCRIPTION_EN", "DESCRIPTION_EN");

            return View(vENDORS);
        }

        // GET: VENDORS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var vENDORS = await _context.VENDORS.FindAsync(id);
            if (vENDORS == null)
            {
                return NotFound();
            }
            var project = await _context.PROJECTS.Where(p => p.ProjectID == vENDORS.ProjectID).FirstOrDefaultAsync();
            var nation = await _context.NATIONS.Where(v => v.IDNATION == vENDORS.NATIONSID).FirstOrDefaultAsync();
            vENDORS.NATIONS = nation;

            var list = _context.NATIONS.OrderBy(n => n.DESCRIPTION_EN);
            ViewData["NATIONS"] = new SelectList(list, "IDNATION", "DESCRIPTION_EN", vENDORS.NATIONS.IDNATION);
            ViewData["Project"] = project.Code;
            ViewData["ProjectID"] = vENDORS.ProjectID;
            return View(vENDORS);
        }

        // POST: VENDORS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IDVENDOR,COMPANYNAME,ADDRESS,CAP,CITY,PROVINCE,NATIONSID,TELEPHONE,FAX,EMAIL,WEBSITE,NOTES,RERERENCEPEOPLE,RERERENCEEMAIL,ProjectID,UserID,CreationDate,LastModified")] VENDORS vENDORS)
        {
            if (id != vENDORS.IDVENDOR)
                return NotFound();
            

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null)
                {
                    try
                    {
                        // Set user and creation date
                        vENDORS.UserID = user.USERID;
                        vENDORS.LastModified = DateTime.UtcNow;

                        _context.Update(vENDORS);
                        await _context.SaveChangesAsync();

                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.VENDOR_UPDATED);
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.VENDOR_NOT_UPDATED, ex.Message);
                    }
                }
                else
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            var project = await _context.PROJECTS.Where(p => p.ProjectID == vENDORS.ProjectID).FirstOrDefaultAsync();
            var nation = await _context.NATIONS.Where(v => v.IDNATION == vENDORS.NATIONSID).FirstOrDefaultAsync();
            vENDORS.NATIONS = nation;

            var list = _context.NATIONS.OrderBy(n => n.DESCRIPTION_EN);
            ViewData["NATIONS"] = new SelectList(list, "IDNATION", "DESCRIPTION_EN", vENDORS.NATIONS.IDNATION);
            ViewData["Project"] = project.Code;
            ViewData["ProjectID"] = vENDORS.ProjectID;
            return View(vENDORS);
        }

        // GET: VENDORS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var vENDORS = await _context.VENDORS
                .Include(v => v.NATIONS)
                .Include(v => v.Project)
                .Include(v => v.USERS)
                .FirstOrDefaultAsync(m => m.IDVENDOR == id);
            if (vENDORS == null)
            {
                return NotFound();
            }

            return View(vENDORS);
        }

        // POST: VENDORS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var vENDORS = await _context.VENDORS.FindAsync(id);
            _context.VENDORS.Remove(vENDORS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool VENDORSExists(int id)
        {
            return _context.VENDORS.Any(e => e.IDVENDOR == id);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteVendor(int id)
        {
            try
            {
                var vendor = await _context.VENDORS.FindAsync(id);
                if (vendor != null)
                {
                    _context.VENDORS.Remove(vendor);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.VENDOR_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        #region BLOCK START FOR MWPDATAREGISTER
        public async Task<IActionResult> MWPDATAREGISTER(string code)
        {
            string [] projectcode= code.Split('-');
            if (string.IsNullOrEmpty(projectcode[0]))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == projectcode[0]);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var vENDORSContext = _context.VENDORS.Where(v => v.ProjectID == project.ProjectID).Include(v => v.NATIONS).Include(v => v.Project).Include(v => v.USERS);
            return View(await vENDORSContext.ToListAsync());
        }

       

        //CreateNewDetailer block
        //[HttpPost]
        //public async Task<string> CreateNewDetailer(string detailername,
        //  string inputDETAILER_NATION,
        //  string inputDETAILER_CITY,
        //  string inputkeyuser,
        //  string inputEmail,
        //  string inputpono,
        //  string inputNotes)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            var detailerUser = await _dcontext.DETAILER.Where(u => u.DETAILER_NAME.ToUpperInvariant() ==
        //                detailername.ToUpperInvariant()).FirstOrDefaultAsync();
        //            if (detailerUser != null)
        //                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);

        //            DATAREGISTER dataregister = new DATAREGISTER();
        //            dataregister.DETAILER_NAME = detailername;
        //            dataregister.DETAILER_NATION = inputDETAILER_NATION;
        //            dataregister.DETAILER_CITY = inputDETAILER_CITY;
        //            dataregister.DETAILER_KEY_USER = inputkeyuser;
        //            dataregister.DETAILER_EMAIL = inputEmail;
        //            dataregister.DETAILER_PO_NO = inputpono;
        //            dataregister.NOTES = inputNotes;
        //            _dcontext.Add(dataregister);
        //            await _dcontext.SaveChangesAsync();

        //            return _sharedResource.Message(MESSAGE_CODES.Detailer_Created);
        //        }
        //        catch (Exception ex)
        //        {
        //            return ex.Message;
        //        }
        //    }
        //    return _sharedResource.Message(MESSAGE_CODES.DETAILER_NOT_CREATED);
        //}

        #endregion
    }
}
