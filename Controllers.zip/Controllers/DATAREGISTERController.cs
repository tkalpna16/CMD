﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;

namespace CivilMasterData
{
    public class DATAREGISTERController : Controller
    {
        private readonly DETAILERDRContext _context;
        protected readonly ISharedResource _sharedResource;

        public DATAREGISTERController(DETAILERDRContext context, ISharedResource sharedResource)
        {
            _context = context;
            this._sharedResource = sharedResource;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var detailerContext = _context.DETAILER.Where(v => v.ProjectID == project.ProjectID).Include(v => v.Project).Include(v => v.USERS);

             return View(await _context.DETAILER.ToListAsync());
            //return View();
        }



        //CreateNewDetailer block
        [HttpPost]
        public async Task<string> CreateNewDetailer(string detailername,
          string inputDETAILER_NATION,
          string inputDETAILER_CITY,
          string inputkeyuser,
          string inputEmail,
          string inputpono,
          string inputNotes)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var detailerUser = await _context.DETAILER.Where(u => u.DETAILER_NAME.ToUpperInvariant() ==
                        detailername.ToUpperInvariant()).FirstOrDefaultAsync();
                    if (detailerUser != null)
                        return _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);

                    DETAILER dataregister = new DETAILER();
                    dataregister.DETAILER_ID = 1;
                    dataregister.DETAILER_NAME = detailername;
                    dataregister.DETAILER_NATION = inputDETAILER_NATION;
                    dataregister.DETAILER_CITY = inputDETAILER_CITY;
                    dataregister.DETAILER_KEY_USER = inputkeyuser;
                    dataregister.DETAILER_EMAIL = inputEmail;
                    dataregister.DETAILER_PO_NO = inputpono;
                    dataregister.NOTES = inputNotes;
                    dataregister.ProjectID = _context.ProjectID;
                    //dataregister.UserID=_context.user
                    dataregister.CreationDate = DateTime.UtcNow;
                    _context.Add(dataregister);
                    await _context.SaveChangesAsync();

                    return _sharedResource.Message(MESSAGE_CODES.Detailer_Created);
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
            return _sharedResource.Message(MESSAGE_CODES.DETAILER_NOT_CREATED);
        }


        //save Detailers data 
        [HttpPost]
        public async Task<string> UpdateValues(string idsstr,
          string Dname,
          string Dnation,
          string Dcity,
          string Dkeyuser,
          string Demail,string DPoNo,string Dnotes)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    var detailers = await _context.DETAILER.ToListAsync();

                    int[] ids = Utils.SplitIntVector(idsstr);
                    string[] detailername = Utils.SplitText(Dname);
                    string[] dnation = Utils.SplitText(Dnation);
                    string[] dcity = Utils.SplitText(Dcity);
                    string[] dkeyuser = Utils.SplitText(Dkeyuser);
                    string[] demail = Utils.SplitText(Demail);
                    string[] dpono = Utils.SplitText(DPoNo);
                    string[] dnotes = Utils.SplitText(Dnotes);

                    int count = detailername.Distinct().ToList().Count;
                    if (count != detailername.Length)
                    {
                        return "Duplicated Detailer Name";
                    }

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in ids)
                    {
                        var currentDetailer = detailers.Where(d => d.DETAILER_ID == ids[counter]).FirstOrDefault();
                        if (currentDetailer != null)
                        {
                            if (!string.IsNullOrEmpty(detailername[counter]))
                            {
                                detailername[counter] = detailername[counter].Replace("\\\\", "\\");
                            }
                            currentDetailer.DETAILER_NAME = detailername[counter];
                            currentDetailer.DETAILER_NATION = dnation[counter];
                            currentDetailer.DETAILER_CITY = dcity[counter];
                            currentDetailer.DETAILER_KEY_USER = dkeyuser[counter];
                            currentDetailer.DETAILER_EMAIL = demail[counter]; 
                            currentDetailer.DETAILER_PO_NO = dpono[counter];
                            currentDetailer.NOTES = dnotes[counter];
                            changed = true;
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, "Detailer " + id.ToString()) + "; ";
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.DETAILER_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

    }
}
