﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;

namespace CivilMasterData
{
    public class PURCHASEORDERSController : Controller
    {
        private readonly PURCHASEORDERSContext _context;
        protected readonly ISharedResource _sharedResource;

        public PURCHASEORDERSController(PURCHASEORDERSContext context, ISharedResource sharedResource)
        {
            _context = context;
            this._sharedResource = sharedResource;
        }

        // GET: PURCHASEORDERS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var pURCHASEORDERSContext = _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID).Include(p => p.Project).Include(p => p.USERS);
            return View(await pURCHASEORDERSContext.ToListAsync());
        }

        // GET: PURCHASEORDERS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pURCHASEORDERS = await _context.PURCHASEORDERS
                .Include(p => p.Project)
                .Include(p => p.USERS)
                .FirstOrDefaultAsync(m => m.IDPO == id);
            if (pURCHASEORDERS == null)
            {
                return NotFound();
            }

            return View(pURCHASEORDERS);
        }

        // GET: PURCHASEORDERS/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View();
        }

        // POST: PURCHASEORDERS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IDMR,NAME,NOTES,ProjectID,UserID,CreationDate,LastModified")] PURCHASEORDERS pURCHASEORDERS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (string.IsNullOrEmpty(pURCHASEORDERS.NAME))
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                }
                else
                {
                    if (ModelState.IsValid && user != null)
                    {
                        var vendor = await _context.PURCHASEORDERS.FirstOrDefaultAsync(m => m.ProjectID == pURCHASEORDERS.ProjectID && m.NAME.ToUpper() == pURCHASEORDERS.NAME.ToUpper());

                        if (vendor == null)
                        {
                            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pURCHASEORDERS.ProjectID);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            try
                            {
                                pURCHASEORDERS.UserID = user.USERID;
                                pURCHASEORDERS.CreationDate = DateTime.UtcNow;
                                pURCHASEORDERS.LastModified = DateTime.UtcNow;
                                pURCHASEORDERS.IsVisible = true;
                                _context.PURCHASEORDERS.Add(pURCHASEORDERS);
                                await _context.SaveChangesAsync();

                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PO_CREATED);
                            }
                            catch (Exception ex)
                            {
                                ViewBag.Message = ex.Message;
                            }
                        }
                        else
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PO_EXISTING);
                        }
                    }
                    else
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PO_NOT_CREATED);
                    }
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            ViewData["ProjectID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", pURCHASEORDERS.ProjectID);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", pURCHASEORDERS.UserID);
            return View(pURCHASEORDERS);
        }

        // GET: PURCHASEORDERS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pURCHASEORDERS = await _context.PURCHASEORDERS.FindAsync(id);
            if (pURCHASEORDERS == null)
            {
                return NotFound();
            }
            ViewData["ProjectID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", pURCHASEORDERS.ProjectID);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", pURCHASEORDERS.UserID);
            return View(pURCHASEORDERS);
        }

        // POST: PURCHASEORDERS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IDPO,NAME,NOTES,ProjectID,CreationDate")] PURCHASEORDERS pURCHASEORDERS)
        {
            if (id != pURCHASEORDERS.IDPO)
            {
                return NotFound();
            }

            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null)
                {
                    try
                    {
                        // Set user and creation date
                        pURCHASEORDERS.UserID = user.USERID;
                        pURCHASEORDERS.LastModified = DateTime.UtcNow;
                        pURCHASEORDERS.IsVisible = true;

                        _context.Update(pURCHASEORDERS);
                        await _context.SaveChangesAsync();

                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PO_UPDATED);
                    }
                    catch (Exception ex)
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PO_NOT_UPDATED, ex.Message);
                    }
                }
                else
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            var project = await _context.PROJECTS.Where(p => p.ProjectID == pURCHASEORDERS.ProjectID).FirstOrDefaultAsync();
            ViewData["Project"] = project.Code;
            ViewData["ProjectID"] = pURCHASEORDERS.ProjectID;
            return View(pURCHASEORDERS);
        }

        // GET: PURCHASEORDERS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pURCHASEORDERS = await _context.PURCHASEORDERS
                .Include(p => p.Project)
                .Include(p => p.USERS)
                .FirstOrDefaultAsync(m => m.IDPO == id);
            if (pURCHASEORDERS == null)
            {
                return NotFound();
            }

            return View(pURCHASEORDERS);
        }

        // POST: PURCHASEORDERS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pURCHASEORDERS = await _context.PURCHASEORDERS.FindAsync(id);
            _context.PURCHASEORDERS.Remove(pURCHASEORDERS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PURCHASEORDERSExists(int id)
        {
            return _context.PURCHASEORDERS.Any(e => e.IDPO == id);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeletePO(int id)
        {
            try
            {
                var vendor = await _context.PURCHASEORDERS.FindAsync(id);
                if (vendor != null)
                {
                    _context.PURCHASEORDERS.Remove(vendor);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.PO_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }
    }
}
