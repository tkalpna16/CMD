﻿using System;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Data;
using CivilMasterData.Models;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace CivilMasterData.Controllers
{
    public class SteelQuantityManagerController : Controller
    {
        private readonly SteelQuantityManagerContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public SteelQuantityManagerController(SteelQuantityManagerContext context,
            ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (!User.Identity.IsAuthenticated)
                return NotFound();
            if (String.IsNullOrEmpty(code))
                return NotFound();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            SteelQuantityManager itemListCreation = new SteelQuantityManager();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var lots = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID).ToListAsync();
            var pbs = await _context.PBS.Where(m => m.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == project.ProjectID && x.TagTypeID == tagTypeSteel).ToListAsync();

            var mainItemsEstimatedQty = await _context.STEEL_ESTIMATED_QUANTITIES.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            var mainItemsQty = await _context.STEEL_QUANTITIES.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();

            var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();
            // Check main item quantities
            bool added = false;
            if (mainItems != null && mainItems.Count > 0)
            {
                // Search main quantity
                if (commodities != null && commodities.Count > 0)
                {
                    foreach (MAINITEMS mainItem in mainItems)
                    {
                        foreach (COMMODITYCODES currentCode in commodities)
                        {
                            var currentSteelQty = mainItemsQty.Where(q => q.MainItemId == mainItem.MainItemID && q.CodeId == currentCode.CodeID).FirstOrDefault();
                            if (currentSteelQty == null)
                            {
                                STEEL_QUANTITIES steelQty = new STEEL_QUANTITIES();
                                steelQty.MainItemId = mainItem.MainItemID;
                                steelQty.CodeId = currentCode.CodeID;
                                steelQty.QTY = 0.0;
                                steelQty.UserID = user.USERID;
                                steelQty.CreationDate = DateTime.UtcNow;
                                steelQty.LastModified = DateTime.UtcNow;
                                _context.STEEL_QUANTITIES.Add(steelQty);
                                added = true;
                            }
                        }
                    }
                }

                // Find estimated quamtities
                foreach (MAINITEMS mainItem in mainItems)
                {
                    var steelEstimated = mainItemsEstimatedQty.Where(q => q.MainItemId == mainItem.MainItemID).FirstOrDefault();
                    if (steelEstimated == null)
                    {
                        STEEL_ESTIMATED_QUANTITIES steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                        steelEstimateQty.MainItemId = mainItem.MainItemID;
                        steelEstimateQty.IFF_DELTA_QTY = 0.0;
                        steelEstimateQty.IFF_E_QTY = 0.0;
                        steelEstimateQty.IFP_DELTA_QTY = 0.0;
                        steelEstimateQty.IFP_E_QTY = 0.0;
                        steelEstimateQty.PO_E_QTY = 0.0;
                        steelEstimateQty.UserID = user.USERID;
                        steelEstimateQty.CreationDate = DateTime.UtcNow;
                        steelEstimateQty.LastModified = DateTime.UtcNow;
                        _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);
                        added = true;
                    }
                }
            }

            if (added)
            {
                await _context.SaveChangesAsync();
                mainItemsEstimatedQty = await _context.STEEL_ESTIMATED_QUANTITIES.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
                mainItemsQty = await _context.STEEL_QUANTITIES.Where(x => x.MAINITEMS.PBS.ProjectID == project.ProjectID).ToListAsync();
            }

            itemListCreation.MainItems = mainItems;
            itemListCreation.Project = project;
            itemListCreation.PBS = pbs;
            itemListCreation.STEEL_QUANTITIES = mainItemsQty;
            itemListCreation.STEEL_ESTIMATED_QUANTITIES = mainItemsEstimatedQty;
            itemListCreation.COMMODITYCODES = commodities;
            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(itemListCreation);
        }


        [HttpPost]
        public async Task<string> UpdateEstimatedQty(string code, string mainitemsstr, string lotsstr,
            string poeqtystr, string ifpeqtystr, string iffeqtystr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                    var lotsdb = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID).ToListAsync();
                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] lots = Utils.SplitText(lotsstr);
                    double[] poeqty = Utils.SplitVector(poeqtystr);
                    double[] ifpeqty = Utils.SplitVector(ifpeqtystr);
                    double[] iffeqty = Utils.SplitVector(iffeqtystr);
                    int counter = 0;
                    foreach (string item in mainitems)
                    {
                        MAINITEMS mainitem;
                        if (!string.IsNullOrEmpty(lots[counter]))
                        {
                            mainitem = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item &&
                                m.LOTS.NAME == lots[counter] &&
                                m.TagTypeID == tagTypeSteel &&
                                m.PBS.ProjectID == project.ProjectID);
                        }
                        else
                        {
                            mainitem = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item &&
                                m.LOTS == null &&
                                m.TagTypeID == tagTypeSteel &&
                                m.PBS.ProjectID == project.ProjectID);
                        }

                        if (mainitem != null)
                        {
                            var mainItemsQty = await _context.STEEL_ESTIMATED_QUANTITIES.Where(x => x.MainItemId == mainitem.MainItemID).FirstOrDefaultAsync();
                            if (mainItemsQty != null)
                            {
                                mainItemsQty.PO_E_QTY = poeqty[counter];
                                mainItemsQty.IFP_E_QTY = ifpeqty[counter];
                                mainItemsQty.IFF_E_QTY = iffeqty[counter];
                                mainItemsQty.IFP_DELTA_QTY = poeqty[counter] - ifpeqty[counter];
                                mainItemsQty.IFF_DELTA_QTY = poeqty[counter] - iffeqty[counter];
                                mainItemsQty.LastModified = DateTime.UtcNow;
                                mainItemsQty.UserID = user.USERID;

                                await _context.SaveChangesAsync();
                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_NOT_FOUND, item + " ");
                            }
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND, item + " ");
                        }
                        counter++;
                    }
                    msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }


        [HttpPost]
        public async Task<string> UpdateQty(string code, string mainitemsstr, string lotsstr,
            string codestr, string qtystr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                    if (String.IsNullOrEmpty(code))
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                    int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                    var lotsdb = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID).ToListAsync();
                    var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
                    var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID).ToListAsync();
                    if (commodities == null)
                        return _sharedResource.Message(MESSAGE_CODES.COMMODITY_CODES_NOT_FOUND);

                    string[] mainitems = Utils.SplitText(mainitemsstr);
                    string[] lots = Utils.SplitText(lotsstr);
                    string[] subcodes = Utils.SplitText(codestr);
                    double[] qtylist = Utils.SplitVector(qtystr);
                    int counter = 0;
                    foreach (string item in mainitems)
                    {
                        MAINITEMS mainitem;

                        if (!string.IsNullOrEmpty(lots[counter]))
                        {
                            mainitem = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item &&
                                m.LOTS.NAME == lots[counter] &&
                                m.TagTypeID == tagTypeSteel &&
                                m.PBS.ProjectID == project.ProjectID);
                        }
                        else
                        {
                            mainitem = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item &&
                                m.LOTS == null &&
                                m.TagTypeID == tagTypeSteel &&
                                m.PBS.ProjectID == project.ProjectID);
                        }

                        var commodity = commodities.Where(c => c.SubCode == subcodes[counter]).FirstOrDefault();
                        if (mainitem != null && commodity != null)
                        {
                            var mainItemsQty = await _context.STEEL_QUANTITIES.Where(x => x.MainItemId == mainitem.MainItemID &&
                                x.CodeId == commodity.CodeID).FirstOrDefaultAsync();
                            if (mainItemsQty != null)
                            {
                                mainItemsQty.QTY = qtylist[counter];
                                mainItemsQty.LastModified = DateTime.UtcNow;
                                mainItemsQty.UserID = user.USERID;

                                await _context.SaveChangesAsync();
                            }
                            else
                            {
                                msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_NOT_FOUND, item + " ");
                            }
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND, item + " ");
                        }
                        counter++;
                    }
                    msg += _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_QTY_UPDATED);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }
    }
}
