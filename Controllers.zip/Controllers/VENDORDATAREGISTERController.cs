﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using Microsoft.Extensions.Configuration;

namespace CivilMasterData.Controllers
{
    public class VENDORDATAREGISTERController : Controller
    {
        private readonly VENDORDATAREGISTERContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public VENDORDATAREGISTERController(VENDORDATAREGISTERContext context, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        // GET: VENDOR DATA REGISTER
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            _context.ProjectID = project.ProjectID;

            // Read Vendors Data
            var vendors = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.IsVisible == true).Include(v => v.NATIONS).ToListAsync();
            var mrlist = await _context.MATERIALREQUESTS.Where(v => v.ProjectID == project.ProjectID && v.IsVisible == true).ToListAsync();
            var polist = await _context.PURCHASEORDERS.Where(v => v.ProjectID == project.ProjectID && v.IsVisible == true).ToListAsync();

            VendorDataRegister vendorDataRegister = new VendorDataRegister();
            vendorDataRegister.Vendors = vendors;
            vendorDataRegister.MaterialRequests = mrlist;
            vendorDataRegister.PurchaseOrders = polist;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(vendorDataRegister);
        }

    }
}
