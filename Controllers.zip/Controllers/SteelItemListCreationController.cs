﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Drawing;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace CivilMasterData.Controllers
{
    [UnAuthorized]
    public class SteelItemListCreationController : Controller
    {
        private readonly ItemListCreationContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public SteelItemListCreationController(ItemListCreationContext context, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index(string code)
        {
            if (String.IsNullOrEmpty(code))
                return NotFound();

            SteelItemListCreation itemListCreation = new SteelItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();


            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == project.ProjectID && x.TagTypeID == tagTypeSteel).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var vendors = await _context.VENDORS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mrlist = await _context.MATERIALREQUESTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var polist = await _context.PURCHASEORDERS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Lots = lots;
            itemListCreation.Vendors = vendors;
            itemListCreation.Materialrequests = mrlist;
            itemListCreation.PurchaseOrders = polist;

            itemListCreation.MainItems = MAINITEMS.ReorderMainItems(itemListCreation.MainItems);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(itemListCreation);
        }

        // GET: MAINITEMS/Create
        public async Task<IActionResult> CreateAutomatic(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            SteelItemListCreation itemListCreation = new SteelItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();


            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == project.ProjectID && x.TagTypeID == tagTypeSteel).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var vendors = await _context.VENDORS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mrlist = await _context.MATERIALREQUESTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var polist = await _context.PURCHASEORDERS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Lots = lots;
            itemListCreation.Vendors = vendors;
            itemListCreation.Materialrequests = mrlist;
            itemListCreation.PurchaseOrders = polist;

            itemListCreation.MainItems = MAINITEMS.ReorderMainItems(itemListCreation.MainItems);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(itemListCreation);
        }

        // GET: MAINITEMS/Create
        public async Task<IActionResult> CreateManual(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            SteelItemListCreation itemListCreation = new SteelItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();


            int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
            var objects = await _context.OBJECTCODES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == project.ProjectID && x.TagTypeID == tagTypeSteel).ToListAsync();
            var lots = await _context.LOTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var vendors = await _context.VENDORS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var mrlist = await _context.MATERIALREQUESTS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var polist = await _context.PURCHASEORDERS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.MainItems = mainItems;
            itemListCreation.Lots = lots;
            itemListCreation.Vendors = vendors;
            itemListCreation.Materialrequests = mrlist;
            itemListCreation.PurchaseOrders = polist;

            itemListCreation.MainItems = MAINITEMS.ReorderMainItems(itemListCreation.MainItems);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(itemListCreation);
        }

        // GET: MAINITEMS/Replace
        public async Task<IActionResult> Replace(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            ItemListCreation itemListCreation = new ItemListCreation();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
                return NotFound();
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            var pbs = await _context.PBS.Where(x => x.ProjectID == project.ProjectID).ToListAsync();
            var wp = await _context.WORKINGPACKAGES.Where(x => x.ProjectID == project.ProjectID).ToListAsync();

            itemListCreation.Project = project;
            itemListCreation.TagTypes = tagTypes;
            itemListCreation.PBS = pbs;
            itemListCreation.WORKINGPACKAGES = wp;

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(itemListCreation);
        }

        private async Task<List<MAINITEMS>> AddMainItemToContext(string area, string wp, string objectcode,
            string material, bool materialChecked, string tagtype, int totalItems, int projectId, USERS user,
            LOTS lot, VENDORS vendor, MATERIALREQUESTS mr, PURCHASEORDERS po, int tagTypeSteel)
        {
            List<MAINITEMS> mAINITEMs = new List<MAINITEMS>();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == projectId);
            var materialitem = await _context.MATERIALWORKGROUPS.FirstOrDefaultAsync(x => x.GroupCode == material);
            var objects = await _context.OBJECTCODES.FirstOrDefaultAsync(x => x.Code == objectcode);
            var tagTypes = await _context.TAGTYPES.FirstOrDefaultAsync(x => x.Description == tagtype);
            var pbs = await _context.PBS.FirstOrDefaultAsync(x => x.Area == area && x.ProjectID == projectId);
            var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();
            var wpItem = await _context.WORKINGPACKAGES.Where(w => w.NAME == wp && w.ProjectID == project.ProjectID).FirstOrDefaultAsync();

            bool isSteel = tagTypes.TagTypeID == tagTypeSteel;

            MAINITEMS item = new MAINITEMS();
            item.PBS = pbs;
            item.PBSID = item.PBS.PBSID;
            item.LV01_Object_Code = objects;
            item.LV01_Object_CodeID = objects.CodeID;
            item.LV01_Material_Work_Group = materialitem;
            item.LV01_Material_Work_GroupID = materialitem.GroupID;
            item.TAGTYPES = tagTypes;
            item.TagTypeID = tagTypes.TagTypeID;
            item.WORKINGPACKAGESID = wpItem?.IDWP;
            item.AddedManually = 0;
            item.BALANCE = 0;

            // Set User and Date
            item.UserID = user.USERID;
            item.CreationDate = DateTime.UtcNow;
            item.LastModified = DateTime.UtcNow;

            if (isSteel)
            {
                item.VENDORSID = vendor.IDVENDOR;
                item.MATERIALREQUESTSID = mr.IDMR;
                item.PURCHASEORDERSID = po.IDPO;
                item.LOTSID = lot.IDLOT;
            }

            int startIndex = 1;
            bool found = true;
            while (found)
            {
                found = ContainsItem(item, startIndex, mainItems);
                if (found)
                    startIndex++;
                else
                    found = false;
            }

            if (totalItems > 0)
            {
                for (int i = 0; i < totalItems; i++)
                {
                    item = new MAINITEMS();
                    item.PBS = pbs;
                    item.PBSID = item.PBS.PBSID;
                    item.LV01_Object_Code = objects;
                    item.LV01_Object_CodeID = objects.CodeID;
                    item.LV01_Material_Work_Group = materialitem;
                    item.LV01_Material_Work_GroupID = materialitem.GroupID;
                    item.TAGTYPES = tagTypes;
                    item.TagTypeID = tagTypes.TagTypeID;
                    item.WORKINGPACKAGESID = wpItem?.IDWP;
                    string tag = item.CalculateMainTag(startIndex, materialChecked);
                    item.MainItemTag = tag;
                    item.AddedManually = 0;
                    item.BALANCE = 0;

                    // Set User and Date
                    item.UserID = user.USERID;
                    item.CreationDate = DateTime.UtcNow;
                    item.LastModified = DateTime.UtcNow;

                    if (isSteel)
                    {
                        item.VENDORSID = vendor.IDVENDOR;
                        item.MATERIALREQUESTSID = mr.IDMR;
                        item.PURCHASEORDERSID = po.IDPO;
                        item.LOTSID = lot.IDLOT;
                    }

                    startIndex++;

                    mAINITEMs.Add(item);
                    _context.MAINITEMS.Add(item);
                }
            }
            return mAINITEMs;
        }

        [HttpPost]
        public async Task<List<string>> GetMainItems(int? projectId)
        {
            List<string> items = new List<string>();
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == projectId);
            var tagTypes = await _context.TAGTYPES.ToListAsync();
            if (project != null)
            {
                var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                if (mainItems != null)
                    items = mainItems.Select(m => m.Description).ToList();
            }

            return items;
        }


        [HttpPost]
        public async Task<string> CreateElementAutomatically(string area, string wp, string objectcode, 
            string material, bool considerMaterial, string tagtype, int totalItems, string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                bool valid = !String.IsNullOrEmpty(area) && !String.IsNullOrEmpty(objectcode);
                List<string> areas = null;
                List<string> codes = null;
                List<string> tagtypes = null;
                if (valid)
                {
                    areas = JsonConvert.DeserializeObject<List<string>>(area);
                    codes = JsonConvert.DeserializeObject<List<string>>(objectcode);
                    tagtypes = JsonConvert.DeserializeObject<List<string>>(tagtype);
                }
                valid &= areas != null && areas.Count > 0;
                valid &= codes != null && codes.Count > 0;
                valid &= tagtypes != null && tagtypes.Count > 0;

                PLANNINGS pLANNINGS = null;
                MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                MAINITEMDRAWINGS mainItemDrawing = null;
                HOLDS mainItemHold = null;
                STEEL_QUANTITIES steelQty = null;
                STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;
                int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");
                int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                string lotName = _configuration.GetValue<string>("Steel:DefaultLotName");
                string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                var lot = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotName).FirstOrDefaultAsync();
                var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();

                if (valid)
                {
                    List<MAINITEMS> mAINITEMs = new List<MAINITEMS>();
                    List<MAINITEMS> currentMAINITEMs = new List<MAINITEMS>();

                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    foreach (string a in areas)
                    {
                        foreach (string c in codes)
                        {
                            foreach (string currentTagType in tagtypes)
                            {
                                currentMAINITEMs = await AddMainItemToContext(a, wp, c, material, considerMaterial, currentTagType, 
                                    totalItems, project.ProjectID, user, lot, vendor, mr, po, tagTypeSteel);
                                if (currentMAINITEMs != null && currentMAINITEMs.Count > 0)
                                    mAINITEMs.AddRange(currentMAINITEMs);
                            }
                        }
                    }

                    if (mAINITEMs != null && mAINITEMs.Count > 0)
                    {
                        STEELPLANNINGS steelPlanning = null;
                        using (var dbContextTransaction = _context.Database.BeginTransaction())
                        {
                            try
                            {
                                int result = _context.SaveChanges(true);
                                foreach (MAINITEMS item in mAINITEMs)
                                {

                                    // Add empty planning
                                    pLANNINGS = new PLANNINGS();
                                    pLANNINGS.MainItemId = item.MainItemID;
                                    pLANNINGS.UserID = user.USERID;
                                    pLANNINGS.CreationDate = DateTime.UtcNow;
                                    pLANNINGS.LastModified = DateTime.UtcNow;

                                    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                    mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                                    mainItemDrawing = new MAINITEMDRAWINGS();
                                    mainItemDrawing.UserID = user.USERID;
                                    mainItemDrawing.CreationDate = DateTime.UtcNow;
                                    mainItemDrawing.LastModified = DateTime.UtcNow;
                                    mainItemDrawing.MainItemID = item.MainItemID;

                                    //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);

                                    _context.PLANNINGS.Add(pLANNINGS);
                                    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);

                                    //if (item.TagTypeID != tagTypeSteel)
                                    //{
                                    //    // Add empty planning
                                    //    pLANNINGS = new PLANNINGS();
                                    //    pLANNINGS.MainItemId = item.MainItemID;
                                    //    pLANNINGS.UserID = user.USERID;
                                    //    pLANNINGS.CreationDate = DateTime.UtcNow;
                                    //    pLANNINGS.LastModified = DateTime.UtcNow;

                                    //    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                    //    mAIN_ITEM_QUANTITY.MainItemId = item.MainItemID;
                                    //    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                    //    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                    //    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;

                                    //    mainItemDrawing = new MAINITEMDRAWINGS();
                                    //    mainItemDrawing.UserID = user.USERID;
                                    //    mainItemDrawing.CreationDate = DateTime.UtcNow;
                                    //    mainItemDrawing.LastModified = DateTime.UtcNow;
                                    //    mainItemDrawing.MainItemID = item.MainItemID;

                                    //    //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);

                                    //    _context.PLANNINGS.Add(pLANNINGS);
                                    //    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);
                                    //    _context.MAINITEMDRAWINGS.Add(mainItemDrawing);
                                    //    //_context.HOLDS.Add(mainItemHold);
                                    //}
                                    //else
                                    //{
                                    //    steelPlanning = new STEELPLANNINGS();
                                    //    steelPlanning.MainItemId = item.MainItemID;
                                    //    steelPlanning.UserID = user.USERID;
                                    //    steelPlanning.CreationDate = DateTime.UtcNow;
                                    //    steelPlanning.LastModified = DateTime.UtcNow;
                                    //    _context.STEELPLANNINGS.Add(steelPlanning);

                                    //    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                    //    steelEstimateQty.MainItemId = item.MainItemID;
                                    //    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                    //    steelEstimateQty.IFF_E_QTY = 0.0;
                                    //    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                    //    steelEstimateQty.IFP_E_QTY = 0.0;
                                    //    steelEstimateQty.PO_E_QTY = 0.0;
                                    //    steelEstimateQty.UserID = user.USERID;
                                    //    steelEstimateQty.CreationDate = DateTime.UtcNow;
                                    //    steelEstimateQty.LastModified = DateTime.UtcNow;
                                    //    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                    //    if (commodities != null)
                                    //    {
                                    //        foreach (COMMODITYCODES commodityCode in commodities)
                                    //        {
                                    //            steelQty = new STEEL_QUANTITIES();
                                    //            steelQty.MainItemId = item.MainItemID;
                                    //            steelQty.CodeId = commodityCode.CodeID;
                                    //            steelQty.QTY = 0.0;
                                    //            steelQty.UserID = user.USERID;
                                    //            steelQty.CreationDate = DateTime.UtcNow;
                                    //            steelQty.LastModified = DateTime.UtcNow;
                                    //            _context.STEEL_QUANTITIES.Add(steelQty);
                                    //        }
                                    //    }
                                    //}
                                }
                                result = _context.SaveChanges(true);
                                dbContextTransaction.Commit();
                                msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEMS_CREATED);
                            }
                            catch (Exception ex)
                            {
                                msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED, ex.Message);
                                dbContextTransaction.Rollback();
                            }
                        }
                    }
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> SaveElementManual(string mainitemstr, 
            string lotstr, 
            string vendorstr,
            string mrstr, 
            string postr,
            string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);

                int projectId = project.ProjectID;
                string name = User.Identity.Name;
                var pbs = await _context.PBS.Where(p => p.ProjectID == projectId).ToListAsync();
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                var vendor = await _context.VENDORS.FirstOrDefaultAsync(x => x.COMPANYNAME == vendorstr && x.ProjectID == projectId);
                LOTS lot = await _context.LOTS.FirstOrDefaultAsync(x => x.NAME.ToUpperInvariant() == lotstr.ToUpperInvariant() && x.ProjectID == projectId);
                var mr = await _context.MATERIALREQUESTS.FirstOrDefaultAsync(x => x.NAME == mrstr && x.ProjectID == projectId);
                var po = await _context.PURCHASEORDERS.FirstOrDefaultAsync(x => x.NAME == postr && x.ProjectID == projectId);
                int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                var mainItem = await _context.MAINITEMS.FirstOrDefaultAsync(x => x.PBS.ProjectID == projectId && mainitemstr.ToUpper() == x.MainItemTag.ToUpper()
                    && x.TagTypeID == tagTypeSteel);


                if (lot == null) // Create LOT
                {
                    lot = new LOTS();
                    lot.NAME = lotstr;
                    lot.ProjectID = projectId;
                    lot.UserID = user.USERID;
                    lot.CreationDate = DateTime.UtcNow;
                    lot.LastModified = DateTime.UtcNow;
                    _context.LOTS.Add(lot);
                    await _context.SaveChangesAsync();
                }

                if (mainItem != null)
                {
                    mainItem.LOTSID = lot.IDLOT;
                    mainItem.VENDORSID = vendor.IDVENDOR;
                    mainItem.PURCHASEORDERSID = po.IDPO;
                    mainItem.MATERIALREQUESTSID = mr.IDMR;
                    mainItem.UserID = user.USERID;
                    mainItem.LastModified = DateTime.UtcNow;
                    await _context.SaveChangesAsync();
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_UPDATED);
                }
                else
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                }
            }
            else
            {
                msg = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return msg;
        }

        [HttpPost]
        public async Task<string> ReplaceElementManual(string itemtoreplace, string area, string wp, string tcmtag,
            string tagdescription, string tagclient, string tagtype, string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                ItemListCreation itemListCreation = new ItemListCreation();
                if (String.IsNullOrEmpty(code))
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                _context.ProjectID = project.ProjectID;
                if (project == null)
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND); var tagTypes = await _context.TAGTYPES.ToListAsync();

                int projectId = project.ProjectID;
                var pbs = await _context.PBS.Where(x => x.ProjectID == projectId).ToListAsync();
                var tagType = tagTypes.FirstOrDefault(x => x.Description == tagtype);
                var selectedpbs = await _context.PBS.FirstOrDefaultAsync(x => x.Area == area && x.ProjectID == projectId);

                var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == projectId).ToListAsync();
                var mainItemToReplace = mainItems.Where(x => x.Description == itemtoreplace).FirstOrDefault();
                if (mainItemToReplace == null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_FOUND);
                    return msg;
                }

                var mainItemToAdd = await _context.MAINITEMS.FirstOrDefaultAsync(x => x.PBS.ProjectID == projectId && tcmtag.ToUpper() == x.MainItemTag.ToUpper()
                    && x.TAGTYPES.Description.ToUpper() == tagtype.ToUpper());

                if (mainItemToAdd != null)
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_ALREADY_EXISTING);
                    return msg;
                }

                PLANNINGS pLANNINGS = null;
                STEELPLANNINGS steelPlannings = null;
                MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY = null;
                HOLDS mainItemHold = null;
                STEEL_QUANTITIES steelQty = null;
                STEEL_ESTIMATED_QUANTITIES steelEstimateQty = null;

                int holdType = _configuration.GetValue<int>("Items:DefaultHoldType");
                int holdDept = _configuration.GetValue<int>("Items:DefaultHoldDept");
                int tagTypeSteel = _configuration.GetValue<int>("Steel:TagTypeSteel");
                string lotName = _configuration.GetValue<string>("Items:DefaultLotName");
                string elementName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");

                var lot = await _context.LOTS.Where(l => l.ProjectID == project.ProjectID && l.NAME == lotName).FirstOrDefaultAsync();
                var vendor = await _context.VENDORS.Where(v => v.ProjectID == project.ProjectID && v.COMPANYNAME == elementName).FirstOrDefaultAsync();
                var po = await _context.PURCHASEORDERS.Where(p => p.ProjectID == project.ProjectID && p.NAME == elementName).FirstOrDefaultAsync();
                var mr = await _context.MATERIALREQUESTS.Where(m => m.ProjectID == project.ProjectID && m.NAME == elementName).FirstOrDefaultAsync();
                var commodities = await _context.COMMODITYCODES.Where(c => c.ProjectID == project.ProjectID && c.Selected).ToListAsync();
                var wpItem = await _context.WORKINGPACKAGES.Where(w => w.NAME == wp && w.ProjectID == project.ProjectID).FirstOrDefaultAsync();

                bool isSteel = false;

                if (project != null && tagType != null && pbs != null)
                {
                    isSteel = tagType.TagTypeID == tagTypeSteel;

                    MAINITEMS item = new MAINITEMS();
                    item.PBS = selectedpbs;
                    item.PBSID = item.PBS.PBSID;
                    item.TAGTYPES = tagType;
                    item.TagTypeID = tagType.TagTypeID;
                    item.MainItemTag = tcmtag;
                    item.TagDescription = tagdescription;
                    item.TagClient = tagclient;
                    item.AddedManually = 1;
                    item.WORKINGPACKAGESID = wpItem.IDWP;
                    item.LV01_Object_CodeID = null;
                    item.LV01_Material_Work_GroupID = null;
                    item.PARENTID = mainItemToReplace.MainItemID;

                    // Set User and Date
                    item.UserID = user.USERID;
                    item.CreationDate = DateTime.UtcNow;
                    item.LastModified = DateTime.UtcNow;

                    if (isSteel)
                    {
                        item.VENDORSID = vendor.IDVENDOR;
                        item.MATERIALREQUESTSID = mr.IDMR;
                        item.PURCHASEORDERSID = po.IDPO;
                        item.LOTSID = lot.IDLOT;
                    }

                    _context.MAINITEMS.Add(item);

                    mainItemToReplace.MAINITEMSTATUSID = MainItemsCostants.REPLACED;
                    item.MAINITEMSTATUSID = MainItemsCostants.REPLACER;

                    using (var dbContextTransaction = _context.Database.BeginTransaction())
                    {
                        try
                        {
                            int result = _context.SaveChanges(true);
                            var mainItemAdded = await _context.MAINITEMS.FirstOrDefaultAsync(m => m.MainItemTag == item.MainItemTag);
                            if (!isSteel)
                            {
                                var planningItemReplaced = await _context.PLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainItemToReplace.MainItemID);
                                if (mainItemAdded != null && planningItemReplaced != null)
                                {
                                    // Add empty planning
                                    pLANNINGS = new PLANNINGS(planningItemReplaced);
                                    pLANNINGS.MainItemId = mainItemAdded.MainItemID;
                                    // Set User and Date
                                    pLANNINGS.UserID = user.USERID;
                                    pLANNINGS.CreationDate = DateTime.UtcNow;
                                    pLANNINGS.LastModified = DateTime.UtcNow;
                                    _context.PLANNINGS.Add(pLANNINGS);

                                    mAIN_ITEM_QUANTITY = new MAIN_ITEM_QUANTITY();
                                    mAIN_ITEM_QUANTITY.MainItemId = mainItemAdded.MainItemID;
                                    // Set User and Date
                                    mAIN_ITEM_QUANTITY.UserID = user.USERID;
                                    mAIN_ITEM_QUANTITY.CreationDate = DateTime.UtcNow;
                                    mAIN_ITEM_QUANTITY.LastModified = DateTime.UtcNow;
                                    _context.MAIN_ITEM_QUANTITY.Add(mAIN_ITEM_QUANTITY);

                                    //mainItemHold = new HOLDS(item, user.USERID.Value, holdType, holdDept);
                                    //_context.HOLDS.Add(mainItemHold);

                                    result = _context.SaveChanges(true);
                                }
                            }
                            else
                            {
                                var planningSteelItemReplaced = await _context.STEELPLANNINGS.FirstOrDefaultAsync(m => m.MainItemId == mainItemToReplace.MainItemID);
                                if (mainItemAdded != null && planningSteelItemReplaced != null)
                                {
                                    // Add empty planning
                                    steelPlannings = new STEELPLANNINGS(planningSteelItemReplaced);
                                    steelPlannings.MainItemId = mainItemAdded.MainItemID;
                                    // Set User and Date
                                    steelPlannings.UserID = user.USERID;
                                    steelPlannings.CreationDate = DateTime.UtcNow;
                                    steelPlannings.LastModified = DateTime.UtcNow;
                                    _context.STEELPLANNINGS.Add(steelPlannings);

                                    steelEstimateQty = new STEEL_ESTIMATED_QUANTITIES();
                                    steelEstimateQty.MainItemId = mainItemAdded.MainItemID;
                                    steelEstimateQty.IFF_DELTA_QTY = 0.0;
                                    steelEstimateQty.IFF_E_QTY = 0.0;
                                    steelEstimateQty.IFP_DELTA_QTY = 0.0;
                                    steelEstimateQty.IFP_E_QTY = 0.0;
                                    steelEstimateQty.PO_E_QTY = 0.0;
                                    steelEstimateQty.UserID = user.USERID;
                                    steelEstimateQty.CreationDate = DateTime.UtcNow;
                                    steelEstimateQty.LastModified = DateTime.UtcNow;
                                    _context.STEEL_ESTIMATED_QUANTITIES.Add(steelEstimateQty);

                                    if (commodities != null)
                                    {
                                        foreach (COMMODITYCODES commodityCode in commodities)
                                        {
                                            steelQty = new STEEL_QUANTITIES();
                                            steelQty.MainItemId = mainItemAdded.MainItemID;
                                            steelQty.CodeId = commodityCode.CodeID;
                                            steelQty.QTY = 0.0;
                                            steelQty.UserID = user.USERID;
                                            steelQty.CreationDate = DateTime.UtcNow;
                                            steelQty.LastModified = DateTime.UtcNow;
                                            _context.STEEL_QUANTITIES.Add(steelQty);
                                        }
                                    }

                                    result = _context.SaveChanges(true);
                                }
                            }
                            dbContextTransaction.Commit();
                            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_REPLACED);
                        }
                        catch (Exception ex)
                        {
                            msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_REPLACED, ex.Message);
                            dbContextTransaction.Rollback();
                            return ex.Message;
                        }
                    }
                }
                else
                {
                    msg = _sharedResource.Message(MESSAGE_CODES.MAIN_ITEM_NOT_CREATED);
                }
            }
            return msg;
        }

        private bool ContainsItem(MAINITEMS item, int id, List<MAINITEMS> items)
        {
            string value = item.CalculateMainTag(id, true);
            foreach (MAINITEMS currentItem in items)
                if (currentItem.MainItemTag.ToUpper() == value.ToUpper() && item.TagTypeID == currentItem.TagTypeID)
                    return true;
            return false;
        }
    }
}