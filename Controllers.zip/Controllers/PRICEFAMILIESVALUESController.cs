﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models.PriceList;
using CivilMasterData.Models;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Users;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.IO;
using OfficeOpenXml;
using CivilMasterData.Models.Costants;

namespace CivilMasterData
{
    public class PRICEFAMILIESVALUESController : Controller
    {
        private readonly PRICEFAMILIESVALUESContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public PRICEFAMILIESVALUESController(PRICEFAMILIESVALUESContext context,
            IConfiguration configuration, ISharedResource sharedResource, IWebHostEnvironment env)
        {
            _context = context;
            _configuration = configuration;
            this._sharedResource = sharedResource;
            _env = env;
        }

        // GET: PRICEFAMILIESVALUES
        public async Task<IActionResult> Index(string code)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                    if (user == null)
                        return NotFound();
                    if (user.IsDisabled)
                        return Redirect("~/Home/NoPermission");

                    if (String.IsNullOrEmpty(code))
                        return NotFound();
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    _context.ProjectID = project.ProjectID;
                    if (project == null)
                        return NotFound();
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    var pRICECODEDEFINITIONS = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).Include(p => p.Project).ToListAsync();
                    var priceFamilies = await _context.PRICEFAMILIESVALUES.Where(p => p.ProjectID == project.ProjectID).Include(p => p.Project).Include(p => p.PRICECODEDEFINITIONS).ToListAsync();


                    return View(priceFamilies);
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return NotFound();
        }

        // GET: PRICEFAMILIESVALUES/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICEFAMILIESVALUES = await _context.PRICEFAMILIESVALUES
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.FamilyValueID == id);
            if (pRICEFAMILIESVALUES == null)
            {
                return NotFound();
            }

            return View(pRICEFAMILIESVALUES);
        }

        // GET: PRICEFAMILIESVALUES/Create
        public async Task<IActionResult> Create(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var codes = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
            ViewBag.PriceCodeGroups = codes.Select(p => p.GroupCode);
            return View();
        }

        // POST: PRICEFAMILIESVALUES/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("FamilyValueID,ProjectID,FamilyName,Formula,Unit,PriceCodeDefinitionID,LengthValue,WidthValue,HeightValue,AreaValue,WeightValue")] PRICEFAMILIESVALUES pRICEFAMILIESVALUES,
            string priceCodeGroups, int projectId)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (ModelState.IsValid && user != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == projectId);
                    ViewBag.ProjectID = project.ProjectID;
                    ViewBag.Project = project.Code;

                    if (project != null)
                    {
                        var codes = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                        ViewBag.PriceCodeGroups = codes.Select(p => p.GroupCode);
                        var priceDef = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID && p.GroupCode == priceCodeGroups).FirstOrDefaultAsync();

                        ViewBag.ProjectID = project.ProjectID;
                        ViewBag.Project = project.Code;

                        if (priceDef == null)
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.FAMILY_FORMULA_NOT_VALID);
                        }
                        else
                        {
                            pRICEFAMILIESVALUES.ProjectID = project.ProjectID;
                            pRICEFAMILIESVALUES.PRICECODEDEFINITIONSID = priceDef.PriceCodeDefinitionID.Value;
                            _context.Add(pRICEFAMILIESVALUES);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.FAMILY_FORMULA_CREATED);
                        }
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.FAMILY_FORMULA_NOT_VALID);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pRICEFAMILIESVALUES);
        }


        // GET: PRICEFAMILIESVALUES/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICEFAMILIESVALUES = await _context.PRICEFAMILIESVALUES.Include(p => p.PRICECODEDEFINITIONS).Where(p => p.FamilyValueID == id.Value).FirstOrDefaultAsync();
            if (pRICEFAMILIESVALUES == null)
            {
                return NotFound();
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICEFAMILIESVALUES.ProjectID);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(pRICEFAMILIESVALUES);
        }

        // POST: PRICEFAMILIESVALUES/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id,
            [Bind("FamilyValueID,PRICECODEID,ProjectID,FamilyName,Formula,Unit,PriceCodeDefinitionID,LengthValue,WidthValue,HeightValue,AreaValue,WeightValue")] PRICEFAMILIESVALUES pRICEFAMILIESVALUES)
        {
            if (id != pRICEFAMILIESVALUES.FamilyValueID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _context.PRICECODES.Where(p => p.ProjectID == pRICEFAMILIESVALUES.ProjectID).ToListAsync();
                    _context.Update(pRICEFAMILIESVALUES);
                    await _context.SaveChangesAsync();
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.FORMULA_SAVED);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PRICEFAMILIESVALUESExists(pRICEFAMILIESVALUES.FamilyValueID.Value))
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.FORMULA_NOT_SAVED);
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == pRICEFAMILIESVALUES.ProjectID);
            _context.ProjectID = project.ProjectID;

            if (project == null)
                return NotFound();

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View(pRICEFAMILIESVALUES);
        }

        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteFormulas(string idStr)
        {
            try
            {
                int[] pbsList = Utils.SplitIntVector(idStr);
                if (pbsList != null && pbsList.Length > 0)
                {
                    foreach (int id in pbsList)
                    {
                        var group = await _context.PRICEFAMILIESVALUES.FindAsync(id);
                        if (group != null)
                            _context.PRICEFAMILIESVALUES.Remove(group);
                    }
                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
            return string.Empty;
        }


        // POST: PBS/Delete/5
        [HttpPost]
        public async Task<string> DeleteFamily(int id)
        {
            try
            {
                var group = await _context.PRICEFAMILIESVALUES.FindAsync(id);
                if (group != null)
                {
                    _context.PRICEFAMILIESVALUES.Remove(group);
                    await _context.SaveChangesAsync();
                }
                return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // GET: PRICEFAMILIESVALUES/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pRICEFAMILIESVALUES = await _context.PRICEFAMILIESVALUES
                .Include(p => p.Project)
                .FirstOrDefaultAsync(m => m.FamilyValueID == id);
            if (pRICEFAMILIESVALUES == null)
            {
                return NotFound();
            }

            return View(pRICEFAMILIESVALUES);
        }

        // POST: PRICEFAMILIESVALUES/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pRICEFAMILIESVALUES = await _context.PRICEFAMILIESVALUES.FindAsync(id);
            _context.PRICEFAMILIESVALUES.Remove(pRICEFAMILIESVALUES);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<string> ImportExcel(IFormFile postedFile, string code)
        {
            string msg = string.Empty;
            string lfcr = "\r\n";
            try
            {
                if (postedFile != null)
                {
                    var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                    if (project == null)
                        return "Project not found";

                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    var projectSettings = await _context.PROJECTSETTINGS
                            .FirstOrDefaultAsync(m => m.ProjectID == project.ProjectID);
                    if (projectSettings == null)
                    {
                        projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                    }

                    var codes = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    List<string> names = new List<string>();
                    if (codes != null)
                        names = codes.Select(c => c.GroupCode).ToList();
                    var families = await _context.PRICEFAMILIESVALUES.Where(p => p.ProjectID == project.ProjectID).ToListAsync();
                    List<string> familyNames = new List<string>();
                    if (families != null)
                        familyNames = families.Select(c => c.FamilyName.ToUpperInvariant()).ToList();

                    // Read Data
                    List<string> codeList = new List<string>();
                    List<string> nameList = new List<string>();
                    List<string> formulaList = new List<string>();
                    List<string> unitList = new List<string>();
                    List<string> lengthList = new List<string>();
                    List<string> widthList = new List<string>();
                    List<string> heightList = new List<string>();
                    List<string> areaList = new List<string>();
                    List<string> weightList = new List<string>();


                    bool notEmpty = true;
                    int counter = 3;
                    while (notEmpty)
                    {
                        try
                        {
                            string familyName = worksheet.Cells[counter, 1].Value != null ? worksheet.Cells[counter, 1].Value.ToString() : string.Empty;
                            string priceCode = worksheet.Cells[counter, 2].Value != null ? worksheet.Cells[counter, 2].Value.ToString() : string.Empty;
                            string formula = worksheet.Cells[counter, 3].Value != null ? worksheet.Cells[counter, 3].Value.ToString() : string.Empty;
                            string unit = worksheet.Cells[counter, 4].Value != null ? worksheet.Cells[counter, 4].Value.ToString() : string.Empty;
                            string length = worksheet.Cells[counter, 5].Value != null ? worksheet.Cells[counter, 5].Value.ToString() : string.Empty;
                            string width = worksheet.Cells[counter, 6].Value != null ? worksheet.Cells[counter, 6].Value.ToString() : string.Empty;
                            string height = worksheet.Cells[counter, 7].Value != null ? worksheet.Cells[counter, 7].Value.ToString() : string.Empty;
                            string area = worksheet.Cells[counter, 8].Value != null ? worksheet.Cells[counter, 8].Value.ToString() : string.Empty;
                            string weight = worksheet.Cells[counter, 9].Value != null ? worksheet.Cells[counter, 9].Value.ToString() : string.Empty;

                            if (string.IsNullOrEmpty(priceCode) || string.IsNullOrEmpty(familyName))
                                notEmpty = false;
                            else
                            {
                                codeList.Add(priceCode);
                                nameList.Add(familyName);
                                formulaList.Add(formula);
                                unitList.Add(unit);
                                lengthList.Add(length);
                                widthList.Add(width);
                                heightList.Add(height);
                                areaList.Add(area);
                                weightList.Add(weight);
                            }
                            counter++;
                        }
                        catch
                        {
                            notEmpty = false;
                        }
                    }

                    if (User.Identity.IsAuthenticated)
                    {
                        try
                        {
                            string name = User.Identity.Name;
                            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                            if (user == null)
                                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);

                            ViewBag.ProjectID = project.ProjectID;
                            ViewBag.Project = project.Code;

                            PRICECODEDEFINITIONS pRICECODEDEFINITIONS = null;
                            for (int i = 0; i < codeList.Count; i++)
                            {
                                if (codes != null)
                                    pRICECODEDEFINITIONS = codes.Where(g => g.GroupCode == codeList[i]).FirstOrDefault();
                                if (pRICECODEDEFINITIONS == null)
                                {
                                    msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, codeList[i]) + lfcr;
                                    continue;
                                }
                                var priceFamily = _context.PRICEFAMILIESVALUES.Where(p => p.ProjectID == project.ProjectID && p.FamilyName.ToUpperInvariant() == nameList[i].ToUpperInvariant() &&
                                    p.PRICECODEDEFINITIONSID == pRICECODEDEFINITIONS.PriceCodeDefinitionID).FirstOrDefault();
                                if (priceFamily != null)
                                {
                                    msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, codeList[i]) + lfcr;
                                    continue;
                                }
                                PRICEFAMILIESVALUES pRICEFAMILIESVALUES = new PRICEFAMILIESVALUES();
                                pRICEFAMILIESVALUES.PRICECODEDEFINITIONSID = pRICECODEDEFINITIONS.PriceCodeDefinitionID.Value;
                                pRICEFAMILIESVALUES.FamilyName = nameList[i];
                                pRICEFAMILIESVALUES.Formula = formulaList[i];
                                pRICEFAMILIESVALUES.Unit = unitList[i];
                                pRICEFAMILIESVALUES.LengthValue = lengthList[i];
                                pRICEFAMILIESVALUES.WidthValue = widthList[i];
                                pRICEFAMILIESVALUES.HeightValue = heightList[i];
                                pRICEFAMILIESVALUES.AreaValue = areaList[i];
                                pRICEFAMILIESVALUES.WeightValue = weightList[i];
                                pRICEFAMILIESVALUES.ProjectID = project.ProjectID;
                                _context.PRICEFAMILIESVALUES.Add(pRICEFAMILIESVALUES);
                                await _context.SaveChangesAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message) + lfcr;
                        }
                    }
                    else
                    {
                        msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED) + lfcr;
                    }
                }
            }
            catch { }

            return string.IsNullOrEmpty(msg) ? "Imported" : msg;
        }

        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:PriceFormulaTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        private bool PRICEFAMILIESVALUESExists(int id)
        {
            return _context.PRICEFAMILIESVALUES.Any(e => e.FamilyValueID == id);
        }
    }
}
