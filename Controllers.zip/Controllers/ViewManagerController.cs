﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Utilities;
using CivilMasterData.Models.Views;
using Microsoft.Extensions.Configuration;

namespace CivilMasterData.Controllers
{
    public class ViewManagerController : Controller
    {
        private readonly ViewManagerContext _context;
        private IConfiguration _configuration;

        public ViewManagerController(ViewManagerContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // GET: PROJECTS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return NotFound();
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            DatabaseCostants.InitValues(_configuration);

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;

            var projectSettings = await _context.PROJECTSETTINGS.Where(p => p.ProjectID == pROJECTS.ProjectID).FirstOrDefaultAsync();

            //var holdTypes = await _context.HOLDTYPES.ToListAsync();
            //var holdDepts = await _context.HOLDDEPTS.ToListAsync();
            //var items = await _context.ITEMS.Where(i => i.Project == code).ToListAsync();
            //var holds = await _context.HOLDLISTS.Where(i => i.Project == code).ToListAsync();
            //var planning = await _context.PROJECTPLANNINGS.Where(i => i.Project == code).ToListAsync();
            //var mainItems = await _context.MAINITEMS.Where(x => x.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            //var mainItemsRev = await _context.MTOREVS.Where(x => x.MAINITEMS.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            //var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            //var steelItems = await _context.STEELVENDORITEMLISTS.Where(x => x.Project == code).ToListAsync();
            //var secondaryItems = await _context.SECONDARYITEMS.Where(x => x.Project == code).ToListAsync();

            ViewManager viewManager = new ViewManager();
            //viewManager.Project = pROJECTS;
            //viewManager.ITEMS = items;
            //viewManager.HOLDLISTS = holds;
            //viewManager.PROJECTPLANNINGS = planning;
            //viewManager.MAINITEMS = mainItems;
            //viewManager.STEELVENDORITEMLISTS = steelItems;
            //viewManager.SECONDARYITEMS = secondaryItems;

            // Calculate Tag Types Qty
            viewManager.TagTypeResult = new List<TagTypeResult>();
            var tagTypes = await _context.TAGTYPES.OrderBy(t => t.TagTypeID).ToListAsync();
            var qtyCEList = await _context.MAIN_ITEM_QUANTITY_CE.Include(q => q.MAINITEMS.PBS).Where(q => q.MAINITEMS.PBS.ProjectID ==
                pROJECTS.ProjectID).ToListAsync();
            if (tagTypes != null)
            {
                foreach (TAGTYPES tagType in tagTypes)
                {
                    if (tagType.TagTypeID == 1)
                        continue;
                    var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Where(m => m.PBS.ProjectID == pROJECTS.ProjectID &&
                        m.TagTypeID == tagType.TagTypeID && !m.IsDeleted && !m.IsReplaced && !m.IsBalance).ToListAsync();
                    TagTypeResult tagTypeResult = new TagTypeResult();
                    tagTypeResult.Description = tagType.Description;
                    if (mainItems != null)
                        tagTypeResult.Items = mainItems.Count;

                    // Get QTY CE
                    if (mainItems != null)
                    {
                        var ids = mainItems.Select(m => m.MainItemID).ToList();
                        if (qtyCEList != null)
                        {
                            var ceQty = qtyCEList.Where(q => ids.Contains(q.MainItemId) && q.QTY_CE != null && q.QTY_CE.HasValue).ToList();
                            if (ceQty != null)
                                tagTypeResult.QtyCE = ceQty.Sum(q => q.QTY_CE.Value);
                        }
                    }
                    tagTypeResult.Unit = TAGTYPES.QtyUnitsShort(projectSettings, tagType.TagTypeID);
                    viewManager.TagTypeResult.Add(tagTypeResult);
                }
            }

            // Update Models
            var bim360Items = await _context.BIM360ITEMSTATUS.Where(p => p.ProjectID == pROJECTS.ProjectID).ToListAsync();
            if (bim360Items != null)
            {
                var concreteModels = bim360Items.Where(m => m.ModelName.Contains("AA")).Select(m => m.ModelName).Distinct().ToList();
                var steelModels = bim360Items.Where(m => m.ModelName.Contains("AI")).Select(m => m.ModelName).Distinct().ToList();
                var undergroundModels = bim360Items.Where(m => m.ModelName.Contains("AQ")).Select(m => m.ModelName).Distinct().ToList();
                var pavingModels = bim360Items.Where(m => m.ModelName.Contains("AP") || m.ModelName.Contains("AR")).Select(m => m.ModelName).Distinct().ToList();
                if (concreteModels != null)
                    viewManager.ConcreteModels = concreteModels.Count;
                if (steelModels != null)
                    viewManager.SteelModels = steelModels.Count;
                if (undergroundModels != null)
                    viewManager.UndergroundModels = undergroundModels.Count;
                if (pavingModels != null)
                    viewManager.PavingModels = pavingModels.Count;
            }

            //// Update revisions foreach MainItems
            //if (items != null)
            //{
            //    foreach (ITEMS item in items)
            //    {
            //        item.MAIN_ITEM_QTY_REV = mainItemsRev.Where(m => m.MAINITEMID.Value == item.MainItemID.Value).ToList();
            //        item.MAIN_ITEM_QTY = mainItemsQty.Where(m => m.MainItemId == item.MainItemID.Value).FirstOrDefault();
            //    }
            //}

            return View(viewManager);
        }

        public async Task<IActionResult> Items(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            var items = await _context.ITEMS.Where(i => i.Project == code).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pROJECTS.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            items = MainItemUtils.OrderItems(items, projectSettings.BALANCE);

            return View(items);
        }

        public async Task<IActionResult> QuantityItems(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            var items = await _context.ITEMS.Where(i => i.Project == code).ToListAsync();
            var mainItemsRev = await _context.MTOREVS.Where(x => x.MAINITEMS.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();

            // Update revisions foreach MainItems
            if (items != null)
            {
                foreach (ITEMS item in items)
                {
                    item.MAIN_ITEM_QTY_REV = mainItemsRev.Where(m => m.MAINITEMID.Value == item.MainItemID.Value).ToList();
                    item.MAIN_ITEM_QTY = mainItemsQty.Where(m => m.MainItemId == item.MainItemID.Value).FirstOrDefault();
                }
            }

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pROJECTS.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            items = MainItemUtils.OrderItems(items, projectSettings.BALANCE);

            return View(items);
        }

        public async Task<IActionResult> Holds(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            var holds = await _context.HOLDLISTS.Where(i => i.Project == code).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pROJECTS.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            holds = MainItemUtils.OrderHoldList(holds, projectSettings.BALANCE);

            return View(holds);
        }

        public async Task<IActionResult> Planning(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            var planning = await _context.PROJECTPLANNINGS.Where(i => i.Project == code).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pROJECTS.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            planning = MainItemUtils.OrderProjectPlanning(planning, projectSettings.BALANCE);

            return View(planning);
        }

        public async Task<IActionResult> SecondaryItems(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            var secondaryItems = await _context.SECONDARYITEMS.Where(x => x.Project == code).ToListAsync();
            if (secondaryItems != null)
                secondaryItems = secondaryItems.OrderBy(s => s.ItemTag).ToList();
            return View(secondaryItems);
        }

        public async Task<IActionResult> SteelItems(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            var steelItems = await _context.STEELVENDORITEMLISTS.Where(x => x.Project == code).ToListAsync();

            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pROJECTS.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            steelItems = MainItemUtils.OrderSteelItems(steelItems, projectSettings.BALANCE);

            return View(steelItems);
        }

        public async Task<IActionResult> Overalls(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectID = pROJECTS.ProjectID;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;

            // Get Items
            var items = await _context.ITEMS.Where(i => i.Project == code).ToListAsync();
            var projectSettings = await _context.PROJECTSETTINGS
                        .FirstOrDefaultAsync(m => m.ProjectID == pROJECTS.ProjectID);
            if (projectSettings == null)
            {
                projectSettings = await _context.PROJECTSETTINGS
                .FirstOrDefaultAsync(m => m.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
            }

            items = MainItemUtils.OrderItems(items, projectSettings.BALANCE);

            // Update QTY
            var mainItemsRev = await _context.MTOREVS.Where(x => x.MAINITEMS.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();
            var mainItemsQty = await _context.MAIN_ITEM_QUANTITY.Where(x => x.MAINITEMS.PBS.ProjectID == pROJECTS.ProjectID).ToListAsync();

            // Update revisions foreach MainItems
            if (items != null)
            {
                foreach (ITEMS item in items)
                {
                    item.MAIN_ITEM_QTY_REV = mainItemsRev.Where(m => m.MAINITEMID.Value == item.MainItemID.Value).ToList();
                    item.MAIN_ITEM_QTY = mainItemsQty.Where(m => m.MainItemId == item.MainItemID.Value).FirstOrDefault();
                }
            }

            // Holds
            var holds = await _context.HOLDLISTS.Where(i => i.Project == code).ToListAsync();

            // Plannings
            var planning = await _context.PROJECTPLANNINGS.Where(i => i.Project == code).ToListAsync();

            List<OVERALLS> overalls = new List<OVERALLS>();
            if (items != null)
            {
                foreach (var item in items)
                {
                    OVERALLS current = new OVERALLS();
                    current.ITEMS = item;
                    current.HOLDLISTS = holds != null ? holds.Where(d => d.ItemId == item.MainItemID).FirstOrDefault() : null;
                    current.PROJECTPLANNINGS = planning != null ? planning.Where(d => d.ItemId == item.MainItemID).FirstOrDefault() : null;
                    overalls.Add(current);
                }
            }

            return View(overalls);
        }
    }
}
