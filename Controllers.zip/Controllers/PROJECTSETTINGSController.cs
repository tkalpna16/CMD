﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Users;
using AuthorizeAttribute = CivilMasterData.Models.Users.AuthorizeAttribute;
using Microsoft.AspNetCore.Http;
using CivilMasterData.Models.Utilities;
using System;

namespace CivilMasterData.Controllers
{
    [UnAuthorized]
    public class PROJECTSETTINGSController : Controller
    {
        private readonly PROJECTSETTINGSContext _context;
        protected readonly ISharedResource _sharedResource;

        public PROJECTSETTINGSController(PROJECTSETTINGSContext context, ISharedResource sharedResource)
        {
            _context = context;
            this._sharedResource = sharedResource;
        }

        // GET: PROJECTSETTINGS/Edit/5
        [HttpGet]
        public async Task<IActionResult> Edit(string code)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (string.IsNullOrEmpty(code) || user == null)
                {
                    return NotFound();
                }
                if (user.IsDisabled)
                    return Redirect("~/Home/NoPermission");

                var project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.Code == code);
                if (project == null)
                {
                    project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.GetCompleteDescription == code);
                    if (project == null)
                        return NotFound();
                }

                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;

                int id = project.ProjectID;
                var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == id);
                var pROJECTSETTINGSDefault = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                if (pROJECTSETTINGS == null)
                {
                    // Create the first
                    pROJECTSETTINGS = new PROJECTSETTINGS(pROJECTSETTINGSDefault, id);

                    // Set user and creation date
                    pROJECTSETTINGS.UserID = user.USERID;
                    pROJECTSETTINGS.USERS = user;
                    pROJECTSETTINGS.CreationDate = DateTime.UtcNow;
                    pROJECTSETTINGS.LastModified = DateTime.UtcNow;

                    _context.Add(pROJECTSETTINGS);
                    await _context.SaveChangesAsync();
                }
                if (pROJECTSETTINGS == null)
                {
                    return NotFound();
                }
                return View(pROJECTSETTINGS);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return Redirect("~/Home/NoPermission");
        }

        // POST: PROJECTSETTINGS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string code, [Bind("ProjectSettingID,ProjectID,CWA,SUBAREA,BALANCE,DRAWINGNUMBER,DRAWINGCWADIGIT,DRAWINGOBJECTDIGIT,DRAWINGSEQDIGIT,DRAWINGDESCITEMS,DRAWINGDESCAREA,DRAWINGDESCCOMMON,BIM360PARAMETERS,ELEVATIONCONCRETEUNIT,FOUNDATIONCONCRETEUNIT,PAVINGUNIT,PILESUNIT,STEELUNIT,UNDERGROUNDPIPEUNIT,CONCRETESLABUNIT")] PROJECTSETTINGS pROJECTSETTINGS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null)
                {
                    try
                    {
                        var project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.ProjectID == pROJECTSETTINGS.ProjectID);
                        if (project == null)
                        {
                            return NotFound();
                        }

                        ViewBag.Project = project.Code;

                        pROJECTSETTINGS.DRAWINGCWADIGIT = ReplaceString(pROJECTSETTINGS.DRAWINGCWADIGIT);
                        pROJECTSETTINGS.DRAWINGOBJECTDIGIT = ReplaceString(pROJECTSETTINGS.DRAWINGOBJECTDIGIT);
                        pROJECTSETTINGS.DRAWINGSEQDIGIT = ReplaceString(pROJECTSETTINGS.DRAWINGSEQDIGIT);

                        // Set user and creation date
                        pROJECTSETTINGS.UserID = user.USERID;
                        pROJECTSETTINGS.USERS = user;
                        pROJECTSETTINGS.CreationDate = DateTime.UtcNow;
                        pROJECTSETTINGS.LastModified = DateTime.UtcNow;

                        _context.Update(pROJECTSETTINGS);
                        await _context.SaveChangesAsync();

                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_SETTINGS_SAVED);
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        if (!PROJECTSETTINGSExists(pROJECTSETTINGS.ProjectSettingID))
                        {
                            return NotFound();
                        }
                        else
                        {
                            throw;
                        }
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_SETTINGS_NOT_SAVED);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pROJECTSETTINGS);
        }


        // POST: PROJECTSETTINGS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<string> SaveSettings(string code,
            string cwa,
            string balance,
            string DRAWINGNUMBER,
            string DRAWINGCWADIGIT,
            string DRAWINGOBJECTDIGIT,
            string DRAWINGSEQDIGIT,
            string DRAWINGDESCITEMS,
            string DRAWINGDESCAREA,
            string DRAWINGDESCCOMMON,
            string BIM360PARAMETERS,
            string ELEVATIONCONCRETEUNIT,
            string FOUNDATIONCONCRETEUNIT,
            string PAVINGUNIT,
            string PILESUNIT,
            string STEELUNIT,
            string UNDERGROUNDPIPEUNIT,
            string CONCRETESLABUNIT,
            int NDOCS,
            int MANUALNDOCS,
            int MAXDOCS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (ModelState.IsValid && user != null)
                {
                    try
                    {
                        var project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.Code == code);
                        if (project == null)
                        {
                            return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                        }

                        ViewBag.Project = project.Code;

                        var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == project.ProjectID);
                        var pROJECTSETTINGSDefault = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                        if (pROJECTSETTINGS == null)
                        {
                            // Create the first
                            pROJECTSETTINGS = new PROJECTSETTINGS(pROJECTSETTINGSDefault, project.ProjectID);

                            // Set user and creation date
                            pROJECTSETTINGS.UserID = user.USERID;
                            pROJECTSETTINGS.USERS = user;
                            pROJECTSETTINGS.CreationDate = DateTime.UtcNow;
                            pROJECTSETTINGS.LastModified = DateTime.UtcNow;

                            _context.Add(pROJECTSETTINGS);
                            await _context.SaveChangesAsync();
                        }


                        pROJECTSETTINGS.CWA = cwa;
                        pROJECTSETTINGS.BALANCE = balance;
                        pROJECTSETTINGS.DRAWINGNUMBER = DRAWINGNUMBER;
                        pROJECTSETTINGS.DRAWINGCWADIGIT = DRAWINGCWADIGIT;
                        pROJECTSETTINGS.DRAWINGOBJECTDIGIT = DRAWINGOBJECTDIGIT;
                        pROJECTSETTINGS.DRAWINGSEQDIGIT = DRAWINGSEQDIGIT;
                        pROJECTSETTINGS.DRAWINGDESCITEMS = DRAWINGDESCITEMS;
                        pROJECTSETTINGS.DRAWINGDESCAREA = DRAWINGDESCAREA;
                        pROJECTSETTINGS.DRAWINGDESCCOMMON = DRAWINGDESCCOMMON;
                        pROJECTSETTINGS.BIM360PARAMETERS = BIM360PARAMETERS;
                        pROJECTSETTINGS.ELEVATIONCONCRETEUNIT = ELEVATIONCONCRETEUNIT;
                        pROJECTSETTINGS.FOUNDATIONCONCRETEUNIT = FOUNDATIONCONCRETEUNIT;
                        pROJECTSETTINGS.PAVINGUNIT = PAVINGUNIT;
                        pROJECTSETTINGS.PILESUNIT = PILESUNIT;
                        pROJECTSETTINGS.STEELUNIT = STEELUNIT;
                        pROJECTSETTINGS.UNDERGROUNDPIPEUNIT = UNDERGROUNDPIPEUNIT;
                        pROJECTSETTINGS.CONCRETESLABUNIT = CONCRETESLABUNIT;

                        pROJECTSETTINGS.DRAWINGCWADIGIT = ReplaceString(pROJECTSETTINGS.DRAWINGCWADIGIT);
                        pROJECTSETTINGS.DRAWINGOBJECTDIGIT = ReplaceString(pROJECTSETTINGS.DRAWINGOBJECTDIGIT);
                        pROJECTSETTINGS.DRAWINGSEQDIGIT = ReplaceString(pROJECTSETTINGS.DRAWINGSEQDIGIT);

                        if (NDOCS < 0)
                            NDOCS = 0;
                        pROJECTSETTINGS.DRAWING_MAX_NDOCS = NDOCS;
                        if (MANUALNDOCS < 0)
                            MANUALNDOCS = 0;
                        pROJECTSETTINGS.DRAWING_MAX_MANUAL_NDOCS = MANUALNDOCS;

                        if (MAXDOCS < 0)
                            MAXDOCS = 100;
                        pROJECTSETTINGS.DRAWING_MAX_FOR_TYPE = MAXDOCS;

                        // Set user and creation date
                        pROJECTSETTINGS.UserID = user.USERID;
                        pROJECTSETTINGS.USERS = user;
                        pROJECTSETTINGS.CreationDate = DateTime.UtcNow;
                        pROJECTSETTINGS.LastModified = DateTime.UtcNow;

                        _context.Update(pROJECTSETTINGS);
                        await _context.SaveChangesAsync();

                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_SETTINGS_SAVED);
                    }
                    catch (Exception ex)
                    {
                        return ex.Message;
                    }
                }
                else
                {
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_SETTINGS_NOT_SAVED);
                }
            }
            else
            {
                return _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return _sharedResource.Message(MESSAGE_CODES.PROJECT_SETTINGS_SAVED);
        }


        private string ReplaceString(string value)
        {
            if (string.IsNullOrEmpty(value))
                return value;
            string newValue = string.Empty;
            for (int i = 0; i < value.Length; i++)
                newValue += "0";
            return newValue;
        }

        // GET: PROJECTSETTINGS/Edit/5
        [HttpGet]
        public async Task<IActionResult> PriceCodesManager(string code)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (string.IsNullOrEmpty(code) || user == null)
                {
                    return NotFound();
                }

                var project = await _context.PROJECTS.FirstOrDefaultAsync(x => x.Code == code);
                if (project == null)
                {
                    return NotFound();
                }

                ViewBag.Project = project.Code;
                ViewBag.ProjectDescription = project.GetCompleteDescription;

                int id = project.ProjectID;
                var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == id);
                var pROJECTSETTINGSDefault = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                if (pROJECTSETTINGS == null)
                {
                    // Create the first
                    pROJECTSETTINGS = new PROJECTSETTINGS(pROJECTSETTINGSDefault, id);

                    // Set user and creation date
                    pROJECTSETTINGS.UserID = user.USERID;
                    pROJECTSETTINGS.USERS = user;
                    pROJECTSETTINGS.CreationDate = DateTime.UtcNow;
                    pROJECTSETTINGS.LastModified = DateTime.UtcNow;

                    _context.Add(pROJECTSETTINGS);
                    await _context.SaveChangesAsync();
                }
                if (pROJECTSETTINGS == null)
                {
                    return NotFound();
                }
                return View(pROJECTSETTINGS);
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return Redirect("~/Home/NoPermission");
        }

        private bool PROJECTSETTINGSExists(int id)
        {
            return _context.PROJECTSETTINGS.Any(e => e.ProjectSettingID == id);
        }
    }
}
