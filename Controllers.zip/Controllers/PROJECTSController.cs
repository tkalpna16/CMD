﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using System;
using Microsoft.Extensions.Configuration;
using CivilMasterData.Models.Drawing.Settings;
using CivilMasterData.Models.Costants;
using CivilMasterData.Models.Steel;
using CivilMasterData.Models.PriceList;
using System.Collections.Generic;

namespace CivilMasterData.Controllers
{
    [UnAuthorized]
    public class PROJECTSController : Controller
    {
        private readonly PROJECTSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;

        public PROJECTSController(PROJECTSContext context, ISharedResource sharedResource, IConfiguration configuration)
        {
            _context = context;
            this._sharedResource = sharedResource;
            this._configuration = configuration;
        }

        // GET: PROJECTS
        public async Task<IActionResult> Index(string code)
        {
            var projects = await _context.PROJECTS.ToListAsync();
            if (projects != null)
                projects = projects.OrderBy(p => p.GetCompleteDescription).ToList();

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.USERNAME.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");
            if (user.IsDisabled)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN && projects != null)
            {
                List<PROJECTS> visibleProjects = new List<PROJECTS>();
                foreach (PROJECTS prj in projects)
                {
                    var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == prj.ProjectID).FirstOrDefaultAsync();
                    if (userProject != null)
                        visibleProjects.Add(prj);
                }
                projects = visibleProjects;
            }

            ViewBag.Project = code;
            var currentProject = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (currentProject != null)
            {
                ViewBag.ProjectDescription = currentProject.GetCompleteDescription;
            }

            return View(projects);
        }

        public async Task<string> Delete(string code)
        {
            try
            {
                var currentProject = await _context.PROJECTS.FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
                if (currentProject != null)
                {
                    _context.PROJECTS.Remove(currentProject);
                    await _context.SaveChangesAsync();
                    return _sharedResource.Message(MESSAGE_CODES.ELEMENT_DELETED);
                }
                else
                {
                    return _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_FOUND);
                }
            }
            catch (Exception ex)
            {
                return _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
            }
        }

        // GET: PROJECTS/DataManagement?code=1
        public async Task<IActionResult> DataManagement(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
            if (pROJECTS == null)
            {
                pROJECTS = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
                if (pROJECTS == null)
                    return NotFound();
            }

            string name = User.Identity.Name;
            var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
            if (user == null)
                return Redirect("~/Home/NoPermission");

            if (user.ACCESS_LEVEL != Roles.ADMIN)
            {
                var userProject = await _context.PROJECTUSERS.Where(u => u.UserID == user.USERID && u.ProjectID == pROJECTS.ProjectID).FirstOrDefaultAsync();
                if (userProject == null)
                    return Redirect("~/Home/NoPermission");
            }

            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;
            return View(pROJECTS);
        }

        // GET: PROJECTS/DataManagement?code=1
        public async Task<IActionResult> SteelDataManagement(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;
            return View(pROJECTS);
        }

        // GET: PROJECTS/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PROJECTS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProjectID,Code,DLProjectCode,Title,Notes,StartDate,EndDate")] PROJECTS pROJECTS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                int globalProjectId = _configuration.GetValue<int>("Oracle:GlobalProjectId");
                var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code.ToUpper() == pROJECTS.Code.ToUpper());

                // Check Dates
                if (pROJECTS.StartDate == null || pROJECTS.EndDate == null || pROJECTS.StartDate >= pROJECTS.EndDate)
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_DATES_NOT_VALID);
                else if (project != null)
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_EXISTING);
                else
                {
                    if (ModelState.IsValid && user != null)
                    {
                        // Set user and creation date
                        pROJECTS.UserID = user.USERID;
                        pROJECTS.USERS = user;
                        pROJECTS.CreationDate = DateTime.UtcNow;
                        pROJECTS.LastModified = DateTime.UtcNow;

                        _context.Add(pROJECTS);
                        await _context.SaveChangesAsync();

                        // Add ObjectCode settings
                        var objectCodes = await _context.OBJECTCODES.Where(p => p.ProjectID == globalProjectId).ToListAsync();
                        if (objectCodes != null)
                        {
                            foreach (OBJECTCODES objectCode in objectCodes)
                            {
                                OBJECTCODES newObjectCode = objectCode.Copy(pROJECTS.ProjectID, user);
                                _context.OBJECTCODES.Add(newObjectCode);
                            }
                        }

                        // Add Document settings
                        var docTypes = await _context.DOCUMENTTYPES.ToListAsync();
                        if (docTypes != null)
                        {
                            foreach (DOCUMENTTYPES docType in docTypes)
                            {
                                DOCUMENTSETTINGS docSetting = new DOCUMENTSETTINGS(pROJECTS.ProjectID, user.USERID.Value, docType.TypeID,
                                    docType.DefaultScaleID.Value, docType.DefaultDwgSizeID.Value);
                                _context.DOCUMENTSETTINGS.Add(docSetting);
                            }
                        }

                        // Add Drawing settings
                        AddSettings(pROJECTS.ProjectID, user.USERID.Value);

                        var pROJECTSETTINGS = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == pROJECTS.ProjectID);
                        var pROJECTSETTINGSDefault = await _context.PROJECTSETTINGS.FirstOrDefaultAsync(x => x.ProjectID == AppCostants.PROJECT_SETTINGS_DEFAULT);
                        if (pROJECTSETTINGS == null)
                        {
                            // Create the first
                            pROJECTSETTINGS = new PROJECTSETTINGS(pROJECTSETTINGSDefault, pROJECTS.ProjectID);

                            // Set user and creation date
                            pROJECTSETTINGS.UserID = user.USERID;
                            pROJECTSETTINGS.USERS = user;
                            pROJECTSETTINGS.CreationDate = DateTime.UtcNow;
                            pROJECTSETTINGS.LastModified = DateTime.UtcNow;

                            _context.Add(pROJECTSETTINGS);
                            await _context.SaveChangesAsync();
                        }

                        // Add CommodityCodes
                        var commodityCodes = await _context.COMMODITYCODES.Where(p => p.ProjectID == globalProjectId).ToListAsync();
                        if (commodityCodes != null)
                        {
                            foreach (COMMODITYCODES currentCode in commodityCodes)
                            {
                                COMMODITYCODES newCode = new COMMODITYCODES(currentCode, user, pROJECTS);
                                _context.COMMODITYCODES.Add(newCode);
                            }
                        }

                        // Add default LOT
                        string defaultLotName = _configuration.GetValue<string>("Items:DefaultLotName");
                        LOTS civilLot = LOTS.GetNewLot(defaultLotName, pROJECTS.ProjectID, user.USERID.Value);
                        _context.LOTS.Add(civilLot);

                        string defaultName = _configuration.GetValue<string>("Steel:DefaultAttributeValue");
                        // Add default VENDORS
                        VENDORS vendor = VENDORS.GetStartVendor(defaultName, pROJECTS.ProjectID, user.USERID.Value);
                        _context.VENDORS.Add(vendor);
                        // Add default MR
                        MATERIALREQUESTS mr = MATERIALREQUESTS.GetStartMR(defaultName, pROJECTS.ProjectID, user.USERID.Value);
                        _context.MATERIALREQUESTS.Add(mr);
                        // Add default PO
                        PURCHASEORDERS po = PURCHASEORDERS.GetStartPO(defaultName, pROJECTS.ProjectID, user.USERID.Value);
                        _context.PURCHASEORDERS.Add(po);
                        await _context.SaveChangesAsync();

                        // Copy Price Codes
                        var priceCodeGroups = await _context.PRICECODEDEFINITIONS.Where(p => p.ProjectID == globalProjectId).ToListAsync();
                        if (priceCodeGroups != null)
                        {
                            foreach (PRICECODEDEFINITIONS group in priceCodeGroups)
                            {
                                bool added = false;

                                PRICECODEDEFINITIONS newGroup = group.Copy(pROJECTS.ProjectID);
                                _context.PRICECODEDEFINITIONS.Add(newGroup);
                                await _context.SaveChangesAsync();

                                var priceCodes = await _context.PRICECODES.Where(p => p.PriceCodeDefinitionID == group.PriceCodeDefinitionID).ToListAsync();
                                if (priceCodes != null && priceCodes.Count > 0)
                                {
                                    foreach (PRICECODES priceCode in priceCodes)
                                    {
                                        PRICECODES newCode = priceCode.Copy(pROJECTS.ProjectID, newGroup.PriceCodeDefinitionID.Value);
                                        _context.PRICECODES.Add(newCode);
                                        await _context.SaveChangesAsync();

                                        var priceConditions = await _context.PRICECONDITIONS.Where(p => p.PRICECODEID == priceCode.PriceCodeID).ToListAsync();
                                        if (priceConditions != null && priceConditions.Count > 0)
                                        {
                                            foreach (PRICECONDITIONS condition in priceConditions)
                                            {
                                                PRICECONDITIONS newCondition = condition.Copy(pROJECTS.ProjectID, newCode.PriceCodeID.Value);
                                                _context.PRICECONDITIONS.Add(newCondition);
                                                added = true;
                                            }
                                        }
                                    }
                                }

                                var families = await _context.PRICEFAMILIESVALUES.Where(p => p.PRICECODEDEFINITIONSID == group.PriceCodeDefinitionID).ToListAsync();
                                if (families != null && families.Count > 0)
                                {
                                    foreach (PRICEFAMILIESVALUES family in families)
                                    {
                                        PRICEFAMILIESVALUES newFamily = family.Copy(pROJECTS.ProjectID, group.PriceCodeDefinitionID.Value);
                                        _context.PRICEFAMILIESVALUES.Add(newFamily);
                                        added = true;
                                    }
                                }
                                if (added)
                                    await _context.SaveChangesAsync();
                            }
                        }

                        // Add Delivery Time Settings
                        DELIVERYTIMES dELIVERYTIMES = new DELIVERYTIMES();
                        dELIVERYTIMES.ProjectID = pROJECTS.ProjectID;
                        dELIVERYTIMES.UserID = user.USERID;
                        dELIVERYTIMES.CreationDate = DateTime.UtcNow;
                        dELIVERYTIMES.LastModified = DateTime.UtcNow;
                        dELIVERYTIMES.InitValueToDefault();
                        _context.DELIVERYTIMES.Add(dELIVERYTIMES);
                        await _context.SaveChangesAsync();

                        //// Add default project users
                        //var adminUsers = await _context.USERS.Where(u => u.ACCESS_LEVEL == Roles.ADMIN).ToListAsync();
                        //if (adminUsers != null)
                        //{
                        //    bool userAdded = false;
                        //    foreach(USERS adminUser in adminUsers)
                        //    {
                        //        PROJECTUSERS pROJECTUSERS = new PROJECTUSERS();
                        //        pROJECTUSERS.UserID = adminUser.USERID.Value;
                        //        pROJECTUSERS.ProjectID = pROJECTS.ProjectID;
                        //        _context.PROJECTUSERS.Add(pROJECTUSERS);
                        //        userAdded = true;
                        //    }
                        //    if (userAdded)
                        //        await _context.SaveChangesAsync();
                        //}

                        ViewBag.Project = pROJECTS.Code;
                        ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_CREATED);
                    }
                    else
                    {
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_CREATED);
                    }
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pROJECTS);
        }

        private void AddSettings(int projectId, int userId)
        {
            int globalProjectId = _configuration.GetValue<int>("Oracle:GlobalProjectId");

            var aacsGlobalSettings = _context.AACSSETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AACSSETTINGS aacssetting = new AACSSETTINGS(aacsGlobalSettings, projectId, userId);
            _context.AACSSETTINGS.Add(aacssetting);

            var aadaGlobalSettings = _context.AADASETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AADASETTINGS aadasetting = new AADASETTINGS(aadaGlobalSettings, projectId, userId);
            _context.AADASETTINGS.Add(aadasetting);

            var aadcGlobalSettings = _context.AADCSETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AADCSETTINGS aDCSETTINGS = new AADCSETTINGS(aadcGlobalSettings, projectId, userId);
            _context.AADCSETTINGS.Add(aDCSETTINGS);

            var aicsGlobalSettings = _context.AICSSETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AICSSETTINGS aICSSETTINGS = new AICSSETTINGS(aicsGlobalSettings, projectId, userId);
            _context.AICSSETTINGS.Add(aICSSETTINGS);

            var aidaGlobalSettings = _context.AIDASETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AIDASETTINGS aIDASETTINGS = new AIDASETTINGS(aidaGlobalSettings, projectId, userId);
            _context.AIDASETTINGS.Add(aIDASETTINGS);

            var aiduGlobalSettings = _context.AIDUSETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AIDUSETTINGS aIDUSETTINGS = new AIDUSETTINGS(aiduGlobalSettings, projectId, userId);
            _context.AIDUSETTINGS.Add(aIDUSETTINGS);

            var apdaGlobalSettings = _context.APDASETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            APDASETTINGS aPDASETTINGS = new APDASETTINGS(apdaGlobalSettings, projectId, userId);
            _context.APDASETTINGS.Add(aPDASETTINGS);

            var aqdaGlobalSettings = _context.AQDASETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            AQDASETTINGS aQDASETTINGS = new AQDASETTINGS(aqdaGlobalSettings, projectId, userId);
            _context.AQDASETTINGS.Add(aQDASETTINGS);

            var ardaGlobalSettings = _context.ARDASETTINGS.Where(a => a.ProjectID == globalProjectId).FirstOrDefault();
            ARDASETTINGS aRDASETTINGS = new ARDASETTINGS(ardaGlobalSettings, projectId, userId);
            _context.ARDASETTINGS.Add(aRDASETTINGS);
        }

        // GET: PROJECTS/Edit/5
        public async Task<IActionResult> Edit(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return NotFound();
            }

            var pROJECTS = await _context.PROJECTS.
                Where(m => m.GetCompleteDescription == code).
                FirstOrDefaultAsync();
            if (pROJECTS == null)
            {
                return NotFound();
            }
            ViewBag.Project = pROJECTS.Code;
            ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;
            return View(pROJECTS);
        }

        // POST: PROJECTS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit([Bind("ProjectID,CreationDate,Code,DLProjectCode,Title,Notes,StartDate,EndDate")] PROJECTS pROJECTS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());
                if (user != null)
                {
                    // Check Dates
                    if (pROJECTS.StartDate == null || pROJECTS.EndDate == null)
                        ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_DATES_NOT_VALID);
                    else
                    {
                        if (ModelState.IsValid)
                        {
                            try
                            {
                                pROJECTS.UserID = user.USERID;
                                pROJECTS.LastModified = DateTime.UtcNow;
                                _context.Update(pROJECTS);
                                await _context.SaveChangesAsync();

                                ViewBag.Project = pROJECTS.Code;
                                ViewBag.ProjectDescription = pROJECTS.GetCompleteDescription;
                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_SAVED);
                            }
                            catch (Exception ex)
                            {
                                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.PROJECT_NOT_SAVED, ex.Message);
                            }
                        }
                        else
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.INCORRECT_DATA);
                        }
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(pROJECTS);
        }

        private bool PROJECTSExists(int id)
        {
            return _context.PROJECTS.Any(e => e.ProjectID == id);
        }
    }
}
