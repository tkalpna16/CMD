﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using CivilMasterData.Models.Users;
using CivilMasterData.Models.Utilities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using OfficeOpenXml;
using CivilMasterData.Models.Logs;
using System.IO;
using Microsoft.AspNetCore.Identity;

namespace CivilMasterData
{
    public class USERSController : Controller
    {
        private readonly USERSContext _context;
        protected readonly ISharedResource _sharedResource;
        private IConfiguration _configuration;
        private IWebHostEnvironment _env;

        public USERSController(USERSContext context, ISharedResource sharedResource, IConfiguration configuration,
            IWebHostEnvironment env)
        {
            _context = context;
            this._sharedResource = sharedResource;
            _configuration = configuration;
            _env = env;
        }

        // GET: USERS
        public async Task<IActionResult> Index()
        {
            if (!User.HasClaim(Roles.ROLE, Roles.ADMIN))
                return Redirect("~/Home/NoPermission");

            var users = await _context.USERS.ToListAsync();
            if (users != null)
            {
                var user = users.FirstOrDefault(m => m.IdentityUserName.ToUpper() == User.Identity.Name.ToUpper());
                if (user == null)
                    return NotFound();
                if (user.IsDisabled)
                    return Redirect("~/Home/NoPermission");
            }

            return View(users);
        }

        // GET: USERS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uSERS = await _context.USERS
                .FirstOrDefaultAsync(m => m.USERID == id);
            if (uSERS == null)
            {
                return NotFound();
            }

            return View(uSERS);
        }

        // GET: USERS/Create
        public IActionResult Create()
        {
            return View(null);
        }

        // POST: USERS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("USERID,USERNAME,PASSWORD,FIRST_NAME,LAST_NAME,EMAIL,PHONE,ACCESS_LEVEL")] USERS uSERS)
        {
            if (ModelState.IsValid)
            {
                uSERS.READ_ONLY = bool.FalseString;
                uSERS.WRITE_ACCESS = bool.TrueString;
                _context.Add(uSERS);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(uSERS);
        }

        [HttpPost]
        public async Task<string> CreateNewUser(string username,
            string password,
            string firstname,
            string lastname,
            string email,
            string phone,
            string role)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var existingUser = await _context.USERS.Where(u => u.USERNAME.ToUpperInvariant() ==
                        username.ToUpperInvariant()).FirstOrDefaultAsync();
                    if (existingUser != null)
                        return _sharedResource.Message(MESSAGE_CODES.ELEMENT_EXISTING);

                    USERS uSERS = new USERS();
                    uSERS.USERNAME = username;
                    uSERS.PASSWORD = password;
                    uSERS.FIRST_NAME = firstname;
                    uSERS.LAST_NAME = lastname;
                    uSERS.EMAIL = email;
                    uSERS.PHONE = "n.d.";
                    uSERS.ACCESS_LEVEL = role;
                    uSERS.READ_ONLY = bool.FalseString;
                    uSERS.WRITE_ACCESS = bool.TrueString;
                    _context.Add(uSERS);
                    await _context.SaveChangesAsync();

                    return _sharedResource.Message(MESSAGE_CODES.USERS_CREATED);
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
            }
            return _sharedResource.Message(MESSAGE_CODES.USERS_NOT_CREATED);
        }

        // GET: USERS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uSERS = await _context.USERS.FindAsync(id);
            if (uSERS == null)
            {
                return NotFound();
            }
            return View(uSERS);
        }

        // POST: USERS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, [Bind("USERID,USERNAME,PASSWORD,FIRST_NAME,LAST_NAME,EMAIL,PHONE,ACCESS_LEVEL")] USERS uSERS)
        {
            if (User.Identity.IsAuthenticated)
            {
                string name = User.Identity.Name;
                var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                if (id != uSERS.USERID)
                {
                    return NotFound();
                }

                uSERS.READ_ONLY = bool.FalseString;
                uSERS.WRITE_ACCESS = bool.TrueString;

                if (!String.IsNullOrEmpty(uSERS.ACCESS_LEVEL) && Roles.AvailableRoles().Contains(uSERS.ACCESS_LEVEL))
                {
                    if (ModelState.IsValid)
                    {
                        try
                        {
                            _context.Update(uSERS);
                            await _context.SaveChangesAsync();
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USERS_UPDATED);
                        }
                        catch (DbUpdateConcurrencyException)
                        {
                            ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USERS_NOT_UPDATED);
                            if (!USERSExists(uSERS.USERID))
                            {
                                return NotFound();
                            }
                            else
                            {
                                throw;
                            }
                        }
                        return RedirectToAction(nameof(Index));
                    }
                }
                else
                {
                    ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USERS_INVALID_ROLES);
                }
            }
            else
            {
                ViewBag.Message = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }
            return View(uSERS);
        }

        // GET: USERS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var uSERS = await _context.USERS
                .FirstOrDefaultAsync(m => m.USERID == id);
            if (uSERS == null)
            {
                return NotFound();
            }

            return View(uSERS);
        }

        // POST: USERS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            var uSERS = await _context.USERS.FindAsync(id);
            _context.USERS.Remove(uSERS);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool USERSExists(int? id)
        {
            return _context.USERS.Any(e => e.USERID == id);
        }

        // GET: USERS/CanEditProject
        public bool CanEditProject()
        {
            bool allowed = PermissionExtension.HavePermission(this, Roles.ADMIN);
            return allowed;
        }

        [HttpPost]
        public async Task<string> UpdateValues(string idsstr,
            string usernamestr,
            string firstnamestr,
            string lastnamestr,
            string emailstr,
            string rolesstr)
        {
            string msg = string.Empty;
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    var users = await _context.USERS.ToListAsync();

                    int[] ids = Utils.SplitIntVector(idsstr);
                    string[] usernames = Utils.SplitText(usernamestr);
                    string[] firstnames = Utils.SplitText(firstnamestr);
                    string[] lastnames = Utils.SplitText(lastnamestr);
                    string[] emails = Utils.SplitText(emailstr);
                    string[] roles = Utils.SplitText(rolesstr);

                    int count = usernames.Distinct().ToList().Count;
                    if (count != usernames.Length)
                    {
                        return "Duplicated usernames";
                    }

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in ids)
                    {
                        var currentUser = users.Where(u => u.USERID == ids[counter]).FirstOrDefault();
                        if (currentUser != null)
                        {
                            if (!string.IsNullOrEmpty(usernames[counter]))
                            {
                                usernames[counter] = usernames[counter].Replace("\\\\", "\\");
                            }
                            currentUser.USERNAME = usernames[counter];
                            currentUser.FIRST_NAME = firstnames[counter];
                            currentUser.LAST_NAME = lastnames[counter];
                            currentUser.EMAIL = emails[counter];
                            currentUser.PHONE = "n.a.";
                            currentUser.ACCESS_LEVEL = roles[counter];
                            changed = true;
                        }
                        else
                        {
                            msg += _sharedResource.Message(MESSAGE_CODES.ELEMENT_NOT_SAVED, "USER " + id.ToString()) + "; ";
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        msg += _sharedResource.Message(MESSAGE_CODES.USERS_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    msg += _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                msg += _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return msg;
        }

        [HttpPost]
        public async Task<ExcelLogManager> DisableUsers(string idsstr)
        {
            ExcelLogManager excelLogManager = new ExcelLogManager();
            if (User.Identity.IsAuthenticated)
            {
                try
                {
                    var users = await _context.USERS.ToListAsync();

                    int[] ids = Utils.SplitIntVector(idsstr);

                    int counter = 0;
                    bool changed = false;
                    foreach (int id in ids)
                    {
                        var currentUser = users.Where(u => u.USERID == ids[counter]).FirstOrDefault();
                        if (currentUser != null)
                        {
                            if (currentUser.ACCESS_LEVEL == Roles.ADMIN)
                            {
                                excelLogManager.AddLog(counter, 0, "User not disabled " + currentUser.GetCompleteName + " - Admin role");
                            }
                            else
                            {
                                var projectForUsers = await _context.PROJECTUSERS.Include(p => p.PROJECTS).Where(p => p.UserID.Value == currentUser.USERID.Value).ToListAsync();
                                if (projectForUsers != null && projectForUsers.Count > 0)
                                {
                                    excelLogManager.AddLog(counter, 0, "User not disabled " + currentUser.GetCompleteName + " - Projects " +
                                        String.Join(";", projectForUsers.Select(p => p.PROJECTS.Code)));
                                }
                                else
                                {
                                    currentUser.DISABLED = 1;
                                    changed = true;
                                }
                            }
                        }
                        else
                        {
                            excelLogManager.AddLog(counter, 0, "User not found " + id.ToString());
                        }
                        counter++;
                    }
                    if (changed)
                    {
                        await _context.SaveChangesAsync();
                        excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USERS_UPDATED);
                    }
                }
                catch (Exception ex)
                {
                    excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.GENERIC_ERROR, ex.Message);
                }
            }
            else
            {
                excelLogManager.Result = _sharedResource.Message(MESSAGE_CODES.USER_NOT_AUTHORIZED);
            }

            return excelLogManager;
        }


        [HttpGet]
        public IActionResult GetTemplate()
        {
            try
            {
                // Init Paths
                var webRoot = _env.WebRootPath;
                string excelTemplate = _configuration.GetValue<string>("Excel:UserTemplate");
                string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
                string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
                var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);

                //Get the temp folder and file path in server
                var errorMessage = "";
                return Json(new { fileName = baseReportFile, errorMessage });
            }
            catch
            {
                return null;
            }
        }

        [HttpGet]
        public async Task<ActionResult> CreateExcel()
        {
            // Init Paths
            var webRoot = _env.WebRootPath;
            string excelTemplate = _configuration.GetValue<string>("Excel:AdminUserTemplate");
            string reportFolder = _configuration.GetValue<string>("Excel:ReportFolder");
            string tempFolder = _configuration.GetValue<string>("Excel:TempFolder");
            var baseReportFile = System.IO.Path.Combine(webRoot, reportFolder, excelTemplate);
            string fileToSave = System.IO.Path.Combine(webRoot, tempFolder, "AdminUsers.xlsx");
            string excelSheet = _configuration.GetValue<string>("Excel:AdminUserSheetName");
            int startRow = _configuration.GetValue<int>("Excel:AdminUserSheetStartRow");
            int startColumn = _configuration.GetValue<int>("Excel:AdminUserSheetStartColumn");

            System.IO.FileInfo baseFile = new System.IO.FileInfo(baseReportFile);
            ExcelPackage Ep = new ExcelPackage(baseFile);
            ExcelWorksheet Sheet = Ep.Workbook.Worksheets[excelSheet];

            // Inser data
            var users = await _context.USERS.ToListAsync();
            if (users != null)
            {
                int currentRow = startRow;
                foreach (USERS user in users)
                {
                    Sheet.Cells[currentRow, startColumn].Value = user.USERNAME;
                    Sheet.Cells[currentRow, startColumn + 1].Value = user.FIRST_NAME;
                    Sheet.Cells[currentRow, startColumn + 2].Value = user.LAST_NAME;
                    Sheet.Cells[currentRow, startColumn + 3].Value = user.EMAIL;
                    Sheet.Cells[currentRow, startColumn + 4].Value = user.ACCESS_LEVEL;
                    currentRow++;
                }
            }

            //Save the file to server temp folder            
            System.IO.FileInfo fi = new System.IO.FileInfo(fileToSave);
            Ep.SaveAs(fi);

            var errorMessage = "";
            return Json(new { fileName = fileToSave, errorMessage });
        }

        [HttpPost]
        public async Task<ExcelLogManager> ImportExcel(IFormFile postedFile)
        {
            string msg = string.Empty;
            ExcelLogManager excelLogManager = new ExcelLogManager();
            try
            {
                if (postedFile != null)
                {
                    //Create a Folder.
                    var webRoot = _env.WebRootPath;
                    string path = Path.Combine(webRoot, "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    //Save the uploaded Excel file.
                    string fileName = Path.GetFileName(postedFile.FileName);
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }

                    FileInfo fileInfo = new FileInfo(filePath);
                    ExcelPackage package = new ExcelPackage(fileInfo);
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.FirstOrDefault();

                    // Read Data
                    List<string> logins = new List<string>();
                    List<string> usernames = new List<string>();
                    List<string> usersurnames = new List<string>();
                    List<string> emails = new List<string>();
                    List<string> roles = new List<string>();
                    bool notEmpty = true;
                    int startRow = _configuration.GetValue<int>("Excel:AdminUserSheetStartRow");
                    int counter = startRow;
                    int startColumn = _configuration.GetValue<int>("Excel:AdminUserSheetStartColumn");

                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == User.Identity.Name.ToUpper());

                    int totalUsers = 0;
                    var rolesList = Roles.AvailableRoles();
                    while (notEmpty)
                    {
                        try
                        {
                            var cell = worksheet.Cells[counter, startColumn];
                            string login = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 1];
                            string name = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 2];
                            string surname = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 3];
                            string email = cell != null && cell.Value != null ? cell.Value.ToString() : null;
                            cell = worksheet.Cells[counter, startColumn + 4];
                            string role = cell != null && cell.Value != null ? cell.Value.ToString() : null;

                            if (string.IsNullOrEmpty(login))
                            {
                                notEmpty = false;
                            }
                            else if (string.IsNullOrEmpty(name))
                            {
                                excelLogManager.AddLog(counter, startColumn + 1, "Not valid name");
                            }
                            else if (string.IsNullOrEmpty(surname))
                            {
                                excelLogManager.AddLog(counter, startColumn + 2, "Not valid surname");
                            }
                            else if (string.IsNullOrEmpty(email))
                            {
                                excelLogManager.AddLog(counter, startColumn + 3, "Not valid email");
                            }
                            else if (string.IsNullOrEmpty(role))
                            {
                                excelLogManager.AddLog(counter, startColumn + 4, "Not valid role");
                            }
                            else if (!rolesList.Contains(role))
                            {
                                excelLogManager.AddLog(counter, startColumn + 4, "Not valid role");
                            }
                            else
                            {
                                logins.Add(login);
                                usernames.Add(name);
                                usersurnames.Add(surname);
                                emails.Add(email);
                                roles.Add(role);
                            }
                            counter++;
                        }
                        catch (Exception ex)
                        {
                            excelLogManager.AddLog(counter, 0, ex.Message);
                            notEmpty = false;
                        }
                    }

                    for (int i = 0; i < logins.Count; i++)
                    {
                        // Search existing User
                        var currentUser = await _context.USERS.Where(p => p.FIRST_NAME.ToUpperInvariant() == usernames[i].ToUpperInvariant() &&
                            p.LAST_NAME.ToUpperInvariant() == usersurnames[i].ToUpperInvariant()).FirstOrDefaultAsync();
                        if (currentUser != null)
                        {
                            currentUser.USERNAME = logins[i];
                            currentUser.EMAIL = emails[i];
                            currentUser.ACCESS_LEVEL = roles[i];
                            totalUsers++;
                        }
                        else
                        {
                            USERS newUser = new USERS();
                            newUser.USERNAME = logins[i];
                            newUser.ACCESS_LEVEL = roles[i];
                            newUser.FIRST_NAME = usernames[i];
                            newUser.LAST_NAME = usersurnames[i];
                            newUser.EMAIL = emails[i];
                            newUser.PASSWORD = "na";
                            newUser.PHONE = "na";
                            newUser.READ_ONLY = "na";
                            newUser.WRITE_ACCESS = "na";
                            _context.USERS.Add(newUser);
                            totalUsers++;
                        }
                    }

                    int result = await _context.SaveChangesAsync();

                    excelLogManager.Result = "Saved " + totalUsers.ToString() + " elements";
                }
            }
            catch (Exception ex)
            {

            }

            return excelLogManager;
        }
    }
}
