﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;
using System;

namespace CivilMasterData
{
    public class MAINITEMPLANNINGDATESController : Controller
    {
        private readonly MAINITEMPLANNINGDATESContext _context;

        public MAINITEMPLANNINGDATESController(MAINITEMPLANNINGDATESContext context)
        {
            _context = context;
        }

        // GET: MAINITEMPARAMETERS
        public async Task<IActionResult> Index(string code)
        {
            if (string.IsNullOrEmpty(code))
                return NotFound();

            var project = await _context.PROJECTS
                .FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
            {
                project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.GetCompleteDescription == code);
                if (project == null)
                    return NotFound();
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            var parameters = await _context.MAINITEMPLANNINGDATES.Where(c => c.PROJECTID == project.ProjectID).OrderBy(p => p.PARAMETERNAME).ToListAsync();
            return View(parameters);
        }

        // GET: OBJECTCODES/Create
        public async Task<IActionResult> Create(string projectcode)
        {
            if (string.IsNullOrEmpty(projectcode))
                return NotFound();

            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == projectcode);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            return View();
        }

        // POST: MAINITEMPARAMETERS/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PROJECTID,PARAMETERNAME")] MAINITEMPLANNINGDATES mAINITEMPLANNINGDATES, string CATEGORYNAME)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.ProjectID == mAINITEMPLANNINGDATES.PROJECTID);

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            if (!string.IsNullOrEmpty(mAINITEMPLANNINGDATES.PARAMETERNAME))
            {
                if (User.Identity.IsAuthenticated)
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    if (ModelState.IsValid && user != null)
                    {
                        // Check if Object Code exist
                        var obj = await _context.MAINITEMPLANNINGDATES.Where(o => o.PARAMETERNAME.ToUpperInvariant() == mAINITEMPLANNINGDATES.PARAMETERNAME.ToUpperInvariant()).FirstOrDefaultAsync();
                        if (obj == null)
                        {
                            mAINITEMPLANNINGDATES.UserID = user.USERID;
                            mAINITEMPLANNINGDATES.CreationDate = DateTime.UtcNow;
                            mAINITEMPLANNINGDATES.LastModified = DateTime.UtcNow;
                            _context.Add(mAINITEMPLANNINGDATES);
                            await _context.SaveChangesAsync();

                            // Add parameter values for every main items in the project
                            var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
                            if (mainItems != null)
                            {
                                foreach(MAINITEMS mainItem in mainItems)
                                {
                                    MAINITEMDATEVALUES mainItemDate = new MAINITEMDATEVALUES();
                                    mainItemDate.CreationDate = DateTime.UtcNow;
                                    mainItemDate.LastModified = DateTime.UtcNow;
                                    mainItemDate.UserID = user.USERID.Value;
                                    mainItemDate.MainItemsID = mainItem.MainItemID;
                                    mainItemDate.MainItemPlanningDatesID = mAINITEMPLANNINGDATES.DateID;

                                    _context.MAINITEMDATEVALUES.Add(mainItemDate);
                                    await _context.SaveChangesAsync();
                                }
                            }

                            ViewBag.Message = "Parameter created";
                        }
                        else
                        {
                            ViewBag.Message = "Existing Parameter";
                        }
                    }
                }
            }
            return View(mAINITEMPLANNINGDATES);
        }

        [HttpPost]
        public async Task<string> CreateDate(string code, string datename)
        {
            var project = await _context.PROJECTS.FirstOrDefaultAsync(m => m.Code == code);
            if (project == null)
            {
                return "Project not found";
            }

            ViewBag.ProjectID = project.ProjectID;
            ViewBag.Project = project.Code;

            if (!string.IsNullOrEmpty(datename))
            {
                if (User.Identity.IsAuthenticated)
                {
                    string name = User.Identity.Name;
                    var user = await _context.USERS.FirstOrDefaultAsync(m => m.IdentityUserName.ToUpper() == name.ToUpper());

                    if (ModelState.IsValid && user != null)
                    {
                        // Check if Object Code exist
                        var obj = await _context.MAINITEMPLANNINGDATES.Where(o => o.PARAMETERNAME.ToUpperInvariant() == datename.ToUpperInvariant()).FirstOrDefaultAsync();
                        if (obj == null)
                        {
                            MAINITEMPLANNINGDATES mAINITEMPLANNINGDATES = new MAINITEMPLANNINGDATES();
                            mAINITEMPLANNINGDATES.PROJECTID = project.ProjectID;
                            mAINITEMPLANNINGDATES.UserID = user.USERID;
                            mAINITEMPLANNINGDATES.CreationDate = DateTime.UtcNow;
                            mAINITEMPLANNINGDATES.LastModified = DateTime.UtcNow;
                            mAINITEMPLANNINGDATES.PARAMETERNAME = datename;
                            _context.Add(mAINITEMPLANNINGDATES);
                            await _context.SaveChangesAsync();

                            // Add parameter values for every main items in the project
                            var mainItems = await _context.MAINITEMS.Include(m => m.PBS).Where(m => m.PBS.ProjectID == project.ProjectID).ToListAsync();
                            if (mainItems != null)
                            {
                                foreach (MAINITEMS mainItem in mainItems)
                                {
                                    MAINITEMDATEVALUES mainItemDate = new MAINITEMDATEVALUES();
                                    mainItemDate.CreationDate = DateTime.UtcNow;
                                    mainItemDate.LastModified = DateTime.UtcNow;
                                    mainItemDate.UserID = user.USERID.Value;
                                    mainItemDate.MainItemsID = mainItem.MainItemID;
                                    mainItemDate.MainItemPlanningDatesID = mAINITEMPLANNINGDATES.DateID;

                                    _context.MAINITEMDATEVALUES.Add(mainItemDate);
                                }
                            }
                            await _context.SaveChangesAsync();
                            ViewBag.Message = "Parameter created";
                        }
                        else
                        {
                            ViewBag.Message = "Existing Parameter";
                        }
                    }
                }
            }
            return "Parameter created";
        }


        // GET: MAINITEMPARAMETERS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMPARAMETERS = await _context.MAINITEMPLANNINGDATES.FindAsync(id);
            if (mAINITEMPARAMETERS == null)
            {
                return NotFound();
            }
            ViewData["PROJECTID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", mAINITEMPARAMETERS.PROJECTID);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", mAINITEMPARAMETERS.UserID);
            return View(mAINITEMPARAMETERS);
        }

        // POST: MAINITEMPARAMETERS/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PARAMETERID,PROJECTID,PARAMETERNAME,UserID,CreationDate,LastModified")] MAINITEMPARAMETERS mAINITEMPARAMETERS)
        {
            if (id != mAINITEMPARAMETERS.ParameterID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(mAINITEMPARAMETERS);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MAINITEMPARAMETERSExists(mAINITEMPARAMETERS.ParameterID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PROJECTID"] = new SelectList(_context.PROJECTS, "ProjectID", "ProjectID", mAINITEMPARAMETERS.PROJECTID);
            ViewData["UserID"] = new SelectList(_context.USERS, "USERID", "USERID", mAINITEMPARAMETERS.UserID);
            return View(mAINITEMPARAMETERS);
        }

        // GET: MAINITEMPARAMETERS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAINITEMPARAMETERS = await _context.MAINITEMPLANNINGDATES
                .Include(m => m.Project)
                .Include(m => m.USERS)
                .FirstOrDefaultAsync(m => m.DateID == id);
            if (mAINITEMPARAMETERS == null)
            {
                return NotFound();
            }

            return View(mAINITEMPARAMETERS);
        }


        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            if (id == null)
                return NotFound();

            var mAINITEMPARAMETERS = await _context.MAINITEMPLANNINGDATES.Include(m => m.Project).Where(m => 
                m.DateID == id.Value).FirstOrDefaultAsync();
            string projectCode = mAINITEMPARAMETERS.Project.Code;
            _context.MAINITEMPLANNINGDATES.Remove(mAINITEMPARAMETERS);
            await _context.SaveChangesAsync();
            return Redirect("/MAINITEMPLANNINGDATES/" + nameof(Index) + "?code=" + projectCode);
        }

        public async Task<string> DeleteDates(int id)
        {
            try
            {
                var mAINITEMPARAMETERS = await _context.MAINITEMPLANNINGDATES.Include(m => m.Project).Where(m =>
                    m.DateID == id).FirstOrDefaultAsync();
                string projectCode = mAINITEMPARAMETERS.Project.Code;
                _context.MAINITEMPLANNINGDATES.Remove(mAINITEMPARAMETERS);
                await _context.SaveChangesAsync();
                return "Deleted";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        private bool MAINITEMPARAMETERSExists(int id)
        {
            return _context.MAINITEMPLANNINGDATES.Any(e => e.DateID == id);
        }
    }
}
