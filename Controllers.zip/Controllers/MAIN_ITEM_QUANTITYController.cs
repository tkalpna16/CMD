﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CivilMasterData.Models;

namespace CivilMasterData
{
    public class MAIN_ITEM_QUANTITYController : Controller
    {
        private readonly MAIN_ITEM_QUANTITYContext _context;

        public MAIN_ITEM_QUANTITYController(MAIN_ITEM_QUANTITYContext context)
        {
            _context = context;
        }

        // GET: MAIN_ITEM_QUANTITY
        public async Task<IActionResult> Index(int? projectId)
        {
            if (projectId == null)
                return NotFound();
            
            // Get all main items
            var mainItemsQuantity = await _context.MAIN_ITEM_QUANTITY.Where(m => m.MAINITEMS.PBS.ProjectID == projectId.Value).ToListAsync();
            return View(mainItemsQuantity);
        }

        // GET: MAIN_ITEM_QUANTITY/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAIN_ITEM_QUANTITY = await _context.MAIN_ITEM_QUANTITY
                .Include(m => m.MAINITEMS)
                .FirstOrDefaultAsync(m => m.QuantityId == id);
            if (mAIN_ITEM_QUANTITY == null)
            {
                return NotFound();
            }

            return View(mAIN_ITEM_QUANTITY);
        }

        // GET: MAIN_ITEM_QUANTITY/Create
        public IActionResult Create()
        {
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID");
            return View();
        }

        // POST: MAIN_ITEM_QUANTITY/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MainItemTagId,MainItemId,MTO_Rev,Model_Status,QTY,QTY_CE,K_Factor,QTY_REBAR,QTY_REBAR_INCI,QTY_HOLD")] MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY)
        {
            if (ModelState.IsValid)
            {
                _context.Add(mAIN_ITEM_QUANTITY);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID", mAIN_ITEM_QUANTITY.MainItemId);
            return View(mAIN_ITEM_QUANTITY);
        }

        // GET: MAIN_ITEM_QUANTITY/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAIN_ITEM_QUANTITY = await _context.MAIN_ITEM_QUANTITY.FindAsync(id);
            if (mAIN_ITEM_QUANTITY == null)
            {
                return NotFound();
            }
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID", mAIN_ITEM_QUANTITY.MainItemId);
            return View(mAIN_ITEM_QUANTITY);
        }

        // POST: MAIN_ITEM_QUANTITY/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MainItemTagId,MainItemId,MTO_Rev,Model_Status,QTY,QTY_CE,K_Factor,QTY_REBAR,QTY_REBAR_INCI,QTY_HOLD")] MAIN_ITEM_QUANTITY mAIN_ITEM_QUANTITY)
        {
            if (id != mAIN_ITEM_QUANTITY.QuantityId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(mAIN_ITEM_QUANTITY);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MAIN_ITEM_QUANTITYExists(mAIN_ITEM_QUANTITY.QuantityId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MainItemId"] = new SelectList(_context.MAINITEMS, "MainItemID", "MainItemID", mAIN_ITEM_QUANTITY.MainItemId);
            return View(mAIN_ITEM_QUANTITY);
        }

        // GET: MAIN_ITEM_QUANTITY/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var mAIN_ITEM_QUANTITY = await _context.MAIN_ITEM_QUANTITY
                .Include(m => m.MAINITEMS)
                .FirstOrDefaultAsync(m => m.QuantityId == id);
            if (mAIN_ITEM_QUANTITY == null)
            {
                return NotFound();
            }

            return View(mAIN_ITEM_QUANTITY);
        }

        // POST: MAIN_ITEM_QUANTITY/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var mAIN_ITEM_QUANTITY = await _context.MAIN_ITEM_QUANTITY.FindAsync(id);
            _context.MAIN_ITEM_QUANTITY.Remove(mAIN_ITEM_QUANTITY);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MAIN_ITEM_QUANTITYExists(int id)
        {
            return _context.MAIN_ITEM_QUANTITY.Any(e => e.QuantityId == id);
        }
    }
}
