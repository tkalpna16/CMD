﻿$(document).ready(function () {

    setTitle("Feasibility Curves");
    showElement("#navTopButton");
    showElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");
    $("#divdaterange").hide();

    //$('#TagType_dropdown').multiselect();
    $('#TagType_dropdown').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#engstatus_dropdown').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '57%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class= "btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" data-bs-auto-close="true" aria-expanded="false"><i class="fa fa-filter" aria-hidden="true"></i><span class="caret"></span></button>',
        }
    });

    $('#subcon_dropdown').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    //WP_dropdown
    $('#WP_dropdown').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect btn btn-default dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#Project_timeframe').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#ReportType_dd').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $(function () {
        $('input[name="daterange"]').daterangepicker({
            opens: 'left'
        }, function (start, end, label) {
            //console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
        });
    });


    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDesc').text();
        var url= '/cmd/Reports/Index?code=' + project;
       window.location.href = url;
    });         

    $('#downloadLink').click(function () {
        
        // TagType
        var dropdownvaltagtype = $("#TagType").val();
        if (!dropdownvaltagtype) {
            alert("Any TagType selected!!");
            return;
        }

        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        // WP List
        var wp = [];
        $('#WPCode :selected').each(function () {
            wp.push($(this).text());
        });
        if (wp.length == 0) {
            alert("Any WP selected!!");
            return;
        }

        loadSpinner();

        var url: '/cmd/Reports/CreateExcelFeasibilityCurve';
        $.ajax({
            type: "GET",
            url: url,
            contentType: "application/json; charset=utf-8",
            data: {
                'code': project,
                'tagTypeStr': dropdownvaltagtype,
                'wpStr': JSON.stringify(wp)
            },
            dataType: "json",
            success: function (data) {
                var now = new Date();
                var dateString = moment(now).format('YYYY-MM-DD');
                var link = document.createElement('a');
                link.href = "/cmd/Temp/FeasibilityCurve.xlsx";
                link.download = project + "-FeasibilityCurve_" + dateString + ".xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (response) {
                hideSpinner();
            }
        });
    });

    $('#Project_timeframe').change(function () {

        $('#Project_timeframe :selected').each(function () {
            var obj = $(this).text();
            var P_timeframe = obj;
            if (P_timeframe == 'Project LifeTime') {
                $("#divdaterange").hide();
            }
            else {
                $("#divdaterange").show();
            }
        });

       
    });


    $("#btnApply_OLD").click(function () {
        //Daterangepicker values
        var start_date = $('input[name="daterange"]').data('daterangepicker').startDate.format('MM-DD-YYYY');
        var end_date = $('input[name="daterange"]').data('daterangepicker').endDate.format('MM-DD-YYYY');

        var dropdownvaltagtype = [];
        $('#TagType_dropdown :selected').each(function () {
            dropdownvaltagtype.push($(this).text());
        });
        if (dropdownvaltagtype.length == 0) {
            alert("Any Tag Type selected!!");
            return;
        }
        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        // WP List
        var wp = [];
        $('#WP_dropdown :selected').each(function () {
            wp.push($(this).text());
        });
        if (wp.length == 0) {
            alert("Any WP selected!!");
            return;
        }

        //Report type        
        var dropdownvalRType = $("#ReportType_dd").val();
        if (!dropdownvalRType) {
            alert("Any Report type selected!!");
            return;
        }
        //Project Timeframe
        var dropdownvalPTframe = $("#Project_timeframe").val();
        if (!dropdownvalPTframe) {
            alert("Any Project Timeframe selected!!");
            return;
        }

        $('#TableId').DataTable(
            {
                bSort: false,
                aoColumns: [{ sWidth: "45%" }, { sWidth: "45%" }, { sWidth: "10%", bSearchable: false, bSortable: false }],
                "scrollY": "200px",
                "scrollCollapse": true,
                "info": true,
                "paging": true,
                "ajax":
                {
                    "url": "/Reports/PopulateFeasibilityCurve",
                    "data": {
                        'code': project,
                        'tagTypeStr': JSON.stringify(dropdownvaltagtype),
                        'wpStr': '2',//JSON.stringify(wp),
                        'ReportType': dropdownvalRType,
                        'ProjectTimeframe': dropdownvalPTframe,
                        'start_Dt': start_date, 'end_Dt': end_date
                    },
                    "type": "POST",
                    "contentType": "application/json;charset=utf-8",
                    "dataType": "JSON",
                    "dataSrc": function (json) {
                        // Settings.  
                        alert('hi');
                        //jsonObj = $.parseJSON(result.data)

                        // Data  
                        return null; //jsonObj.data;
                    }
                },
                //"columns": json.data.columns
            });
               
    });

    $("#btnApply").click(function () {
        //Daterangepicker values
        var start_date = $('input[name="daterange"]').data('daterangepicker').startDate.format('MM-DD-YYYY');
        var end_date = $('input[name="daterange"]').data('daterangepicker').endDate.format('MM-DD-YYYY');

        var dropdownvaltagtype = [];
        $('#TagType_dropdown :selected').each(function () {
            dropdownvaltagtype.push($(this).text());
        });
        if (dropdownvaltagtype.length == 0) {
            alert("Any Tag Type selected!!");
            return;
        }
        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        // WP List
        var wp = [];
        $('#WP_dropdown :selected').each(function () {
            wp.push($(this).text());
        });
        if (wp.length == 0) {
            alert("Any WP selected!!");
            return;
        }

        //Report type        
        var dropdownvalRType = $("#ReportType_dd").val();
        if (!dropdownvalRType) {
            alert("Any Report type selected!!");
            return;
        }
        //Project Timeframe
        var dropdownvalPTframe = $("#Project_timeframe").val();
        if (!dropdownvalPTframe) {
            alert("Any Project Timeframe selected!!");
            return;
        }
        //Eng Status
        // WP List
        var engstatus = [];
        $('#engstatus_dropdown :selected').each(function () {
            engstatus.push($(this).text());
        });
        //var dropdownengstatus = $("#engstatus_dropdown").val();
        if (engstatus.length == 0) {
            alert("Select Any Eng Status");
            return;
        }

        //Subcontractor

        var dropdownvalsc = [];
        $('#subcon_dropdown :selected').each(function () {
            dropdownvalsc.push($(this).text());
        });
        if (dropdownvalsc.length == 0) {
            alert("Any S/C selected!!");
            return;
        }

        loadSpinner();

        var Tablenameselect = $("#TableId").find("option:selected").text();
        var columns = [];
        //alert(Tablenameselect);
        $.ajax({
            type: "POST",
            url: "/Reports/PopulateFeasibilityCurve",
            data: {
                'code': project,
                'engstatus': JSON.stringify(engstatus), //dropdownengstatus,
                'tagTypeStr': JSON.stringify(dropdownvaltagtype),
                'wpStr': JSON.stringify(wp),
                'ReportType': dropdownvalRType,
                'ProjectTimeframe': dropdownvalPTframe,
                'start_Dt': start_date, 'end_Dt': end_date,
                'subcont': JSON.stringify(dropdownvalsc),
            },
            dataType: "json",
            success: function (data) {
                debugger;
                if (data != "[]") {
                    console.log(JSON.parse(data));
                    columnNames = Object.keys(JSON.parse(data)[0]);
                    console.log(columnNames);
                    for (var i in columnNames) {
                        columns.push({
                            data: columnNames[i],
                            title: columnNames[i]
                        });
                    }
                    CreateChart(JSON.parse(data), columnNames, engstatus);
                    $("#divGridSales").css({ display: "block" });

                    if ($.fn.DataTable.isDataTable('#TableId')) {
                        $('#TableId').DataTable().destroy();
                    }
                    $('#TableId tbody').empty();
                    $('#TableId thead').empty();
                    //if (oTable) {
                    //    oTable.clear().destroy();
                    //    oTable.clear().draw();
                    //new $.fn.dataTable.FixedColumns(oTable, {
                    //    autoWidth: true,
                    //    scrollY: "1500px",
                    //    scrollX: true,
                    //    scrollCollapse: true,
                    //    "fixedColumns": { left: 1 },     //leftColumns: 1 ,//specifies how many left columns should be fixed.
                    //    columnDefs: [
                    //        { "width": "110px", "targets": 0 }
                    //    ],
                    //});
                    //}
                    /*  $('#TableId').DataTable().destroy();*/
                    oTable = $('#TableId').DataTable({

                        "paging": false,
                        "searching": false,
                        "processing": true, // for show progress barz
                        "serverSide": false, // for process server side
                        "filter": false, // this is for disable filter (search box)
                        "orderMulti": false, // for disable multiple column at once
                        "destroy": true,   //for reinitialize the datatable
                        "data": JSON.parse(data),
                        "columns": columns,
                        "autoWidth": true,
                        "scrollY": "1500px",
                        "scrollX": true,
                        "scrollCollapse": true,
                        "fixedColumns": { left: 1 },
                        columnDefs: [
                            { "width": "110px", "targets": 0 }
                        ],
                        //  "responsive": true
                    });
                   
                }
                else {
                    alert("No data for Selected Filter");
                }
                hideSpinner();
            },
            error: function (data) {
                alert("Error while fetching Data");
                hideSpinner();
            }
        });
        hideSpinner();
    });

    $('#btnDownloadExcel').click(function () {

        var start_date = $('input[name="daterange"]').data('daterangepicker').startDate.format('MM-DD-YYYY');
        var end_date = $('input[name="daterange"]').data('daterangepicker').endDate.format('MM-DD-YYYY');

        var dropdownvaltagtype = [];
        $('#TagType_dropdown :selected').each(function () {
            dropdownvaltagtype.push($(this).text());
        });
        if (dropdownvaltagtype.length == 0) {
            alert("Any Tag Type selected!!");
            return;
        }
        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        // WP List
        var wp = [];
        $('#WP_dropdown :selected').each(function () {
            wp.push($(this).text());
        });
        if (wp.length == 0) {
            alert("Any WP selected!!");
            return;
        }

        //Report type        
        var dropdownvalRType = $("#ReportType_dd").val();
        if (!dropdownvalRType) {
            alert("Any Report type selected!!");
            return;
        }
        //Project Timeframe
        var dropdownvalPTframe = $("#Project_timeframe").val();
        if (!dropdownvalPTframe) {
            alert("Any Project Timeframe selected!!");
            return;
        }
        //Eng Status
        // WP List
        var engstatus = [];
        $('#engstatus_dropdown :selected').each(function () {
            engstatus.push($(this).text());
        });
        //var dropdownengstatus = $("#engstatus_dropdown").val();
        if (engstatus.length == 0) {
            alert("Select Any Eng Status");
            return;
        }

        //Subcontractor

        var dropdownvalsc = [];
        $('#subcon_dropdown :selected').each(function () {
            dropdownvalsc.push($(this).text());
        });
        if (dropdownvalsc.length == 0) {
            alert("Any S/C selected!!");
            return;
        }

        loadSpinner();

        var url: '/cmd/Reports/GenerateFeasibilityCurve';
        $.ajax({
            type: "GET",
            url: url,
            contentType: "application/json; charset=utf-8",
            data: {
                'code': project,
                'engstatus': JSON.stringify(engstatus), //dropdownengstatus,
                'tagTypeStr': JSON.stringify(dropdownvaltagtype),
                'wpStr': JSON.stringify(wp),
                'ReportType': dropdownvalRType,
                'ProjectTimeframe': dropdownvalPTframe,
                'start_Dt': start_date, 'end_Dt': end_date,
                'subcont': JSON.stringify(dropdownvalsc),
            },
            dataType: "json",
            success: function (data) {
                var now = new Date();
                var dateString = moment(now).format('YYYY-MM-DD');
                var link = document.createElement('a');
                link.href = "/cmd/Temp/FeasibilityCurve.xlsx";
                link.download = project + "-FeasibilityCurve_" + dateString + ".xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (response) {
                hideSpinner();
            }
        });
    });
 
    function CreateChart(data, columnNames, engstatus) {
        var columns = [];
        var series = [];
        
        console.log(columnNames);
        for (var i in columnNames) {
            if (columnNames[i] != "LEGEND") {
                columns.push(columnNames[i]);

            }
        }
        //for (var j = 0; j < engstatus.length; j++) {
            for (var key in data) {
                var sdata = [];
                for (var i = 0; i < columns.length; i++) {
                    sdata.push(data[key][columns[i]]);
                }
                if (data[key]["LEGEND"].includes('BASELINE MONTHLY')) {//&& data[key]["LEGEND"].includes(engstatus[j])
                    // series.push(data[key]);
                    series.push({
                        name: data[key]["LEGEND"],
                        type: "column",
                        data: sdata,
                        color: getSeriesColor(data[key]["LEGEND"])
                    });

                }
                else if (data[key]["LEGEND"].includes('CUM.')) { //&& data[key]["LEGEND"].includes(engstatus[j])
                    series.push({
                        name: data[key]["LEGEND"],
                        type: "line",
                        data: sdata,
                        color: getSeriesColor(data[key]["LEGEND"])
                    });

                }
                else {
                    // do nothing 
                    // exclude IFR - FORECAST MONTHLY, IFR - ACTUAL MONTHLY, IFC - FORECAST MONTHLY, IFC - ACTUAL MONTHLY from graph histogram
                }
            }
        //}
        
      
        $("#dCurve").kendoChart({
            legend: {
                position: "top"
            },
            series: series,
            categoryAxis: [{
                labels: {
                    rotation: 270
                },
                justified: true,
                name: "Months",
                categories: columns
                
            }],
            tooltip: {
                visible: true,
                template: "#= series.name #: #= value #"
            }
        });
    }

    function getSeriesColor(seriesName) {
        var color = '';
        switch (seriesName) {
            case "IFR-BASELINE MONTHLY":
                color = '#B8DAA2';
                break;
            case "IFR-BASELINE CUM.":
                color = '#B8DAA2';
                break;
            case "IFR-FORECAST CUM.":
                color = '#A9D18E';
                break;
            case "IFR-ACTUAL CUM.":
                color = '#548235';
                break;
            case "IFC-BASELINE MONTHLY" :
                color = '#DEEBF7';
                break;
            case "IFC-BASELINE CUM.":
                color = '#DEEBF7';
                break;
            case "IFC-FORECAST CUM.":
                color = '#9DC3E6';
                break;
            case "IFC-ACTUAL CUM.":
                color = '#2E75B6';
                break;
            default:
                color = 'RED';
                break;
        }
        //if (seriesName.includes('IFR')) {
        //    color = 'green';
        //}
        //else {
        //    color = 'blue';
        //}
        return color;
    }


    //Passing parameters to read event of grid
    function additionalInfo() {
        //var grid = $("#gvCurve").data("kendoGrid");
        //var currentPage = grid.dataSource.page();

        //Daterangepicker values
        var start_date = $('input[name="daterange"]').data('daterangepicker').startDate.format('MM-DD-YYYY');
        var end_date = $('input[name="daterange"]').data('daterangepicker').endDate.format('MM-DD-YYYY');

        var dropdownvaltagtype = [];
        $('#TagType_dropdown :selected').each(function () {
            dropdownvaltagtype.push($(this).text());
        });
        if (dropdownvaltagtype.length == 0) {
            alert("Any Tag Type selected!!");
            return;
        }
        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        // WP List
        var wp = [];
        $('#WP_dropdown :selected').each(function () {
            wp.push($(this).text());
        });
        if (wp.length == 0) {
            alert("Any WP selected!!");
            return;
        }

        //Report type        
        var dropdownvalRType = $("#ReportType_dd").val();
        if (!dropdownvalRType) {
            alert("Any Report type selected!!");
            return;
        }
        //Project Timeframe
        var dropdownvalPTframe = $("#Project_timeframe").val();
        if (!dropdownvalPTframe) {
            alert("Any Project Timeframe selected!!");
            return;
        }

        return {
            code: project,
            tagTypeStr: JSON.stringify(dropdownvaltagtype),
            wpStr: JSON.stringify(wp),
            ReportType: dropdownvalRType,
            ProjectTimeframe: dropdownvalPTframe,
            start_Dt: start_date,
            end_Dt: end_date
            // pageNo: currentPage
        };
    }

});

