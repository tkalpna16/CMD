﻿$(document).ready(function () {
    // Set Title
    setTitle("Administration");
    hideElement("#ulProject");
    hideElement("#ulProjectCode");
    hideElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    $("#sidebarCollapse").prop("disabled", true);

    // Set back button
    $("#btnPrevious").click(function () {
        var url= '/cmd/HOME/Index';
        window.location.href = url;
    });

    // Open Project
    $("#btnEditUsers").click(function () {
        var url= '/cmd/USERS/Index';
        window.location.href = url;
    });
});