﻿$(document).ready(function () {
    // Set Title
    setTitle("Create New User");
});