﻿var tableProjectUsers = null;
var totalProjectUsersColumns = 3;

$(document).ready(function () {
    // Set title
    setTitle("Users List");
    showElement("#ulProject");
    showElement("#ulProjectCode");
    showElement("#btnDownloadExcel");
    showElement("#btnImportExcel");

    $("#sidebarCollapse").prop("disabled", true);

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        //var url: '/cmd/PROJECTS/Index?code=' + project;
        var url= '/cmd/PROJECTS/Index?code=' + project;
        window.location.href = url;
    });

    $("#btnDownloadExcel").click(function () {
        createExcelUsers();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    InitTableProjectUsers();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('#inputSelectUser').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });
});

function InitTableProjectUsers() {

    tableProjectUsers = $('#tableUsers').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 3], "searchable": false },
            {
                "targets": [0, 3], //first column / numbering column
                "orderable": false, //set not orderable
            }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableProjectUsers.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableProjectUsers.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableProjectUsers.draw();

        colorDatatableAllRow(tableProjectUsers);
    });
}

function updateTableProjectUsersSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableProjectUsers.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalProjectUsersColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableProjectUsers.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableProjectUsers.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function showModalAddProjectUser() {
    $("#modalAddProjectUsers").modal('show');
}

function addNewProjectUser() {
    var project = $('#labelProject').text();

    // Area
    var username = [];
    $('#inputSelectUser :selected').each(function () {
        username.push($(this).text());
    });
    if (username.length < 1) {
        alert("Select at least one user!!");
        return;
    }

    if (username == '') {
        alert("Any user selecte!!");
        return;
    }

    var url = "/cmd/PROJECTUSERS/AddNewUser";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'projectCode': project,
            'username': username,
        },
        dataType: "text",
        success: function (response) {
            var logs = JSON.parse(response);
            showExcelLogsAlertNoColumn(logs);
            var project = $('#labelProject').text();
            window.location = '/cmd/PROJECTUSERS/Index?code=' + project;
        },
        error: function (response, error) {
            $("#msgCommonArea").text(response);
        },
    });
}

function deleteCurrentUser(button) {
    var row = $(button).closest("tr");
    var id = row.find("span").html();
    var url = "/cmd/PROJECTUSERS/DeleteUser?id=" + id;
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            if (response == "Deleted") {
                if ($("#tableUsers tr").length > 1) {
                    row.remove();
                    tableProjectUsers.row($(row)).remove().draw(false);
                } else {
                    row.find(".Edit").hide();
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
                var project = $('#labelProject').text();
                window.location = '/cmd/PROJECTUSERS/Index?code=' + project;
            }
            else {
                displayMessage(response);
            }
        },
        error: function (response, error) {
            if (response.responseText == "Deleted") {
                if ($("#tableUsers tr").length > 1) {
                    row.remove();
                    tableProjectUsers.row($(row)).remove().draw(false);
                } else {
                    row.find(".Edit").hide();
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
                var project = $('#labelProject').text();
                window.location = '/cmd/PROJECTUSERS/Index?code=' + project;
            }
            else {
                displayMessage(response.responseText);
            }
        },
    });
}

function downloadExcelTemplateUsers() {
    loadSpinnerModal2();

    $.ajax({
        type: 'GET',
        url: '/cmd/PROJECTUSERS/GetTemplate',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            var link = document.createElement('a');
            link.href = "/cmd/Report/TemplateUsers.xlsx";
            link.download = "TemplateUsers.xlsx";
            link.click();;

            hideSpinnerModal2();
        },
        error: function (data) {
            hideSpinnerModal2();
            alert(data);
        }
    });
}

function importExcelUsers() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal2();
    setProgressMessageModal2("Import Users..");

    $.ajax({
        url: '/cmd/PROJECTUSERS/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/PROJECTUSERS/Index?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelCode').text();
            window.location = '/cmd/PROJECTUSERS/Index?code=' + project;
        }
    });
}

function createExcelUsers() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/PROJECTUSERS/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/Users.xlsx";
            link.download = project + "-Users-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

