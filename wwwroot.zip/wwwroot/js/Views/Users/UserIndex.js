﻿var tableUsers = null;
var totalUsersColumns = 5;

$(document).ready(function () {
    // Set title
    setTitle("Users List");
    hideElement("#ulProject");
    hideElement("#ulProjectCode");
    showElement("#btnDownloadExcel");
    showElement("#btnImportExcel");

    $("#sidebarCollapse").prop("disabled", true);

    $("#btnPrevious").click(function () {
        var url= '/cmd/ADMIN/Index';
        window.location.href = url;
    });

    $("#btnDownloadExcel").click(function () {
        createExcelAdminUsers();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    InitTableUsers();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });
});

function InitTableUsers() {

    tableUsers = $('#tableUsers').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 5], "searchable": false },
            {
                "targets": [0, 5], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 100, targets: 0 }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableUserIndexSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableUsers.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableUsers.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableUsers.draw();

        colorDatatableAllRow(tableUsers);
    });

    hideEventsColumnsUsers();
}

function updateTableUserIndexSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableUsers.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalUsersColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableUsers.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableUsers.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function showModalCreateUser() {
    $("#modalCreateUsers").modal('show');
}

function createNewUser() {
    var username = $("#inputUsername").val();
    if (username == '') {
        alert("Any username!!");
        return;
    }

    var password = 'test';

    var firstname = $("#inputFirstName").val();
    if (firstname == '') {
        alert("Any first name!!");
        return;
    }

    var lastname = $("#inputLastname").val();
    if (lastname == '') {
        alert("Any last name!!");
        return;
    }

    var email = $("#inputEmail").val();
    if (email == '') {
        alert("Any email!!");
        return;
    }

    var phone = '';

    var role = $("#ACCESS_LEVEL").val();
    if (role == '') {
        alert("Any role!!");
        return;
    }

//    var url = "/cmd/USERS/CreateNewUser";
    var url = "/cmd/USERS/CreateNewUser";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'username': username,
            'password': password,
            'firstname': firstname,
            'lastname': lastname,
            'email': email,
            'phone': phone,
            'role': role
        },
        dataType: "text",
        success: function (response) {
            if (response == 'User created') {
                var url= '/cmd/USERS/Index';
                window.location.href = url;
            }
            else {
                $("#msgNewUser").text(response);
            }
        },
        error: function (response, error) {
            $("#msgNewUser").text(response.responseText);
        }
    });
}

function hideEventsColumnsUsers() {
    for (let i = 1; i <= totalUsersColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableUsers.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableUsers);
        })
    }
}

function userApplyTextValues() {
    // Get selected columns
    var colIds = [];
    for (let i = 1; i <= 5; i++) {
        var col1 = document.getElementById("checkBoxVal" + i).checked;
        if (col1) {
            colIds.push(i);
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableUsers.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateUserTableValues(colIdx, rowIdx));
        });
        tableUsers.draw();
    }
}

function updateUserTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableUsers.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        cell = tableUsers.cell({ row: rowIdx, column: colIdx }).node();
        if (colIdx != 5) {
            $('input', cell).val(valueToApply);
        }
        else {
            $('select', cell).val(valueToApply);
        }
    }
}

function userSaveTextValues() {
    var ids = [];
    var usernamelist = [];
    var firstnamelist = [];
    var lastnamelist = [];
    var emaillist = [];
    var phonelist = [];
    var rolelist = [];

    var valid = true;

    tableUsers.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cellvalue = tableUsers.cell({ row: rowIdx, column: 0 }).node();
        value = $('span', cellvalue).text();
        ids.push(value);

        cellvalue = tableUsers.cell({ row: rowIdx, column: 1 }).node();
        value = $('input', cellvalue).val();
        usernamelist.push(value);

        cellvalue = tableUsers.cell({ row: rowIdx, column: 2 }).node();
        value = $('input', cellvalue).val();
        firstnamelist.push(value);

        cellvalue = tableUsers.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellvalue).val();
        lastnamelist.push(value);

        cellvalue = tableUsers.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellvalue).val();
        emaillist.push(value);

        cellvalue = tableUsers.cell({ row: rowIdx, column: 5 }).node();
        value = $('select', cellvalue).val();
        rolelist.push(value);

        if (value == '' || value == null) {
            alert("Incorrect role at row " + rowIdx);
            valid = false;
            return;
        }
    });

    if (!valid) {
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/USERS/UpdateValues',
        data: {
            'idsstr': JSON.stringify(ids),
            'usernamestr': JSON.stringify(usernamelist),
            'firstnamestr': JSON.stringify(firstnamelist),
            'lastnamestr': JSON.stringify(lastnamelist),
            'emailstr': JSON.stringify(emaillist),
            'rolesstr': JSON.stringify(rolelist)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            displayMessage('messageLabel', response);
        },
    });
}

function downloadExcelTemplateAdminUsers() {
    loadSpinnerModal2();

    $.ajax({
        type: 'GET',
        url: '/cmd/USERS/GetTemplate',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            var link = document.createElement('a');
            link.href = "/cmd/Report/TemplateAdminUsers.xlsx";
            link.download = "TemplateAdminUsers.xlsx";
            link.click();;

            hideSpinnerModal2();
        },
        error: function (data) {
            hideSpinnerModal2();
            alert(data);
        }
    });
}

function importExcelAdminUsers() {
    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);

    loadSpinnerModal2();
    setProgressMessageModal2("Import Users..");

    $.ajax({
        url: '/cmd/USERS/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/USERS/Index?code=' + project;   
        },
        error: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelCode').text();
            window.location = '/cmd/USERS/Index?code=' + project;
        }
    });
}

function createExcelAdminUsers() {

    loadSpinner();

    var url= '/cmd/USERS/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/AdminUsers.xlsx";
            link.download = "Users-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function disableUsers() {
    var ids = [];

    tableUsers.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = tableUsers.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            cellvalue = tableUsers.cell({ row: rowIdx, column: 0 }).node();
            value = $('span', cellvalue).text();
            ids.push(value);
        }
    });

    if (ids.length == 0) {
        Alert("Please select at least one user");
        return;
    }

    if (confirm("Do you want disable selected users?")) {
        $.ajax({
            type: 'POST',
            url: '/cmd/USERS/DisableUsers',
            data: {
                'idsstr': JSON.stringify(ids)
            },
            dataType: 'text',
            success: function (response) {
                var logs = JSON.parse(response);
                showExcelLogsAlertNoColumn(logs);
                var project = $('#labelProject').text();
                window.location = '/cmd/USERS/Index?code=' + project;
            },
            error: function (response, error) {
                var logs = JSON.parse(response.responseText);
                showExcelLogsAlertNoColumn(logs);
                var project = $('#labelProject').text();
                window.location = '/cmd/USERS/Index?code=' + project;
            },
        });
    }
}