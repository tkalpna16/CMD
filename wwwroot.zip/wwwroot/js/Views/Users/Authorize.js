﻿$(document).ready(function () {
    // Set title
    setTitle("Access Denied");
    hideElement("#ulProject");
    hideElement("#ulProjectCode");
    hideElement("#btnDownloadExcel");
    hideElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    $("#sidebarCollapse").prop("disabled", true);

    $("#btnPrevious").click(function () {
        var url= '/cmd/cmd/HOME/Index';
        window.location = url;
    });

});


