﻿$(document).ready(function () {
    // Init UI
    InitSteelQtyTables();
    HideAllTablesSteelQty();
    showElement('#divTableSteelEstimatedQty');
});

var pressedBntSteelClass = 'btn-primary'
var notPressedBntSteelClass = 'btn-light'
var steelCodes = ['SteelQty', 'SteelEstimatedQty']
var tableSteelVendors = ['divTableSteelQty', 'divTableSteelEstimatedQty']

var tableSteelQty = null;
var tableSteelEstimatedQty = null;

function SetDLBtnPressed(id) {
    $("#" + id).removeClass(notPressedBntSteelClass);
    $("#" + id).addClass(pressedBntSteelClass);
}
function SetDLBtnNotPressed(id) {
    $("#" + id).removeClass(pressedBntSteelClass);
    $("#" + id).addClass(notPressedBntSteelClass);
}
function RemoveAllButtonPressedSteel() {
    steelCodes.forEach(element => SetDLBtnNotPressed('btn' + element));
}

function HideAllTablesSteelQty() {
    tableSteelVendors.forEach(element => hideElement('#' + element));
}

function InitSteelQtyTables() {
    tableSteelQty = InitSteelQtyTable('tableSteelQty', '32vh');
    tableSteelEstimatedQty = InitSteelQtyTable('tableSteelEstimatedQty', '32vh');
}

function InitSteelQtyTable(tableId, height) {
    var table = $('#' + tableId).DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: height,
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
    return table;
 }

function clickSteelVendorButton(clicked_id) {
    HideAllTablesSteelQty();
    RemoveAllButtonPressedSteel();
    SetDLBtnPressed(clicked_id);
    if (clicked_id != '') {
        var colName = clicked_id.replace('btn', '');
        var divTableName = '#divTable' + colName;
        showElement(divTableName);
        var tableName = '#table' + colName;
        var table = $(tableName).DataTable().columns.adjust();
        table.draw(true);
    }
}

function SaveSteelEstimatedQty() {
    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var lots = [];
    var poeqty = [];
    var ifpeqty = [];
    var iffeqty = [];


    var table = $('#tableSteelEstimatedQty').DataTable();
    var value = null;
    var qty = 0.0;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[1]);
        lots.push(data[2]);

        // PO_E_QTY
        cell = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cell).val();
        qty = parseFloat(value);
        poeqty.push(qty);

        // IFP_E_QTY
        cell = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cell).val();
        qty = parseFloat(value);
        ifpeqty.push(qty);

        // IFF_E_QTY
        cell = table.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', cell).val();
        qty = parseFloat(value);
        iffeqty.push(qty);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/SteelQuantityManager/UpdateEstimatedQty',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'lotsstr': JSON.stringify(lots),
            'poeqtystr': JSON.stringify(poeqty),
            'ifpeqtystr': JSON.stringify(ifpeqty),
            'iffeqtystr': JSON.stringify(iffeqty)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
            setTimeout(function () {
            }, 1000);
            window.location.reload();
        },
        error: function (response, error) {
            displayMessage('messageLabel', response.responseText);
        },
    });
}

function SaveSteelQty() {
    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var lots = [];
    var codes = [];
    var qtylist = [];


    var table = $('#tableSteelQty').DataTable();
    var value = null;
    var qty = 0.0;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[1]);
        lots.push(data[2]);
        codes.push(data[3]);

        // Qty
        cell = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cell).val();
        qty = parseFloat(value);
        qtylist.push(qty);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/SteelQuantityManager/UpdateQty',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'lotsstr': JSON.stringify(lots),
            'codestr': JSON.stringify(codes),
            'qtystr': JSON.stringify(qtylist)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            displayMessage('messageLabel', response.responseText);
        },
    });
}

function ApplySteelEstimatedQty() {
    var value = $('#itemEstimatedQty').val();

    var colPO_E_QTY = document.getElementById("checkboxPO_E_QTY").checked;
    var colIFP_E_QTY = document.getElementById("checkboxIFP_E_QTY").checked;
    var colIFF_E_QTY = document.getElementById("checkboxIFF_E_QTY").checked;
    var rowChecked;
    var cell;

    tableSteelEstimatedQty.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (colPO_E_QTY) {
            cell = tableSteelEstimatedQty.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tableSteelEstimatedQty.cell({ row: rowIdx, column: 3 }).node();
                $('input', cell).val(value);
            }
        }
        if (colIFP_E_QTY) {
            cell = tableSteelEstimatedQty.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tableSteelEstimatedQty.cell({ row: rowIdx, column: 4 }).node();
                $('input', cell).val(value);
            }
        }
        if (colIFF_E_QTY) {
            cell = tableSteelEstimatedQty.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tableSteelEstimatedQty.cell({ row: rowIdx, column: 6 }).node();
                $('input', cell).val(value);
            }
        }
        
    });
    tableSteelEstimatedQty.draw();
}

function ApplySteelQty() {
    var value = $('#itemQty').val();
    
    var rowChecked;
    var cell;

    tableSteelQty.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = tableSteelQty.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            cell = tableSteelQty.cell({ row: rowIdx, column: 5 }).node();
            $('input', cell).val(value);
        }

    });
    tableSteelEstimatedQty.draw();
}

function checkAllColEstimatedQty() {
    var colChecked = document.getElementById("checkboxAllColumn").checked;
    document.getElementById("checkboxPO_E_QTY").checked = colChecked;
    document.getElementById("checkboxIFP_E_QTY").checked = colChecked;
    document.getElementById("checkboxIFF_E_QTY").checked = colChecked;
}

function checkAllItemEstimatedQty() {
    var itemsChecked = document.getElementById("checkboxAllItemsEstimatedQty").checked;
    var table = document.getElementById("tableSteelEstimatedQty");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}

function checkAllItemQty() {
    var itemsChecked = document.getElementById("checkboxAllItemsQty").checked;
    var table = document.getElementById("tableSteelQty");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}
