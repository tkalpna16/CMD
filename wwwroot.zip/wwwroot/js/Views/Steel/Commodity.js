﻿var tableCommodities = null;
var totalCommodityColumns = 6;

$(document).ready(function () {

    setTitle("Commodity Codes");

    // Init UI
    InitTableCommodity();
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/Edit?code=' + project;
        window.location.href = url;
    });

    // Create Button Event
    $("#btnImportCommodities").click(function () {

        var formData = new FormData();
        var totalFiles = document.getElementById("inputExcelFile").files.length;

        // Project code
        var code = $('#labelProject').text();

        if (totalFiles > 0) {
            var file = document.getElementById("inputExcelFile").files[0];
            formData.append("excelFile", file);
            formData.append("projectcode", code);

            $.ajax({
                type: "POST",
                url: '/cmd/COMMODITYCODES/ImportCommodities',
                data: formData,
                contentType: false,
                processData: false,
                success: function (result) {
                    if (result) {
                        displayMessage('messageLabel', result);
                        window.location = '/cmd/COMMODITYCODES/Index?code=' + code;
                    }
                },
                error: function (result) {
                    alert(result.responseText);
                },
                complete: function () {
                    
                }
            });
        }

    });

    // Create Button Event
    $("#btnGetExcelTemplateCommodities").click(function () {
        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/COMMODITYCODES/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Report/TemplateCommodities.xlsx";
                link.download = "TemplateCommodities.xlsx";
                link.click();;
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    colorDatatableAllRow(tableCommodities);

    $('#rowTable').show();
    tableCommodities.columns.adjust();
});

function InitTableCommodity() {
    var projectCode = $('#labelProject').text();
    var currentDate = moment().format("YYYYMMDD");
    var filename = projectCode + "-CommodityCodes-" + currentDate;

    tableCommodities = $('#tableCommodity').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 6], "searchable": false },
            {
                "targets": [0, 6], //first column / numbering column
                "orderable": false, //set not orderable
            }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableCommoditiesSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableCommodities.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableCommodities.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableCommodities.draw();

        colorDatatableAllRow(tableCommodities);
    });
}

function updateTableCommoditiesSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableCommodities.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalCommodityColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableCommodities.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableCommodities.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function checkAllCommodity() {
    colorDatatableAllRow(tableCommodities);
}

function SaveCommodity() {
    var project = $('#labelProject').text();

    // GetData
    var codes = [];
    var checked = [];

    tableCommodities.rows().every(function (rowIdx, tableLoop, rowLoop) {

        var cell = tableCommodities.cell({ row: rowIdx, column: 5 }).node();
        value = cell.innerHTML;
        if (value) {
            value = value.trim();
        }
        codes.push(value);

        cell = tableCommodities.cell({ row: rowIdx, column: 0 }).node();
        value = $('input', cell).prop('checked');;
        checked.push(value);
    });


    $.ajax({
        type: 'POST',
        url: '/cmd/COMMODITYCODES/UpdateSettings',
        data: {
            'projectcode': project,
            'codesstr': JSON.stringify(codes),
            'checkedstr': JSON.stringify(checked)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            displayMessage('messageLabel', response.responseText);
        },
    });
}