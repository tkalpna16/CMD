﻿var tableSteelPlanning = null;

$(document).ready(function () {

    InitTableSteelPlanning();
});

function InitTableSteelPlanning() {
    // Setup - add a text input to each footer cell
    $('#tablePlanning thead tr').clone(true).appendTo('#tablePlanning thead');
    $('#tablePlanning thead tr:eq(1) th').each(function (i) {
        var title = $(this).text();
        if ($(this).index() != 0) {
            $(this).html('<input type="text" placeholder="Search" style="width:100%" />');

            $('input[type="text"]', this).on('keyup change', function () {
                if (tableQTY.column(i).search() !== this.value) {
                    tableQTY
                        .column(i)
                        .search(this.value)
                        .draw();
                }
            });
        }
    });

    tableSteelPlanning = $('#tablePlanning').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        scrollY: '36vh',
        scrollCollapse: true,
        searching: true,
        bInfo: false,
        bSort: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });

    UpdateSteelPlanningVisibility();
}

function UpdateSteelPlanningVisibility() {
    var table = tableSteelPlanning;
    if (!table.rows().count()) {
        hideElement("#divTablePlanning");
        showElement('#emptyRows');
    }
    else {
        showElement('#divTablePlanning');
        hideElement('#emptyRows');
    }
}

function ApplyDateSteelPlanning() {
    var value = $('#itemDateAll').val();
    var inputDate = moment(value).format('YYYY-MM-DD');

    var colDateIFP = document.getElementById("checkboxDateIFP").checked;
    var colDateIFF = document.getElementById("checkboxDateIFF").checked;
    var colDate1AIVD = document.getElementById("checkboxDate1AIVD").checked;
    var colDate2AIVD = document.getElementById("checkboxDate2AIVD").checked;
    var colDate3AIVD = document.getElementById("checkboxDate3AIVD").checked;
    var colDate4AIVD = document.getElementById("checkboxDate4AIVD").checked;
    var colDate5AIVD = document.getElementById("checkboxDate5AIVD").checked;
    var colDate6AIVD = document.getElementById("checkboxDate6AIVD").checked;
    var colDate7AIVD = document.getElementById("checkboxDate7AIVD").checked;
    var rowChecked;
    var cell;

    var datatable = tableSteelPlanning;
    datatable.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (colDateIFP) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 3 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDateIFF) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 4 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate1AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 5 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate2AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 6 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate3AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 7 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate4AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 8 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate5AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 9 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate6AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 10 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colDate7AIVD) {
            cell = datatable.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = datatable.cell({ row: rowIdx, column: 11 }).node();
                $('input', cell).val(inputDate);
            }
        }
    });
    datatable.draw();
}

function SaveDateSteelPlanning() {
    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var lots = [];
    var dates1 = [];
    var dates2 = [];
    var dates3 = [];
    var dates4 = [];
    var dates5 = [];
    var dates6 = [];
    var dates7 = [];
    var dates8 = [];
    var dates9 = [];
    var celldate;


    var table = tableSteelPlanning;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[1]);
        lots.push(data[2]);

        celldate = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', celldate).val();
        dates1.push(value);

        celldate = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', celldate).val();
        dates2.push(value);

        celldate = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', celldate).val();
        dates3.push(value);

        celldate = table.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', celldate).val();
        dates4.push(value);

        celldate = table.cell({ row: rowIdx, column: 7 }).node();
        value = $('input', celldate).val();
        dates5.push(value);

        celldate = table.cell({ row: rowIdx, column: 8 }).node();
        value = $('input', celldate).val();
        dates6.push(value);

        celldate = table.cell({ row: rowIdx, column: 9 }).node();
        value = $('input', celldate).val();
        dates7.push(value);

        celldate = table.cell({ row: rowIdx, column: 10 }).node();
        value = $('input', celldate).val();
        dates8.push(value);

        celldate = table.cell({ row: rowIdx, column: 11 }).node();
        value = $('input', celldate).val();
        dates9.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/STEELPLANNINGS/UpdateDates',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'lotsstr': JSON.stringify(lots),
            'datesstr1': JSON.stringify(dates1),
            'datesstr2': JSON.stringify(dates2),
            'datesstr3': JSON.stringify(dates3),
            'datesstr4': JSON.stringify(dates4),
            'datesstr5': JSON.stringify(dates5),
            'datesstr6': JSON.stringify(dates6),
            'datesstr7': JSON.stringify(dates7),
            'datesstr8': JSON.stringify(dates8),
            'datesstr9': JSON.stringify(dates9)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            displayMessage('messageLabel', response.responseText);
        },
    });
}

function checkAllColPlanning() {
    var colChecked = document.getElementById("checkboxAllColumn").checked;
    document.getElementById("checkboxDateIFP").checked = colChecked;
    document.getElementById("checkboxDateIFF").checked = colChecked;
    document.getElementById("checkboxDate1AIVD").checked = colChecked;
    document.getElementById("checkboxDate2AIVD").checked = colChecked;
    document.getElementById("checkboxDate3AIVD").checked = colChecked;
    document.getElementById("checkboxDate4AIVD").checked = colChecked;
    document.getElementById("checkboxDate5AIVD").checked = colChecked;
    document.getElementById("checkboxDate6AIVD").checked = colChecked;
    document.getElementById("checkboxDate7AIVD").checked = colChecked;
}

function checkAllItemPlanning() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = document.getElementById("tablePlanning");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}