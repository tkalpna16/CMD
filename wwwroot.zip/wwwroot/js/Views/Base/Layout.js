﻿var tableActiveUsers = null;

$(document).ready(function () {

    addNavigationButtonEvents();
    addSidebarNavigationButtonEvents();
    InitTableActiveUsers();

    // Dashboard
    $('#selectLogin').on('change', function () {

        var dropdownval = $("#selectLogin").val();
        if (dropdownval == '2') {
            $.ajax({
                url: '/cmd/HOME/Logoff',
                type: 'POST',
                username: '<%:random%>',
                password: '<%:random%>',
                success: function () {
                    alert('logged off');
                    var url= '/cmd/HOME/Index';
                    window.location.href = url;
                },
                error: function () {
                    alert('logged off');
                    var url= '/cmd/HOME/Index';
                    window.location.href = url;
                }
            });
        }
    });
});

function addSidebarNavigationButtonEvents() {
    $('#sidebarDataManagement').click(function () {
        openDataManagementFromButton();
        return false;
    });

    $('#sidebarPBS').click(function () {
        openPBSCreatorFromButton();
        return false;
    });

    $('#sidebarItemList').click(function () {
        openMainItemCreatorFromButton();
        return false;
    });

    $('#sidebarDLGenerator').click(function () {
        openDLGeneratorFromButton();
        return false;
    });

    $('#sidebar3DModel').click(function () {
        openModelConnectorFromButton();
        return false;
    });

    $('#sidebarPlanning').click(function () {
        openPlanningManagerFromButton();
        return false;
    });

    $('#sidebarQtyManager').click(function () {
        openQuantityManagerFromButton();
        return false;
    });

    $('#sidebarHoldManager').click(function () {
        openHoldManagerFromButton();
        return false;
    });

    $('#sidebarPreAccounting').click(function () {
        openPreAccountingSheetFromButton();
        return false;
    });

    $('#sidebarDataSchedule').click(function () {
        openDataScheduleFromButton();
        return false;
    });

    
    $('#sidebarDataReports').click(function () {
        openDataReportsFromButton();
        return false;
    });
}

function addNavigationButtonEvents() {
    $('#pbsGeneratorBtn').click(function () {
        openPBSCreatorFromButton();
        return false;
    });

    $('#itemListGeneratorBtn').click(function () {
        openMainItemCreatorFromButton();
        return false;
    });

    $('#dlGeneratorBtn').click(function () {
        openDLGeneratorFromButton();
        return false;
    });

    $('#modelConnectorBtn').click(function () {
        openModelConnectorFromButton();
        return false;
    });

    $('#modelPlanningBtn').click(function () {
        openPlanningManagerFromButton();
        return false;
    });

    $('#modelQtyManagerBtn').click(function () {
        openQuantityManagerFromButton();
        return false;
    });

    $('#holdManagerBtn').click(function () {
        openHoldManagerFromButton();
        return false;
    });

    $('#preAccountingBtn').click(function () {
        openPreAccountingSheetFromButton();
        return false;
    });
}

function openDataManagementFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/PROJECTS/DataManagement?code=' + projectId;
    window.location.href = url;
}

function openPBSCreatorFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/PBS/Index?code=' + projectId;
    window.location.href = url;
}

function openMainItemCreatorFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/ItemListCreation/Index?code=' + projectId;
    window.location.href = url;
}

function openPlanningManagerFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/PLANNINGS/Index?code=' + projectId;
    window.location.href = url;
}

function openHoldManagerFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/HoldManager/Index?code=' + projectId;
    window.location.href = url;
}

function openModelConnectorFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/MODELCONNECTOR/Index?code=' + projectId;
    window.location.href = url;
}

function openQuantityManagerFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/QUANTITYMANAGER/Manager?code=' + projectId;
    window.location.href = url;
}

function openPreAccountingSheetFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/PriceEvaluator/Index?code=' + projectId;
    window.location.href = url;
}

function openDLGeneratorFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProject').text();
    var url= '/cmd/DLGENERATOR/Index?code=' + projectId;
    window.location.href = url;
}

function openDataScheduleFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProjectDescription').text();
    var url= '/cmd/ViewManager/Index?code=' + projectId;
    window.location.href = url;
}


function openDataReportsFromButton() {
    loadSpinner();
    setProgressMessage("Loading..");
    var projectId = $('#labelProjectDescription').text();
    var url= '/cmd/Reports/Index?code=' + projectId;
    window.location.href = url;
}

function hideExcelButtons() {
    hideElement('#btnDownloadExcel');
    hideElement('#btnImportExcel');
}

function getActiveUsers() {
    $.ajax({
        url: '/cmd/HOME/GetActiveUsers',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response) {
                tableActiveUsers.clear();
                $.each(response, function (i, item) {
                    addRowAcriveUser(item);
                });
            }
        },
        error: function (response) {
            alert(response.responseText);
        }
    });
}

function InitTableActiveUsers() {

    tableActiveUsers = $('#tableActiveUsers').DataTable({
        dom: 'Rrtip',
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: false,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        order: [
            [0, 'asc']
        ]
    });
}

function addRowAcriveUser(element) {
    tableActiveUsers.row.add([
        element.username
    ]).draw(true);
}
