﻿$(document).ready(function () {

    $("#btnLinkProjects").click(function () {
        var url= '/cmd/PROJECTS/Index';
        window.location.href = url;
    });

    $("#btnLinkAdmin").click(function () {
        var url= '/cmd/ADMIN/Index';
        window.location.href = url;
    });
});