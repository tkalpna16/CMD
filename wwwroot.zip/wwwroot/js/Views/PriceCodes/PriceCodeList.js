﻿var tablePriceCodes = null;

$(document).ready(function () {
    // Init UI
    InitTablePriceCode();

    $("#btnBack").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/PriceCodesManager?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    $('#btnGetExcel').on('click', function (evt) {
        evt.preventDefault();

        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        var fileInput = document.getElementById('inputFile');
        var file = fileInput.files[0];
        var formData = new FormData();
        formData.append('postedFile', file);
        formData.append('code', project);

        loadSpinner();
        $.ajax({
            url: '/cmd/PRICECODEDEFINITIONS/ImportExcel',
            contentType: false,
            processData: false,
            type: 'post',
            data: formData,
            success: function (val) {
                hideSpinner();
                alert(val);
                document.location.reload();
            },
            error: function (val) {
                hideSpinner();
                alert(val);
                document.location.reload();
            },
        });
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/PRICECODEDEFINITIONS/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Report/TemplatePriceCodeDefinitions.xlsx";
                link.download = "TemplatePriceCodeDefinitions.xlsx";
                link.click();;
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });
});

function InitTablePriceCode() {

    $('#tablePriceCodeList thead th').each(function () {
        var title = $(this).text();
        title = title.trim();
        if (title == 'Unit' || title == 'Area') {
            var html = '<div style="display:inline-block">' + title + '<input type="text" style="margin-left:1vw" placeholder="Search"></div>';
            $(this).html(html);
        }
    });

    var table = $('#tablePriceCodeList').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '40vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        search: {
            "caseInsensitive": true
        }
    });
    tablePriceCodes = table;
}

function checkAllGroups() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = document.getElementById("tablePriceCodeList");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}

function DeletePriceGroup() {
    var project = $('#labelProject').text();
    var selectedItems = [];
    var cell = null;

    tablePriceCodes.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = tablePriceCodes.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            cell = tablePriceCodes.cell({ row: rowIdx, column: 1 }).node();
            var id = $('span', cell).text();
            selectedItems.push(id);
        }
    });

    if (selectedItems.length == 0) {
        alert("Any item selected!!");
        return;
    }

    if (confirm("Do you want to delete selected Groups and all element derived?")) {
        var url = "/cmd/PRICECODEDEFINITIONS/DeleteMultipleGroups";
        var data = JSON.stringify(selectedItems);
        $.ajax({
            type: "POST",
            url: url,
            data: {
                'idStr': data
            },
            dataType: "text",
            success: function (response) {
                if (response == STATUS_DELETED) {
                    window.location = '/cmd/PRICECODEDEFINITIONS/Index?code=' + project;
                }
                else {
                    displayMessage(response);
                }
            },
            error: function (response, error) {
                if (response.responseText == STATUS_DELETED) {
                    window.location = '/cmd/PRICECODEDEFINITIONS/Index?code=' + project;
                }
                else {
                    displayMessage(response.responseText);
                }
            },
        });
    }
}

//Delete Item event handler.
$("body").on("click", "#tablePriceCodeList .Delete", function () {
    if (confirm("Do you want to delete this Group and all element derived?")) {
        var row = $(this).closest("tr");
        var pbsId = row.find("span").html();
        var url = "/cmd/PRICECODEDEFINITIONS/DeleteGroup?id=" + pbsId;
        $.ajax({
            type: "POST",
            url: url,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response == STATUS_DELETED) {
                    if ($("#tablePriceCodeList tr").length > 1) {
                        row.remove();
                        tablePriceCodes.row($(row)).remove().draw(false);
                    } else {
                        row.find(".Edit").hide();
                        row.find(".Delete").hide();
                        row.find("span").html('&nbsp;');
                    }
                }
                else {
                    displayMessage(response);
                }
            },
            error: function (response, error) {
                if (response.responseText == STATUS_DELETED) {
                    if ($("#tablePriceCodeList tr").length > 1) {
                        row.remove();
                        tablePriceCodes.row($(row)).remove().draw(false);
                    } else {
                        row.find(".Edit").hide();
                        row.find(".Delete").hide();
                        row.find("span").html('&nbsp;');
                    }
                }
                else {
                    displayMessage(response.responseText);
                }
            },
        });
    }
});
