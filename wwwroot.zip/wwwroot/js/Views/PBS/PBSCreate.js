﻿$(document).ready(function () {

    $("#AutoCWA").on("change", function () {
        $("#inputCWA").prop("disabled", $(this).prop("checked"));
    });

    $("#AutoDAS").on("change", function () {
        $("#inputDAS").prop("disabled", $(this).prop("checked"));
    });
});