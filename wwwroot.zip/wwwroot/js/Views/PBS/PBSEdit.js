﻿$(document).ready(function () {

    // Create Button Event
    $("#btnSavePBS").click(function () {

        $.ajax({
            type: 'POST',
            url: '/cmd/PBS/Edit',
            data: $('form').serialize(),
            success: function (response) {
                displayMessage(response);
            },
            error: function (response, error) {
                displayMessage(response.responseText);
            },
        });
    });
});