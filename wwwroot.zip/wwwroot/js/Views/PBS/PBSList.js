﻿var tablePBS = null;
var totalPBSColumns = 5;

$(document).ready(function () {
    // Main Settings
    setTitle("PBS Generator"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    showElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#pbsGeneratorBtn"); // Hide PBS Button

    $("#btnDownloadExcel").click(function () {
        createExcelPBS();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTablePBS();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $("#checkBoxAutoCWA").on("change", function () {
        $("#inputCWA").prop("disabled", $(this).prop("checked"));
    });

    $('#rowTable').show();
    tablePBS.columns.adjust();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });
});

function InitTablePBS() {

    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    tablePBS = $('#tablePBSList').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": 3, "orderDataType": "dom-text", type: 'string' },
            { "targets": 4, "orderDataType": "dom-text", type: 'string' },
            { "targets": 5, "orderDataType": "dom-text", type: 'string' },
            { "targets": [0, 6], "searchable": false },
            {
                "targets": [0, 6], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 100, targets: 0 }
        ],
        order: [
            [2, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTablePBSSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tablePBS.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tablePBS.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tablePBS.draw();

        colorDatatableAllRow(tablePBS);
    });

    hideEventsColumnsPBS();
}

function updateTablePBSSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tablePBS.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalPBSColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tablePBS.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tablePBS.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function showModalCreatePBS() {
    $("#modalCreatePBS").modal('show');
}

function showModalCommonArea() {
    $("#modalCommonArea").modal('show');
    var commonArea = $("#labelCommonArea").text();
    $("#inputCommonArea").val(commonArea);
    $("#msgCommonArea").text('');
}

function setCommonArea() {
    var project = $('#labelProject').text();
    var commonArea = $("#inputCommonArea").val();

    if (commonArea == '') {
        alert("Any common area!!");
        return;
    }

    var url = "/cmd/PBS/SaveCommonArea";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'projectCode': project,
            'commonArea': commonArea,
        },
        dataType: "text",
        success: function (response) {
            $("#msgCommonArea").text(response);
            if (response == "Saved") {
                $("#labelCommonArea").text(commonArea);
            }
        },
        error: function (response, error) {
            $("#msgCommonArea").text(response);
        },
    });
}

function deletePBSItems() {
    var project = $('#labelProject').text();
    var selectedItems = [];
    var cell = null;

    tablePBS.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = tablePBS.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            cell = tablePBS.cell({ row: rowIdx, column: 1 }).node();
            var id = $('span', cell).text();
            selectedItems.push(id);
        }
    });

    if (selectedItems.length == 0) {
        alert("Any item selected!!");
        return;
    }

    if (confirm("Do you want to delete selected PBS and all element derived?")) {
        var url = "/cmd/PBS/DeleteMultiplePBS";
        var data = JSON.stringify(selectedItems);
        $.ajax({
            type: "POST",
            url: url,
            data: {
                'idStr': data
            },
            dataType: "text",
            success: function (response) {
                if (response == STATUS_PBS_DELETED) {
                    window.location = '/cmd/PBS/Index?code=' + project;
                }
                else {
                    displayMessage(response);
                }
            },
            error: function (response, error) {
                if (response.responseText == STATUS_PBS_DELETED) {
                    window.location = '/cmd/PBS/Index?code=' + project;
                }
                else {
                    displayMessage(response.responseText);
                }
            },
        });
    }
}

//Delete Item event handler.
$("#tablePBSList").on("click", ".Delete", function () {
    if (confirm("Do you want to delete this PBS and all element derived?")) {
        var row = $(this).closest("tr");
        var pbsId = row.find("span").html();
        var url = "/cmd/PBS/DeletePBS?id=" + pbsId;
        $.ajax({
            type: "POST",
            url: url,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response == STATUS_PBS_DELETED) {
                    if ($("#tablePBSList tr").length > 1) {
                        row.remove();
                        tablePBS.row($(row)).remove().draw(false);
                    } else {
                        row.find(".Edit").hide();
                        row.find(".Delete").hide();
                        row.find("span").html('&nbsp;');
                    }
                }
                else {
                    displayMessage(response);
                }
            },
            error: function (response, error) {
                if (response.responseText == STATUS_PBS_DELETED) {
                    if ($("#tablePBSList tr").length > 1) {
                        row.remove();
                        tablePBS.row($(row)).remove().draw(false);
                    } else {
                        row.find(".Edit").hide();
                        row.find(".Delete").hide();
                        row.find("span").html('&nbsp;');
                    }
                }
                else {
                    displayMessage(response.responseText);
                }
            },
        });
    }
});

function deleteCurrentPBS(button) {
    var row = $(button).closest("tr");
    var pbsId = row.find("span").html();
    var url = "/cmd/PBS/DeletePBS?id=" + pbsId;
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            if (response == STATUS_PBS_DELETED) {
                if ($("#tablePBSList tr").length > 1) {
                    row.remove();
                    tablePBS.row($(row)).remove().draw(false);
                } else {
                    row.find(".Edit").hide();
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response);
            }
        },
        error: function (response, error) {
            if (response.responseText == STATUS_PBS_DELETED) {
                if ($("#tablePBSList tr").length > 1) {
                    row.remove();
                    tablePBS.row($(row)).remove().draw(false);
                } else {
                    row.find(".Edit").hide();
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response.responseText);
            }
        },
    });
}

function checkAllItemPBS(itemsChecked) {
    colorDatatableAllRow(tablePBS);
}

function createNewPBS() {
    var project = $('#labelProject').text();

    var unit = $("#inputUnit").val();
    if (unit == '') {
        alert("Any unit!!");
        return;
    }

    var area = $("#inputArea").val();
    if (area == '') {
        alert("Any area!!");
        return;
    }

    var autoCWA = document.getElementById("checkBoxAutoCWA").checked;
    var cwa = $("#inputCWA").val();

    var areasize = document.getElementById("inputAreaSize").value;
    if (area < 0) {
        alert("Incorrect area size!!");
        return;
    }

    var areadescription = $("#inputAreaDescription").val();

    loadSpinnerModal();
    setProgressMessageModal("Creating PBS..");

    var url = "/cmd/PBS/CreateNewPBS";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'projectCode': project,
            'unit': unit,
            'area': area,
            'autoCWA': autoCWA,
            'cwa': cwa,
            'areasize': areasize,
            'areadescription': areadescription
        },
        dataType: "text",
        success: function (response) {
            hideSpinnerModal();
            if (response == 'PBS created') {
                var url= '/cmd/PBS/Index?code=' + project;
                window.location.href = url;
            }
            else {
                $("#msgNewPBS").text(response);
            }
        },
        error: function (response, error) {
            hideSpinnerModal();
            $("#msgNewPBS").text(response);
        },
    });
}

function pbsApplyTextValues() {
    // Get selected columns
    var colIds = [];
    for (let i = 1; i <= 5; i++) {
        if (i > 2) {
            var col1 = document.getElementById("checkBoxVal" + i).checked;
            if (col1) {
                colIds.push(i);
            }
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tablePBS.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updatePBSTableValues(colIdx, rowIdx));
        });
    }
}

function updatePBSTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tablePBS.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        if (colIdx != 5 && colIdx != 1) {
            cell = tablePBS.cell({ row: rowIdx, column: colIdx }).node();
            $('input', cell).val(valueToApply);
        }
        else {
            // Parse float
            var val = parseInt(valueToApply);
            if (val) {
                cell = tablePBS.cell({ row: rowIdx, column: colIdx }).node();
                $('input', cell).val(val);
            }
        }
    }
}

function pbsSaveTextValues() {
    loadSpinner();
    setProgressMessage("Saving PBS..");

    var project = $('#labelProject').text();

    var pbsid = [];
    var cwas = [];
    var sizes = [];
    var descriptions = [];

    var valid = true;

    tablePBS.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (!valid) {
            return;
        }

        var data = this.data();

        cellvalue = tablePBS.cell({ row: rowIdx, column: 0 }).node();
        value = $('span', cellvalue).text();
        pbsid.push(value);

        cellvalue = tablePBS.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellvalue).val();
        cwas.push(value);

        cellvalue = tablePBS.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellvalue).val();
        descriptions.push(value);

        cellvalue = tablePBS.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellvalue).val();
        var floatval = parseFloat(value);
        if (floatval >= 0.0) {
            sizes.push(floatval);
        }
        else {
            alert("Invalid value for area size at row " + rowIdx);
            valid = false;
            return;
        }
    });

    if (!valid) {
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/PBS/UpdateValues',
        data: {
            'code': project,
            'pbsidstr': JSON.stringify(pbsid),
            'cwasstr': JSON.stringify(cwas),
            'sizesstr': JSON.stringify(sizes),
            'descriptionsstr': JSON.stringify(descriptions)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
    });
}

function createExcelPBS() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/PBS/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/PBS.xlsx";
            link.download = project + "-PBS-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function downloadExcelPBSTemplate() {
    loadSpinnerModal2();

    $.ajax({
        type: 'GET',
        url: '/cmd/PBS/GetTemplate',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            var link = document.createElement('a');
            link.href = "/cmd/Report/TemplatePBS.xlsx";
            link.download = "TemplatePBS.xlsx";
            link.click();;

            hideSpinnerModal2();
        },
        error: function (data) {
            hideSpinnerModal2();
            alert(data);
        }
    });
}

function importExcelPBS() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal2();
    setProgressMessageModal2("Import PBS..");

    $.ajax({
        url: '/cmd/PBS/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/PBS/Index?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelCode').text();
            window.location = '/cmd/PBS/Index?code=' + project;
        }
    });
}

function hideEventsColumnsPBS() {
    for (let i = 1; i <= totalPBSColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tablePBS.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tablePBS);
        })
    }
}