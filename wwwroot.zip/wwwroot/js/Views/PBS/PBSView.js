﻿var tablePBSView = null;
var totalPBSViewColumns = 4;

$(document).ready(function () {
    // Main Settings
    setTitle("PBS List"); // Set Title
    hideElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        createExcelPBSView();
    });
    
    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTablePBSView();

    $('#rowTable').show();
    tablePBSView.columns.adjust();

});

function InitTablePBSView() {

    tablePBSView = $('#tablePBSList').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        order: [
            [0, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTablePBSViewSearch();
    });

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    hideEventsColumnsPBSView();
}

function updateTablePBSViewSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tablePBSView.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalPBSViewColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tablePBSView.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tablePBSView.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}


function createExcelPBSView() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/PBS/CreateExcelView';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/PBSView.xlsx";
            link.download = project + "-PBSView-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}


function hideEventsColumnsPBSView() {
    for (let i = 0; i < totalPBSViewColumns; i++) {
        var index = i + 1;
        var checkbox = document.getElementById("checkBoxVis" + index);
        checkbox.addEventListener('change', (event) => {
            tablePBSView.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tablePBSView);
        })
    }
}