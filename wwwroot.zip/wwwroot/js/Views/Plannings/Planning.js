﻿var tablePlanning = null;
var tableDeliveryTime = null;
var totalPlanningColumns = 30;
var totalParameters = 0;

var sourceDateNames = ['DATE INPUT FORECAST', 'DATE IFR BASELINE (LEV3)', 'DATE IFR BASELINE (ENG)', 'DATE IFR QUALITY CHECK FORECAST', 'DATE IFR QUALITY CHECK ACTUAL', 'DATE IFR FORECAST', 'DATE IFR ACTUAL', 'DATE IFC BASELINE (LEV3)', 'DATE IFC BASELINE (ENG)', 'DATE IFC QUALITY CHECK FORECAST', 'DATE IFC QUALITY CHECK ACTUAL', 'DATE IFC FORECAST', 'DATE IFC ACTUAL'];
var sourceDateIndex = [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28];

const startingColumnPlanning = 30;
const maxParametersPlanning = 10;

$(document).ready(function () {
    // Main Settings
    setTitle("Planning Manager"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    showElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#modelPlanningBtn"); // Disable Planning Button

    // Additional buttons
    var role = $("#labelRole").text();
    if (role == 'Admin' || role == 'Discipline Leader') {
        InitCommandsPlanning1();
        showElement("#btnCommand1");
    }
    if (role == 'Admin' || role == 'Discipline Leader' || role == 'Specialist') {
        InitCommandsPlanning2();
        showElement("#btnCommand2");
    }

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcelPlanning();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });

    $('.datepicker').datepicker({
        changeMonth: true,
        changeYear: true,
        format: "yyyy/mm/dd",
        language: "en"
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/ItemListCreation/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: {
                'code': project
            },
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Temp/TemplateCIL.xlsx";
                link.download = "TemplateCIL.xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    // Init UI
    InitTablePlanning();
    initDTSelection(false);

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    // Init Parameters
    var labelVal = $('#labelParameters').text();
    totalParameters = parseInt(labelVal);

    // Add Custom Dates
    for (let i = 0; i < totalParameters; i++) {
        sourceDateIndex.push(i + startingColumnPlanning);
        var value = $("#labelCheckBoxDT" + (i + 6)).text();
        sourceDateNames.push(value);
    }

    // Hide Checkbox
    for (let i = totalParameters; i < maxParametersPlanning; i++) {
        hideElement("#rowParam" + (i + startingColumnPlanning));
        hideElement("#rowParamAD" + (i + startingColumnPlanning));
        hideElement("#rowParamVis" + (i + startingColumnPlanning));
        hideElement("#rowParamVal" + (i + startingColumnPlanning));
        hideElement("#checkRow" + i);
    }

    $('#rowTable').show();
    tablePlanning.columns.adjust();
    tablePlanning.draw();
});

function InitTablePlanning() {
    var labelVal = $('#labelParameters').text();
    var totalParameters = parseInt(labelVal);

    tablePlanning = $('#tablePlanning').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: false,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, totalPlanningColumns], "searchable": false },
            {
                "targets": [0, totalPlanningColumns], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 35, targets: 0 },
            { width: 70, targets: 8 },
            { width: 60, targets: 15 },
            { "targets": 15, "orderDataType": "dom-text", type: 'string' },
            { "targets": 16, "orderDataType": "dom-text", type: 'string' },
            { "targets": 17, "orderDataType": "dom-text", type: 'string' },
            { "targets": 18, "orderDataType": "dom-text", type: 'string' },
            { "targets": 19, "orderDataType": "dom-text", type: 'string' },
            { "targets": 20, "orderDataType": "dom-text", type: 'string' },
            { "targets": 21, "orderDataType": "dom-text", type: 'string' },
            { "targets": 22, "orderDataType": "dom-text", type: 'string' },
            { "targets": 23, "orderDataType": "dom-text", type: 'string' },
            { "targets": 24, "orderDataType": "dom-text", type: 'string' },
            { "targets": 25, "orderDataType": "dom-text", type: 'string' },
            { "targets": 26, "orderDataType": "dom-text", type: 'string' },
            { "targets": 27, "orderDataType": "dom-text", type: 'string' },
            { "targets": 28, "orderDataType": "dom-text", type: 'string' }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        createdRow: function (row, data, index) {
            try {
                var cell = row.cells[8];
                if (cell.children.length > 0) {
                    var status = cell.children[0].value;
                    if (status == "Deleted" || status == "Replaced") {
                        return;
                    }
                }

                var dateIFRFore = null;
                var dateIFCFore = null;
                var dateInpFore = null;
                var dateIFRCheckFore = null;
                var dateIFCCheckFore = null;
                var dateIFRAct = null;
                var dateIFCAct = null;

                var validIFRAct = false;
                var cell = row.cells[22];
                if (cell.children.length > 0) {
                    var dateIFRActStr = cell.children[0].value;
                    dateIFRAct = moment(dateIFRActStr, 'YYYY-MM-DD');
                    validIFRAct = dateIFRAct.isValid();
                }
                var validIFCAct = false;
                cell = row.cells[28];
                if (cell.children.length > 0) {
                    var dateIFCActStr = cell.children[0].value;
                    dateIFCAct = moment(dateIFCActStr, 'YYYY-MM-DD');
                    validIFCAct = dateIFCAct.isValid();
                }

                // Get current date
                var currentDate = moment().utcOffset(0);
                currentDate.set({ hour: 0, minute: 0, second: 0, millisecond: 0 });

                // Check IFR FORECAST - Current Date
                var validIFRFore = false;
                if (!validIFRAct) {
                    cell = row.cells[21];
                    if (cell.children.length > 0) {
                        var dateIFRForeStr = cell.children[0].value;
                        dateIFRFore = moment(dateIFRForeStr, 'YYYY-MM-DD');
                        if (dateIFRFore.isValid()) {
                            validIFRFore = true;
                            if (dateIFRFore < currentDate) {
                                row.cells[21].style.backgroundColor = "red";
                                settooltiptext(cell.children[0], 'FORECAST DATE IS OUTDATED');
                            }
                        }
                    }
                }

                // Check IFC FORECAST - Current Date
                var validIFCFore = false;
                if (!validIFCAct) {
                    cell = row.cells[27];
                    if (cell.children.length > 0) {
                        var dateIFCForeStr = cell.children[0].value;
                        dateIFCFore = moment(dateIFCForeStr, 'YYYY-MM-DD');
                        if (dateIFCFore.isValid()) {
                            validIFCFore = true;
                            if (dateIFCFore < currentDate) {
                                row.cells[27].style.backgroundColor = "red";
                                settooltiptext(cell.children[0], 'FORECAST DATE IS OUTDATED');
                            }
                        }
                    }
                }

                // Get DATE INPUT FORECAST
                cell = row.cells[16];
                if (cell.children.length > 0) {
                    var dateInpForeStr = cell.children[0].value;
                    dateInpFore = moment(dateInpForeStr, 'YYYY-MM-DD');
                }

                // Get DATE IFR QUALITY CHECK FORECAST
                cell = row.cells[19];
                if (cell.children.length > 0) {
                    var dateIFRCheckForeStr = cell.children[0].value;
                    dateIFRCheckFore = moment(dateIFRCheckForeStr, 'YYYY-MM-DD');
                }

                // Get DATE IFC QUALITY CHECK FORECAST
                cell = row.cells[25];
                if (cell.children.length > 0) {
                    var dateIFCCheckForeStr = cell.children[0].value;
                    dateIFCCheckFore = moment(dateIFCCheckForeStr, 'YYYY-MM-DD');
                }

                if (!validIFRAct && !validIFCAct) {

                    // Check DATE IFR FORECAST
                    if (dateIFRFore != null && dateIFRFore.isValid()) {
                        if (dateIFRCheckFore != null && dateIFRCheckFore.isValid()) {
                            if (dateIFRFore < dateIFRCheckFore) {
                                row.cells[21].style.backgroundColor = "red";
                                settooltiptext(row.cells[21].children[0], 'FORECAST DATE IS OUTDATED');
                            }
                        }
                    }

                    // Check DATE IFR QUALITY CHECK FORECAST
                    if (dateIFRCheckFore != null && dateIFRCheckFore.isValid()) {
                        if (dateInpFore != null && dateInpFore.isValid()) {
                            if (dateIFRCheckFore < dateInpFore) {
                                row.cells[19].style.backgroundColor = "red";
                                settooltiptext(row.cells[19].children[0], 'FORECAST DATE IS OUTDATED');
                            }
                        }
                    }
                }

                if (!validIFCAct) {
                    // Check IFC Forecast
                    if (dateIFCFore != null && dateIFCFore.isValid()) {
                        if (dateIFCCheckFore != null && dateIFCCheckFore.isValid()) {
                            if (dateIFCFore < dateIFCCheckFore) {
                                row.cells[27].style.backgroundColor = "red";
                                settooltiptext(row.cells[27].children[0], 'FORECAST DATE IS OUTDATED');
                            }
                        }
                    }

                    // Check  DATE IFC QUALITY CHECK FORECAST
                    if (dateIFCCheckFore != null && dateIFCCheckFore.isValid()) {
                        if (dateIFRFore != null && dateIFRFore.isValid()) {
                            if (dateIFCCheckFore < dateIFRFore) {
                                row.cells[25].style.backgroundColor = "red";
                                settooltiptext(row.cells[25].children[0], 'FORECAST DATE IS OUTDATED');
                            }
                        }
                    }
                }

                // QTY
                try {

                    // Check IFR Actual
                    var cell1 = row.cells[41];
                    if (cell1.children.length > 0) {
                        var qtyIFR = cell1.children[0].value;
                        if (qtyIFR && qtyIFR > 0.0) {
                            cell = row.cells[22];
                            var dateIFRActStr = cell.children[0].value;
                            dateIFRAct = moment(dateIFRActStr, 'YYYY-MM-DD');
                            if (!dateIFRAct.isValid()) {
                                row.cells[22].style.backgroundColor = "orange";
                                settooltiptext(row.cells[22].children[0], 'DATE MISSING, RELATIVE QTY IN QUANTITY MANAGER IS AVAILABLE');
                            }
                        }
                    }

                    // Check IFC Actual
                    var cell2 = row.cells[40];
                    if (cell2.children.length > 0) {
                        var qtyIFC = cell2.children[0].value;
                        if (qtyIFC && qtyIFC > 0.0) {
                            cell = row.cells[28];
                            var dateIFCActStr = cell.children[0].value;
                            dateIFCAct = moment(dateIFCActStr, 'YYYY-MM-DD');
                            if (!dateIFCAct.isValid()) {
                                row.cells[28].style.backgroundColor = "orange";
                                settooltiptext(row.cells[28].children[0], 'DATE MISSING, RELATIVE QTY IN QUANTITY MANAGER IS AVAILABLE');
                            }
                        }
                    }
                }
                catch (exception_var) {
                    console.log(exception_var);
                }
                finally {

                }
            }
            catch (error) {
                console.log(error);
            }
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTablePlanningSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tablePlanning.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tablePlanning.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tablePlanning.draw();

        colorDatatableAllRow(tablePlanning);
    });

    hideEventsColumnsPlanning();

    // Hide colums
    for (let i = 1; i <= totalPlanningColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        if (!checkbox.checked) {
            tablePlanning.column(i).visible(checkbox.checked, false);
        }
    }

    // Hide additional columns
    var columnsToHide = [];
    if (totalParameters < maxParametersPlanning) {
        var starting = startingColumnPlanning + totalParameters;
        var final = startingColumnPlanning + maxParametersPlanning;
        for (let i = starting; i < final; i++) {
            columnsToHide.push(i);
        }
    }
    if (columnsToHide.length > 0) {
        tablePlanning.columns(columnsToHide).visible(false);
    }
}

function updateTablePlanningSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tablePlanning.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalPlanningColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tablePlanning.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tablePlanning.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function hideEventsColumnsPlanning() {
    for (let i = 1; i <= totalPlanningColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tablePlanning.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tablePlanning);
        })
    }
}

function InitCommandsPlanning1() {
    $("#btnCommand1").html('Manage Baselines');
    $("#btnCommand1").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PLANNINGS/Baseline?code=' + project;
        window.location.href = url;
    });
}

function InitCommandsPlanning2() {
    $("#btnCommand2").html('Manage DT');
    $("#btnCommand2").click(function () {
        initDTSelection(true);
    });
}

function ApplyDatePlanning() {
    loadSpinner();
    setProgressMessage("Apply values..");

    var value = $('#inputValue').val();
    var inputDate = moment(value).format('YYYY/MM/DD');
    if (inputDate == "Invalid date") {
        alert("Invalid date");
        return;
    }

    // Get all checked columns
    var selectedColumns = [];
    var colChecked = document.getElementById("checkBoxVal16").checked;
    if (colChecked) {
        selectedColumns.push(16);
    }
    colChecked = document.getElementById("checkBoxVal19").checked;
    if (colChecked) {
        selectedColumns.push(19);
    }
    colChecked = document.getElementById("checkBoxVal20").checked;
    if (colChecked) {
        selectedColumns.push(20);
    }
    colChecked = document.getElementById("checkBoxVal21").checked;
    if (colChecked) {
        selectedColumns.push(21);
    }
    colChecked = document.getElementById("checkBoxVal22").checked;
    if (colChecked) {
        selectedColumns.push(22);
    }
    colChecked = document.getElementById("checkBoxVal25").checked;
    if (colChecked) {
        selectedColumns.push(25);
    }
    colChecked = document.getElementById("checkBoxVal26").checked;
    if (colChecked) {
        selectedColumns.push(26);
    }
    colChecked = document.getElementById("checkBoxVal27").checked;
    if (colChecked) {
        selectedColumns.push(27);
    }
    colChecked = document.getElementById("checkBoxVal28").checked;
    if (colChecked) {
        selectedColumns.push(28);
    }

    if (totalParameters > 0) {
        colParam1 = document.getElementById("checkBoxVal30").checked;
        selectedColumns.push(30);
    }
    if (totalParameters > 1) {
        colParam1 = document.getElementById("checkBoxVal31").checked;
        selectedColumns.push(31);
    }
    if (totalParameters > 2) {
        colParam1 = document.getElementById("checkBoxVal32").checked;
        selectedColumns.push(32);
    }
    if (totalParameters > 3) {
        colParam1 = document.getElementById("checkBoxVal33").checked;
        selectedColumns.push(33);
    }
    if (totalParameters > 4) {
        colParam1 = document.getElementById("checkBoxVal34").checked;
        selectedColumns.push(34);
    }
    if (totalParameters > 5) {
        colParam1 = document.getElementById("checkBoxVal35").checked;
        selectedColumns.push(35);
    }
    if (totalParameters > 6) {
        colParam1 = document.getElementById("checkBoxVal36").checked;
        selectedColumns.push(36);
    }
    if (totalParameters > 7) {
        colParam1 = document.getElementById("checkBoxVal37").checked;
        selectedColumns.push(37);
    }
    if (totalParameters > 8) {
        colParam1 = document.getElementById("checkBoxVal38").checked;
        selectedColumns.push(38);
    }
    if (totalParameters > 9) {
        colParam1 = document.getElementById("checkBoxVal39").checked;
        selectedColumns.push(39);
    }
    

    var rowChecked;
    var cell;

    // Apply to selected items
    if (selectedColumns.length > 0) {
        tablePlanning.rows().every(function (rowIdx, tableLoop, rowLoop) {

            for (let i = 0; i < selectedColumns.length; i++) {
                var index = selectedColumns[i];
                cell = tablePlanning.cell({ row: rowIdx, column: 0 }).node();
                rowChecked = $('input', cell).prop('checked');
                if (rowChecked) {
                    cell = tablePlanning.cell({ row: rowIdx, column: index }).node();
                    $('input', cell).val(inputDate);
                }
            }

        });
    }

    hideSpinner();
}

function downloadPlanningExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();
    setProgressMessage("Downloading Excel..")

    var url= '/cmd/PLANNINGS/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/Plannings.xlsx";
            link.download = project + "-Plannings-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function SaveDatePlanning() {
    loadSpinner();
    setProgressMessage("Save dates..");
    
    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var tagtypes = [];
    var lots = [];
    var dates1 = [];
    var dates2 = [];
    var dates3 = [];
    var dates4 = [];
    var dates5 = [];
    var dates6 = [];
    var dates7 = [];
    var dates8 = [];
    var dates9 = [];
    var dates10 = [];
    var dates11 = [];
    var param1Values = [];
    var param2Values = [];
    var param3Values = [];
    var param4Values = [];
    var param5Values = [];
    var param6Values = [];
    var param7Values = [];
    var param8Values = [];
    var param9Values = [];
    var param10Values = [];
    var celldate;


    var table = tablePlanning;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[3]);
        tagtypes.push(data[6]);
        lots.push(data[7]);

        celldate = table.cell({ row: rowIdx, column: 16 }).node();
        value = $('input', celldate).val();
        dates1.push(value);

        celldate = table.cell({ row: rowIdx, column: 18 }).node();
        value = $('input', celldate).val();
        dates10.push(value);

        celldate = table.cell({ row: rowIdx, column: 19 }).node();
        value = $('input', celldate).val();
        dates2.push(value);

        celldate = table.cell({ row: rowIdx, column: 20 }).node();
        value = $('input', celldate).val();
        dates3.push(value);

        celldate = table.cell({ row: rowIdx, column: 21 }).node();
        value = $('input', celldate).val();
        dates4.push(value);

        celldate = table.cell({ row: rowIdx, column: 22 }).node();
        value = $('input', celldate).val();
        dates5.push(value);

        celldate = table.cell({ row: rowIdx, column: 24 }).node();
        value = $('input', celldate).val();
        dates11.push(value);

        celldate = table.cell({ row: rowIdx, column: 25 }).node();
        value = $('input', celldate).val();
        dates6.push(value);

        celldate = table.cell({ row: rowIdx, column: 26 }).node();
        value = $('input', celldate).val();
        dates7.push(value);

        celldate = table.cell({ row: rowIdx, column: 27 }).node();
        value = $('input', celldate).val();
        dates8.push(value);

        celldate = table.cell({ row: rowIdx, column: 28 }).node();
        value = $('input', celldate).val();
        dates9.push(value);

        celldate = table.cell({ row: rowIdx, column: 30 }).node();
        value = $('input', celldate).val();
        param1Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 31 }).node();
        value = $('input', celldate).val();
        param2Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 32 }).node();
        value = $('input', celldate).val();
        param3Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 33 }).node();
        value = $('input', celldate).val();
        param4Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 34 }).node();
        value = $('input', celldate).val();
        param5Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 35 }).node();
        value = $('input', celldate).val();
        param6Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 36 }).node();
        value = $('input', celldate).val();
        param7Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 37 }).node();
        value = $('input', celldate).val();
        param8Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 38 }).node();
        value = $('input', celldate).val();
        param9Values.push(value);

        celldate = table.cell({ row: rowIdx, column: 39 }).node();
        value = $('input', celldate).val();
        param10Values.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/PLANNINGS/UpdateDates',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'tagtypesstr': JSON.stringify(tagtypes),
            'lotstr': JSON.stringify(lots),
            'datesstr1': JSON.stringify(dates1),
            'datesstr2': JSON.stringify(dates2),
            'datesstr3': JSON.stringify(dates3),
            'datesstr4': JSON.stringify(dates4),
            'datesstr5': JSON.stringify(dates5),
            'datesstr6': JSON.stringify(dates6),
            'datesstr7': JSON.stringify(dates7),
            'datesstr8': JSON.stringify(dates8),
            'datesstr9': JSON.stringify(dates9),
            'datesstr10': JSON.stringify(dates10),
            'datesstr11': JSON.stringify(dates11),
            'param1ValuesStr': JSON.stringify(param1Values),
            'param2ValuesStr': JSON.stringify(param2Values),
            'param3ValuesStr': JSON.stringify(param3Values),
            'param4ValuesStr': JSON.stringify(param4Values),
            'param5ValuesStr': JSON.stringify(param5Values),
            'param6ValuesStr': JSON.stringify(param6Values),
            'param7ValuesStr': JSON.stringify(param7Values),
            'param8ValuesStr': JSON.stringify(param8Values),
            'param9ValuesStr': JSON.stringify(param9Values),
            'param10ValuesStr': JSON.stringify(param10Values)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            alert(response);
            if (response == 'Dates updated') {
                window.location = '/cmd/PLANNINGS/Index?code=' + project;
            }
        },
        error: function (response, error) {
            hideSpinner();
            alert(response.responseText);
        },
    });
}

function checkAllColPlanning() {
    var colChecked = document.getElementById("checkboxAllColumn").checked;
    document.getElementById("checkboxInpFore").checked = colChecked;
    document.getElementById("checkboxIFRCheckFore").checked = colChecked;
    document.getElementById("checkboxIFRCheckAct").checked = colChecked;
    document.getElementById("checkboxIFRFore").checked = colChecked;
    document.getElementById("checkboxIFRAct").checked = colChecked;
    document.getElementById("checkboxIFCCheckFore").checked = colChecked;
    document.getElementById("checkboxIFCCheckAct").checked = colChecked;
    document.getElementById("checkboxIFCFore").checked = colChecked;
    document.getElementById("checkboxIFCAct").checked = colChecked;
}

function checkAllItemPlanning() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = $('#tablePlanning').DataTable();;
    var cell = null;
    var input = null;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = table.cell({ row: rowIdx, column: 0 }).node();
        input = $('input', cell);
        input.prop("checked", itemsChecked);
    });
    table.draw();
}

function showModalDelivery() {
    for (let i = totalParameters; i < maxParametersPlanning; i++) {
        var index = i + 6;
        hideElement("#row" + index);
    }

    $('#modalDeliveryTime').modal('show');

    if (!tableDeliveryTime) {
        tableDeliveryTime = $('#tableDeliveryTime').DataTable({
            dom: 'Rrtip',
            paging: false,
            orderCellsTop: true,
            fixedHeader: false,
            searching: false,
            bInfo: false,
            bSort: true,
            colReorder: {
                'allowReorder': false
            },
            bAutoWidth: true,
            language: {
                "zeroRecords": "",
                "emptyTable": "",
                "paginate": {
                    "previous": "<",
                    "next": ">"
                },
                search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
                searchPlaceholder: 'Search...'
            },
            "columnDefs": [
                { "targets": [0, 2], "searchable": false },
                {
                    "targets": [0, 2], //first column / numbering column
                    "orderable": false, //set not orderable
                }
            ],
            order: [
                [1, 'asc']
            ],
            search: {
                "caseInsensitive": true
            }
        });
    }
}

function initDTSelection(showModal) {
    var project = $('#labelProject').text();

    loadSpinner();
    setProgressMessage("Reading settings..");

    var url = "/cmd/PLANNINGS/GetProjectDeliveryTimes";
    $.ajax({
        type: "GET",
        url: url,
        data: {
            'code': project
        },
        dataType: "text",
        success: function (response) {
            hideSpinner();
            if (response) {
                // Set values
                var values = JSON.parse(response);

                document.getElementById('inputDate1_1').value = values.date11;
                document.getElementById('inputDate2_1').value = values.date21;
                $("#itemDateDays1").val(values.value1);
                $("#labelCheckBoxDT1").text(values.date11);

                document.getElementById('inputDate1_2').value = values.date12;
                document.getElementById('inputDate2_2').value = values.date22;
                $("#itemDateDays2").val(values.value2);
                $("#labelCheckBoxDT2").text(values.date12);

                document.getElementById('inputDate1_3').value = values.date13;
                document.getElementById('inputDate2_3').value = values.date23;
                $("#itemDateDays3").val(values.value3);
                $("#labelCheckBoxDT3").text(values.date13);

                document.getElementById('inputDate1_4').value = values.date14;
                document.getElementById('inputDate2_4').value = values.date24;
                $("#itemDateDays4").val(values.value4);
                $("#labelCheckBoxDT4").text(values.date14);

                document.getElementById('inputDate1_5').value = values.date15;
                document.getElementById('inputDate2_5').value = values.date25;
                $("#itemDateDays5").val(values.value5);
                $("#labelCheckBoxDT5").text(values.date15);

                document.getElementById('inputDate1_6').value = values.date16;
                document.getElementById('inputDate2_6').value = values.date26;
                $("#itemDateDays6").val(values.value6);

                document.getElementById('inputDate1_7').value = values.date17;
                document.getElementById('inputDate2_7').value = values.date27;
                $("#itemDateDays7").val(values.value7);

                document.getElementById('inputDate1_8').value = values.date18;
                document.getElementById('inputDate2_8').value = values.date28;
                $("#itemDateDays8").val(values.value8);

                document.getElementById('inputDate1_9').value = values.date19;
                document.getElementById('inputDate2_9').value = values.date29;
                $("#itemDateDays9").val(values.value9);

                document.getElementById('inputDate1_10').value = values.date110;
                document.getElementById('inputDate2_10').value = values.date210;
                $("#itemDateDays10").val(values.value10);

                document.getElementById('inputDate1_11').value = values.date111;
                document.getElementById('inputDate2_11').value = values.date211;
                $("#itemDateDays11").val(values.value11);

                document.getElementById('inputDate1_12').value = values.date112;
                document.getElementById('inputDate2_12').value = values.date212;
                $("#itemDateDays12").val(values.value12);

                document.getElementById('inputDate1_13').value = values.date113;
                document.getElementById('inputDate2_13').value = values.date213;
                $("#itemDateDays13").val(values.value13);

                document.getElementById('inputDate1_14').value = values.date114;
                document.getElementById('inputDate2_14').value = values.date214;
                $("#itemDateDays14").val(values.value14);

                document.getElementById('inputDate1_15').value = values.date115;
                document.getElementById('inputDate2_15').value = values.date215;
                $("#itemDateDays15").val(values.value15);

                if (showModal) {
                    showModalDelivery();
                }
            }
        },
        error: function (response, error) {
            hideSpinner();
            alert(response.responseText);
        },
    });
}


function SaveDeliveryTime() {
    loadSpinner();
    setProgressMessage("Saving DT..");

    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var tagtypes = [];
    var lots = [];
    var dates1a = [];
    var dates2a = [];
    var dates3a = [];
    var dates4a = [];
    var dates5a = [];
    var dates6a = [];
    var dates7a = [];
    var dates8a = [];
    var dates9a = [];
    var dates10a = [];
    var dates11a = [];
    var dates12a = [];
    var dates13a = [];
    var dates14a = [];
    var dates15a = [];
    var dates1b = [];
    var dates2b = [];
    var dates3b = [];
    var dates4b = [];
    var dates5b = [];
    var dates6b = [];
    var dates7b = [];
    var dates8b = [];
    var dates9b = [];
    var dates10b = [];
    var dates11b = [];
    var dates12b = [];
    var dates13b = [];
    var dates14b = [];
    var dates15b = [];
    var param1Values = [];
    var param2Values = [];
    var param3Values = [];
    var param4Values = [];
    var param5Values = [];
    var param6Values = [];
    var param7Values = [];
    var param8Values = [];
    var param9Values = [];
    var param10Values = [];
    var param11Values = [];
    var param12Values = [];
    var param13Values = [];
    var param14Values = [];
    var param15Values = [];
    var val1 = null;
    var val2 = null;
    var value = null;

    tablePlanning.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[3]);
        tagtypes.push(data[6]);
        lots.push(data[7]);

        val1 = $("#inputDate1_1 option:selected").text();
        val2 = $("#inputDate2_1 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays1").value);
        dates1a.push(val1);
        dates1b.push(val2);
        param1Values.push(value);

        val1 = $("#inputDate1_2 option:selected").text();
        val2 = $("#inputDate2_2 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays2").value);
        dates2a.push(val1);
        dates2b.push(val2);
        param2Values.push(value);

        val1 = $("#inputDate1_3 option:selected").text();
        val2 = $("#inputDate2_3 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays3").value);
        dates3a.push(val1);
        dates3b.push(val2);
        param3Values.push(value);

        val1 = $("#inputDate1_4 option:selected").text();
        val2 = $("#inputDate2_4 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays4").value);
        dates4a.push(val1);
        dates4b.push(val2);
        param4Values.push(value);

        val1 = $("#inputDate1_5 option:selected").text();
        val2 = $("#inputDate2_5 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays5").value);
        dates5a.push(val1);
        dates5b.push(val2);
        param5Values.push(value);

        val1 = $("#inputDate1_6 option:selected").text();
        val2 = $("#inputDate2_6 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays6").value);
        dates6a.push(val1);
        dates6b.push(val2);
        param6Values.push(value);

        val1 = $("#inputDate1_7 option:selected").text();
        val2 = $("#inputDate2_7 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays7").value);
        dates7a.push(val1);
        dates7b.push(val2);
        param7Values.push(value);

        val1 = $("#inputDate1_8 option:selected").text();
        val2 = $("#inputDate2_8 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays8").value);
        dates8a.push(val1);
        dates8b.push(val2);
        param8Values.push(value);

        val1 = $("#inputDate1_9 option:selected").text();
        val2 = $("#inputDate2_9 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays9").value);
        dates9a.push(val1);
        dates9b.push(val2);
        param9Values.push(value);

        val1 = $("#inputDate1_10 option:selected").text();
        val2 = $("#inputDate2_10 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays10").value);
        dates10a.push(val1);
        dates10b.push(val2);
        param10Values.push(value);

        val1 = $("#inputDate1_11 option:selected").text();
        val2 = $("#inputDate2_11 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays11").value);
        dates11a.push(val1);
        dates11b.push(val2);
        param11Values.push(value);

        val1 = $("#inputDate1_12 option:selected").text();
        val2 = $("#inputDate2_12 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays12").value);
        dates12a.push(val1);
        dates12b.push(val2);
        param12Values.push(value);

        val1 = $("#inputDate1_13 option:selected").text();
        val2 = $("#inputDate2_13 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays13").value);
        dates13a.push(val1);
        dates13b.push(val2);
        param13Values.push(value);

        val1 = $("#inputDate1_14 option:selected").text();
        val2 = $("#inputDate2_14 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays14").value);
        dates14a.push(val1);
        dates14b.push(val2);
        param14Values.push(value);

        val1 = $("#inputDate1_15 option:selected").text();
        val2 = $("#inputDate2_15 option:selected").text();
        value = parseInt(document.getElementById("itemDateDays15").value);
        dates15a.push(val1);
        dates15b.push(val2);
        param15Values.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/PLANNINGS/SaveDeliveryTime',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'tagtypesstr': JSON.stringify(tagtypes),
            'lotstr': JSON.stringify(lots),
            'datesstr1a': JSON.stringify(dates1a),
            'datesstr2a': JSON.stringify(dates2a),
            'datesstr3a': JSON.stringify(dates3a),
            'datesstr4a': JSON.stringify(dates4a),
            'datesstr5a': JSON.stringify(dates5a),
            'datesstr6a': JSON.stringify(dates6a),
            'datesstr7a': JSON.stringify(dates7a),
            'datesstr8a': JSON.stringify(dates8a),
            'datesstr9a': JSON.stringify(dates9a),
            'datesstr10a': JSON.stringify(dates10a),
            'datesstr11a': JSON.stringify(dates11a),
            'datesstr12a': JSON.stringify(dates12a),
            'datesstr13a': JSON.stringify(dates13a),
            'datesstr14a': JSON.stringify(dates14a),
            'datesstr15a': JSON.stringify(dates15a),
            'datesstr1b': JSON.stringify(dates1b),
            'datesstr2b': JSON.stringify(dates2b),
            'datesstr3b': JSON.stringify(dates3b),
            'datesstr4b': JSON.stringify(dates4b),
            'datesstr5b': JSON.stringify(dates5b),
            'datesstr6b': JSON.stringify(dates6b),
            'datesstr7b': JSON.stringify(dates7b),
            'datesstr8b': JSON.stringify(dates8b),
            'datesstr9b': JSON.stringify(dates9b),
            'datesstr10b': JSON.stringify(dates10b),
            'datesstr11b': JSON.stringify(dates11b),
            'datesstr12b': JSON.stringify(dates12b),
            'datesstr13b': JSON.stringify(dates13b),
            'datesstr14b': JSON.stringify(dates14b),
            'datesstr15b': JSON.stringify(dates15b),
            'param1ValuesStr': JSON.stringify(param1Values),
            'param2ValuesStr': JSON.stringify(param2Values),
            'param3ValuesStr': JSON.stringify(param3Values),
            'param4ValuesStr': JSON.stringify(param4Values),
            'param5ValuesStr': JSON.stringify(param5Values),
            'param6ValuesStr': JSON.stringify(param6Values),
            'param7ValuesStr': JSON.stringify(param7Values),
            'param8ValuesStr': JSON.stringify(param8Values),
            'param9ValuesStr': JSON.stringify(param9Values),
            'param10ValuesStr': JSON.stringify(param10Values),
            'param11ValuesStr': JSON.stringify(param11Values),
            'param12ValuesStr': JSON.stringify(param12Values),
            'param13ValuesStr': JSON.stringify(param13Values),
            'param14ValuesStr': JSON.stringify(param14Values),
            'param15ValuesStr': JSON.stringify(param15Values)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            if (response == 'Dates updated') {
                alert(response);
            }
            else {
                window.location = '/cmd/PLANNINGS/Index?code=' + project;
            }
        },
        error: function (response, error) {
            hideSpinner();
            alert(response.responseText);
        },
    });
}

function SaveDeliveryTimeSettings() {
    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var tagtypes = [];
    var lots = [];
    var dates = [];
    var days = [];

    val1 = $("#inputDate1_1 option:selected").text();
    val2 = $("#inputDate2_1 option:selected").text();
    day = $("#itemDateDays1").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_2 option:selected").text();
    val2 = $("#inputDate2_2 option:selected").text();
    day = $("#itemDateDays2").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_3 option:selected").text();
    val2 = $("#inputDate2_3 option:selected").text();
    day = $("#itemDateDays3").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_4 option:selected").text();
    val2 = $("#inputDate2_4 option:selected").text();
    day = $("#itemDateDays4").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_5 option:selected").text();
    val2 = $("#inputDate2_5 option:selected").text();
    day = $("#itemDateDays5").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_6 option:selected").text();
    val2 = $("#inputDate2_6 option:selected").text();
    day = $("#itemDateDays6").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_7 option:selected").text();
    val2 = $("#inputDate2_7 option:selected").text();
    day = $("#itemDateDays7").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_8 option:selected").text();
    val2 = $("#inputDate2_8 option:selected").text();
    day = $("#itemDateDays8").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_9 option:selected").text();
    val2 = $("#inputDate2_9 option:selected").text();
    day = $("#itemDateDays9").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_10 option:selected").text();
    val2 = $("#inputDate2_10 option:selected").text();
    day = $("#itemDateDays10").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_11 option:selected").text();
    val2 = $("#inputDate2_11 option:selected").text();
    day = $("#itemDateDays11").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_12 option:selected").text();
    val2 = $("#inputDate2_12 option:selected").text();
    day = $("#itemDateDays12").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_13 option:selected").text();
    val2 = $("#inputDate2_13 option:selected").text();
    day = $("#itemDateDays13").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_14 option:selected").text();
    val2 = $("#inputDate2_14 option:selected").text();
    day = $("#itemDateDays14").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    val1 = $("#inputDate1_15 option:selected").text();
    val2 = $("#inputDate2_15 option:selected").text();
    day = $("#itemDateDays15").val();
    dates.push(val1);
    dates.push(val2);
    days.push(day);

    $.ajax({
        type: 'POST',
        url: '/cmd/PLANNINGS/SaveProjectDeliveryTimes',
        data: {
            'code': project,
            'datesstr': JSON.stringify(dates),
            'daysstr': JSON.stringify(days)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}

function updateDateDeliveryTime(sourceColumnNameInputId, destColumnNameInputId, daysInputName, rowIdx) {

    var sourceColumnName = document.getElementById(sourceColumnNameInputId).value;
    var arrayIndex = sourceDateNames.indexOf(sourceColumnName);
    var colIndex = sourceDateIndex[arrayIndex];

    var destColumnName = document.getElementById(destColumnNameInputId).value;
    var arrayIndex1 = sourceDateNames.indexOf(destColumnName);
    var colIndex1 = sourceDateIndex[arrayIndex1];

    var days = parseInt(document.getElementById(daysInputName).value);

    if (colIndex > 0 && colIndex1 > 0) {
        var cell = tablePlanning.cell({ row: rowIdx, column: colIndex }).node();
        var date1 = $('input', cell).val();
        var inputDate1 = moment(date1, 'YYYY-MM-DD');
        if (inputDate1 == 'Invalid date' || !inputDate1.isValid()) {
            return;
        }
        var inputDate2 = inputDate1.add(days, 'days');
        cell = tablePlanning.cell({ row: rowIdx, column: colIndex1 }).node();
        var newdate = inputDate2.format('YYYY-MM-DD');
        $('input', cell).val(newdate);
    }
}

function ApplyDeliveryTime() {

    loadSpinner();
    setProgressMessage("Apply DT..");

    var checkedRow1 = document.getElementById("checkBoxDT1").checked;
    var checkedRow2 = document.getElementById("checkBoxDT2").checked;
    var checkedRow3 = document.getElementById("checkBoxDT3").checked;
    var checkedRow4 = document.getElementById("checkBoxDT4").checked;
    var checkedRow5 = document.getElementById("checkBoxDT5").checked;
    var checkedRow6 = document.getElementById("checkBoxDT6").checked;
    var checkedRow7 = document.getElementById("checkBoxDT7").checked;
    var checkedRow8 = document.getElementById("checkBoxDT8").checked;
    var checkedRow9 = document.getElementById("checkBoxDT9").checked;
    var checkedRow10 = document.getElementById("checkBoxDT10").checked;
    var checkedRow11 = document.getElementById("checkBoxDT11").checked;
    var checkedRow12 = document.getElementById("checkBoxDT12").checked;
    var checkedRow13 = document.getElementById("checkBoxDT13").checked;
    var checkedRow14 = document.getElementById("checkBoxDT14").checked;
    var checkedRow15 = document.getElementById("checkBoxDT15").checked;

    tablePlanning.rows().every(function (rowIdx, tableLoop, rowLoop) {

        var cell = tablePlanning.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            if (checkedRow1) {
                updateDateDeliveryTime('inputDate2_1', 'inputDate1_1', 'itemDateDays1', rowIdx);
            };
            if (checkedRow2) {
                updateDateDeliveryTime('inputDate2_2', 'inputDate1_2', 'itemDateDays2', rowIdx);
            };
            if (checkedRow3) {
                updateDateDeliveryTime('inputDate2_3', 'inputDate1_3', 'itemDateDays3', rowIdx);
            };
            if (checkedRow4) {
                updateDateDeliveryTime('inputDate2_4', 'inputDate1_4', 'itemDateDays4', rowIdx);
            };
            if (checkedRow5) {
                updateDateDeliveryTime('inputDate2_5', 'inputDate1_5', 'itemDateDays5', rowIdx);
            };
            if (checkedRow6) {
                updateDateDeliveryTime('inputDate2_6', 'inputDate1_6', 'itemDateDays6', rowIdx);
            };
            if (checkedRow7) {
                updateDateDeliveryTime('inputDate2_7', 'inputDate1_7', 'itemDateDays7', rowIdx);
            };
            if (checkedRow8) {
                updateDateDeliveryTime('inputDate2_8', 'inputDate1_8', 'itemDateDays8', rowIdx);
            };
            if (checkedRow9) {
                updateDateDeliveryTime('inputDate2_9', 'inputDate1_9', 'itemDateDays9', rowIdx);
            };
            if (checkedRow10) {
                updateDateDeliveryTime('inputDate2_10', 'inputDate1_10', 'itemDateDays10', rowIdx);
            };
            if (checkedRow11) {
                updateDateDeliveryTime('inputDate2_11', 'inputDate1_11', 'itemDateDays11', rowIdx);
            };
            if (checkedRow12) {
                updateDateDeliveryTime('inputDate2_12', 'inputDate1_12', 'itemDateDays12', rowIdx);
            };
            if (checkedRow13) {
                updateDateDeliveryTime('inputDate2_13', 'inputDate1_13', 'itemDateDays13', rowIdx);
            };
            if (checkedRow14) {
                updateDateDeliveryTime('inputDate2_14', 'inputDate1_14', 'itemDateDays14', rowIdx);
            };
            if (checkedRow15) {
                updateDateDeliveryTime('inputDate2_15', 'inputDate1_15', 'itemDateDays15', rowIdx);
            };
        }
    });

    hideSpinner();
}

function downloadMainItemsListExcelPlanning() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();
    setProgressMessage("Downloading Excel..");

    var url= '/cmd/ItemListCreation/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemList.xlsx";
            link.download = project + "-MainItems-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function importExcelMainItemsTemplatePlanning() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Create Main Items..");

    $.ajax({
        url: '/cmd/ItemListCreation/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/Plannings/Index?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/Plannings/Index?code=' + project;
        }
    });
}