﻿var tablePlanningBaseLine = null;
var tablePlanningBaseLineColumns = 7;

$(document).ready(function () {
    // Main Settings
    setTitle("Planning Baseline"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#navTopButton"); // Show Navbar Data Management
    disableLink("#modelPlanningBtn"); // Hide PBS Button

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PLANNINGS/Index?code=' + project;
        window.location.href = url;
    });

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcelPlanningBaseline();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });
    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/PLANNINGS/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Report/TemplateCILBaseline.xlsx";
                link.download = "TemplateCILBaseline.xlsx";
                link.click();;
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    $('.datepicker').datepicker({
        changeMonth: true,
        changeYear: true,
        format: "yyyy/mm/dd",
        language: "en"
    });

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    InitTablePlanningBaseline();
});

function InitTablePlanningBaseline() {
    tablePlanningBaseLine = $('#tablePlanningBaseline').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, tablePlanningBaseLineColumns], "searchable": false },
            {
                "targets": [0, tablePlanningBaseLineColumns], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 50, targets: 0 }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTablePlanningBaselineSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tablePlanningBaseLine.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tablePlanningBaseLine.draw();

        colorDatatableAllRow(tablePlanningBaseLine);
    });

    UpdatePlanningBaselineVisibility();
}

function updateTablePlanningBaselineSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tablePlanningBaseLine.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= tablePlanningBaseLineColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tablePlanningBaseLine.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tablePlanningBaseLine.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function UpdatePlanningBaselineVisibility() {
    if (!tablePlanningBaseLine.rows().count()) {
        hideElement("#divTablePlanningBaseline");
        showElement('#emptyRows');
    }
    else {
        showElement('#divTablePlanningBaseline');
        hideElement('#emptyRows');
        tablePlanningBaseLine.draw(true);
    }
}

function ApplyDatePlanningBaseline() {
    loadSpinner();
    setProgressMessage("Apply Baseline..");

    var value = $('#itemDateAll').val();
    var inputDate = moment(value).format('YYYY-MM-DD');

    if (inputDate == 'Invalid date') {
        alert('Invalid date');
        return;
    }

    var colIFRBaseLev3 = document.getElementById("checkBoxBase1").checked;
    var colIIFCBaseLev3 = document.getElementById("checkBoxBase2").checked;
    var rowChecked;
    var cell;

    tablePlanningBaseLine.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (colIFRBaseLev3) {
            cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 4 }).node();
                $('input', cell).val(inputDate);
            }
        }
        if (colIIFCBaseLev3) {
            cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 6 }).node();
                $('input', cell).val(inputDate);
            }
        }
    });

    hideSpinner();
}

function ApplyDatePlanningEng() {
    loadSpinner();
    setProgressMessage("Apply Dates..");

    var value = parseInt(document.getElementById("itemDays").value);

    var colIIFRBaseEng = document.getElementById("checkBoxDay1").checked;
    var colIIFCBaseEng = document.getElementById("checkBoxDay2").checked;
    var rowChecked;
    var cell;

    tablePlanningBaseLine.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (colIIFRBaseEng) {
            cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 4 }).node();
                var date1 = $('input', cell).val();
                if (date1) {
                    var inputDate1 = moment(date1, 'YYYY-MM-DD');
                    var newDate1 = inputDate1.add(value, 'days').format('YYYY-MM-DD');
                    cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 5 }).node();
                    $('input', cell).val(newDate1);
                }
            }
        }
        if (colIIFCBaseEng) {
            cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 6 }).node();
                var date2 = $('input', cell).val();
                if (date2) {
                    var inputDate2 = moment(date2, 'YYYY-MM-DD');
                    var newDate2 = inputDate2.add(value, 'days').format('YYYY-MM-DD');
                    cell = tablePlanningBaseLine.cell({ row: rowIdx, column: 7 }).node();
                    $('input', cell).val(newDate2);
                }
            }
        }
    });

    hideSpinner();
}

function SaveDatePlanningBaseline() {
    loadSpinner();
    setProgressMessage("Save Baseline..");

    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var tagtypes = [];
    var lots = [];
    var dates1 = [];
    var dates2 = [];
    var dates3 = [];
    var dates4 = [];
    var celldate;


    var table = $('#tablePlanningBaseline').DataTable();;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[1]);
        tagtypes.push(data[2]);
        lots.push(data[3]);

        celldate = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', celldate).val();
        dates1.push(value);

        celldate = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', celldate).val();
        dates2.push(value);

        celldate = table.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', celldate).val();
        dates3.push(value);

        celldate = table.cell({ row: rowIdx, column: 7 }).node();
        value = $('input', celldate).val();
        dates4.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/PLANNINGS/UpdateDateBaseline',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'tagtypesstr': JSON.stringify(tagtypes),
            'lotstr': JSON.stringify(lots),
            'datesstr1': JSON.stringify(dates1),
            'datesstr2': JSON.stringify(dates2),
            'datesstr3': JSON.stringify(dates3),
            'datesstr4': JSON.stringify(dates4)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            alert(response);
            if (response == 'Dates updated') {
                window.location = '/cmd/PLANNINGS/Baseline?code=' + project;
            }
        },
        error: function (response, error) {
            hideSpinner();
            alert(response.responseText);
        },
    });
}

function checkAllItemPlanningBaseline() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = $('#tablePlanningBaseline').DataTable();;
    var cell = null;
    var input = null;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = table.cell({ row: rowIdx, column: 0 }).node();
        input = $('input', cell);
        input.prop("checked", itemsChecked);
    });
    table.draw();
}

function downloadMainItemsListExcelPlanningBaseline() {
    
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();
    setProgressMessage("Downloading Excel..");

    var url= '/cmd/Plannings/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/Plannings.xlsx";
            link.download = project + "-PlanningsBaseline-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function importExcelMainItemsTemplatePlanningBaseline() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Import Excel..");

    $.ajax({
        url: '/cmd/Plannings/ImportBaselineExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/Plannings/Baseline?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/Plannings/Baseline?code=' + project;
        }
    });
}