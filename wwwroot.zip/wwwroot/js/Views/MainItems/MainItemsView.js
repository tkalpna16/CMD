﻿var tableMainItemsView = null;
var totalMainItemsViewColumns = 24;

$(document).ready(function () {
    // Main Settings
    setTitle("Items"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar

    // Show Commands
    showElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcel();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });
    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    InitTableMainItems();

    document.getElementById("rowTable").style.opacity = "1.0";
});

function InitTableMainItems() {
    tableMainItemsView = $('#tableMainItems').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: false,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollX: '100%',
        scrollY: '58vh',
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { width: 100, targets: 2 },
            { width: 100, targets: 5 },
            { width: 100, targets: 9 }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i < totalMainItemsViewColumns; i++) {
            var col1 = document.getElementById("checkBox" + i).checked;
            if (col1) {
                colId.push(i - 1);
            }
            tableMainItemsView.column(colId).search('').draw();
        }

        if (colId.length == 0) {
            tableMainItemsView.search(filter).draw();
        }
        else {
            tableMainItemsView.column(colId).search(filter).draw();
        }
    });

    // Hide colums
    for (let i = 1; i <= totalMainItemsViewColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        tableMainItemsView.column(i - 1).visible(checkbox.checked);
    }

    hideEventsColumnsMainItems();
}

function downloadMainItemsListExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcelItemsView';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/ItemsView.xlsx";
            link.download = project + "-ItemsView-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}


function hideEventsColumnsMainItems() {
    for (let i = 0; i < totalMainItemsViewColumns; i++) {
        var index = i + 1;
        var checkbox = document.getElementById("checkBoxVis" + index);
        checkbox.addEventListener('change', (event) => {
            tableMainItemsView.column(i).visible(event.currentTarget.checked);
        })
    }
}