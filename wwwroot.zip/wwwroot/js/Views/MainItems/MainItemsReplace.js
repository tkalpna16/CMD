﻿var items = null;

$(document).ready(function () {
    // To List
    $("#btnBackToList").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ITEMLISTCREATION/Index?code=' + project;
        window.location.href = url;
    });

    // Add Item List
    var projectId = $('#labelProjectId').text();

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/GetMainItems',
        data: {
            'projectId': projectId
        },
        dataType: 'text',
        success: function (response) {
            items = JSON.parse(response);
        }
    });

    // Create Button Event
    $("#btnReplaceMainItem").click(function () {

        // Item To Replace
        var itemToReplace = $("#inputItemToReplace").val();
        if (!itemToReplace) {
            alert("Any Main Item selected!!");
            return;
        }

        // PBS
        var selectedArea = $("#inputPBS option:selected").text();

        // WP
        var wp = $("#inputWP option:selected").text();
        if (wp == '' || wp == "NA") {
            alert("Select a Working Package!!");
            return;
        }

        // LV01_Object_Code
        var selectedCode = $("#inputObjectCode").val();

        // Material
        var material = $("#inputMaterialWorkGroup").val();
        var materialChecked = document.getElementById("inputMaterialWorkGroupActive").checked;

        // TagType
        var dropdownvaltagtype = $("#inputTagType option:selected").text();
        if (!dropdownvaltagtype) {
            alert("Any TagType selected!!");
            return;
        }

        // Sequence number
        var sequenceNumber = $('#inputSequenceNumber').val();
        if (!sequenceNumber) {
            alert("Sequence number not defined");
            return;
        }

        // Tag Description
        var tagDescription = $('#inputTagDescription').val();

        // Tag Client
        var tagClient = $('#inputTagClient').val();

        // LOT
        var lot = $('#inputLot').val();
        if (!lot) {
            alert("Lot not defined");
            return;
        }

        // projectId
        var code = $('#labelProject').text();

        loadSpinner();

        $.ajax({
            type: 'POST',
            url: '/cmd/ItemListCreation/ReplaceElementManual',
            data: {
                'projectCode': code,
                'itemtoreplace': itemToReplace,
                'area': selectedArea, 'wp': wp,
                'tagdescription': tagDescription,
                'tagclient': tagClient, 'tagtype': dropdownvaltagtype,
                'material': material, 'materialChecked': materialChecked,
                'sequenceNumber': sequenceNumber, 'objectcode': selectedCode,
                'lot': lot
            },
            dataType: 'text',
            success: function (response) {
                document.getElementById("divMessage").innerHTML = response;
                hideSpinner();
            },
            error: function (response, error) {
                document.getElementById("divMessage").innerHTML = response.responseText;
                hideSpinner();
            }
        });
    });

    $("#inputItemToReplace").on("change", function (e) {
        var input = document.getElementById("inputItemToReplace");
        var val = input.options[input.selectedIndex].text;

        if (val != '' && items != null) {
            var i;
            for (i = 0; i < items.length; i++) {
                if (items[i].description == val) {

                    $("#inputPBS").val(items[i].area);
                    $("#inputWP").val(items[i].wp);
                    $("#inputObjectCode").val(items[i].objectCode);
                    $("#inputMaterialWorkGroup").val(items[i].material);
                    $("#inputTagType").val(items[i].tagType);
                    $("#inputTagDescription").val(items[i].tagClient);
                    $("#inputTagClient").val(items[i].tagDescription);
                    $("#inputLot").val(items[i].lot);

                    break;
                }
            }
        }
    });
});