﻿$(document).ready(function () {
    // To List
    $("#btnMainItemsList").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ITEMLISTCREATION/Index?code=' + project;
        window.location.href = url;
    });

    // Add Item List
    var projectId = $('#labelProject').text();

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/GetMainItems',
        data: {
            'projectId': projectId
        },
        dataType: 'text',
        success: function (response) {
            var element = JSON.parse(response);;
            var options = '';

            for (var i = 0; i < element.length; i++)
                options += '<option value="' + element[i] + '" />';

            document.getElementById('itemList').innerHTML = options;
        }
    });

    // Create Button Event
    $("#btnCreateMainItem").click(function () {

        // Area
        var dropdownarea = $("#PBS").val();
        if (!dropdownarea) {
            alert("Any Area selected!!");
            return;
        }

        // WP
        var wp = $('#inputWP').val();
        if (wp == '' || wp == "NA") {
            alert("Select a Working Package!!");
            return;
        }

        // TCM Tag
        var tcmTag = $('#inputTCMTag').val();
        if (!tcmTag) {
            alert("TCM Tag Incorrect!!");
            return;
        }

        // Tag Description
        var tagDescription = $('#inputTagDescription').val();

        // Tag Client
        var tagClient = $('#inputTagClient').val();

        // TagType
        var dropdownvaltagtype = $("#TagType").val();
        if (!dropdownvaltagtype) {
            alert("Any TagType selected!!");
            return;
        }

        // projectId
        var code = $('#labelProject').text();

        loadSpinner();

        $.ajax({
            type: 'POST',
            url: '/cmd/ItemListCreation/CreateElementManual',
            data: {
                'area': dropdownarea, 'wp': wp,
                'tcmtag': tcmTag, 'tagdescription': tagDescription,
                'tagclient': tagClient, 'tagtype': dropdownvaltagtype,
                'code': code},
            dataType: 'text',
            success: function (response) {
                document.getElementById("divMessage").innerHTML = response;
                hideSpinner();
            },
            error: function (response, error) {
                document.getElementById("divMessage").innerHTML = response.responseText;
                hideSpinner();
            }
        });
    });
});