﻿var tableMainItems = null;
var totalMainItemsColumns = 11;

$(document).ready(function () {
    // Main Settings
    setTitle("Item List Generator"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar

    // Show Commands
    showElement("#btnDownloadExcel");
    showElement("#btnImportExcel");

    // Additional buttons
    InitCommandsItemList();
    showElement("#btnCommand1");
    showElement("#btnCommand2");
    showElement("#btnCommand3");

    showElement("#navTopButton"); // Show Navbar
    disableLink("#itemListGeneratorBtn"); // Hide PBS Button

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcel();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });
    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });
    $("#btnCommand1").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ItemListCreation/MainItemData?code=' + project;
        window.location.href = url;
    });
    $("#btnCommand2").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ItemListCreation/MainItemTagTypes?code=' + project;
        window.location.href = url;
    });
    $("#btnCommand3").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ItemListCreation/MainItemSize?code=' + project;
        window.location.href = url;
    });

    // Init commands
    $("#btnAddProfile").html('Save');

    setMultiselectMainItemsCombine();
    setMultiselectMainItemsReplace();

    // Init UI
    InitTableMainItems();
    setMultiselectMainItems();
    InitMainItemsCheckBoxEvents();
    updateEnableControlsMainItems();
    hideEventsColumnsMainItems();

    tableMainItems.column(1).visible(false);
    tableMainItems.column(2).visible(false);
    tableMainItems.column(4).visible(false);
    tableMainItems.column(5).visible(false);

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $('#btnGetExcelList').on('click', function (evt) {
        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        var fileInput = document.getElementById('inputFile');
        if (fileInput.files.length == 0) {
            alert("Select an Excel file!!")
            return;
        }
        var file = fileInput.files[0];
        var formData = new FormData();
        formData.append('postedFile', file);
        formData.append('code', project);

        loadSpinner();
        $.ajax({
            url: '/cmd/ItemListCreation/ImportExcel',
            contentType: false,
            processData: false,
            type: 'post',
            data: formData,
            success: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProjectCode').text();
                window.location = '/cmd/ItemListCreation/Index?code=' + project;
            },
            error: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProjectCode').text();
                window.location = '/cmd/ItemListCreation/Index?code=' + project;
            }
        });
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/ItemListCreation/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: {
                'code': project
            },
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Temp/TemplateCIL.xlsx";
                link.download = "TemplateCIL.xlsx";
                link.click();;

                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    // Create Button Event
    $("#btnCreateMainItems").click(function () {
        if (document.getElementById("checkBoxMultipleItems").checked) {
            CreateMultipleItem();
        }
        else {
            CreateSingleItem();
        }
    });

    // Create Combine Event
    $("#btnCombine").click(function () {
        showModalCombineItems();
    });

    // Create Replace Event
    $("#btnReplace").click(function () {
        showModalReplaceItem();
    });

    // Create Delete Event
    $("#btnDelete").click(function () {
        showModalDeleteItems();
    });

    $('#rowTable').show();
    tableMainItems.columns.adjust();

    $("#tableMainItems").on("click", ".btn-danger", function () {
        if (confirm("Do you want to delete this Main Items and all element derived?")) {
            var row = $(this).closest("tr");
            var span = row.find("span");
            var id = span.text();
            var url = "/cmd/MAINITEMS/DeleteItem?id=" + id;
            $.ajax({
                type: "POST",
                url: url,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response == STATUS_MAIN_ITEM_DELETED) {
                        if ($("#tableMainItems tr").length > 1) {
                            row.remove();
                            tableMainItems.row($(row)).remove().draw(false);
                        } else {
                            row.find(".Edit").hide();
                            row.find(".Delete").hide();
                            row.find("span").html('&nbsp;');
                        }
                        tableMainItems.draw();
                    }
                    displayMessage(response);
                },
                error: function (response, error) {
                    if (response.responseText == STATUS_MAIN_ITEM_DELETED) {
                        if ($("#tableMainItems tr").length > 1) {
                            row.remove();
                            tableMainItems.row($(row)).remove().draw(false);
                            UpdatePBSVisibility();
                        } else {
                            row.find(".Edit").hide();
                            row.find(".Delete").hide();
                            row.find("span").html('&nbsp;');
                        }
                        tableMainItems.draw();
                    }
                    displayMessage(response.responseText);
                },
            });
        }
    });


    $("#selectItemCombine").on("change", function (e) {
        var selectedValue = this.value;
        var selectedOptions = $('#selectItemCombine option:selected');

        if (selectedOptions.length > 1) {
            // Disable all other checkboxes.
            var nonSelectedOptions = $('#selectItemCombine option').filter(function () {
                return $(this).is(':selected');
            });

            nonSelectedOptions.each(function () {
                $('#selectItemCombine').multiselect('deselect', selectedValue);
            });
        }
    });

    $("#selectItemReplaceWith").on("change", function (e) {
        var selectedValue = this.value;
        var selectedOptions = $('#selectItemReplaceWith option:selected');

        if (selectedOptions.length > 1) {
            // Disable all other checkboxes.
            var nonSelectedOptions = $('#selectItemReplaceWith option').filter(function () {
                return $(this).is(':selected');
            });

            nonSelectedOptions.each(function () {
                $('#selectItemReplaceWith').multiselect('deselect', selectedValue);
            });
        }
    });
});

function InitTableMainItems() {
    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    tableMainItems = $('#tableMainItems').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: false,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": 10, "orderDataType": "dom-text", type: 'string' },
            {
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 50, targets: 0 },
            { width: 80, targets: 7 },
            { width: 80, targets: 8 },
            { width: 200, targets: 12 },
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableMainItemsSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableMainItems.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableMainItems.draw();

        colorDatatableAllRow(tableMainItems);
    });
}

function updateTableMainItemsSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableMainItems.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalMainItemsColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableMainItems.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableMainItems.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitCommandsItemList() {
    $("#btnCommand1").html('Manage Main Items Data');
    $("#btnCommand2").html('Manage Tag Types Data');
    $("#btnCommand3").html('Manage Main Item Size');
}

function InitMainItemsCheckBoxEvents() {
    $("#checkBoxMultipleItems").on("change", function () {
        updateEnableControlsMainItems();
    });
}

function updateEnableControlsMainItems() {
    var checked = $("#checkBoxMultipleItems").prop("checked");
    if (checked) {
        $("#labelItems").prop("disabled", false);
        $("#inputItems").prop("disabled", false);
        $("#labelTagClient").prop("disabled", true);
        $("#inputTagClient").prop("disabled", true);
        $("#labelTagDescription").prop("disabled", true);
        $("#inputTagDescription").prop("disabled", true);
        $("#labelLot").prop("disabled", true);
        $("#inputLot").prop("disabled", true);
    }
    else {
        $("#labelItems").prop("disabled", true);
        $("#inputItems").prop("disabled", true);
        $("#labelTagClient").prop("disabled", false);
        $("#inputTagClient").prop("disabled", false);
        $("#labelTagDescription").prop("disabled", false);
        $("#inputTagDescription").prop("disabled", false);
        $("#labelLot").prop("disabled", false);
        $("#inputLot").prop("disabled", false);
    }
}

function downloadMainItemsListExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemList.xlsx";
            link.download = project + "-MainItems-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function setMultiselectMainItems() {
    $('#Area').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#ObjectCode').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#TagType').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });
}

function checkAllItems(itemsChecked) {
    var table = document.getElementById("tableMainItems");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}

//Delete event handler.
function deleteMainItems () {
    var project = $('#labelProjectCode').text();
    var selectedItems = [];
    var cell = null;

    tableMainItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            cell = tableMainItems.cell({ row: rowIdx, column: 1 }).node();
            var id = $('span', cell).text();
            selectedItems.push(id);
        }
    });

    if (selectedItems.length == 0) {
        alert("Any item selected!!");
        return;
    }

    if (confirm("Do you want to mark selected Main Items as deleted?")) {
        var url = "/cmd/MAINITEMS/DeleteMultipleItems";
        var data = JSON.stringify(selectedItems);
        $.ajax({
            type: "POST",
            url: url,
            data: {
                'idStr': data
            },
            dataType: "text",
            success: function (response) {
                if (response == STATUS_MAIN_ITEM_DELETED) {
                    window.location = '/cmd/ItemListCreation/Index?code=' + project;
                }
                else {
                    displayMessage(response);
                }
            },
            error: function (response, error) {
                if (response.responseText == STATUS_MAIN_ITEM_DELETED) {
                    window.location = '/cmd/ItemListCreation/Index?code=' + project;
                }
                else {
                    displayMessage(response.responseText);
                }
            },
        });
    }
};

function CreateSingleItem() {

    // Area
    var selectedArea = [];
    $('#Area :selected').each(function () {
        selectedArea.push($(this).text());
    });
    if (selectedArea.length != 1) {
        alert("Select only one Area!!");
        return;
    }

    // LV01_Object_Code
    var selectedCodes = [];
    $('#ObjectCode :selected').each(function () {
        selectedCodes.push($(this).text());
    });
    if (selectedCodes.length != 1) {
        alert("Select only one Object Code!!");
        return;
    }

    // Material
    var material = $("#MaterialWorkGroup").val();
    var materialChecked = document.getElementById("inputMaterialWorkGroupActive").checked;
    if (materialChecked && material == '') {
        alert("Select a Material Work Group!!");
        return;
    }

    // TagType
    var selectedTagTypes = [];
    $('#TagType :selected').each(function () {
        selectedTagTypes.push($(this).text());
    });
    if (selectedTagTypes.length == 0) {
        alert("Any TagType selected!!");
        return;
    }
    if (selectedTagTypes.length != 1) {
        alert("Select only one TagType!!");
        return;
    }

    // Sequence number
    var sequenceNumber = $('#inputSequenceNumber').val();

    // Tag Description
    var tagDescription = $('#inputTagDescription').val();

    // Tag Client
    var tagClient = $('#inputTagClient').val();

    // LOT
    var lot = $('#inputLot').val();

    // projectId
    var code = $('#labelProject').text();

    loadSpinnerModal();
    setProgressMessageModal("Creating Main Item..");

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/CreateElementManual',
        data: {
            'area': selectedArea[0],
            'tagdescription': tagDescription,
            'tagclient': tagClient, 'tagtype': selectedTagTypes[0],
            'code': code, 'material': material, 'materialChecked': materialChecked,
            'sequenceNumber': sequenceNumber, 'objectcode': selectedCodes[0],
            'lot': lot
        },
        dataType: 'text',
        success: function (response) {
            hideSpinnerModal();
            alert(response);
            if (response == 'Main Item created') {
                var url= '/cmd/ItemListCreation/Index?code=' + code;
                window.location.href = url;
            }
        },
        error: function (response, error) {
            hideSpinnerModal();
            alert(response.responseText);
            if (response.responseText == 'Main Item created') {
                var url= '/cmd/ItemListCreation/Index?code=' + code;
                window.location.href = url;
            }
        }
    });
}

function CreateMultipleItem() {

    // Area
    var selectedArea = [];
    $('#Area :selected').each(function () {
        selectedArea.push($(this).text());
    });
    if (selectedArea.length == 0) {
        alert("Any Area selected!!");
        return;
    }

    // LV01_Object_Code
    var selectedCodes = [];
    $('#ObjectCode :selected').each(function () {
        selectedCodes.push($(this).text());
    });
    if (selectedCodes.length == 0) {
        alert("Any Object Code selected!!");
        return;
    }

    // Material
    var dropdownvalmaterial = $("#MaterialWorkGroup").val();
    var materialChecked = document.getElementById("inputMaterialWorkGroupActive").checked;
    if (materialChecked && dropdownvalmaterial == '') {
        alert("Select a Material Work Group!!");
        return;
    }

    // TagType
    var selectedTagTypes = [];
    $('#TagType :selected').each(function () {
        selectedTagTypes.push($(this).text());
    });
    if (selectedTagTypes.length == 0) {
        alert("Any TagType selected!!");
        return;
    }

    // Items
    var totalitems = $('#inputItems').val();
    if (totalitems > 10) {
        alert("Please create less than 11 new item tags");
        return;
    }

    // LOT
    var lot = $('#inputLot').val();

    // Sequence number
    var sequenceNumberStr = $('#inputSequenceNumber').val();
    var sequenceNumber = parseInt(sequenceNumberStr);
    if (isNaN(sequenceNumber)) {
        sequenceNumber = 1;
    }
    else if (sequenceNumber < 0) {
        sequenceNumber = 1;
    }

    // projectId
    var code = $('#labelProject').text();

    loadSpinnerModal();
    setProgressMessageModal("Creating Main Items..");

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/CreateElementAutomatically',
        data: {
            'area': JSON.stringify(selectedArea),
            'objectcode': JSON.stringify(selectedCodes), 'material': dropdownvalmaterial,
            'materialChecked': materialChecked, 'tagtype': JSON.stringify(selectedTagTypes),
            'totalItems': totalitems, 'code': code, 'lot': lot, 'sequenceNumber': sequenceNumber
        },
        dataType: 'text',
        success: function (response) {
            hideSpinnerModal();
            alert(response);
            if (response == 'Main Items created') {
                var url= '/cmd/ItemListCreation/Index?code=' + code;
                window.location.href = url;
            }
        }
    });
}


function importExcelMainItemsTemplate() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal2();
    setProgressMessageModal2("Import Main Items..");

    $.ajax({
        url: '/cmd/ItemListCreation/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/ItemListCreation/Index?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal2();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/ItemListCreation/Index?code=' + project;
        }
    });
}

function showModalReplaceItem() {
    clearDropDown('selectItemReplaceWith');

    var code = $('#labelProject').text();

    var selectedItem = '';
    var selectedCount = 0;
    var correctBalance = true;
    var correctItemType = true;

    tableMainItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            selectedCount++;
            cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
            selectedItem = $('label', cell).text();

            var correctBalance = $('p', cell).text();
            if (correctBalance == 'True') {
                correct = false;
            }

            cell = tableMainItems.cell({ row: rowIdx, column: 10 }).node();
            var type = $('input', cell).val();
            if (type == 'Replaced' || type == 'Deleted') {
                correctItemType = false;
            }
        }
    });

    if (!correctBalance) {
        alert("Balance not valid for replace!!");
        return;
    }

    if (!correctItemType) {
        alert("Main Item Status not valid!!");
        return;
    }

    if (selectedCount != 1) {
        alert("Incorrect selection!!");
        return;
    }

    $('#inputReplaceSelectedItem').val(selectedItem);
    loadSpinner();

    // Fill select and show modal
    $.ajax({
        type: 'GET',
        url: '/cmd/ItemListCreation/GetAllItemsForReplace',
        data: {
            'projectCode': code,
            'itemToReplace': selectedItem
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            if (response) {
                var elements = JSON.parse(response);
                for (var i = 0; i < elements.length; i++) {
                    $('#selectItemReplaceWith').append('<option value="' + elements[i] + '">' + elements[i] + '</option>');
                }
                $('#selectItemReplaceWith').multiselect('rebuild');
                $("#modalReplaceItem").modal('show');
            }
            else {
                alert("Any compatible items!!");
            }
        },
        error: function (response, error) {
            alert(response.responseText);
            hideSpinner();
        }
    });
}

function replaceMainItems() {
    var code = $('#labelProject').text();

    // Item To Replace
    var itemToReplace = $("#inputReplaceSelectedItem").val();
    if (!itemToReplace || itemToReplace == '') {
        alert("Any Main Item selected!!");
        return;
    }

    // New Item
    var selectedItemTags = [];
    $('#selectItemReplaceWith :selected').each(function () {
        selectedItemTags.push($(this).text());
    });
    if (selectedItemTags.length == 0) {
        alert("Any Item Tag selected!!");
        return;
    }
    if (selectedItemTags.length > 1) {
        alert("Select only one Item Tag!!");
        return;
    }
    var newItem = selectedItemTags[0];

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/ReplaceElement',
        data: {
            'projectCode': code,
            'itemToReplace': itemToReplace,
            'newItem': newItem
        },
        dataType: 'text',
        success: function (response) {
            if (response == 'Main Item replaced') {
                var project = $('#labelProject').text();
                var url= '/cmd/ItemListCreation/Index?code=' + project;
                window.location.href = url;
            }
            else {
                alert(response);
            }
        },
        error: function (response, error) {
            alert(response.responseText);
        }
    });
}

function showModalCombineItems() {
    clearDropDown('selectItemCombine');

    var code = $('#labelProject').text();

    var selectedItems = [];
    var selectedCount = 0;
    var correctBalance = true;
    var correctItemType = true;

    tableMainItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            selectedCount++;
            cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
            selectedItems.push($('label', cell).text());

            var balance = $('p', cell).text();
            if (balance == 'True') {
                correctBalance = false;
            }

            cell = tableMainItems.cell({ row: rowIdx, column: 10 }).node();
            var type = $('input', cell).val();
            if (type == 'Replaced' || type == 'Deleted') {
                correctItemType = false;
            }
        }
    });

    if (!correctBalance) {
        alert("Balance not valid for replace!!");
        return;
    }

    if (!correctItemType) {
        alert("Main Item Status not valid!!");
        return;
    }

    if (selectedCount < 1) {
        alert("Incorrect selection!!");
        return;
    }

    document.getElementById("inputCombinedItems").rows = selectedItems.length;
    var textVal = '';
    for (var i = 0; i < selectedItems.length; i++) {
        textVal += selectedItems[i];
        if (i < (selectedItems.length - 1)) {
            textVal += '\r\n';
        }
    }
    $('#inputCombinedItems').val(textVal);
    loadSpinner();

    // Fill select and show modal
    $.ajax({
        type: 'GET',
        url: '/cmd/ItemListCreation/GetAllItemsForCombine',
        data: {
            'projectCode': code,
            'itemtocombinestr': JSON.stringify(selectedItems)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            if (response) {
                var elements = JSON.parse(response);
                for (var i = 0; i < elements.length; i++) {
                    $('#selectItemCombine').append('<option value="' + elements[i] + '">' + elements[i] + '</option>');
                }
                $('#selectItemCombine').multiselect('rebuild');
                $("#modalCombineItem").modal('show');
            }
            else {
                alert("Any compatible items!!");
            }
        },
        error: function (response, error) {
            alert(response.responseText);
            hideSpinner();
        }
    });
}

function combineMainItems() {
    var code = $('#labelProject').text();

    var selectedItems = [];
    var selectedCount = 0;
    tableMainItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            selectedCount++;
            cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
            selectedItems.push($('label', cell).text());
        }
    });

    if (selectedCount < 1) {
        alert("Incorrect selection!!");
        return;
    }

    // New Item
    var selectedItemTags = [];
    $('#selectItemCombine :selected').each(function () {
        selectedItemTags.push($(this).text());
    });
    if (selectedItemTags.length == 0) {
        alert("Any Item Tag selected!!");
        return;
    }
    if (selectedItemTags.length > 1) {
        alert("Select only one Item Tag!!");
        return;
    }
    var newItem = selectedItemTags[0];


    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/CombineItems',
        data: {
            'items': JSON.stringify(selectedItems),
            'itemCombined': newItem,
            'code': code
        },
        dataType: 'text',
        success: function (response) {
            if (response == 'Combined') {
                var project = $('#labelProject').text();
                var url= '/cmd/ItemListCreation/Index?code=' + project;
                window.location.href = url;
            }
            else {
                alert(response);
            }
        },
        error: function (response, error) {
            alert(response.responseText);
        }
    });
}

function showModalDeleteItems() {
    var selectedItems = [];
    var selectedCount = 0;
    tableMainItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            selectedCount++;
            cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
            selectedItems.push($('label', cell).text());
        }
    });

    if (selectedCount < 1) {
        alert("Incorrect selection!!");
        return;
    }

    document.getElementById("inputDeleteItems").rows = selectedItems.length;
    var textVal = '';
    for (var i = 0; i < selectedItems.length; i++) {
        textVal += selectedItems[i];
        if (i < (selectedItems.length - 1)) {
            textVal += '\r\n';
        }
    }
    $('#inputDeleteItems').val(textVal);

    $("#modalDeleteItem").modal('show');
}

function deleteMainItems() {
    var code = $('#labelProject').text();

    var selectedItems = [];
    var selectedCount = 0;
    tableMainItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            selectedCount++;
            cell = tableMainItems.cell({ row: rowIdx, column: 0 }).node();
            selectedItems.push($('span', cell).text());
        }
    });

    if (selectedCount < 1) {
        alert("Incorrect selection!!");
        return;
    }

    if (confirm("Do you want to mark selected Main Items as deleted?")) {
        var url = "/cmd/MAINITEMS/DeleteMultipleItems";
        var data = JSON.stringify(selectedItems);
        $.ajax({
            type: "POST",
            url: url,
            data: {
                'idStr': data
            },
            dataType: "text",
            success: function (response) {
                var logs = JSON.parse(response);
                showExcelLogsAlertNoColumn(logs);
                var project = $('#labelProject').text();
                var url= '/cmd/ItemListCreation/Index?code=' + project;
                window.location.href = url;
            },
            error: function (response, error) {
                var logs = JSON.parse(response.responseText);
                showExcelLogsAlertNoColumn(logs);
                var project = $('#labelProject').text();
                var url= '/cmd/ItemListCreation/Index?code=' + project;
                window.location.href = url;
            },
        });
    }
}

function hideEventsColumnsMainItems() {
    for (let i = 1; i <= totalMainItemsColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableMainItems.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableMainItems);
        })
    }
}

function setMultiselectMainItemsReplace() {
    $('#selectItemReplaceWith').multiselect({
        includeSelectAllOption: false,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });
}

function setMultiselectMainItemsCombine() {
    $('#selectItemCombine').multiselect({
        includeSelectAllOption: false,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });
}