﻿$(document).ready(function () {
    $('#MainItemsToCombine').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    // Add Item List
    var projectId = $('#labelProjectId').text();

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/GetMainItems',
        data: {
            'projectId': projectId
        },
        dataType: 'text',
        success: function (response) {
            items = JSON.parse(response);
            var options = '';

            for (var i = 0; i < items.length; i++)
                options += '<option value="' + items[i].description + '" />';

            document.getElementById('itemList').innerHTML = options;
        }
    });

    // Create Button Event
    $("#btnCombineMainItem").click(function () {
        CombineItems();
    });
});

function CombineItems() {

    // Item to Combine
    var selectedItems = [];
    $('#MainItemsToCombine :selected').each(function () {
        selectedItems.push($(this).text());
    });
    if (selectedItems.length == 0) {
        alert("Any Items selected!!");
        return;
    }

    // Main Item
    var itemCombined = $('#inputItemCombined').val();
    if (itemCombined == '' || itemCombined == "Nd") {
        alert("Select a Working Package!!");
        return;
    }

    // projectId
    var code = $('#labelProject').text();

    loadSpinner();

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/CombineItems',
        data: {
            'items': JSON.stringify(selectedItems),
            'itemCombined': itemCombined,
            'code': code
        },
        dataType: 'text',
        success: function (response) {
            document.getElementById("divMessage").innerHTML = response;
            hideSpinner();
        }
    });
}