﻿$(document).ready(function () {
    // To List
    $("#btnMainItemsList").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/STEELITEMLISTCREATION/Index?code=' + project;
        window.location.href = url;
    });

    // Add Item List
    var projectId = $('#labelProject').text();

    // Create Button Event
    $("#btnSaveMainItem").click(function () {

        // Main Item
        var dropdownmainitem = $("#MainItem").val();
        if (!dropdownmainitem) {
            alert("Any MainItem selected!!");
            return;
        }

        // LOT
        var lot = $('#inputLOT').val();
        if (!lot) {
            alert("Lot not indicated!!");
            return;
        }
        if (!isLetter(lot)) {
            alert("Lot is not a letter!!");
            return;
        }

        // Vendor
        var dropdownvendor = $("#Vendor").val();
        if (!dropdownvendor) {
            alert("Any Vendor selected!!");
            return;
        }

        // MR
        var dropdownMR = $("#MR").val();
        if (!dropdownMR) {
            alert("Any MR selected!!");
            return;
        }

        // PO
        var dropdownPO = $("#PO").val();
        if (!dropdownPO) {
            alert("Any PO selected!!");
            return;
        }

        // projectId
        var code = $('#labelProject').text();

        loadSpinner();

        $.ajax({
            type: 'POST',
            url: '/cmd/SteelItemListCreation/SaveElementManual',
            data: {
                'mainitemstr': dropdownmainitem, 'lotstr': lot,
                'vendorstr': dropdownvendor, 'mrstr': dropdownMR,
                'postr': dropdownPO, 'code': code},
            dataType: 'text',
            success: function (response) {
                document.getElementById("divMessage").innerHTML = response;
                hideSpinner();
            },
            error: function (response, error) {
                document.getElementById("divMessage").innerHTML = response.responseText;
                hideSpinner();
            }
        });
    });
});

function isLetter(s) {
    return s.match("^[a-zA-Z\(\)]+$");
}