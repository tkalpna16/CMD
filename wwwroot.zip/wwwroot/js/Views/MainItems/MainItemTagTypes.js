﻿var tableMainItemTagType = null;
var totalMainItemTagTypesColumns = 15;

$(document).ready(function () {
    // Main Settings
    setTitle("Manage Tag Types Data"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#itemListGeneratorBtn"); // Hide PBS Button

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcelTagType();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    // To List
    $("#btnMainItemsList").click(function () {
        var code = $('#labelProject').text();
        var url= '/cmd/ITEMLISTCREATION/Index?code=' + code;
        window.location.href = url;
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ItemListCreation/Index?code=' + project;
        window.location.href = url;
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/ItemListCreation/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: {
                'code': project
            },
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Temp/TemplateCIL.xlsx";
                link.download = "TemplateCIL.xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    $('#btnGetExcelList').on('click', function (evt) {
        evt.preventDefault();

        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        var fileInput = document.getElementById('inputFile');
        if (fileInput.files.length == 0) {
            alert("Select an Excel file!!")
            return;
        }
        var file = fileInput.files[0];
        var formData = new FormData();
        formData.append('postedFile', file);
        formData.append('code', project);

        loadSpinner();
        $.ajax({
            url: '/cmd/ItemListCreation/ImportExcelParameters',
            contentType: false,
            processData: false,
            type: 'post',
            data: formData,
            success: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProject').text();
                window.location = '/cmd/ItemListCreation/Parameters?code=' + project;
            },
            error: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProject').text();
                window.location = '/cmd/ItemListCreation/Parameters?code=' + project;
            }
        });
    });

    InitTableMainTagTypes();

    hideEventsColumnsMainItemTagTypes();

    tableMainItemTagType.column(1).visible(false);
    tableMainItemTagType.column(2).visible(false);
    tableMainItemTagType.column(4).visible(false);
    tableMainItemTagType.column(5).visible(false);
    tableMainItemTagType.column(9).visible(false);

    $('#rowTable').show();
    tableMainItemTagType.columns.adjust();
});

function downloadMainItemsListExcelTagType() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemList.xlsx";
            link.download = project + "-MainItems-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function InitTableMainTagTypes() {
    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    /* Create an array with the values of all the select options in a column */
    $.fn.dataTable.ext.order['dom-select'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('select', td).text();
        });
    }

    tableMainItemTagType = $('#tableParameters').DataTable({
        dom: 'Rrtip',
        responsive: true,
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { width: 50, targets: 0 },
            { width: 80, targets: 7 },
            { width: 100, targets: 10 },
            { width: 160, targets: 11 },
            { "targets": 10, "orderDataType": "dom-select" },
            { "targets": 11, "orderDataType": "dom-text", type: 'string' },
            { "targets": 12, "orderDataType": "dom-text", type: 'string' },
            { "targets": 13, "orderDataType": "dom-text", type: 'string' },
            { "targets": 14, "orderDataType": "dom-text", type: 'string' },
            { "targets": 15, "orderDataType": "dom-text", type: 'string' },
            {
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            },
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableMainItemTagTypeSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableMainItemTagType.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableMainItemTagType.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableMainItemTagType.draw();

        colorDatatableAllRow(tableMainItemTagType);
    });

    hideEventsColumnsMainItemTagTypes();

    tableMainItemTagType.column(1).visible(false);
    tableMainItemTagType.column(2).visible(false);
    tableMainItemTagType.column(4).visible(false);
    tableMainItemTagType.column(5).visible(false);
}

function updateTableMainItemTagTypeSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableMainItemTagType.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalMainItemTagTypesColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableMainItemTagType.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableMainItemTagType.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function ApplyParameterMainItemTagTypes() {
    loadSpinner();
    setProgressMessage("Appy values..");

    var value = $('#itemParameterValue').val();
    var rowChecked;
    var cell;

    // Get all checked columns
    var selectedColumns = [];
    var colChecked = document.getElementById("checkboxWP").checked;
    if (colChecked) {
        selectedColumns.push(5);
    }
    colChecked = document.getElementById("checkboxTagClient").checked;
    if (colChecked) {
        selectedColumns.push(6);
    }
    colChecked = document.getElementById("checkboxSubContractor").checked;
    if (colChecked) {
        selectedColumns.push(7);
    }
    colChecked = document.getElementById("checkboxRemarks").checked;
    if (colChecked) {
        selectedColumns.push(8);
    }
    colChecked = document.getElementById("checkboxOptRatio").checked;
    if (colChecked) {
        selectedColumns.push(9);
    }
    colChecked = document.getElementById("checkboxTCM").checked;
    if (colChecked) {
        selectedColumns.push(10);
    }
    colChecked = document.getElementById("checkboxDrawRev").checked;
    if (colChecked) {
        selectedColumns.push(11);
    }

    for (let i = 1; i <= maxParameters; i++) {
        var element = document.getElementById("checkboxParameter" + i);
        if (element) {
            colChecked = element.checked;
            if (colChecked) {
                selectedColumns.push(startingColumn + i);
            }
        }
    }
    


    tableParameters.rows().every(function (rowIdx, tableLoop, rowLoop) {
        for (let i = 0; i < selectedColumns.length; i++) {
            var index = selectedColumns[i];
            cell = tableParameters.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tableParameters.cell({ row: rowIdx, column: index }).node();
                $('input', cell).val(value);
                $('select', cell).val(value);
            }
        }
    });
    tableParameters.draw();

    hideSpinner();
}

function SaveParameters() {
    loadSpinner();
    setProgressMessage("Saving data..");

    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var tagtypes = [];
    var lots = [];
    var wps = [];
    var tagDescriptions = [];
    var tagClients = [];
    var subContractors = [];
    var remarks = [];
    var optRatios = [];
    var tcmcodes = [];
    var drawrev = [];
    var param1Values = [];
    var param2Values = [];
    var param3Values = [];
    var param4Values = [];
    var param5Values = [];
    var param6Values = [];
    var param7Values = [];
    var param8Values = [];
    var param9Values = [];
    var param10Values = [];
    var param11Values = [];
    var param12Values = [];
    var param13Values = [];
    var param14Values = [];
    var param15Values = [];
    var param16Values = [];
    var param17Values = [];
    var param18Values = [];
    var param19Values = [];
    var param20Values = [];

    loadSpinner();

    var table = tableParameters;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[1]);
        tagtypes.push(data[3]);
        lots.push(data[4]);

        var cell = table.cell({ row: rowIdx, column: 5 }).node();
        var value = $('select', cell).val();
        wps.push(value);

        cell = table.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', cell).val();
        tagClients.push(value);

        cell = table.cell({ row: rowIdx, column: 7 }).node();
        value = $('input', cell).val();
        subContractors.push(value);

        cell = table.cell({ row: rowIdx, column: 8 }).node();
        value = $('input', cell).val();
        remarks.push(value);

        cell = table.cell({ row: rowIdx, column: 9 }).node();
        value = $('input', cell).val();
        if (value == '') {
            optRatios.push(0);
        }
        else {
            var opt = parseFloat(value);
            if (!isNaN(opt)) {
                optRatios.push(opt);
            }
            else {
                optRatios.push(0.0);
            }
        }

        cell = table.cell({ row: rowIdx, column: 10 }).node();
        value = $('input', cell).val();
        tcmcodes.push(value);

        cell = table.cell({ row: rowIdx, column: 11 }).node();
        value = $('input', cell).val();
        drawrev.push(value);

        var i = 12;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param1Values.push('');
            }
            else {
                param1Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param2Values.push('');
            }
            else {
                param2Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param3Values.push('');
            }
            else {
                param3Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param4Values.push('');
            }
            else {
                param4Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param5Values.push('');
            }
            else {
                param5Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if(value == null) {
                param6Values.push('');
            }
            else {
                param6Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param7Values.push('');
            }
            else {
                param7Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param8Values.push('');
            }
            else {
                param8Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param9Values.push('');
            }
            else {
                param9Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param10Values.push('');
            }
            else {
                param10Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param11Values.push('');
            }
            else {
                param11Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param12Values.push('');
            }
            else {
                param12Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param13Values.push('');
            }
            else {
                param13Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param14Values.push('');
            }
            else {
                param14Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param15Values.push('');
            }
            else {
                param15Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param16Values.push('');
            }
            else {
                param16Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param17Values.push('');
            }
            else {
                param17Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param18Values.push('');
            }
            else {
                param18Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param19Values.push('');
            }
            else {
                param19Values.push(value);
            }
        }
        i++;
        if (data.length > (i - 1)) {
            cell = table.cell({ row: rowIdx, column: i }).node();
            value = $('input', cell).val();
            if (value == null) {
                param20Values.push('');
            }
            else {
                param20Values.push(value);
            }
        }
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/SaveParameters',
        data: {
            'code': project,
            'mainitemsStr': JSON.stringify(mainItems),
            'tagtypesStr': JSON.stringify(tagtypes),
            'lotsStr': JSON.stringify(lots),
            'wpsStr': JSON.stringify(wps),
            'tagClientsStr': JSON.stringify(tagClients),
            'subContractorsStr': JSON.stringify(subContractors),
            'remarksStr': JSON.stringify(remarks),
            'optRatiosStr': JSON.stringify(optRatios),
            'tcmcodesStr': JSON.stringify(tcmcodes),
            'drawrevStr': JSON.stringify(drawrev),
            'param1ValuesStr': JSON.stringify(param1Values),
            'param2ValuesStr': JSON.stringify(param2Values),
            'param3ValuesStr': JSON.stringify(param3Values),
            'param4ValuesStr': JSON.stringify(param4Values),
            'param5ValuesStr': JSON.stringify(param5Values),
            'param6ValuesStr': JSON.stringify(param6Values),
            'param7ValuesStr': JSON.stringify(param7Values),
            'param8ValuesStr': JSON.stringify(param8Values),
            'param9ValuesStr': JSON.stringify(param9Values),
            'param10ValuesStr': JSON.stringify(param10Values),
            'param11ValuesStr': JSON.stringify(param11Values),
            'param12ValuesStr': JSON.stringify(param12Values),
            'param13ValuesStr': JSON.stringify(param13Values),
            'param14ValuesStr': JSON.stringify(param14Values),
            'param15ValuesStr': JSON.stringify(param15Values),
            'param16ValuesStr': JSON.stringify(param16Values),
            'param17ValuesStr': JSON.stringify(param17Values),
            'param18ValuesStr': JSON.stringify(param18Values),
            'param19ValuesStr': JSON.stringify(param19Values),
            'param20ValuesStr': JSON.stringify(param20Values)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageLabel', response.responseText);
            hideSpinner();
        },
    });
}


function checkAllItems() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = $('#tableParameters').DataTable();;
    var cell = null;
    var input = null;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = table.cell({ row: rowIdx, column: 0 }).node();
        input = $('input', cell);
        input.prop("checked", itemsChecked);
    });
    table.draw();
}


function mainItemTagTypesApplyTextValues() {
    loadSpinner();
    setProgressMessage("Apply values..");

    // Get selected columns
    var colIds = [];
    for (let i = 10; i <= 14; i++) {
        var col1 = document.getElementById("checkBoxVal" + i).checked;
        if (col1) {
            colIds.push(i);
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableMainItemTagType.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateMainItemTagTypeTableValues(colIdx, rowIdx));
        });
        tableMainItemTagType.draw();
    }

    hideSpinner();
}

function updateMainItemTagTypeTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableMainItemTagType.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        if (colIdx != 10) {
            cell = tableMainItemTagType.cell({ row: rowIdx, column: colIdx }).node();
            $('input', cell).val(valueToApply);
        }
        else {
            cell = tableMainItemTagType.cell({ row: rowIdx, column: colIdx }).node();
            $('select', cell).val(valueToApply);
        }
    }
}

function downloadMainItemsParametersExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcelParameters';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemListParameters.xlsx";
            link.download = project + "-MainItemsParameters-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function hideEventsColumnsMainItemTagTypes() {
    for (let i = 1; i <= totalMainItemTagTypesColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableMainItemTagType.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableMainItemTagType);
        })
    }
}

function mainItemTypeSaveTextValues() {
    loadSpinner();
    setProgressMessage("Saving data..");

    var project = $('#labelProject').text();

    var items = [];
    var wplist = [];
    var drawnolist = [];
    var drawrevlist = [];
    var subcontractorlist = [];
    var remarklist = [];

    tableMainItemTagType.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellvalue = tableMainItemTagType.cell({ row: rowIdx, column: 0 }).node();
        value = $('span', cellvalue).text();
        items.push(value);

        cellvalue = tableMainItemTagType.cell({ row: rowIdx, column: 10 }).node();
        value = $('select', cellvalue).val();
        wplist.push(value);

        cellvalue = tableMainItemTagType.cell({ row: rowIdx, column: 11 }).node();
        value = $('input', cellvalue).val();
        drawnolist.push(value);

        cellvalue = tableMainItemTagType.cell({ row: rowIdx, column: 12 }).node();
        value = $('input', cellvalue).val();
        drawrevlist.push(value);

        cellvalue = tableMainItemTagType.cell({ row: rowIdx, column: 13 }).node();
        value = $('input', cellvalue).val();
        subcontractorlist.push(value);

        cellvalue = tableMainItemTagType.cell({ row: rowIdx, column: 14 }).node();
        value = $('input', cellvalue).val();
        remarklist.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/SaveMainItemTagType',
        data: {
            'code': project,
            'mainitemids': JSON.stringify(items),
            'wpstr': JSON.stringify(wplist),
            'drawnostr': JSON.stringify(drawnolist),
            'drawrevstr': JSON.stringify(drawrevlist),
            'subcontractorstr': JSON.stringify(subcontractorlist),
            'remarkstr': JSON.stringify(remarklist)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
    });
}

function importExcelMainItemsTemplate() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Import Main Items..");

    $.ajax({
        url: '/cmd/ItemListCreation/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/ItemListCreation/MainItemTagTypes?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/ItemListCreation/MainItemTagTypes?code=' + project;
        }
    });
}