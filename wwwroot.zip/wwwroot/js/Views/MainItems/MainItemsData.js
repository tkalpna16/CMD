﻿var tableMainItemData = null;
var totalMainItemDataColumns = 8;
const startColumnParameterMainItemData = 9;
const maxParametersMainItemData = 10;
var totalParameters = 0;

$(document).ready(function () {
    // Main Settings
    setTitle("Manage Main Items Data"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#itemListGeneratorBtn"); // Hide PBS Button

    // Init total parameters
    var labelVal = $('#labelParameters').text();
    totalParameters = parseInt(labelVal);

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcelData();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ItemListCreation/Index?code=' + project;
        window.location.href = url;
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/ItemListCreation/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: {
                'code': project
            },
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Temp/TemplateCIL.xlsx";
                link.download = "TemplateCIL.xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    $('#btnGetExcelList').on('click', function (evt) {
        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        var fileInput = document.getElementById('inputFile');
        if (fileInput.files.length == 0) {
            alert("Select an Excel file!!")
            return;
        }
        var file = fileInput.files[0];
        var formData = new FormData();
        formData.append('postedFile', file);
        formData.append('code', project);

        loadSpinner();
        $.ajax({
            url: '/cmd/ItemListCreation/ImportExcel',
            contentType: false,
            processData: false,
            type: 'post',
            data: formData,
            success: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProjectCode').text();
                window.location = '/cmd/ItemListCreation/Index?code=' + project;
            },
            error: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProjectCode').text();
                window.location = '/cmd/ItemListCreation/Index?code=' + project;
            }
        });
    });

    InitTableMainItemData();

    hideEventsColumnsMainData();

    tableMainItemData.column(1).visible(false);
    tableMainItemData.column(2).visible(false);
    tableMainItemData.column(8).visible(false);

    for (let i = totalParameters; i < maxParametersMainItemData; i++) {
        tableMainItemData.column(startColumnParameterMainItemData + i).visible(false);
        var id = i + 1;
        hideElement("#rowVis" + id);
        hideElement("#row" + id);
        hideElement("#rowAD" + id);
        hideElement("#rowVal" + id);
    }

    $('#rowTable').show();
    tableMainItemData.columns.adjust();
});

function downloadMainItemsListExcelData() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemList.xlsx";
            link.download = project + "-MainItems-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function InitTableMainItemData() {
    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    tableMainItemData = $('#tableParameters').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [1, 8], "searchable": true },
            {
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 50, targets: 0 },
            { "targets": 4, "orderDataType": "dom-text", type: 'string' },
            { "targets": 5, "orderDataType": "dom-text", type: 'string' },
            { "targets": 6, "orderDataType": "dom-text", type: 'string' },
            { "targets": 7, "orderDataType": "dom-text", type: 'string' }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableMainItemDataSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableMainItemData.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableMainItemData.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableMainItemData.draw();

        colorDatatableAllRow(tableMainItemData);
    });
}

function updateTableMainItemDataSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableMainItemData.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    var totalColumn = totalMainItemDataColumns + totalParameters;
    for (let i = 1; i <= totalColumn; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableMainItemData.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableMainItemData.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function ApplyGroupParameters() {
    var value = $('#itemParameterValue').val();
    var rowChecked;
    var cell;

    // Get all checked columns
    var selectedColumns = [];
    var colChecked = document.getElementById("checkboxDescription").checked;
    if (colChecked) {
        selectedColumns.push(2);
    }
    colChecked = document.getElementById("checkboxTagClient").checked;
    if (colChecked) {
        selectedColumns.push(3);
    }
    colChecked = document.getElementById("checkboxEquipmentTag").checked;
    if (colChecked) {
        selectedColumns.push(4);
    }
    colChecked = document.getElementById("checkboxEquipmentLayout").checked;
    if (colChecked) {
        selectedColumns.push(5);
    }
    colChecked = document.getElementById("checkboxLength").checked;
    if (colChecked) {
        selectedColumns.push(7);
    }
    colChecked = document.getElementById("checkboxWidth").checked;
    if (colChecked) {
        selectedColumns.push(8);
    }
    colChecked = document.getElementById("checkboxConcreteHeight").checked;
    if (colChecked) {
        selectedColumns.push(9);
    }
    colChecked = document.getElementById("checkboxConcreteLevels").checked;
    if (colChecked) {
        selectedColumns.push(10);
    }
    colChecked = document.getElementById("checkboxSteelHeight").checked;
    if (colChecked) {
        selectedColumns.push(11);
    }
    colChecked = document.getElementById("checkboxSteelLevels").checked;
    if (colChecked) {
        selectedColumns.push(12);
    }
    colChecked = document.getElementById("checkboxNumberOfModules").checked;
    if (colChecked) {
        selectedColumns.push(16);
    }
    colChecked = document.getElementById("checkboxImportanceEQ").checked;
    if (colChecked) {
        selectedColumns.push(17);
    }

    tableGroupParameters.rows().every(function (rowIdx, tableLoop, rowLoop) {
        for (let i = 0; i < selectedColumns.length; i++) {
            var index = selectedColumns[i];
            cell = tableGroupParameters.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tableGroupParameters.cell({ row: rowIdx, column: index }).node();
                $('input', cell).val(value);
                $('select', cell).val(value);
            }
        }
    });
    tableGroupParameters.draw();
}

function SaveGroupParameters() {
    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var descriptions = [];
    var tagClients = [];
    var equipmentTags = [];
    var equipmentLayouts = [];
    var lengthList = [];
    var widthList = [];
    var concreteHeightList = [];
    var concreteLevelList = [];
    var steelHeightList = [];
    var steelLevelList = [];
    var moduleList = [];
    var importanceList = [];

    loadSpinner();

    var table = tableGroupParameters;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        mainItems.push(data[1]);


        cell = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cell).val();
        tagClients.push(value);

        var cell = table.cell({ row: rowIdx, column: 5 }).node();
        var value = $('input', cell).val();
        descriptions.push(value);

        cell = table.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', cell).val();
        equipmentTags.push(value);

        cell = table.cell({ row: rowIdx, column: 7 }).node();
        value = $('input', cell).val();
        equipmentLayouts.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/SaveMainItemData',
        data: {
            'code': project,
            'mainitemsStr': JSON.stringify(mainItems),
            'tagClientsStr': JSON.stringify(tagClients),
            'descriptionsStr': JSON.stringify(descriptions),
            'equipmentTagsStr': JSON.stringify(equipmentTags),
            'equipmentLayoutsStr': JSON.stringify(equipmentLayouts)
        },
        dataType: 'text',
        success: function (response) {
            if (response == 'Parameter updated') {
                var url= '/cmd/ITEMLISTCREATION/GroupParameters?code=' + project;
                window.location.href = url;
            }
            else {
                displayMessage('messageLabel', response);
                hideSpinner();
            }
        },
        error: function (response, error) {
            displayMessage('messageLabel', response.responseText);
            hideSpinner();
        },
    });
}

function checkAllItems() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = $('#tableParameters').DataTable();;
    var cell = null;
    var input = null;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = table.cell({ row: rowIdx, column: 0 }).node();
        input = $('input', cell);
        input.prop("checked", itemsChecked);
    });
    table.draw();
}

function downloadGroupMainItemsParametersExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcelGroupParameters';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemListGroupParameters.xlsx";
            link.download = project + "-MainItemsGroupParameters-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function hideEventsColumnsMainData() {
    for (let i = 1; i <= totalMainItemDataColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableMainItemData.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableMainItemData);
        })
    }

    for (let i = 0; i < totalParameters; i++) {
        var index = i + startColumnParameterMainItemData;
        var checkbox = document.getElementById("checkBoxVis" + index);
        checkbox.addEventListener('change', (event) => {
            tableMainItemData.column(index).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableMainItemData);
        })
    }
}

function mainItemDataApplyTextValues() {
    loadSpinner();
    setProgressMessage("Set values..");

    // Get selected columns
    var colIds = [];
    for (let i = 4; i <= 7; i++) {
        var col1 = document.getElementById("checkBoxVal" + i).checked;
        if (col1) {
            colIds.push(i);
        }
    }

    for (let i = 0; i < totalParameters; i++) {
        var index = startColumnParameterMainItemData + i;
        var col1 = document.getElementById("checkBoxVal" + index).checked;
        if (col1) {
            colIds.push(index);
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableMainItemData.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateMainItemDataTableValues(colIdx, rowIdx));
        });
    }

    hideSpinner();
}

function updateMainItemDataTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableMainItemData.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        cell = tableMainItemData.cell({ row: rowIdx, column: colIdx }).node();
        $('input', cell).val(valueToApply);
    }
}

function mainItemDataSaveTextValues() {
    loadSpinner();
    setProgressMessage("Saving data..");


    var project = $('#labelProject').text();

    var items = [];
    var tagclients = [];
    var tagdesc = [];
    var tagequip = [];
    var equipdrawing = [];
    var parameter1 = [];
    var parameter2 = [];
    var parameter3 = [];
    var parameter4 = [];
    var parameter5 = [];
    var parameter6 = [];
    var parameter7 = [];
    var parameter8 = [];
    var parameter9 = [];
    var parameter10 = [];

    tableMainItemData.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        items.push(data[3]);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellvalue).val();
        tagclients.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellvalue).val();
        tagdesc.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', cellvalue).val();
        tagequip.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 7 }).node();
        value = $('input', cellvalue).val();
        equipdrawing.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 9 }).node();
        value = $('input', cellvalue).val();
        parameter1.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 10 }).node();
        value = $('input', cellvalue).val();
        parameter2.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 11 }).node();
        value = $('input', cellvalue).val();
        parameter3.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 12 }).node();
        value = $('input', cellvalue).val();
        parameter4.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 13 }).node();
        value = $('input', cellvalue).val();
        parameter5.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 14 }).node();
        value = $('input', cellvalue).val();
        parameter6.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 15 }).node();
        value = $('input', cellvalue).val();
        parameter7.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 16 }).node();
        value = $('input', cellvalue).val();
        parameter8.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 17 }).node();
        value = $('input', cellvalue).val();
        parameter9.push(value);

        cellvalue = tableMainItemData.cell({ row: rowIdx, column: 18 }).node();
        value = $('input', cellvalue).val();
        parameter10.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/SaveMainItemData',
        data: {
            'code': project,
            'mainItemsStr': JSON.stringify(items),
            'tagClientsStr': JSON.stringify(tagclients),
            'descriptionsStr': JSON.stringify(tagdesc),
            'equipmentTagsStr': JSON.stringify(tagequip),
            'equipmentLayoutsStr': JSON.stringify(equipdrawing),
            'param1ValuesStr': JSON.stringify(parameter1),
            'param2ValuesStr': JSON.stringify(parameter2),
            'param3ValuesStr': JSON.stringify(parameter3),
            'param4ValuesStr': JSON.stringify(parameter4),
            'param5ValuesStr': JSON.stringify(parameter4),
            'param6ValuesStr': JSON.stringify(parameter6),
            'param7ValuesStr': JSON.stringify(parameter7),
            'param8ValuesStr': JSON.stringify(parameter8),
            'param9ValuesStr': JSON.stringify(parameter9),
            'param10ValuesStr': JSON.stringify(parameter10)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
    });
}

function importExcelMainItemsTemplate() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Import Main Items..");

    $.ajax({
        url: '/cmd/ItemListCreation/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/ItemListCreation/MainItemData?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/ItemListCreation/MainItemData?code=' + project;
        }
    });
}