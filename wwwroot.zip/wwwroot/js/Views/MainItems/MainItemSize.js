﻿var tableMainItemSize = null;
var totalMainItemSizeColumns = 17;

$(document).ready(function () {
    // Main Settings
    setTitle("Manage Main Item Size"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#itemListGeneratorBtn"); // Hide PBS Button

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsListExcelSize();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    // To List
    $("#btnMainItemsList").click(function () {
        var code = $('#labelProject').text();
        var url= '/cmd/ITEMLISTCREATION/Index?code=' + code;
        window.location.href = url;
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/ItemListCreation/Index?code=' + project;
        window.location.href = url;
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/ItemListCreation/GetTemplateSize',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Report/TemplateCILSize.xlsx";
                link.download = "TemplateCILSize.xlsx";
                link.click();;
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    $('#btnGetExcelList').on('click', function (evt) {
        evt.preventDefault();

        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        var fileInput = document.getElementById('inputFile');
        if (fileInput.files.length == 0) {
            alert("Select an Excel file!!")
            return;
        }
        var file = fileInput.files[0];
        var formData = new FormData();
        formData.append('postedFile', file);
        formData.append('code', project);

        loadSpinner();
        $.ajax({
            url: '/cmd/ItemListCreation/ImportExcelParameters',
            contentType: false,
            processData: false,
            type: 'post',
            data: formData,
            success: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProject').text();
                window.location = '/ItemListCreation/Parameters?code=' + project;
            },
            error: function (val) {
                hideSpinner();
                alert(val);
                var project = $('#labelProject').text();
                window.location = '/ItemListCreation/Parameters?code=' + project;
            }
        });
    });

    InitTableMainItemSize();

    $('#rowTable').show();
    tableMainItemSize.columns.adjust();
});

function downloadMainItemsListExcelSize() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcelItemSize';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemSizeList.xlsx";
            link.download = project + "-MainItemsSize-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function InitTableMainItemSize() {
    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    /* Create an array with the values of all the select options in a column */
    $.fn.dataTable.ext.order['dom-select'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('select', td).val();
        });
    }

    tableMainItemSize = $('#tableMainItemSize').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: false,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            {
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 50, targets: 0 },
            { "targets": 7, "orderDataType": "dom-text", type: 'string' },
            { "targets": 8, "orderDataType": "dom-text", type: 'string' },
            { "targets": 9, "orderDataType": "dom-text", type: 'string' },
            { "targets": 10, "orderDataType": "dom-text", type: 'string' },
            { "targets": 11, "orderDataType": "dom-text", type: 'string' },
            { "targets": 12, "orderDataType": "dom-text", type: 'string' },
            { "targets": 14, "orderDataType": "dom-text", type: 'string' },
            { "targets": 15, "orderDataType": "dom-text", type: 'string' },
            { "targets": 16, "orderDataType": "dom-text", type: 'string' },
            { "targets": 15, "orderDataType": "dom-text", type: 'string' },
            { "targets": 17, "orderDataType": "dom-select" }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableMainItemSizeSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableMainItemSize.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableMainItemSize.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableMainItemSize.draw();

        colorDatatableAllRow(tableMainItemSize);
    });

    hideEventsColumnsMainItemSize();

    tableMainItemSize.column(1).visible(false);
    tableMainItemSize.column(2).visible(false);
    tableMainItemSize.column(4).visible(false);
    tableMainItemSize.column(5).visible(false);
    tableMainItemSize.column(14).visible(false);
}

function updateTableMainItemSizeSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableMainItemSize.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalMainItemSizeColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableMainItemSize.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableMainItemSize.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function checkAllItemsMainItemSize() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var table = $('#tableParameters').DataTable();;
    var cell = null;
    var input = null;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = table.cell({ row: rowIdx, column: 0 }).node();
        input = $('input', cell);
        input.prop("checked", itemsChecked);
    });
    table.draw();
}

function hideEventsColumnsMainItemSize() {
    for (let i = 1; i <= totalMainItemSizeColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableMainItemSize.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableMainItemSize);
        })
    }
}

function mainItemTagSizeApplyTextValues() {
    loadSpinner();
    setProgressMessage("Apply values..");

    // Get selected columns
    var colIds = [];
    for (let i = 7; i <= 12; i++) {
        var col1 = document.getElementById("checkBoxVal" + i).checked;
        if (col1) {
            colIds.push(i);
        }
    }
    for (let i = 16; i <= 17; i++) {
        var col1 = document.getElementById("checkBoxVal" + i).checked;
        if (col1) {
            colIds.push(i);
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableMainItemSize.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateMainItemTagSizeTableValues(colIdx, rowIdx));
        });
        tableMainItemSize.draw();
    }

    hideSpinner();
}

function updateMainItemTagSizeTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableMainItemSize.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        if (colIdx != 17) {
            cell = tableMainItemSize.cell({ row: rowIdx, column: colIdx }).node();
            $('input', cell).val(valueToApply);
        }
        else {
            cell = tableMainItemSize.cell({ row: rowIdx, column: colIdx }).node();
            $('select', cell).val(valueToApply);
        }
    }
}

function mainItemSizeSaveTextValues() {
    loadSpinner();
    setProgressMessage("Saving data..");

    var project = $('#labelProject').text();

    var items = [];
    var lengthlist = [];
    var widthlist = [];
    var aaheightlist = [];
    var aalevellist = [];
    var aiheightlist = [];
    var ailevellist = [];
    var modulelist = [];
    var importancelist = [];

    var valid = true;
    var invalidRow = 0;

    tableMainItemSize.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        var input = null;
        items.push(data[3]);

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 7 }).node();
        input = $('input', cellvalue);
        value = $('input', cellvalue).val();
        value = parseFloat(value);
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                lengthlist.push(value);
            }
        }
        else {
            lengthlist.push(0.0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 8 }).node();
        value = $('input', cellvalue).val();
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                widthlist.push(value);
            }
        }
        else {
            widthlist.push(0.0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 9 }).node();
        value = $('input', cellvalue).val();
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                aaheightlist.push(value);
            }
        }
        else {
            aaheightlist.push(0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 10 }).node();
        value = $('input', cellvalue).val();
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                aalevellist.push(value);
            }
        }
        else {
            aalevellist.push(0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 11 }).node();
        value = $('input', cellvalue).val();
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                aiheightlist.push(value);
            }
        }
        else {
            aiheightlist.push(0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 12 }).node();
        value = $('input', cellvalue).val();
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                ailevellist.push(value);
            }
        }
        else {
            ailevellist.push(0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 16 }).node();
        value = $('input', cellvalue).val();
        if (value || value == 0) {
            if (value < 0.0) {
                valid = false;
                invalidRow = rowIdx;
            }
            else {
                modulelist.push(value);
            }
        }
        else {
            modulelist.push(0);
        }

        cellvalue = tableMainItemSize.cell({ row: rowIdx, column: 17 }).node();
        value = $('select', cellvalue).val();
        importancelist.push(value);
    });

    if (!valid) {
        alert("Invalid data at row " + invalidRow);
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/SaveMainItemSize',
        data: {
            'code': project,
            'mainitemids': JSON.stringify(items),
            'lengthstr': JSON.stringify(lengthlist),
            'widthstr': JSON.stringify(widthlist),
            'aaheightstr': JSON.stringify(aaheightlist),
            'aalevelsstr': JSON.stringify(aalevellist),
            'aiheightstr': JSON.stringify(aiheightlist),
            'ailevelsstr': JSON.stringify(ailevellist),
            'modulestr': JSON.stringify(modulelist),
            'importancestr': JSON.stringify(importancelist)
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
    });
}

function importExcelMainItemsSizeTemplate() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Import Main Items..");

    $.ajax({
        url: '/cmd/ItemListCreation/ImportSizeExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/ItemListCreation/MainItemSize?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/ItemListCreation/MainItemSize?code=' + project;
        }
    });
}