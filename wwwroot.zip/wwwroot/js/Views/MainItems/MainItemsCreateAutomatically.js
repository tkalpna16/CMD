﻿$(document).ready(function () {

    // Init controls
    InitControls();

    // To List
    $("#btnMainItemsList").click(function () {
        var code = $('#labelProject').text();
        var url= '/cmd/ITEMLISTCREATION/Index?code=' + code;
        window.location.href = url;
    });

    $('#Area').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#ObjectCode').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#TagType').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $("input[type='number']").inputSpinner();

    // Create Button Event
    $("#btnCreateMainItems").click(function () {
        if (document.getElementById("inputCreateSingleItem").checked) {
            CreateSingleItem();
        }
        else {
            CreateMultipleItem();
        }
    });
});

function CreateSingleItem() {

    // Area
    var selectedArea = [];
    $('#Area :selected').each(function () {
        selectedArea.push($(this).text());
    });
    if (selectedArea.length != 1) {
        alert("Select only one Area!!");
        return;
    }

    // WP
    var wp = $('#inputWP').val();
    if (wp == '' || wp == "NA") {
        alert("Select a Working Package!!");
        return;
    }

    // LV01_Object_Code
    var selectedCodes = [];
    $('#ObjectCode :selected').each(function () {
        selectedCodes.push($(this).text());
    });
    if (selectedCodes.length != 1) {
        alert("Select only one Object Code!!");
        return;
    }

    // Material
    var material = $("#MaterialWorkGroup").val();
    var materialChecked = document.getElementById("inputMaterialWorkGroupActive").checked;
    if (materialChecked && material == '') {
        alert("Select a Material Work Group!!");
        return;
    }

    // TagType
    var dropdownvaltagtype = $("#TagType").val();
    if (!dropdownvaltagtype) {
        alert("Any TagType selected!!");
        return;
    }

    // Sequence number
    var sequenceNumber = $('#inputSequenceNumber').val();

    // Tag Description
    var tagDescription = $('#inputTagDescription').val();

    // Tag Client
    var tagClient = $('#inputTagClient').val();

    // LOT
    var lot = $('#inputLot').val();

    // projectId
    var code = $('#labelProject').text();

    loadSpinner();

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/CreateElementManual',
        data: {
            'area': selectedArea[0], 'wp': wp,
            'tagdescription': tagDescription,
            'tagclient': tagClient, 'tagtype': dropdownvaltagtype,
            'code': code, 'material': material, 'materialChecked': materialChecked,
            'sequenceNumber': sequenceNumber, 'objectcode': selectedCodes[0],
            'lot': lot
        },
        dataType: 'text',
        success: function (response) {
            document.getElementById("divMessage").innerHTML = response;
            hideSpinner();
        },
        error: function (response, error) {
            document.getElementById("divMessage").innerHTML = response.responseText;
            hideSpinner();
        }
    });
}

function CreateMultipleItem() {

    // Area
    var selectedArea = [];
    $('#Area :selected').each(function () {
        selectedArea.push($(this).text());
    });
    if (selectedArea.length == 0) {
        alert("Any Area selected!!");
        return;
    }

    // WP
    var wp = $('#inputWP').val();
    if (wp == '' || wp == "Nd") {
        alert("Select a Working Package!!");
        return;
    }

    // LV01_Object_Code
    var selectedCodes = [];
    $('#ObjectCode :selected').each(function () {
        selectedCodes.push($(this).text());
    });
    if (selectedCodes.length == 0) {
        alert("Any Object Code selected!!");
        return;
    }

    // Material
    var dropdownvalmaterial = $("#MaterialWorkGroup").val();
    var materialChecked = document.getElementById("inputMaterialWorkGroupActive").checked;
    if (materialChecked && dropdownvalmaterial == '') {
        alert("Select a Material Work Group!!");
        return;
    }

    // TagType
    var selectedTagTypes = [];
    $('#TagType :selected').each(function () {
        selectedTagTypes.push($(this).text());
    });
    if (selectedTagTypes.length == 0) {
        alert("Any TagType selected!!");
        return;
    }

    // Items
    var totalitems = $('#inputItems').val();

    // LOT
    var lot = $('#inputLot').val();

    // Sequence number
    var sequenceNumberStr = $('#inputSequenceNumber').val();
    var sequenceNumber = parseInt(sequenceNumberStr);
    if (isNaN(sequenceNumber))
    {
        sequenceNumber = 1;
    }

    // projectId
    var code = $('#labelProject').text();

    loadSpinner();

    $.ajax({
        type: 'POST',
        url: '/cmd/ItemListCreation/CreateElementAutomatically',
        data: {
            'area': JSON.stringify(selectedArea), 'wp': wp,
            'objectcode': JSON.stringify(selectedCodes), 'material': dropdownvalmaterial,
            'materialChecked': materialChecked, 'tagtype': JSON.stringify(selectedTagTypes),
            'totalItems': totalitems, 'code': code, 'lot': lot, 'sequenceNumber': sequenceNumber
        },
        dataType: 'text',
        success: function (response) {
            document.getElementById("divMessage").innerHTML = response;
            hideSpinner();
        }
    });
}

function InitControls() {
    hideElement('#rowNumberOfItems');
    showElement('#rowTagDescription');
    showElement('#rowTagClient');
    showElement('#rowLot');
    $("#inputMaterialWorkGroupActive").prop('checked', true);
}

function handleInputType(radioInputVal) {
    if (radioInputVal.value == 'singleItem') {
        hideElement('#rowNumberOfItems');
        showElement('#rowTagDescription');
        showElement('#rowTagClient');
        showElement('#rowLot');
    }
    else {
        showElement('#rowNumberOfItems');
        hideElement('#rowTagDescription');
        hideElement('#rowTagClient');
        hideElement('#rowLot');
    }
}