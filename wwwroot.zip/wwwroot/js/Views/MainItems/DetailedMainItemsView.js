﻿var tableDetailedMainItemsView = null;
var totalDetailedMainItemsViewColumns = 60;

$(document).ready(function () {
    // Main Settings
    setTitle("Civil Item List"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar

    // Show Commands
    showElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        downloadMainItemsDetailedListExcel();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });
    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    InitTableDetailedMainItems();

    document.getElementById("rowTable").style.opacity = "1.0";
});

function InitTableDetailedMainItems() {
    tableDetailedMainItemsView = $('#tableMainItems').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: false,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollX: '100%',
        scrollY: '58vh',
        "orderClasses": false,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { width: 100, targets: 2 },
            { width: 100, targets: 5 },
            { width: 100, targets: 9 }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i < totalDetailedMainItemsViewColumns; i++) {
            var col1 = document.getElementById("checkBox" + i).checked;
            if (col1) {
                colId.push(i - 1);
            }
            tableMainItemsView.column(colId).search('').draw();
        }

        if (colId.length == 0) {
            tableDetailedMainItemsView.search(filter).draw();
        }
        else {
            tableDetailedMainItemsView.column(colId).search(filter).draw();
        }
    });

    // Hide colums
    for (let i = 1; i <= totalDetailedMainItemsViewColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        if (!checkbox.checked) {
            tableDetailedMainItemsView.column(i - 1).visible(checkbox.checked, false);
        }
    }

    hideEventsColumnsDetailedMainItems();

    tableDetailedMainItemsView.draw();
}

function downloadMainItemsDetailedListExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/ItemListCreation/CreateExcelItemsDetailedView';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/CivilItems.xlsx";
            link.download = project + "-CivilItems-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}


function hideEventsColumnsDetailedMainItems() {
    for (let i = 0; i < totalDetailedMainItemsViewColumns; i++) {
        var index = i + 1;
        var checkbox = document.getElementById("checkBoxVis" + index);
        checkbox.addEventListener('change', (event) => {
            tableDetailedMainItemsView.column(i).visible(event.currentTarget.checked);
        })
    }
}