﻿$(document).ready(function () {
    // Set title
    setTitle("Project Settings");
    hideElement("#navTopButton");
    hideElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");
    hideElement("#btnCommand1");
    hideElement("#btnCommand2");
    hideElement("#btnCommand3");

    // Edit Project
    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/Index?code=' + project;
        window.location.href = url;
    })

    // WPA
    $("#btnEditCWASettings").click(function () {
        $("#modalCWA").modal('show');
    });

    // Working Package
    $("#btnEditWPSettings").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/WORKINGPACKAGES/Index?code=' + project;
        window.location.href = url;
    });

    // Balance Package
    $("#btnEditBalanceSettings").click(function () {
        $("#modalBalance").modal('show');
    });

    // DL Settings
    $("#btnEditDLSettings").click(function () {
        $("#modalDLSettings").modal('show');
    });

    $("#btnEditPriceCodes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/PriceCodesManager?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    // Object Codes
    $("#btnEditObjectCodes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/OBJECTCODES/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    // Commodity Codes
    $("#btnEditCommodityCodes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/COMMODITYCODES/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    // Custom Attributes
    $("#btnEditCustomAttributes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/MAINITEMPARAMETERS/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    // BIM360 Attributes
    $("#btnEditBIM360Attributes").click(function () {
        $("#modalBIM360Parameters").modal('show');
    });

    // Units
    $("#btnEditUnits").click(function () {
        $("#modalUnitsSettings").modal('show');
    });

    // Custom Attributes
    $("#btnEditObjectCodes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/OBJECTCODES/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    $("#btnEditPlanningDates").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/MAINITEMPLANNINGDATES/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });
});

function saveProjectSettings() {
    var project = $('#labelProject').text();

    var cwa = $("#inputCWA").val();
    if (cwa == '') {
        alert("Any CWA!!");
        return;
    }

    var balance = $("#inputBalance").val();
    if (balance == '') {
        alert("Any Balance settings!!");
        return;
    }

    var DRAWINGNUMBER = $("#inputDRAWINGNUMBER").val();
    if (DRAWINGNUMBER == '') {
        alert("Any DRAWING NUMBER!!");
        return;
    }

    var DRAWINGCWADIGIT = $("#inputDRAWINGCWADIGIT").val();
    if (DRAWINGCWADIGIT == '') {
        alert("Any CWA Digits!!");
        return;
    }

    var DRAWINGOBJECTDIGIT = $("#inputDRAWINGOBJECTDIGIT").val();
    if (DRAWINGOBJECTDIGIT == '') {
        alert("Any Object digits!!");
        return;
    }

    var DRAWINGSEQDIGIT = $("#inputDRAWINGSEQDIGIT").val();
    if (DRAWINGSEQDIGIT == '') {
        alert("Any Sequence digits!!");
        return;
    }

    var DRAWINGDESCITEMS = $("#inputDRAWINGDESCITEMS").val();
    if (DRAWINGDESCITEMS == '') {
        alert("Any Drw Desc. for Items!!");
        return;
    }

    var DRAWINGDESCAREA = $("#inputDRAWINGDESCAREA").val();
    if (DRAWINGDESCAREA == '') {
        alert("Any Drw Desc. for Area/Balance!!");
        return;
    }

    var DRAWINGDESCCOMMON = $("#inputDRAWINGDESCCOMMON").val();
    if (DRAWINGDESCCOMMON == '') {
        alert("Any Drw Desc. for Common Docs!!");
        return;
    }

    var BIM360PARAMETERS = $("#inputBIM360PARAMETERS").val();

    var ELEVATIONCONCRETEUNIT = $("#ELEVATIONCONCRETEUNIT").val();
    var FOUNDATIONCONCRETEUNIT = $("#FOUNDATIONCONCRETEUNIT").val();
    var PAVINGUNIT = $("#PAVINGUNIT").val();
    var PILESUNIT = $("#PILESUNIT").val();
    var STEELUNIT = $("#STEELUNIT").val();
    var UNDERGROUNDPIPEUNIT = $("#UNDERGROUNDPIPEUNIT").val();
    var CONCRETESLABUNIT = $("#CONCRETESLABUNIT").val();

    var NDOCS = $("#inputDRAWINGSMAXDOCS").val();
    var MANUALNDOCS = $("#inputDRAWINGSMAXMANUALDOCS").val();
    var MAXDOCS = $("#inputDRAWINGSMAX").val();

    loadSpinner();

    var url = "/cmd/PROJECTSETTINGS/SaveSettings";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'code': project,
            'cwa': cwa,
            'balance': balance,
            'DRAWINGNUMBER': DRAWINGNUMBER,
            'DRAWINGCWADIGIT': DRAWINGCWADIGIT,
            'DRAWINGOBJECTDIGIT': DRAWINGOBJECTDIGIT,
            'DRAWINGSEQDIGIT': DRAWINGSEQDIGIT,
            'DRAWINGDESCITEMS': DRAWINGDESCITEMS,
            'DRAWINGDESCAREA': DRAWINGDESCAREA,
            'DRAWINGDESCCOMMON': DRAWINGDESCCOMMON,
            'BIM360PARAMETERS': BIM360PARAMETERS,
            'ELEVATIONCONCRETEUNIT': ELEVATIONCONCRETEUNIT,
            'FOUNDATIONCONCRETEUNIT': FOUNDATIONCONCRETEUNIT,
            'PAVINGUNIT': PAVINGUNIT,
            'PILESUNIT': PILESUNIT,
            'STEELUNIT': STEELUNIT,
            'UNDERGROUNDPIPEUNIT': UNDERGROUNDPIPEUNIT,
            'CONCRETESLABUNIT': CONCRETESLABUNIT,
            'NDOCS': NDOCS,
            'MANUALNDOCS': MANUALNDOCS,
            'MAXDOCS': MAXDOCS
        },
        dataType: "text",
        success: function (response) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            hideSpinner();
            displayMessage('messageLabel', response);
        },
    });
}