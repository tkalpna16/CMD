﻿var tablePlanningDates = null;
var totalPlanningDatesColumns = 1;

$(document).ready(function () {
    // Main Settings
    setTitle("Planning Dates"); // Set Title
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/Edit?code=' + project;
        window.location.href = url;
    });

    $("#btnCreateParameter").click(function () {
        $("#modalCreateParameter").modal('show');
    });

    // Init UI
    InitTablePlanningDates();

    $("#btnCreateParameter").click(function () {
        $("#modalCreateDates").modal('show');
    });
});

function InitTablePlanningDates() {

    tablePlanningDates = $('#tablePlanningDates').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 1], "searchable": true },
            {
                "targets": [0, 1], //first column / numbering column
                "orderable": false, //set not orderable
            }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        }
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i <= totalPlanningDatesColumns; i++) {
            var col1 = document.getElementById("checkBox" + i).checked;
            if (col1) {
                colId.push(i - 1);
            }
        }
        if (colId.length == 0) {
            for (let i = 0; i < totalPlanningDatesColumns; i++) {
                colId.push(i);
            }
        }
        if (colId.length > 0) {
            tablePlanningDates.column(colId).search(filter).draw();
        }
        else {
            tablePlanningDates.search('').draw();
        }
    });
}

function createNewParameter() {
    loadSpinnerModal();
    setProgressMessageModal("Creating new date..");

    var project = $('#labelProject').text();

    var name = $("#inputParameterName").val();
    if (name == '') {
        alert("Any unit!!");
        return;
    }

    var url = "/cmd/MAINITEMPLANNINGDATES/CreateDate";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'code': project,
            'datename': name
        },
        dataType: "text",
        success: function (response) {
            hideSpinnerModal();
            if (response == 'Parameter created') {
                var url='/cmd/MAINITEMPLANNINGDATES/Index?code=' + project;
                window.location.href = url;
            }
            else {
                $("#msgNewParameter").text(response);
            }
        },
        error: function (response, error) {
            hideSpinnerModal();
            $("#msgNewParameter").text(response.responseText);
        },
    });
}

function deleteCurrentPlanningDate(button) {
    var row = $(button).closest("tr");
    var id = row.find("span").html();
    var url = "/cmd/MAINITEMPLANNINGDATES/DeleteDates?id=" + id;
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            if (response == "Deleted") {
                if ($("#tablePlanningDates tr").length > 1) {
                    row.remove();
                    tablePlanningDates.row($(row)).remove().draw(false);
                } else {
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response);
            }
        },
        error: function (response, error) {
            if (response.responseText == "Deleted") {
                if ($("#tablePlanningDates tr").length > 1) {
                    row.remove();
                    tablePlanningDates.row($(row)).remove().draw(false);
                } else {;
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response.responseText);
            }
        },
    });
}