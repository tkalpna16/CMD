﻿$(document).ready(function () {

    // Set Title
    setTitle("New Project");
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    $("#sidebarCollapse").prop("disabled", true);

    // Edit Project
    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/Index';
        window.location.href = url;
    });
});