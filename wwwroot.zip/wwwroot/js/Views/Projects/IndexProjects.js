﻿$(document).ready(function () {
    // Activate navlink
    makeNavlinkActive("#btnLinkProjects");

    // Hide buttons at startup
    hideElement('#tableLinks');
    hideElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    var project = $('#labelProject').text();
    var projectDescription = $('#labelProjectDescription').text();

    if (project) {
        document.getElementById("PROJECTID").value = projectDescription;
        projectListActivateCommands();
        showElement('#labelNavProject');
        showElement('#labelNavProjectName');
        $("#sidebarCollapse").prop("disabled", false);
    }
    else {
        $("#sidebarCollapse").prop("disabled", true);
    }

    // Dashboard
    $('#PROJECTID').on('change', function () {
        projectListActivateCommands();

        var dropdownval = $("#PROJECTID").val();
        if (dropdownval) {
            dropdownval = dropdownval.split('-')[0];
            showElement('#labelNavProject');
            showElement('#labelNavProjectName');
            $('#labelNavProjectName').text(dropdownval);
            $('#labelProject').text(dropdownval);
            $("#sidebarCollapse").prop("disabled", false);
        }
        else {
            hideElement('#labelNavProject');
            hideElement('#labelNavProjectName');
            $('#labelNavProjectName').text('');
            $('#labelProject').text('');
            $("#sidebarCollapse").prop("disabled", true);
        }
    });

    // Open Project
    $("#btnCreateProject").click(function () {
        var url= '/cmd/PROJECTS/Create';
        window.location.href = url;
    });

    // Edit Project
    $("#btnEditProject").click(function () {
        loadSpinner();
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            hideSpinner();
            alert("Nothing selected!!");
            return;
        }
        var url= '/cmd/PROJECTS/Edit?code=' + dropdownval;
        window.location.href = url;
    });

    // Project Settings
    $("#btnProjectSettings").click(function () {
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            alert("Nothing selected!!");
            return;
        }
        var url= '/cmd/PROJECTSETTINGS/Edit?code=' + dropdownval;
        window.location.href = url;
    });

    // Edit Project
    $("#btnPrevious").click(function () {
        var url= '/cmd/HOME/Index';
        window.location.href = url;
    });

    // Users
    $("#btnEditProjectUsers").click(function () {
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            alert("Nothing selected!!");
            return;
        }
        var url= '/cmd/PROJECTUSERS/Index?code=' + dropdownval;
        window.location.href = url;
    });

    // Users
    $("#btnDeleteProject").click(function () {
        deleteCurrentProject();
    });

    // Data Management Button Event
    $("#card1").click(function () {
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            alert("Nothing selected!!");
            return;
        }
        var url= '/cmd/PROJECTS/DataManagement?code=' + dropdownval;
        window.location.href = url;
    });

    // Data Management Button Event
    $("#card2").click(function () {
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            alert("Nothing selected!!");
            return;
        }
        var url = '/cmd/VENDORS/MWPDATAREGISTER?code=' + dropdownval;
        window.location.href = url;
    });

    // Database View Button Event
    $("#card3").click(function () {
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            alert("Nothing selected!!");
            return;
        }
        var url= '/cmd/ViewManager/Index?code=' + dropdownval;
        window.location.href = url;
    });

    // Reports Button Event
    $("#card4").click(function () {
        var dropdownval = $("#PROJECTID").val();
        if (!dropdownval) {
            alert("Nothing selected!!");
            return;
        }
        var url= '/cmd/Reports/Index?code=' + dropdownval;
        window.location.href = url;
    });
});

function projectListActivateCommands() {
    var dropdownval = $("#PROJECTID").val();

    if (!dropdownval) {
        hideElement('#tableLinks');
        showElement('#groupNewProject');
        hideElement('#groupEditProject');
        hideElement('#groupDeleteProject');

        /// Disable cards
        $("#card1").addClass("noHover");
        $("#card1").addClass("hiddenCard");
        $("#card2").addClass("noHover");
        $("#card2").addClass("hiddenCard");
        $("#card3").addClass("noHover");
        $("#card3").addClass("hiddenCard");
        $("#card4").addClass("noHover");
        $("#card4").addClass("hiddenCard");
        $("#card5").addClass("noHover");
        $("#card5").addClass("hiddenCard");
    }
    else {
        showElement('#tableLinks');
        hideElement('#groupNewProject');
        showElement('#groupEditProject');
        showElement('#groupDeleteProject');

        /// Activate cards
        $("#card1").removeClass("noHover");
        $("#card1").removeClass("hiddenCard");
        $("#card2").removeClass("noHover");
        $("#card2").removeClass("hiddenCard");
        $("#card3").removeClass("noHover");
        $("#card3").removeClass("hiddenCard");
        $("#card4").removeClass("noHover");
        $("#card4").removeClass("hiddenCard");
        $("#card5").removeClass("noHover");
        $("#card5").removeClass("hiddenCard");
    }
}

function deleteCurrentProject() {

    var dropdownval = $("#PROJECTID").val();
    if (!dropdownval) {
        alert("Nothing selected!!");
        return;
    }

    var url = "/cmd/PROJECTS/Delete";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'code': dropdownval
        },
        dataType: "text",
        success: function (response) {
            if (response == "Deleted") {
                alert("Deleted");
                window.location = '/cmd/Projects/Index';
            }
            else {
                alert(response);
            }
        },
        error: function (response, error) {
            if (response == "Deleted") {
                alert("Deleted");
                window.location = '/cmd/Projects/Index';
            }
            else {
                alert(response);
            }
        },
    });
}