﻿$(document).ready(function () {
    // Main Settings
    setTitle("Engineering Data Management");
    hideElement("#navTopButton");
    hideElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    // Edit Project
    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/Index?code=' + project;
        window.location.href = url;
    });

    setDataManagementCardEvents();
});

function setDataManagementCardEvents() {
    // Set Button Events
    $("#card1").click(function () {
        openPBSCreator();
    });

    $("#card2").click(function () {
        openMainItemCreator();
    });

    $("#card3").click(function () {
        openDLGenerator();
    });

    $("#card4").click(function () {
        openModelConnector();
    });

    $("#card5").click(function () {
        openPlanningManager();
    });

    $("#card6").click(function () {
        openQuantityManager();
    });

    $("#card7").click(function () {
        openHoldManager();
    });

    $("#card8").click(function () {
        openPreAccountingSheet();
    });
}

function openPBSCreator() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/PBS/Index?code=' + projectId;
    window.location.href = url;
}

function openMainItemCreator() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/ItemListCreation/Index?code=' + projectId;
    window.location.href = url;
}

function openPlanningManager() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/PLANNINGS/Index?code=' + projectId;
    window.location.href = url;
}

function openHoldManager() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/HoldManager/Index?code=' + projectId;
    window.location.href = url;
}

function openModelConnector() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/MODELCONNECTOR/Index?code=' + projectId;
    window.location.href = url;
}

function openQuantityManager() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/QUANTITYMANAGER/Manager?code=' + projectId;
    window.location.href = url;
}

function openPreAccountingSheet() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/PriceEvaluator/Index?code=' + projectId;
    window.location.href = url;
}

function openDLGenerator() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    var url= '/cmd/DLGENERATOR/Index?code=' + projectId;
    window.location.href = url;
}