﻿function goToModule() {
    loadSpinner();
    var projectId = $('#labelProject').text();
    if (!projectId) {
        preventDefault();
    }
}

