﻿$(document).ready(function () {
    // Set Title
    setTitle("Edit Project");
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    // Edit Project
    $("#btnPrevious").click(function () {
        var project = $('#labelProjectNewCode').text();
        if (project == '') {
            project = $('#labelProject').text();
        }
        var url= '/cmd/PROJECTS/Index?code=' + project;
        window.location.href = url;
    });

    // Create Button Event
    $("#btnSaveProject").click(function () {
        
        $.ajax({
            type: 'POST',
            url: '/cmd/PROJECTS/Edit',
            data: $('form').serialize(),
            success: function (response) {
                $("#messageLabel").html(response);
            }
        });
    });
});