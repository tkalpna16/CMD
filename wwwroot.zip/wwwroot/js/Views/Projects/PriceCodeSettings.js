﻿$(document).ready(function () {
    // PBS Button Event
    $("#btnBackToProject").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + projectCode;
        window.location.href = url;
    });

    $("#btnEditObjectCodes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/OBJECTCODES/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });

    $("#btnEditCommodityCodes").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/COMMODITYCODES/Index?code=' + projectCode;
        setTimeout(function () {
            window.location.assign(url);
        }, 0);
    });
});