﻿var tableParameters = null;
var totalParametersColumns = 2;

$(document).ready(function () {

    // Set Title
    setTitle("Custom Attributes");
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    // Init UI
    InitTableParameters();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/Edit?code=' + project;
        window.location.href = url;
    });

    $("#btnCreateParametr").click(function () {
        $("#modalCreateParameter").modal('show');
    });
});

function InitTableParameters() {

    tableParameters = $('#tableParameters').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 1], "searchable": false },
            {
                "targets": [0, 1], //first column / numbering column
                "orderable": false, //set not orderable
            }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });
}

function updateTableMainItemParametersSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableParameters.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalParametersColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableParameters.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableParameters.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function createNewParameter() {
    loadSpinnerModal();
    setProgressMessageModal("Creating attributes..");

    var project = $('#labelProject').text();

    var name = $("#inputParameterName").val();
    if (name == '') {
        alert("Any name!!");
        return;
    }

    var category = $("#CATEGORYNAME").val();
    if (category == '') {
        alert("Any category!!");
        return;
    }

    var url = "/cmd/MAINITEMPARAMETERS/CreateAttribute";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'projectCode': project,
            'parameterName': name,
            'categoryName': category
        },
        dataType: "text",
        success: function (response) {
            hideSpinnerModal();
            if (response == 'Parameter created') {
                var url= '/cmd/MAINITEMPARAMETERS/Index?code=' + project;
                window.location.href = url;
            }
            else {
                $("#msgParameter").text(response);
            }
        },
        error: function (response, error) {
            hideSpinnerModal();
            $("#msgParameter").text(response.responseText);
        },
    });
}

function deleteCurrentParameters(button) {
    var row = $(button).closest("tr");
    var id = row.find("span").html();
    var url = "/cmd/MAINITEMPARAMETERS/DeleteParameter?id=" + id;
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            if (response == "Deleted") {
                if ($("#tableParameters tr").length > 1) {
                    row.remove();
                    tableParameters.row($(row)).remove().draw(false);
                } else {
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response);
            }
        },
        error: function (response, error) {
            if (response.responseText == "Deleted") {
                if ($("#tableParameters tr").length > 1) {
                    row.remove();
                    tableParameters.row($(row)).remove().draw(false);
                } else {
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response.responseText);
            }
        },
    });
}

function showModalRenameParameter(button) {
    var row = $(button).closest("tr");
    var rowIndex = row.index();
    var cell = tableParameters.cell({ row: rowIndex, column: 0 }).node();
    var oldname = cell.innerText;

    $('#inputOldName').val(oldname);
    $("#modalRenameObjectCode").modal('show');
}

function renameParameter() {
    var project = $('#labelProject').text();
    var oldName = $('#inputOldName').val();
    var newName = $('#inputNewName').val();

    if (newName == '' || oldName == newName) {
        alert("Invalid new name");
        return;
    }

    var url = "/cmd/MAINITEMPARAMETERS/Rename";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'projectCode': project,
            'oldname': oldName,
            'newname': newName
        },
        dataType: "text",
        success: function (response) {
            alert(response);
            window.location = '/cmd/MAINITEMPARAMETERS/Index?code=' + project;
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}