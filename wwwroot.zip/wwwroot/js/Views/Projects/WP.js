﻿var tableWP = null;
var totalWPColumns = 2;

$(document).ready(function () {

    // Set title
    setTitle("WP Settings");
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    // Init UI
    InitTableWPList();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/Edit?code=' + project;
        window.location.href = url;
    });
});

function InitTableWPList() {
    /* Create an array with the values of all the input boxes in a column */
    $.fn.dataTable.ext.order['dom-text'] = function (settings, col) {
        return this.api().column(col, { order: 'index' }).nodes().map(function (td, i) {
            return $('input', td).val();
        });
    }

    tableWP = $('#tableWP').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 2], "searchable": true },
            { "targets": 2, "orderDataType": "dom-text", type: 'string' },
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableWPSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableWP.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableWP.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableWP.draw();

        colorDatatableAllRow(tableWP);
    });

    hideEventsColumnsWP();
}

function updateTableWPSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableWP.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalWPColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableWP.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableWP.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

//Delete Item event handler.
$("body").on("click", "#tableWP .Delete", function () {
    if (confirm("Do you want to delete this WP?")) {
        var row = $(this).closest("tr");
        var wpId = row.find("span").html();
        var url = "/cmd/WORKINGPACKAGES/DeleteWP?id=" + wpId;
        $.ajax({
            type: "POST",
            url: url,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response == 'Deleted') {
                    if ($("#tableWP tr").length > 1) {
                        row.remove();
                        tableWP.row($(row)).remove().draw(false);
                    } else {
                        row.find(".Edit").hide();
                        row.find(".Delete").hide();
                        row.find("span").html('&nbsp;');
                    }
                }
                else {
                    displayMessage(response);
                }
            },
            error: function (response, error) {
                if (response.responseText == 'Deleted') {
                    if ($("#tableWP tr").length > 1) {
                        row.remove();
                        tableWP.row($(row)).remove().draw(false);
                    } else {
                        row.find(".Edit").hide();
                        row.find(".Delete").hide();
                        row.find("span").html('&nbsp;');
                    }
                }
                else {
                    displayMessage(response.responseText);
                }
            },
        });
    }
});

function showModalCreateWP() {
    $("#modalCreateWP").modal('show');
}

function hideEventsColumnsWP() {
    for (let i = 1; i <= totalWPColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableWP.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableWP);
        })
    }
}

function createNewWP() {
    var project = $('#labelProject').text();

    var name = $("#inputName").val();
    if (name == '') {
        alert("Any Name!!");
        return;
    }

    var description = $("#inputDescription").val();

    var url = "/cmd/WORKINGPACKAGES/CreateNewWP";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'code': project,
            'wpname': name,
            'wpdescription': description
        },
        dataType: "text",
        success: function (response) {
            if (response == 'Saved') {
                alert("WP created");
                var url= '/cmd/WORKINGPACKAGES/Index?code=' + project;
                window.location.href = url;
            }
            else {
                $("#msgNewWP").text(response);
            }
        },
        error: function (response, error) {
            $("#msgNewWP").text(response.responseText);
        },
    });
}

function wpApplyTextValues() {
    // Get selected columns
    var colIds = [];
    for (let i = 2; i <= 2; i++) {
        var col1 = document.getElementById("checkBoxVal" + i).checked;
        if (col1) {
            colIds.push(i);
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableWP.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateWPTableValues(colIdx, rowIdx));
        });
        tableWP.draw();
    }
}

function updateWPTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableWP.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        cell = tableWP.cell({ row: rowIdx, column: colIdx }).node();
        $('input', cell).val(valueToApply);
    }
}

function wpSaveTextValues() {
    var project = $('#labelProject').text();

    var wpsid = [];
    var descriptions = [];

    tableWP.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellvalue = tableWP.cell({ row: rowIdx, column: 0 }).node();
        value = $('span', cellvalue).text();
        wpsid.push(value);

        cellvalue = tableWP.cell({ row: rowIdx, column: 2 }).node();
        value = $('input', cellvalue).val();
        descriptions.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/WORKINGPACKAGES/UpdateValues',
        data: {
            'code': project,
            'wpidstr': JSON.stringify(wpsid),
            'descriptionsstr': JSON.stringify(descriptions)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabel', response);
        },
        error: function (response, error) {
            displayMessage('messageLabel', response);
        },
    });
}

function deleteCurrentWP(button) {
    var row = $(button).closest("tr");
    var pbsId = row.find("span").html();
    var url = "/cmd/WORKINGPACKAGES/DeleteWP?id=" + pbsId;
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            if (response == 'Deleted') {
                if ($("#tableWP tr").length > 1) {
                    row.remove();
                    tableWP.row($(row)).remove().draw(false);
                    UpdateWPVisibility();
                } else {
                    row.find(".Edit").hide();
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response);
            }
        },
        error: function (response, error) {
            if (response.responseText == 'Deleted') {
                if ($("#tableWP tr").length > 1) {
                    row.remove();
                    tableWP.row($(row)).remove().draw(false);
                    UpdateWPVisibility();
                } else {
                    row.find(".Delete").hide();
                    row.find("span").html('&nbsp;');
                }
            }
            else {
                displayMessage(response.responseText);
            }
        },
    });
}
