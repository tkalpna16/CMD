﻿var tableObjectCodes = null;
var totalObjectCodeColumns = 7;

$(document).ready(function () {

    // Main Settings
    setTitle("Object Codes"); // Set Title
    hideElement("#btnDownloadExcel");
    hideElement("#btnImportExcel");

    InitTableObjectCodes();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $("#btnPrevious").click(function () {
        var projectCode = $('#labelProject').text();
        var url= '/cmd/PROJECTSETTINGS/Edit?code=' + projectCode;
        window.location.href = url;
    });

    $('#rowTable').show();
    tableObjectCodes.columns.adjust();

    //Delete Item event handler.
    $("#tableObjectCodes").on("click", ".Delete", function () {
        if (confirm("Do you want to delete this Object Code?")) {
            var row = $(this).closest("tr");
            var pbsId = row.find("span").html();
            var url = "/cmd/OBJECTCODES/DeleteObjectCode?id=" + pbsId;
            $.ajax({
                type: "POST",
                url: url,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response == STATUS_PBS_DELETED) {
                        if ($("#tableObjectCodes tr").length > 1) {
                            row.remove();
                            tableObjectCodes.row($(row)).remove().draw(false);
                        } else {
                            row.find(".Edit").hide();
                            row.find(".Delete").hide();
                            row.find("span").html('&nbsp;');
                        }
                    }
                    else {
                        displayMessage(response);
                    }
                },
                error: function (response, error) {
                    if (response.responseText == STATUS_PBS_DELETED) {
                        if ($("#tableObjectCodes tr").length > 1) {
                            row.remove();
                            tableObjectCodes.row($(row)).remove().draw(false);
                        } else {
                            row.find(".Edit").hide();
                            row.find(".Delete").hide();
                            row.find("span").html('&nbsp;');
                        }
                    }
                    else {
                        displayMessage(response.responseText);
                    }
                },
            });
        }
    });
});



function InitTableObjectCodes() {
    tableObjectCodes = $('#tableObjectCodes').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { width: 60, targets: 0 },
            { width: 60, targets: 1 }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        }
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableObjectCodesSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableObjectCodes.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableObjectCodes.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableObjectCodes.draw();

        colorDatatableAllRow(tableObjectCodes);
    });
}

function updateTableObjectCodesSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableObjectCodes.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalObjectCodeColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableObjectCodes.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableObjectCodes.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function showModalCreateObjectCodes() {
    $("#modalCreateNewObjectCodes").modal('show');
}

function createNewObjectCode() {
    var project = $('#labelProject').text();

    var code = $("#inputCode").val();
    if (code == '') {
        alert("Any code!!");
        return;
    }

    var description = $("#inputDescription").val();
    if (description == '') {
        alert("Any description!!");
        return;
    }

    var disciplineCode = $("#inputDisciplineCode").val();
    if (disciplineCode == '') {
        alert("Any discipline code!!");
        return;
    }

    var subDisciplineCode = $("#inputSubDisciplineCode").val();
    if (subDisciplineCode == '') {
        alert("Any sub-discipline code!!");
        return;
    }

    var disciplineName = $("#inputDisciplineName").val();
    if (disciplineName == '') {
        alert("Any discipline code!!");
        return;
    }

    var subDisciplineName = $("#inputSubDisciplineName").val();
    if (subDisciplineName == '') {
        alert("Any sub-discipline name!!");
        return;
    }

    var behaviour = $("#inputBehviourNewCode").val();

    loadSpinnerModal();
    setProgressMessageModal("Creating Object Code..");

    var url = "/cmd/OBJECTCODES/CreateObjectCode";
    $.ajax({
        type: "POST",
        url: url,
        data: {
            'projectstr': project,
            'code': code,
            'description': description,
            'disciplineCode': disciplineCode,
            'subDisciplineCode': subDisciplineCode,
            'disciplineName': disciplineName,
            'subDisciplineName': subDisciplineName,
            'behaviour': behaviour,
        },
        dataType: "text",
        success: function (response) {
            hideSpinnerModal();
            if (response == 'Object Code created') {
                var url= '/cmd/OBJECTCODES/Index?code=' + project;
                window.location.href = url;
            }
            else {
                $("#msgNewObjectCode").text(response);
            }
        },
        error: function (response, error) {
            hideSpinnerModal();
            $("#msgNewObjectCode").text(response.responseText);
        },
    });
}

function objectCodeApplyTextValues() {
    // Get selected columns
    var colIds = [];
    for (let i = 1; i <= totalObjectCodeColumns; i++) {
        if (i > 1) {
            var col1 = document.getElementById("checkBoxVal" + i).checked;
            if (col1) {
                colIds.push(i);
            }
        }
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableObjectCodes.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateObjectCodeTableValues(colIdx, rowIdx));
        });
    }
}

function updateObjectCodeTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableObjectCodes.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        if (colIdx == 7) {
            cell = tableObjectCodes.cell({ row: rowIdx, column: colIdx }).node();
            $('select', cell).val(valueToApply);
        }
        else {
            cell = tableObjectCodes.cell({ row: rowIdx, column: colIdx }).node();
            $('input', cell).val(valueToApply);
        }
    }
}

function objectCodeSaveTextValues() {
    loadSpinner();
    setProgressMessage("Saving Object Codes..");

    var project = $('#labelProject').text();

    var codeid = [];
    var descriptions = [];
    var disccodes = [];
    var subdisccodes = [];
    var discnames = [];
    var subdiscnames = [];
    var behaviours = [];


    tableObjectCodes.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 0 }).node();
        value = $('span', cellvalue).text();
        codeid.push(value);

        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 2 }).node();
        value = $('input', cellvalue).val();
        descriptions.push(value);

        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellvalue).val();
        disccodes.push(value);

        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellvalue).val();
        subdisccodes.push(value);

        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellvalue).val();
        discnames.push(value);

        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', cellvalue).val();
        subdiscnames.push(value);

        cellvalue = tableObjectCodes.cell({ row: rowIdx, column: 7 }).node();
        value = $('select', cellvalue).val();
        behaviours.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/OBJECTCODES/UpdateValues',
        data: {
            'code': project,
            'codeidstr': JSON.stringify(codeid),
            'descriptionstr': JSON.stringify(descriptions),
            'disccodestr': JSON.stringify(disccodes),
            'subdisccodestr': JSON.stringify(subdisccodes),
            'discnamestr': JSON.stringify(discnames),
            'subdiscnamestr': JSON.stringify(subdiscnames),
            'behavioursstr': JSON.stringify(behaviours)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
            hideSpinner();
        },
        error: function (response, error) {
            alert(response.responseText);
            hideSpinner();
        },
    });
}

function deleteObjectCodeItems() {
    var project = $('#labelProject').text();
    var selectedItems = [];
    var cell = null;

    tableObjectCodes.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = tableObjectCodes.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            cell = tableObjectCodes.cell({ row: rowIdx, column: 0 }).node();
            var id = $('span', cell).text();
            selectedItems.push(id);
        }
    });

    if (selectedItems.length == 0) {
        alert("Any item selected!!");
        return;
    }

    if (confirm("Do you want to delete selected Object Codes?")) {
        var url = "/cmd/OBJECTCODES/DeleteMultipleObjectCodes";
        var data = JSON.stringify(selectedItems);
        $.ajax({
            type: "POST",
            url: url,
            data: {
                'idStr': data
            },
            dataType: "text",
            success: function (response) {
                var data = JSON.parse(response);
                showExcelLogsAlertNoColumn(data);
                window.location = '/cmd/OBJECTCODES/Index?code=' + project;
            },
            error: function (response, error) {
                alert(response.responseText);
            },
        });
    }
}