﻿var tableItemsView = null;
var totalParamterItemView = 8;

$(document).ready(function () {
    // Main Settings
    setTitle("3D Model List"); // Set Title
    hideElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        createExcel3DModelView();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTable3DModelView();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

});

function InitTable3DModelView() {

    tableItemsView = $('#tableItems').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        }
    });

    // Set table search
    $('#tableSearchItems').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i <= totalParamterItemView; i++) {
            var col1 = document.getElementById("checkBox" + i + "_1").checked;
            if (col1) {
                colId.push(i - 1);
            }
        }

        if (colId.length == 0) {
            tableItemsView.search(filter).draw();
        }
        else {
            tableItemsView.column(colId).search(filter).draw();
        }
    });

    for (let i = 1; i <= totalParamterItemView; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_1");
        checkbox.addEventListener('change', (event) => {
            tableItemsView.column(i - 1).visible(event.currentTarget.checked);
        })
    }

    hideEventsColumnsModelView();
}

function hideEventsColumnsModelView() {
    for (let i = 1; i <= totalParamterItemView; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_1");
        checkbox.addEventListener('change', (event) => {
            tableItemsView.column(i - 1).visible(event.currentTarget.checked);
        })
    }
}

function createExcel3DModelView() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/MODELCONNECTOR/CreateExcelView';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/ModelList.xlsx";
            link.download = project + "-ModelList-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}
