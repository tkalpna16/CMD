﻿// ------------------------------- //
// Class for storing jsTree nodes
// ------------------------------- //
class jsTreeNode {

    constructor(id, parent, text) {
        this.id = id;
        this.parent = parent;
        this.text = text;
        this.type = "root";
    }
}
// Storing data for bim360 tree
var bim360TreeData = [];

// Selected folders
var bim360SelectedFolders = [];
var folderNamesToSave = [];

// ------------------------------- //
// Startup
// ------------------------------- //
$(document).ready(function () {
    // Read bim360 folders
    readBIM360Folders();
});


// ------------------------------- //
// JsTree
// ------------------------------- //
function initBim360Tree() {

    // Clean Directory
    var filteredTree = [];
    var ids = [];
    if (bim360TreeData) {
        for (let i = 0; i < bim360TreeData.length; i++) {
            var node = bim360TreeData[i];
            if (node.parent == "#") {
                if (node.text.includes("AA") || node.text.includes("AI") || node.text.includes("AQ") || node.text.includes("AP")) {
                    filteredTree.push(node);
                    ids.push(node.id);
                }
            }
            else {
                if (ids.includes(node.parent)) {
                    filteredTree.push(node);
                    ids.push(node.id);
                }
            }
        }
    }


    $('#bim360Tree').jstree({
        'core': {
            'data': filteredTree
        },
        types: {
            "root": {
                "icon": "fa fa-folder-open-o"
            },
            "child": {
                "icon": "fa fa-folder-open-o"
            },
            "default": {
            }
        },
        plugins: ["search", "themes", "types", "checkbox"]
    });
}

function getSelectedBim360Folders() {
    bim360SelectedFolders = [];
    folderNamesToSave = [];
    var selectedNodes = $('#bim360Tree').jstree("get_selected", true);
    $.each(selectedNodes, function () {
        bim360SelectedFolders.push(this.id);
        folderNamesToSave.push(this.text);
    });
}

function resetBim360Values() {
    // BIM360
    hub = null;
    project = null;
    rootFolder = null;
    firstFolder = null;
    wpFolder = null;
}

// ------------------------------- //
// Read BIM360 Items
// ------------------------------- //
function readBIM360Folders() {
    // Reset values
    start();
    index = 0;

    loadSpinner();
    setTimeout(function () {
        try {
            getSettingsForBIM360(getFolderToken);
        } catch (err) {
            console.log(err);
        }
    }, 100);
}

// ------------------------------- //
// Get settings of folders
// ------------------------------- //
function getSettingsForBIM360() {
    $.ajax({
        type: 'GET',
        url: '/cmd/MODELCONNECTOR/GetAccessSettings',
        dataType: 'json',
        success: function (response) {
            if (response) {
                // Init variable
                forgeClientId = response["forgeClientId"];
                forgeSecret = response["forgeSecret"];
                hubName = response["hubName"];
                rootFolderName = response["rootFolderName"];
                firstFolderName = response["firstLevelFolderName"];
                secondFolderName = response["secondLevelFolderName"];

                projectCode = $('#labelProject').text();
                projectCodeID = $('#labelProjectID').text();

                setProgressMessage("Authorize access..");

                // Start reading hubs
                getFolderToken();
            }
        },
        error: function (response, error) {
            displayMessage('labelProgressMessage', response.responseText);
        },
    });
}

// ------------------------------- //
// Get Access token
// ------------------------------- //
function getFolderToken() {
    $.ajax({
        method: 'POST',
        url: 'https://developer.api.autodesk.com/authentication/v1/authenticate',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        data: 'client_id=' + forgeClientId + '&client_secret=' + forgeSecret + '&grant_type=client_credentials&scope=data:write data:read bucket:create bucket:delete',
        success: function (response) {
            access_token = response.access_token;
            if (typeof access_token !== 'undefined') {
                setProgressMessage("Access obtained..");
                getFolderHub();
            } else {
                setProgressMessage("Access denied!!");
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Hub
// ------------------------------- //
function getFolderHub() {
        $.ajax({
            method: 'GET',
            url: 'https://developer.api.autodesk.com/project/v1/hubs',
            headers: {
                Authorization: "Bearer " + access_token
            },
            success: function (response) {
                hubs = response;
                var found = false;
                if ((typeof hubs !== 'undefined') && (typeof hubs.data !== 'undefined')) {
                    setProgressMessage('Reading hubs list..');
                    var data = hubs.data;
                    // Read all hubs
                    data.forEach(function (entry) {
                        var name = entry.attributes.name;
                        if (name == hubName) {
                            hub = entry;
                            found = true;
                        }
                    });
                    if (found) {
                        setProgressMessage('Hub found');
                        getBim360Project();
                    } else {
                        setProgressMessage('Hub not found!!');
                    }
                }
            },
            error: function (error) {
                console.log(error);
            }
        })
}

// ------------------------------- //
// Get BIM360 Projects
// ------------------------------- //
function getBim360Project() {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/project/v1/hubs/' + hub.id + '/projects',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            projects = response;
            var found = false;
            if ((typeof projects !== 'undefined') && (typeof projects.data !== 'undefined')) {
                setProgressMessage('Reading projects list..');
                var data = projects.data;
                // Read main folders
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    if (name == projectCode) {
                        project = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage('Project found');
                    getRootFolder(project);
                    
                } else {
                    setProgressMessage('Project not found!!');
                    alert("Project not found!!");
                    hideSpinner();
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Root Folder
// ------------------------------- //
function getRootFolder() {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/project/v1/hubs/' + hub.id + '/projects/' + project.id + '/topFolders',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            topfolders = response;
            var found = false;
            if ((typeof topfolders !== 'undefined') && (typeof topfolders.data !== 'undefined')) {
                setProgressMessage('Reading first level folders..');
                var data = topfolders.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (name == rootFolderName && type == "folders") {
                        rootFolder = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage('Root folder found');
                    getWPFolder(rootFolder);
                } else {
                    setProgressMessage('Root folder not found!!');
                    hideSpinner();
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 WIP Folder
// ------------------------------- //
function getWPFolder() {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/folders/' + rootFolder.id + '/contents',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            folders = response;
            var found = false;
            if ((typeof folders !== 'undefined') && (typeof folders.data !== 'undefined')) {
                setProgressMessage('Reading folders..');
                var data = folders.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (name == secondFolderName && type == "folders") {
                        wpFolder = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage(secondFolderName + ' folder found');
                    getTreeFolders(wpFolder);
                } else {
                    setProgressMessage(secondFolderName + ' folder not found!!');
                    hideSpinner();
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get All Folder Structure
// ------------------------------- //
var alreadyProcessed = [];
var folderToProcess = [];
var counter = 1; // Starting from WIP
var index = 0;

async function getTreeFolders(parentFolder) {
    var url = "https://developer.api.autodesk.com/data/v1/projects/" + project.id + "/folders/" + parentFolder.id + "/contents";
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            Authorization: "Bearer " + access_token
        }
    });
    // waits until the request completes...
    const folders = await response.json();
    alreadyProcessed.push(parentFolder.attributes.name);
    console.log(folders);

    if ((typeof folders !== 'undefined') && (typeof folders.data !== 'undefined')) {
        setProgressMessage('Reading folders..');
        var data = folders.data;
        // Read all folders
        data.forEach(function (entry) {
            var name = entry.attributes.name;
            var type = entry.type;
            if (type == "folders") {
                //if (name.startsWith("A")){
                    counter++;
                    folderToProcess.push[name];
                    if (parentFolder.id == wpFolder.id) {
                        let newNode = new jsTreeNode(entry.id, "#", name);
                        bim360TreeData.push(newNode);
                    }
                    else {
                        let newNode = new jsTreeNode(entry.id, parentFolder.id, name);
                        bim360TreeData.push(newNode);
                    }
                    getTreeFolders(entry);
                //}
            }
        });
    }
    index++;
    if (counter == index) {
        hideSpinner();
        initBim360Tree();
    }
}

