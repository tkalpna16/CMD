﻿// Settings
var projectCode = null;
var projectID = null;

// Forge Connection
var forgeClientId = null;
var forgeSecret = null;
var access_token = null;

// BIM360
var hub = null;
var project = null;
var rootFolder = null;
var civilFolder = null;
var wpFolder = null;
var bim360files = [];
var bim360filesLastVersion = [];

// Filters
var hubName = null;
var rootFolderName = null;
var civilFolderName = null;
var wpFolderName = null;

// Server data
var bim360FilesServer = [];
var forgeModelsServer = [];

// ------------------------------- //
// Classes
// ------------------------------- //
class BIM360FILES {
    FILESID;
    PROJECTID;
    FILENAME;
    FILEVERSION;

    BIM360FILES() {
    }
}

class Property {
    CategoryName;
    Name;
    Value;

    Property() {
    }
}

class ForgeItem {
    ModelName;
    Objectid;
    Name;
    Properties;

    ForgeItem() {
    }
}

class ForgeModel {
    modelName;
    lastVersion;
    items;

    ForgeModel() {
    }
}

// ------------------------------- //
// Read BIM360 Items
// ------------------------------- //
function readBIM360Items() {
    // Reset values
    start();
    index = 0;
    metadata = [];
    bim360files = [];
    bim360filesLastVersion = [];
    bim360FilesServer = [];
    forgeModelsServer = [];

    loadSpinner();
    setTimeout(function () {
        try {
            getSettings(getToken);
        } catch (err) {
            console.log(err);
        }
    }, 100);
}

// ------------------------------- //
// Get settings
// ------------------------------- //
function getSettings(callbackGetToken) {
    $.ajax({
        type: 'GET',
        url: '/MODELCONNECTOR/GetAccessSettings',
        dataType: 'json',
        success: function (response) {
            if (response) {
                // Init variable
                forgeClientId = response["forgeClientId"];
                forgeSecret = response["forgeSecret"];
                hubName = response["hubName"];
                rootFolderName = response["rootFolderName"];
                civilFolderName = response["civilFolderName"];
                wpFolderName = response["wpFolderName"];

                projectCode = $('#labelProject').text();
                projectCodeID = $('#labelProjectID').text();

                setProgressMessage("Authorize access..");

                // Start reading hubs
                callbackGetToken(getHub);
            }
        },
        error: function (response, error) {
            displayMessage('labelProgressMessage', response.responseText);
        },
    });
}

// ------------------------------- //
// Get Access token
// ------------------------------- //
function getToken(callbackHub) {
    $.ajax({
        method: 'POST',
        url: 'https://developer.api.autodesk.com/authentication/v1/authenticate',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        data: 'client_id=' + forgeClientId + '&client_secret=' + forgeSecret + '&grant_type=client_credentials&scope=data:write data:read bucket:create bucket:delete',
        success: function (response) {
            access_token = response.access_token;
            if (typeof access_token !== 'undefined') {
                setProgressMessage("Access obtained..");
                callbackHub(getProject);
            } else {
                setProgressMessage("Access denied!!");
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Hub
// ------------------------------- //
function getHub(callbackProject) {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/project/v1/hubs',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            hubs = response;
            var found = false;
            if ((typeof hubs !== 'undefined') && (typeof hubs.data !== 'undefined')) {
                setProgressMessage('Reading hubs list..');
                var data = hubs.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    if (name == hubName) {
                        hub = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage('Hub found');
                    callbackProject(getTopFolder);
                } else {
                    setProgressMessage('Hub not found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Projects
// ------------------------------- //
function getProject(callbackTopFolder) {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/project/v1/hubs/' + hub.id + '/projects',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            projects = response;
            var found = false;
            if ((typeof projects !== 'undefined') && (typeof projects.data !== 'undefined')) {
                setProgressMessage('Reading projects list..');
                var data = projects.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    if (name == projectCode) {
                        project = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage('Project found');
                    callbackTopFolder(getTopFolder);
                } else {
                    setProgressMessage('Project not found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Root Folder
// ------------------------------- //

function getTopFolder(callbackMainLevelFolder) {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/project/v1/hubs/' + hub.id + '/projects/' + project.id + '/topFolders',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            topfolders = response;
            var found = false;
            if ((typeof topfolders !== 'undefined') && (typeof topfolders.data !== 'undefined')) {
                setProgressMessage('Reading first level folders..');
                var data = topfolders.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (name == rootFolderName && type == "folders") {
                        rootFolder = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage('Root folder found');
                    callbackMainLevelFolder(getMainLevelFolder);
                } else {
                    setProgressMessage('Root folder not found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Civil Folder
// ------------------------------- //
function getMainLevelFolder(callbackWPFolder) {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/folders/' + rootFolder.id + '/contents',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            folders = response;
            var found = false;
            if ((typeof folders !== 'undefined') && (typeof folders.data !== 'undefined')) {
                setProgressMessage('Reading folders..');
                var data = folders.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (name == civilFolderName && type == "folders") {
                        civilFolder = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage(civilFolderName + ' folder found');
                    callbackWPFolder(getWPFolder);
                } else {
                    setProgressMessage(civilFolderName + ' folder not found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 WP Folder
// ------------------------------- //
function getWPFolder(callbackBIM360Files) {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/folders/' + civilFolder.id + '/contents',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            folders = response;
            var found = false;
            if ((typeof folders !== 'undefined') && (typeof folders.data !== 'undefined')) {
                setProgressMessage('Reading folders..');
                var data = folders.data;
                // Read all hubs
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (name == wpFolderName && type == "folders") {
                        wpFolder = entry;
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage(wpFolderName + ' folder found');
                    callbackBIM360Files(getBIM360Files);
                } else {
                    setProgressMessage(wpFolderName + 'folder not found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Files
// ------------------------------- //
function getBIM360Files(callbackBIM360FilesVersion) {

    // Reset BIM360 file list
    bim360files = []

    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/folders/' + wpFolder.id + '/contents',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            files = response;
            var found = false;
            if ((typeof files !== 'undefined') && (typeof files.data !== 'undefined')) {
                setProgressMessage('Reading files list..');
                var data = files.data;
                // Read all files
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (type != "folders") {
                        bim360files.push(entry);
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessage(bim360files.length.toString() + ' files found');
                    callbackBIM360FilesVersion(getBIM360FilesLastVersion);
                } else {
                    setProgressMessage('Any files found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Version
// ------------------------------- //
function getBIM360FilesLastVersion(callbackBIM360FilesLastVersion) {

    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/items/' + bim360files[index].id + '/versions',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            versions = response;
            var found = false;
            if ((typeof versions !== 'undefined') && (typeof versions.data[0] !== 'undefined')) {
                setProgressMessage('Reading file ' + versions.data[0].attributes.name + ' versions');
                var data = versions.data[0];
                bim360filesLastVersion.push(versions.data[0]); // First element is last version
                var currentFile = new BIM360FILES();
                currentFile.FILESID = -1;
                currentFile.FILENAME = versions.data[0].attributes['name'];
                currentFile.FILEVERSION = versions.data[0].attributes['versionNumber'];
                currentFile.PROJECTID = projectCodeID;
                bim360FilesServer.push(currentFile);
            }
            index++;
            if (index < bim360files.length) {
                setTimeout(function () {
                    callbackBIM360FilesLastVersion(getBIM360FilesLastVersion);
                }, 1000);
            } else {
                index = 0;
                ForgeXLS.prepareTables(function () {
                    console.log("test");
                })
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Encode urn to base64
// ------------------------------- //
function base64Encode(urn) {
    var encoded = btoa(urn);
    encoded = encoded.replace("/", "_");
    return encoded;
}

// ------------------------------- //
// Storage
// ------------------------------- //
var index = 0;
var metadata = [];
var forgeModel = null;


// ------------------------------- //
// Forge Metadata Class
// ------------------------------- //
var ForgeXLS = {
    Utility: {
        Constants: {
            BASE_URL: 'https://developer.api.autodesk.com',
            MODEL_DERIVATIVE_V2: '/modelderivative/v2/designdata/'
        },

        forgeGetRequest: function (url, token, callback) {
            jQuery.ajax({
                url: url,
                beforeSend: function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + token);
                },
                success: function (response) {
                    if (response.result && response.result === 'success') {
                        setTimeout(function () {
                            console.log('Data not ready... retry in 1 second');
                            ForgeXLS.Utility.forgeGetRequest(url, token, callback);
                        }, 1000);
                        return;
                    }
                    if (callback)
                        callback(response);
                }
            });
        },
        getMetadata: function (urn, token, callback) {
            console.log('Downloading metadata...');
            this.forgeGetRequest(this.Constants.BASE_URL + this.Constants.MODEL_DERIVATIVE_V2 + urn + '/metadata', token, callback);
        },

        getHierarchy: function (urn, guid, token, callback) {
            console.log('Downloading hierarchy...');
            this.forgeGetRequest(this.Constants.BASE_URL + this.Constants.MODEL_DERIVATIVE_V2 + urn + '/metadata/' + guid, token, callback);
        },

        getProperties: function (urn, guid, token, callback) {
            console.log('Downloading properties...');
            this.forgeGetRequest(this.Constants.BASE_URL + this.Constants.MODEL_DERIVATIVE_V2 + urn + '/metadata/' + guid + '/properties', token, callback);
        }
    },


    prepareTables: function (callback) {
        if (index >= bim360filesLastVersion.length) {
            return;
        }
        var urn = base64Encode(bim360filesLastVersion[index].id);
        var token = access_token;


        this.Utility.getMetadata(urn, token, function (metadata) {
            if (metadata.data.metadata.length == 0) {
                alert('Unexpected metadata');
                return;
            }
            var guid = metadata.data.metadata[0].guid;

            ForgeXLS.Utility.getHierarchy(urn, guid, token, function (hierarchy) {
                ForgeXLS.Utility.getProperties(urn, guid, token, function (properties) {
                    ForgeXLS.prepareRawData(hierarchy, properties);
                });
            });
        });
    },

    prepareRawData: function (hierarchy, properties) {
        var tables = {};

        // Init current models
        forgeModel = new ForgeModel();
        forgeModel.modelName = bim360FilesServer[index].FILENAME;
        forgeModel.lastVersion = bim360FilesServer[index].FILEVERSION;
        forgeModel.items = [];

        var filename = bim360filesLastVersion[index].attributes.name;
        var currentProgress = (index + 1).toString() + '/' + bim360filesLastVersion.length.toString();
        setProgressMessage('Processing file ' + filename + ' ' + currentProgress);

        hierarchy.data.objects[0].objects.forEach(function (category) {
            var idsOnCategory = [];
            ForgeXLS.getAllElementsOnCategory(idsOnCategory, category.objects);

            var rows = [];
            idsOnCategory.forEach(function (objectid) {
                var columns = ForgeXLS.getProperties(objectid, properties);
                rows.push(columns);
            });
            tables[category.name] = rows;
        });
        index++;

        forgeModelsServer.push(forgeModel);
        metadata.push(tables);

        if (index < bim360filesLastVersion.length) {
            setTimeout(function () {
                ForgeXLS.prepareTables(function () {
                    console.log("Reading..");
                });
            }, 1000);
        }
        else {
            setProgressMessage('Saving element to database..');
            setTimeout(function () {
                sendDataToDatabase();
            }, 1000)
        }
    },

    getAllElementsOnCategory: function (ids, category) {
        category.forEach(function (item) {
            if (typeof (item.objects) === 'undefined') {
                if (!ids.indexOf(item.objectid) >= 0)
                    ids.push(item.objectid);
            } else
                ForgeXLS.getAllElementsOnCategory(ids, item.objects);
        });
    },

    getProperties: function (id, objCollection) {
        var data = {};

        objCollection.data.collection.forEach(function (obj) {
            if (obj.objectid != id) return;

            var forgeItem = new ForgeItem();
            forgeItem.Properties = [];
            forgeItem.ModelName = bim360FilesServer[index].FILENAME;
            forgeItem.Objectid = obj.objectid;
            forgeItem.Name = obj.name.replace('[' + data['Revit ID'] + ']', '').trim();

            currentProperty = new Property();
            currentProperty.CategoryName = '';
            currentProperty.Name = 'name';
            currentProperty.Value = obj.name;
            forgeItem.Properties.push(currentProperty);

            data['Viewer ID'] = id;
            data['Revit ID'] = obj.name.match(/\d+/g)[0];
            data['Name'] = obj.name.replace('[' + data['Revit ID'] + ']', '').trim();

            var currentProperty = null;

            for (var propGroup in obj.properties) {
                if (propGroup.indexOf('__') > -1) break;
                if (obj.properties.hasOwnProperty(propGroup)) {
                    for (var propName in obj.properties[propGroup]) {
                        if (obj.properties[propGroup].hasOwnProperty(propName) && !Array.isArray(obj.properties[propGroup][propName])) { }
                        data[propGroup + ':' + propName] = obj.properties[propGroup][propName];
                        currentProperty = new Property();
                        currentProperty.CategoryName = propGroup;
                        currentProperty.Name = propName;
                        currentProperty.Value = obj.properties[propGroup][propName];
                        forgeItem.Properties.push(currentProperty);
                    }
                }
            }
            forgeModel.items.push(forgeItem);
        });

        return data;
    }
};

function sendDataToDatabase() {
    $.ajax({
        type: 'POST',
        url: '/api/forge/saveitems',
        data: {
            'code': projectCode,
            'filesstr': JSON.stringify(bim360FilesServer),
            'itemsStr': JSON.stringify(forgeModelsServer),
            'itemsTagStr': ''
        },
        dataType: 'json',
        encoded: 'gzip',
        success: function (data) {
            setProgressMessage('Completed!!');
            setTimeout(function () {
                hideSpinner();
                drawTableItems(data);
                drawTableLogs(data);
                EnableDisableTable();
                $('#tableItems').DataTable().draw();
                $('#tableLogs').DataTable().draw();
                end();
                document.getElementById('timeElapsed').innerHTML = timeElapsed;
            }, 3000);
        },
        error: function (response, error) {
            setProgressMessage(response.responseText);
            setTimeout(function () {
                hideSpinner();
                hideSpinner();
                alert('error ' + response.responseText);
                end();
            }, 3000);
        },
    });
}

