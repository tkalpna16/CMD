﻿$(document).ready(function () {

    InitTableMainItems();
    InitTableLogs();
    EnableDisableTable();
    initFolderTree();

    $("#tabsBIM360").tabs();
});

function InitTableMainItems() {
    var tableItems = $('#tableItems').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '20vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        "createdRow": function (row, data, dataIndex) {
            $(row).addClass('yellow');
        },
        columnDefs: [
            {
                "targets": 0,
                "orderable": false,
                "render": function () {
                    return '<input type="checkbox" id="createMain" value="no">';
                }
            },
        ],
    });
    tableItems.draw(true);
}

function InitTableLogs() {
    var tableItems = $('#tableLogs').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '20vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ]
    });
    tableItems.draw(true);
}


function EnableDisableTable() {
    var tablePBS = $('#tableItems').DataTable();
    if (!tablePBS.rows().count()) {
        hideElement("#tableWrapper");
    }
    else {
        showElement('#tableWrapper');
    }
    var tableLogs = $('#tableLogs').DataTable();
    if (!tableLogs.rows().count()) {
        hideElement("#tableWrapperLogs");
    }
    else {
        showElement('#tableWrapperLogs');
    }
}

function drawTableItems(data) {
    var table = $('#tableItems').DataTable();
    table.clear();

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            var notes = '';
            if (item.MessageCode == 28) {
                notes = "Main Item Not Found";
                table.row.add([
                    '',
                    item.Unit,
                    item.CA,
                    item.CWA,
                    item.SubDiscipline,
                    item.WP,
                    item.ObjectCode,
                    item.MaterialWorkGroup,
                    item.TagType,
                    item.MainItemTag
                ]).draw(true);
            }
        });
    }
    table.draw(true);
}

function drawTableLogs(data) {
    var table = $('#tableLogs').DataTable();
    table.clear();

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            table.row.add([
                item.GetError,
                item.Description,
                item.FileName,
                item.ItemTag,
            ]).draw(true);
        });
    }
    table.draw(true);
}

function SendToDB() {
    loadSpinner();
    start();
    var projectCode = $('#labelProject').text();
    if (!projectCode) {
        hideSpinner();
        alert("Incorrect project!!");
    }

    var url = '/api/forge/readitems?code=' + projectCode + '&itemStr=""';
    document.getElementById('timeElapsed').innerHTML = '';

    $.ajax({
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            hideSpinner();
            drawTableItems(data);
            drawTableLogs(data);
            EnableDisableTable();
            $('#tableItems').DataTable().draw();
            $('#tableLogs').DataTable().draw();
            end();
            document.getElementById('timeElapsed').innerHTML = timeElapsed;
        },
        error: function () {
            hideSpinner();
            alert('error');
            end();
        }
    });
}

function UpdateItemDB() {
    loadSpinner();
    start();
    var projectCode = $('#labelProject').text();
    if (!projectCode) {
        hideSpinner();
        alert("Incorrect project!!");
    }

    document.getElementById('timeElapsed').innerHTML = '';
    var items = [];
    var cell;
    var value = '';
    var table = document.getElementById("tableItems");
    var tableItems = $('#tableItems').DataTable();
    if (tableItems) {
        tableItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
            if (rowIdx > 0) {
                cell = table.rows[rowIdx].cells[0].querySelector('input');
                if (cell.checked) {
                    value = tableCivilQty.cell(rowIdx, 1).data();
                    items.push(value);
                }
            }
        });
    }

    var url = '/api/forge/readitems';

    $.ajax({
        url: url,
        type: 'POST',
        data: {
            'code': projectCode,
            'itemStr': JSON.stringify(items)
        },
        dataType: 'json',
        success: function (data) {
            hideSpinner();
            showElement('#tableWrapper');

            var table = $('#tableItems').DataTable();
            table.clear();

            // Add row
            if (data) {
                var logs = data;
                $.each(logs, function (i, item) {
                    var notes = '';
                    if (item.MessageCode == 28) {
                        notes = "Main Item Not Found";
                    }
                    else if (item.MessageCode == 36) {
                        notes = "Main Item Not Created";
                    }
                    table.row.add([
                        '',
                        item.Description_1,
                        item.Description_2,
                        notes
                    ]).draw(false);
                });
            }
            table.draw();
            end();
            document.getElementById('timeElapsed').innerHTML = timeElapsed;
        },
        error: function () {
            hideSpinner();
            alert('error');
            end();
        }
    });
}

function CreateMainItems() {

    setProgressMessage('Creating Main Items..');
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var unit = [];
    var ca = [];
    var cwa = [];
    var discipline = [];
    var wp = [];
    var objectCode = [];
    var material = [];
    var tagTypes = [];
    var itemTag = [];

    var table = $('#tableItems').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        var cell = table.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            unit.push(data[1]);
            ca.push(data[2]);
            cwa.push(data[3]);
            discipline.push(data[4]);
            wp.push(data[5]);
            objectCode.push(data[6]);
            material.push(data[7]);
            tagTypes.push(data[8]);
            itemTag.push(data[9]);
        }
    });

    if (unit && unit.length == 0) {
        alert("Any items to add!!");
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/MODELCONNECTOR/CreateMainItems',
        data: {
            'code': project,
            'unitStr': JSON.stringify(unit),
            'caStr': JSON.stringify(ca),
            'cwaStr': JSON.stringify(cwa),
            'disciplineStr': JSON.stringify(discipline),
            'wpStr': JSON.stringify(wp),
            'objectCodeStr': JSON.stringify(objectCode),
            'materialStr': JSON.stringify(material),
            'tagTypesStr': JSON.stringify(tagTypes),
            'itemTagStr': JSON.stringify(itemTag)
        },
        dataType: 'text',
        success: function (data) {
            window.location = '/MODELCONNECTOR/Index?code=' + project;
        },
        error: function (response, error) {
            displayMessage(response.responseText);
            hideSpinner();
            EnableDisableTable();
        },
    });
}

/// Show user information
function showUser() {
    jQuery.ajax({
        url: '/api/forge/user/profile',
        success: function (profile) {
            var img = '<img src="' + profile.picture + '" height="30px">';
            $('#userInfo').html(img + profile.name);
        }
    });
}

function initFolderTree() {
    //var projectCode = $('#labelProject').text();
    //if (!projectCode) {
    //    return;
    //}

    //$('#bim360Tree').jstree({
    //    'core': {
    //        'data': {
    //            'url': '/MODELCONNECTOR/GetFolderStructures?code=' + projectCode,
    //            'data': function (node) {
    //                return { 'id': node.id };
    //            }
    //        }
    //    },
    //    plugins: ["search", "themes", "types", "checkbox"]
    //});


    //$('#bim360Tree').on('changed.jstree', function (e, data) {
    //    var i, j, r = [];
    //    for (i = 0, j = data.selected.length; i < j; i++) {
    //        r.push(data.instance.get_node(data.selected[i]).text);
    //    }
    //    alert('Selected: ' + r.join(', '));
    //}).jstree();
}
