﻿// Settings
var projectCode = null;
var projectID = null;

// Forge Connection
var forgeClientId = null;
var forgeSecret = null;
var access_token = null;

// BIM360
var hub = null;
var project = null;
var rootFolder = null;
var firstFolder = null;
var wpFolder = null;
var bim360files = [];
var bim360filesLastVersion = [];

// Filters
var hubName = null;
var rootFolderName = null;
var firstFolderName = null;
var secondFolderName = null;

// Server data
var bim360FilesServer = [];
var forgeModelsServer = [];

// ------------------------------- //
// Classes
// ------------------------------- //
class BIM360FILES {
    FILESID;
    PROJECTID;
    FILENAME;
    FILEVERSION;
    FILEDATE;

    BIM360FILES() {
    }
}

class Property {
    CategoryName;
    Name;
    Value;

    Property() {
    }
}

class ForgeItem {
    ModelName;
    Objectid;
    Name;
    Properties;

    ForgeItem() {
    }
}

class ForgeModel {
    modelName;
    lastVersion;
    items;

    ForgeModel() {
    }
}


// ------------------------------- //
// Read BIM360 Items
// ------------------------------- //
function readBIM360Items() {
    // Reset values
    start();
    index = 0;
    metadata = [];
    bim360files = [];
    bim360filesLastVersion = [];
    bim360FilesServer = [];
    forgeModelsServer = [];

    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinnerModal();

    var url= '/cmd/ModelConnector/IsProcessing';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            if (data == "Valid") {
                getSelectedBim360Folders();
                if (bim360SelectedFolders.length == 0) {
                    alert("Select at least one folder!!");
                    return;
                }

                setTimeout(function () {
                    try {
                        getToken();
                    } catch (err) {
                        console.log(err);
                    }
                }, 100);
            }
            else {
                alert(data);
                hideSpinnerModal();
            }
        },
        error: function (response) {
            var data = response.responseText;
            if (data == "Valid") {
                getSelectedBim360Folders();
                if (bim360SelectedFolders.length == 0) {
                    alert("Select at least one folder!!");
                    hideSpinnerModal();
                    return;
                }

                setTimeout(function () {
                    try {
                        getToken();
                    } catch (err) {
                        console.log(err);
                    }
                }, 100);
            }
            else {
                alert(data);
                hideSpinnerModal();
            }
        }
    });

    
}

// ------------------------------- //
// Get Access token
// ------------------------------- //
var processedFolders = 0;
var processedFiles = 0;
function getToken() {
    $.ajax({
        method: 'POST',
        url: 'https://developer.api.autodesk.com/authentication/v1/authenticate',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        data: 'client_id=' + forgeClientId + '&client_secret=' + forgeSecret + '&grant_type=client_credentials&scope=data:write data:read bucket:create bucket:delete',
        success: function (response) {
            access_token = response.access_token;
            if (typeof access_token !== 'undefined') {
                setProgressMessageModal("Access obtained..");

                // Reset index before starting
                processedFolders = 0;
                processedFiles = 0;
                getBim360SelectedFiles();
            } else {
                setProgressMessageModal("Access denied!!");
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Files
// ------------------------------- //
async function getBim360SelectedFiles() {
    var url = "https://developer.api.autodesk.com/data/v1/projects/" + project.id + "/folders/" + bim360SelectedFolders[processedFolders] + "/contents";
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            Authorization: "Bearer " + access_token
        }
    });
    // waits until the request completes...
    const files = await response.json();

    if ((typeof files !== 'undefined') && (typeof files.data !== 'undefined')) {
        setProgressMessageModal('Reading files..');
        var data = files.data;
        // Read all folders
        data.forEach(function (entry) {
            var name = entry.attributes.displayName;
            var type = entry.type;
            var fileFilter = $('#fileFilter').val();
            if (type != "folders") {
                counter++;
                if (fileFilter != "") {
                    fileFilter = fileFilter.toUpperCase();
                    var substrings = fileFilter.split(';');
                    var found = false;
                    for (let i = 0; i < substrings.length; i++) {
                        if (name.includes(substrings[i])) {
                            found = true;
                        }
                    }
                    if (found) {
                        var name = entry.attributes['displayName'].toUpperCase();
                        if (strEndsWith(name, "IFC") || strEndsWith(name, "RVT")) {
                            bim360files.push(entry);
                        }
                    }
                }
                else {
                    var name = entry.attributes['displayName'].toUpperCase();
                    if (strEndsWith(name, "IFC") || strEndsWith(name, "RVT")) {
                        bim360files.push(entry);
                    }
                }
            }
        });
    }
    processedFolders++;
    if (processedFolders < bim360SelectedFolders.length) {
        getBim360SelectedFiles();
    }
    else {
        if (bim360files.length > 0) {
            getBIM360FilesLastVersionAsync();
        }
        else {
            alert("No files found!!");
            hideSpinnerModal();
        }
    }
}

function getBIM360Files(callbackBIM360FilesVersion) {

    // Reset BIM360 file list
    bim360files = []

    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/folders/' + wpFolder.id + '/contents',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            files = response;
            var found = false;
            if ((typeof files !== 'undefined') && (typeof files.data !== 'undefined')) {
                setProgressMessageModal('Reading files list..');
                var data = files.data;
                // Read all files
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (type != "folders") {
                        bim360files.push(entry);
                        found = true;
                    }
                });
                if (found) {
                    setProgressMessageModal(bim360files.length.toString() + ' files found');
                    callbackBIM360FilesVersion(getBIM360FilesLastVersion);
                } else {
                    setProgressMessageModal('Any files found!!');
                }
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Version
// ------------------------------- //
async function getBIM360FilesLastVersionAsync() {
    var url = "https://developer.api.autodesk.com/data/v1/projects/" + project.id + "/items/" + bim360files[processedFiles].id + "/versions";
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            Authorization: "Bearer " + access_token
        }
    });
    // waits until the request completes...
    const versions = await response.json();

    if ((typeof versions !== 'undefined') && (typeof versions.data !== 'undefined')) {
        setProgressMessageModal('Reading file ' + versions.data[0].attributes.name + ' versions');

        var data = versions.data[0];
        bim360filesLastVersion.push(versions.data[0]); // First element is last version
        var currentFile = new BIM360FILES();
        currentFile.FILESID = -1;
        currentFile.FILENAME = versions.data[0].attributes['name'];
        currentFile.FILEVERSION = versions.data[0].attributes['versionNumber'];
        currentFile.FILEDATE = versions.data[0].attributes['lastModifiedTime'];
        currentFile.PROJECTID = projectCodeID;
        bim360FilesServer.push(currentFile);
    }
    processedFiles++;
    if (processedFiles < bim360files.length) {
        getBIM360FilesLastVersionAsync();
    }
    else {
        index = 0;
        var valid = true;
        if (bim360files.length > 30) {
            if (confirm('Are you sure you want to process more than 30 models?')) {
            } else {
                // Do nothing!
                valid = false;
            }
        }
        if (valid) {
            ForgeXLS.prepareTables(function () {
                console.log("Read data");
            })
        }
        else {
            hideSpinnerModal();
        }
    }
}

function getBIM360FilesLastVersion(callbackBIM360FilesLastVersion) {

    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/items/' + bim360files[index].id + '/versions',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            versions = response;
            var found = false;
            if ((typeof versions !== 'undefined') && (typeof versions.data[0] !== 'undefined')) {
                setProgressMessageModal('Reading file ' + versions.data[0].attributes.name + ' versions');
                var data = versions.data[0];
                bim360filesLastVersion.push(versions.data[0]); // First element is last version
                var currentFile = new BIM360FILES();
                currentFile.FILESID = -1;
                currentFile.FILENAME = versions.data[0].attributes['name'];
                currentFile.FILEVERSION = versions.data[0].attributes['versionNumber'];
                currentFile.FILEDATE = versions.data[0].attributes['lastModifiedTime'];
                currentFile.PROJECTID = projectCodeID;
                bim360FilesServer.push(currentFile);
            }
            index++;
            if (index < bim360files.length) {
                setTimeout(function () {
                    callbackBIM360FilesLastVersion(getBIM360FilesLastVersion);
                }, 1000);
            } else {
                index = 0;
                ForgeXLS.prepareTables(function () {
                    console.log("test");
                })
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Encode urn to base64
// ------------------------------- //
function base64Encode(urn) {
    var encoded = btoa(urn);
    encoded = encoded.replace("/", "_");
    return encoded;
}

// ------------------------------- //
// Storage
// ------------------------------- //
var index = 0;
var metadata = [];
var forgeModel = null;


// ------------------------------- //
// Forge Metadata Class
// ------------------------------- //
var ForgeXLS = {
    Utility: {
        Constants: {
            BASE_URL: 'https://developer.api.autodesk.com',
            MODEL_DERIVATIVE_V2: '/modelderivative/v2/designdata/'
        },

        forgeGetRequest: function (url, token, callback) {
            jQuery.ajax({
                url: url,
                beforeSend: function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + token);
                },
                success: function (response) {
                    if (response.result && response.result === 'success') {
                        setTimeout(function () {
                            console.log('Data not ready... retry in 1 second');
                            ForgeXLS.Utility.forgeGetRequest(url, token, callback);
                        }, 1000);
                        return;
                    }
                    if (callback)
                        callback(response);
                }
            });
        },
        getMetadata: function (urn, token, callback) {
            console.log('Downloading metadata...');
            this.forgeGetRequest(this.Constants.BASE_URL + this.Constants.MODEL_DERIVATIVE_V2 + urn + '/metadata', token, callback);
        },

        getHierarchy: function (urn, guid, token, callback) {
            console.log('Downloading hierarchy...');
            this.forgeGetRequest(this.Constants.BASE_URL + this.Constants.MODEL_DERIVATIVE_V2 + urn + '/metadata/' + guid, token, callback);
        },

        getProperties: function (urn, guid, token, callback) {
            console.log('Downloading properties...');
            this.forgeGetRequest(this.Constants.BASE_URL + this.Constants.MODEL_DERIVATIVE_V2 + urn + '/metadata/' + guid + '/properties', token, callback);
        }
    },


    prepareTables: function (callback) {
        if (index >= bim360filesLastVersion.length) {
            return;
        }
        var urn = base64Encode(bim360filesLastVersion[index].id);
        var token = access_token;


        this.Utility.getMetadata(urn, token, function (metadata) {
            if (metadata.data.metadata.length == 0) {
                alert('Unexpected metadata');
                return;
            }
            var guid = metadata.data.metadata[0].guid;

            ForgeXLS.Utility.getHierarchy(urn, guid, token, function (hierarchy) {
                ForgeXLS.Utility.getProperties(urn, guid, token, function (properties) {
                    ForgeXLS.prepareRawData(hierarchy, properties);
                });
            });
        });
    },

    prepareRawData: function (hierarchy, properties) {
        var tables = {};

        // Init current models
        forgeModel = new ForgeModel();
        forgeModel.modelName = bim360FilesServer[index].FILENAME;
        forgeModel.lastVersion = bim360FilesServer[index].FILEVERSION;
        forgeModel.items = [];

        var filename = bim360filesLastVersion[index].attributes.name;
        var currentProgress = (index + 1).toString() + '/' + bim360filesLastVersion.length.toString();
        setProgressMessageModal('Processing file ' + filename + ' ' + currentProgress);

        hierarchy.data.objects[0].objects.forEach(function (category) {
            var idsOnCategory = [];
            ForgeXLS.getAllElementsOnCategory(idsOnCategory, category.objects);

            var rows = [];
            idsOnCategory.forEach(function (objectid) {
                var columns = ForgeXLS.getProperties(objectid, properties);
                rows.push(columns);
            });
            tables[category.name] = rows;
        });
        index++;

        forgeModelsServer.push(forgeModel);
        metadata.push(tables);

        if (index < bim360filesLastVersion.length) {
            setTimeout(function () {
                ForgeXLS.prepareTables(function () {
                    console.log("Reading..");
                });
            }, 1000);
        }
        else {
            setProgressMessageModal('Saving element to database..');
            setTimeout(function () {
                sendDataToDatabase();
            }, 1000)
        }
    },

    getAllElementsOnCategory: function (ids, category) {
        category.forEach(function (item) {
            if (typeof (item.objects) === 'undefined') {
                if (!ids.indexOf(item.objectid) >= 0)
                    ids.push(item.objectid);
            } else
                ForgeXLS.getAllElementsOnCategory(ids, item.objects);
        });
    },

    getProperties: function (id, objCollection) {
        var data = {};

        objCollection.data.collection.forEach(function (obj) {
            if (obj.objectid != id) return;

            var forgeItem = new ForgeItem();
            forgeItem.Properties = [];
            forgeItem.ModelName = bim360FilesServer[index].FILENAME;
            forgeItem.Objectid = obj.objectid;
            if (obj.name == "undefined" || obj.name == "Undefined") {
                forgeItem.Name = obj.objectid;
            }
            else {
                forgeItem.Name = obj.name.replace('[' + data['Revit ID'] + ']', '').trim();
            }

            currentProperty = new Property();
            currentProperty.CategoryName = '';
            currentProperty.Name = 'name';
            currentProperty.Value = obj.name;
            forgeItem.Properties.push(currentProperty);

            data['Viewer ID'] = id;
            if (obj.name == "undefined" || obj.name == "Undefined") {
                data['Revit ID'] = id;
                data['Name'] = id;
            }
            else {
                var valArray = obj.name.match(/\d+/g);
                if (valArray && valArray.length > 0) {
                    data['Revit ID'] = obj.name.match(/\d+/g)[0];
                }
                else {
                    data['Revit ID'] = id;
                }
                data['Name'] = obj.name.replace('[' + data['Revit ID'] + ']', '').trim();
            }

            var currentProperty = null;

            for (var propGroup in obj.properties) {
                if (propGroup.indexOf('__') > -1) break;
                if (obj.properties.hasOwnProperty(propGroup)) {
                    for (var propName in obj.properties[propGroup]) {
                        if (obj.properties[propGroup].hasOwnProperty(propName) && !Array.isArray(obj.properties[propGroup][propName])) { }
                        data[propGroup + ':' + propName] = obj.properties[propGroup][propName];
                        currentProperty = new Property();
                        currentProperty.CategoryName = propGroup;
                        currentProperty.Name = propName;
                        currentProperty.Value = obj.properties[propGroup][propName];
                        forgeItem.Properties.push(currentProperty);
                    }
                }
            }
            forgeModel.items.push(forgeItem);
        });

        return data;
    }
};

function sendDataToDatabase() {
    var fileFilter = $('#fileFilter').val();

    $.ajax({
        type: 'POST',
        url: '/cmd/api/forge/saveitems',
        data: {
            'code': projectCode,
            'filesstr': JSON.stringify(bim360FilesServer),
            'itemsStr': JSON.stringify(forgeModelsServer),
            'itemsTagStr': '',
            'folderStr': JSON.stringify(folderNamesToSave),
            'filefilter': fileFilter
        },
        dataType: 'json',
        encoded: 'gzip',
        success: function (data) {
            setProgressMessageModal('Completed!!');
            setTimeout(function () {
                hideSpinnerModal();
                end();
                document.getElementById('timeElapsed').innerHTML = timeElapsed;
            }, 3000);
            location.reload();
        },
        error: function (response, error) {
            setProgressMessageModal(response.responseText);
            setTimeout(function () {
                hideSpinnerModal();
                alert('error ' + response.responseText);
                end();
            }, 3000);
            location.reload();
        },
    });
}

