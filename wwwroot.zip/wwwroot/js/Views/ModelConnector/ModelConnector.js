﻿var tableItems = null;
var tableItemsListCheck = null;
var tableItemsDeletedCheck = null;
var tableItemsMissingAttributes = null;
var tableItemsQualityChecker = null;
var tableItemsLogs = null;
var pressedBntClass = 'btn-success';
var notPressedBntClass = 'btn-light';

$(document).ready(function () {
    // Main Settings
    setTitle("3D Model Connector"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    disableLink("#modelConnectorBtn");

    // Show Commands
    disable("#btnDownloadExcel");
    disable("#btnImportExcel");

    showElement("#navTopButton"); // Show Navbar
    disable("#modelConnectorBtn"); // Hide PBS Button

    // Additional buttons
    InitCommandsModelConnector();

    // Init UI
    initTablesModelConnector();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });
});

function initTablesModelConnector() {
    InitTable3DModelConnectorItems();
    InitTable3DModelItemListCheck();
    InitTable3DModelItemDeletedCheck();
    InitTable3DModelMissingAttributes();
    InitTable3DModelQualityChecker();
    InitTable3DModelLogs();
}

function InitTable3DModelConnectorItems() {

    tableItems = $('#tableItems').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [1, 11], "searchable": true },
            {
                "targets": 0, //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 50, targets: 0 },
            { width: 250, targets: 1 },
            { width: 60, targets: 4 },
            { width: 80, targets: 6 },
            { width: 70, targets: 7 },
            { width: 90, targets: 8 },
            { width: 100, targets: 9 }
        ],
        order: [
            [2, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#tableSearchItems').on('input', function (e) {
        updateTableModelConnectorSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableItems.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableItems.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableItems.draw();

        colorDatatableAllRow(tableItems);
    });

    for (let i = 1; i <= 11; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_1");
        checkbox.addEventListener('change', (event) => {
            tableItems.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableItems);
        })
    }
}

function updateTableModelConnectorSearch() {
    var filter = $('#tableSearchItems').val();

    // Reset filter
    tableItems.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= 11; i++) {
        var col1 = document.getElementById("checkBox" + i + "_1").checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i + "_1").val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableItems.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableItems.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitTable3DModelItemListCheck() {

    tableItemsListCheck = $('#tableItemChecks').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 3], "searchable": true },
        ],
        order: [
            [0, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#tableSearchItemListCheck').on('input', function (e) {
        updateTable3DModelItemListCheckSearch();
    });

    for (let i = 1; i <= 4; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_2");
        checkbox.addEventListener('change', (event) => {
            tableItemsListCheck.column(i - 1).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableItemsListCheck);
        })
    }

    if (tableItemsListCheck.data().count() == 0) {
        $('#labelInfoMissingModel').text('NO MODELS TO BE CREATED');
    }
}

function updateTable3DModelItemListCheckSearch() {
    var filter = $('#tableSearchItemListCheck').val();

    // Reset filter
    tableItemsListCheck.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= 4; i++) {
        var col1 = document.getElementById("checkBox" + i + "_2").checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i + "_2").val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableItemsListCheck.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableItemsListCheck.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitTable3DModelItemDeletedCheck() {

    tableItemsDeletedCheck = $('#tableDeleteItems').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 3], "searchable": true }
        ],
        order: [
            [0, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });


    // Set table search
    $('#tableSearchItemListCheck').on('input', function (e) {
        updateTable3DModelItemDeletedCheck();
    });

    for (let i = 1; i <= 5; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_3");
        checkbox.addEventListener('change', (event) => {
            tableItemsDeletedCheck.column(i - 1).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableItemsDeletedCheck);
        })
    }

    if (tableItemsDeletedCheck.data().count() == 0) {
        $('#labelInfoDeletedModel').text('NO MODELS TO BE DELETED');
    }
}

function updateTable3DModelItemDeletedCheck() {
    var filter = $('#tableSearchItemListCheck').val();

    // Reset filter
    tableItemsDeletedCheck.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= 5; i++) {
        var col1 = document.getElementById("checkBox" + i + "_3").checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i + "_3").val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableItemsDeletedCheck.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableItemsDeletedCheck.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitTable3DModelMissingAttributes() {

    tableItemsMissingAttributes = $('#tableIncorrectFiles').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 1], "searchable": true }
        ],
        order: [
            [0, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#tableSearchMissingAttributes').on('input', function (e) {
        updateTable3DModelMissingAttributes();
    });

    for (let i = 1; i <= 2; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_4");
        checkbox.addEventListener('change', (event) => {
            tableItemsMissingAttributes.column(i - 1).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableItemsMissingAttributes);
        })
    }

    if (tableItemsMissingAttributes.data().count() == 0) {
        $('#labelInfoMissingAttributes').text('NO MODELS EXPORTED WITHOUT ATTRIBUTES ON BIM360');
    }
}

function updateTable3DModelMissingAttributes() {
    var filter = $('#tableSearchMissingAttributes').val();

    // Reset filter
    tableItemsMissingAttributes.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= 2; i++) {
        var col1 = document.getElementById("checkBox" + i + "_4").checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i + "_4").val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableItemsMissingAttributes.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableItemsMissingAttributes.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitTable3DModelQualityChecker() {

    var totalParameters = $('#inputTotalParameters').val();
    var totalColumns = totalParameters + 1;

    tableItemsQualityChecker = $('#tableModelAttributes').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, totalColumns], "searchable": true }
        ],
        order: [
            [0, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#tableSearchQualityChecker').on('input', function (e) {
        updateTable3DModelQualityChecker();
    });

    for (let i = 1; i <= totalColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_5");
        checkbox.addEventListener('change', (event) => {
            tableItemsQualityChecker.column(i - 1).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableItemsQualityChecker);
        })
    }

    if (tableItemsQualityChecker.data().count() == 0) {
        $('#labelInfoQualityChecker').text('NO ATTRIBUTES AVAILABLE');
    }
}

function updateTable3DModelQualityChecker() {
    var totalParameters = $('#inputTotalParameters').val();
    var totalColumns = totalParameters + 1;

    var filter = $('#tableSearchQualityChecker').val();

    // Reset filter
    tableItemsQualityChecker.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalColumns; i++) {
        var col1 = document.getElementById("checkBox" + i + "_5").checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i + "_5").val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableItemsQualityChecker.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableItemsQualityChecker.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitTable3DModelLogs() {

    tableItemsLogs = $('#tableFileRevisions').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 3], "searchable": true }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#buttonSearchLogs').on('input', function (e) {
        updateTable3DModelLogs();
    });

    for (let i = 1; i <= 4; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i + "_6");
        checkbox.addEventListener('change', (event) => {
            tableItemsLogs.column(i - 1).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableItemsLogs);
        })
    }
}

function updateTable3DModelLogs() {
    var filter = $('#buttonSearchLogs').val();

    // Reset filter
    tableItemsLogs.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= 4; i++) {
        var col1 = document.getElementById("checkBox" + i + "_6").checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i + "_6").val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableItemsLogs.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableItemsLogs.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitCommandsModelConnector() {
    showElement("#btnCommand1");
    showElement("#btnCommand2");
    showElement("#btnCommand3");
    showElement("#btnCommand4");
    showElement("#btnCommand5");
    showElement("#btnCommand6");

    $("#btnCommand1").html('Item List');
    $("#btnCommand2").html('Missing Models');
    $("#btnCommand3").html('Models to be deleted');
    $("#btnCommand4").html('Missing Attributes');
    $("#btnCommand5").html('Quality Checker');
    $("#btnCommand6").html('Logs');

    SetModelConnectorBtnPressed("btnCommand1");

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });
    $("#btnCommand1").click(function () {
        SetModelConnectorBtnPressed("btnCommand1");
        SetModelConnectorBtnNotPressed("btnCommand2");
        SetModelConnectorBtnNotPressed("btnCommand3");
        SetModelConnectorBtnNotPressed("btnCommand4");
        SetModelConnectorBtnNotPressed("btnCommand5");
        SetModelConnectorBtnNotPressed("btnCommand6");

        showElement("#divTable3dModelConnector");
        hideElement("#divTableItemListCheck");
        hideElement("#divTableItemDeletedItems");
        hideElement("#divTableMissingAttributes");
        hideElement("#divTableQualityChecker");
        hideElement("#divTableLogs");

        setvisible("#divTable3dModelConnector");
        setnotvisible("#divTableItemListCheck");
        setnotvisible("#divTableItemDeletedItems");
        setnotvisible("#divTableMissingAttributes");
        setnotvisible("#divTableQualityChecker");
        setnotvisible("#divTableLogs");
    });
    $("#btnCommand2").click(function () {
        SetModelConnectorBtnNotPressed("btnCommand1");
        SetModelConnectorBtnPressed("btnCommand2");
        SetModelConnectorBtnNotPressed("btnCommand3");
        SetModelConnectorBtnNotPressed("btnCommand4");
        SetModelConnectorBtnNotPressed("btnCommand5");
        SetModelConnectorBtnNotPressed("btnCommand6");

        hideElement("#divTable3dModelConnector");
        showElement("#divTableItemListCheck");
        hideElement("#divTableItemDeletedItems");
        hideElement("#divTableMissingAttributes");
        hideElement("#divTableQualityChecker");
        hideElement("#divTableLogs");

        setnotvisible("#divTable3dModelConnector");
        setvisible("#divTableItemListCheck");
        hideElement("#divTableItemDeletedItems");
        setnotvisible("#divTableMissingAttributes");
        setnotvisible("#divTableQualityChecker");
        setnotvisible("#divTableLogs");

        
        tableItemsListCheck.destroy();
        InitTable3DModelItemListCheck();
    });
    $("#btnCommand3").click(function () {
        SetModelConnectorBtnNotPressed("btnCommand1");
        SetModelConnectorBtnNotPressed("btnCommand2");
        SetModelConnectorBtnPressed("btnCommand3");
        SetModelConnectorBtnNotPressed("btnCommand4");
        SetModelConnectorBtnNotPressed("btnCommand5");
        SetModelConnectorBtnNotPressed("btnCommand6");

        hideElement("#divTable3dModelConnector");
        hideElement("#divTableItemListCheck");
        showElement("#divTableItemDeletedItems");
        hideElement("#divTableMissingAttributes");
        hideElement("#divTableQualityChecker");
        hideElement("#divTableLogs");

        setnotvisible("#divTable3dModelConnector");
        setnotvisible("#divTableItemListCheck");
        setvisible("#divTableItemDeletedItems");
        setnotvisible("#divTableMissingAttributes");
        setnotvisible("#divTableQualityChecker");
        setnotvisible("#divTableLogs");

        tableItemsDeletedCheck.destroy();
        InitTable3DModelItemDeletedCheck();
    });
    $("#btnCommand4").click(function () {
        SetModelConnectorBtnNotPressed("btnCommand1");
        SetModelConnectorBtnNotPressed("btnCommand2");
        SetModelConnectorBtnNotPressed("btnCommand3");
        SetModelConnectorBtnPressed("btnCommand4");
        SetModelConnectorBtnNotPressed("btnCommand5");
        SetModelConnectorBtnNotPressed("btnCommand6");

        hideElement("#divTable3dModelConnector");
        hideElement("#divTableItemListCheck");
        hideElement("#divTableItemDeletedItems");
        showElement("#divTableMissingAttributes");
        hideElement("#divTableQualityChecker");
        hideElement("#divTableLogs");

        setnotvisible("#divTable3dModelConnector");
        setnotvisible("#divTableItemListCheck");
        setnotvisible("#divTableItemDeletedItems");
        setvisible("#divTableMissingAttributes");
        setnotvisible("#divTableQualityChecker");
        setnotvisible("#divTableLogs");

        tableItemsMissingAttributes.destroy();
        InitTable3DModelMissingAttributes();
    });
    $("#btnCommand5").click(function () {
        SetModelConnectorBtnNotPressed("btnCommand1");
        SetModelConnectorBtnNotPressed("btnCommand2");
        SetModelConnectorBtnNotPressed("btnCommand3");
        SetModelConnectorBtnNotPressed("btnCommand4");
        SetModelConnectorBtnPressed("btnCommand5");
        SetModelConnectorBtnNotPressed("btnCommand6");

        hideElement("#divTable3dModelConnector");
        hideElement("#divTableItemListCheck");
        hideElement("#divTableItemDeletedItems");
        hideElement("#divTableMissingAttributes");
        showElement("#divTableQualityChecker");
        hideElement("#divTableLogs");

        setnotvisible("#divTable3dModelConnector");
        setnotvisible("#divTableItemListCheck");
        setnotvisible("#divTableItemDeletedItems");
        setnotvisible("#divTableMissingAttributes");
        setvisible("#divTableQualityChecker");
        setnotvisible("#divTableLogs");

        tableItemsQualityChecker.destroy();
        InitTable3DModelQualityChecker();
    });
    $("#btnCommand6").click(function () {
        SetModelConnectorBtnNotPressed("btnCommand1");
        SetModelConnectorBtnNotPressed("btnCommand2");
        SetModelConnectorBtnNotPressed("btnCommand3");
        SetModelConnectorBtnNotPressed("btnCommand4");
        SetModelConnectorBtnNotPressed("btnCommand5");
        SetModelConnectorBtnPressed("btnCommand6");

        hideElement("#divTable3dModelConnector");
        hideElement("#divTableItemListCheck");
        hideElement("#divTableItemDeletedItems");
        hideElement("#divTableMissingAttributes");
        hideElement("#divTableQualityChecker");
        showElement("#divTableLogs");

        setnotvisible("#divTable3dModelConnector");
        setnotvisible("#divTableItemListCheck");
        setnotvisible("#divTableItemDeletedItems");
        setnotvisible("#divTableMissingAttributes");
        setnotvisible("#divTableQualityChecker");
        setvisible("#divTableLogs");

        tableItemsLogs.destroy();
        InitTable3DModelLogs();
    });
}

function drawTableItems(data) {
    table3dModelCheck.clear();
    mainItemToCreate = [];

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            if (item.MessageCode == 28) {
                table3dModelCheck.row.add([
                    '',
                    item.FileName,
                    item.MainItemTag,
                    item.TagType,
                    item.Lot,
                    item.Unit,
                    item.CA,
                    item.CWA,
                    item.SubDiscipline,
                    item.WP,
                    item.ObjectCode,
                    item.MaterialWorkGroup
                ]).draw(true);
                mainItemToCreate.push(item);
            }
        });
    }
    table3dModelCheck.draw(true);
}

function drawTableDeletedItems(data) {
    tableDatabaseCheck.clear();
    mainItemToDelete = [];

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            if (item.MessageCode == 113) {
                tableDatabaseCheck.row.add([
                    '',
                    item.MainItemTag,
                    item.TagType,
                    item.Lot
                ]).draw(true);
                mainItemToDelete.push(item);
            }
        });
    }
    tableDatabaseCheck.draw(true);
}

function drawTableLogs(data) {
    tableModelLogs.clear();

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            if (item.MessageCode != 113 && item.MessageCode != 28) {
                tableModelLogs.row.add([
                    item.GetError,
                    item.Description,
                    item.FileName,
                    item.ItemTag,
                ]).draw(true);
            }
        });
    }
    tableModelLogs.draw(true);
}

function SendToDB() {
    loadSpinner();
    start();
    var projectCode = $('#labelProject').text();
    if (!projectCode) {
        hideSpinner();
        alert("Incorrect project!!");
    }

    var url= '/cmd/api/forge/readitems?code=' + projectCode + '&itemStr=""';
    document.getElementById('timeElapsed').innerHTML = '';

    $.ajax({
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            hideSpinner();
            drawTableItems(data);
            drawTableDeletedItems(data);
            drawTableLogs(data);
            $('#tableItems').DataTable().draw();
            $('#tableDeleteItems').DataTable().draw();
            $('#tableLogs').DataTable().draw();
            end();
            document.getElementById('timeElapsed').innerHTML = timeElapsed;
        },
        error: function () {
            hideSpinner();
            alert('error');
            end();
        }
    });
}

function CreateMainItems() {

    setProgressMessage('Creating Main Items..');
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var tagTypes = [];
    var itemTag = [];
    var lots = [];

    tableItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        var cell = tableItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            itemTag.push(data[2]);
            tagTypes.push(data[3]);
            lots.push(data[4]);
        }
    });

    if (itemTag && itemTag.length == 0) {
        alert("Any items to add!!");
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/MODELCONNECTOR/CreateMainItems',
        data: {
            'code': project,
            'itemTagStr': JSON.stringify(itemTag),
            'tagTypesStr': JSON.stringify(tagTypes),
            'lotStr': JSON.stringify(lots)
        },
        dataType: 'text',
        success: function (data) {
            var logs = JSON.parse(data);
            showExcelLogsAlertNoColumn(logs);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage(response.responseText);
            hideSpinner();
        },
    });
}

function DeleteMainItemsModelConnector() {

    setProgressMessage('Deleting Main Items 3D Model Data..');
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var tagTypes = [];
    var itemTag = [];
    var lots = [];

    tableItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        var cell = tableItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            itemTag.push(data[2]);
            tagTypes.push(data[3]);
            lots.push(data[4]);
        }
    });

    if (itemTag && itemTag.length == 0) {
        alert("Any items to delete!!");
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/MODELCONNECTOR/DeleteMainItems',
        data: {
            'code': project,
            'tagTypesStr': JSON.stringify(tagTypes),
            'itemTagStr': JSON.stringify(itemTag),
            'lotStr': JSON.stringify(lots),
        },
        dataType: 'text',
        success: function (data) {
            if (data == '') {
                window.location = '/cmd/MODELCONNECTOR/Index?code=' + project;
            }
            else {
                alert(data);
            }
        },
        error: function (response, error) {
            displayMessage(response.responseText);
            hideSpinner();
        },
    });
}

function checkAllItemsBim360() {
    var itemsChecked = document.getElementById("CheckAllColumnItems").checked;
    var table = document.getElementById("tableItems");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}

function checkAllDeletedItemsBim360() {
    var itemsChecked = document.getElementById("CheckAllColumnDeletedItems").checked;
    var table = document.getElementById("tableDeleteItems");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}

function showModalSyncronizeModal() {
    $("#modalShowBIM360").modal('show');
}

function SetModelConnectorBtnPressed(id) {
    $("#" + id).removeClass(notPressedBntClass);
    $("#" + id).addClass(pressedBntClass);
}

function SetModelConnectorBtnNotPressed(id) {
    $("#" + id).removeClass(pressedBntClass);
    $("#" + id).addClass(notPressedBntClass);
}

function UnlockModelConnector() {
    if (confirm("Do you want to unlock BIM360 Model Connector?")) {
        setProgressMessage('Unlock Model Connector..');
        loadSpinner();
        var project = $('#labelProject').text();

        $.ajax({
            type: 'POST',
            url: '/cmd/MODELCONNECTOR/UnlockBim360',
            data: {
                'code': project
            },
            dataType: 'text',
            success: function (data) {
                alert(data);
                hideSpinner();
            },
            error: function (response, error) {
                alert(response.responseText);
                hideSpinner();
            },
        });
    }
}
