﻿$(document).ready(function () {
    initBim360Tree();
    readBIM360Folders();
});

// ------------------------------- //
// Class
// ------------------------------- //
class jsTreeNode {

    constructor(id, parent, text) {
        this.id = id;
        this.parent = parent;
        this.text = text;
    }
}

var bim360TreeData = [];

// ------------------------------- //
// JsTree
// ------------------------------- //
function initBim360Tree() {

    resetBim360Values();

    $('#bim360Tree').jstree({
        plugins: ["search", "themes", "types", "checkbox"]
    });


    $('#bim360Tree').on('changed.jstree', function (e, data) {
        var i, j, r = [];
        for (i = 0, j = data.selected.length; i < j; i++) {
            r.push(data.instance.get_node(data.selected[i]).text);
        }
        alert('Selected: ' + r.join(', '));
    }).jstree();
}


function resetBim360Values() {
    // BIM360
    hub = null;
    project = null;
    rootFolder = null;
    civilFolder = null;
    wpFolder = null;
}

// ------------------------------- //
// Read BIM360 Items
// ------------------------------- //
function readBIM360Folders() {
    // Reset values
    start();
    index = 0;

    loadSpinner();
    setTimeout(function () {
        try {
            getSettingsForTree(getFolderToken);
        } catch (err) {
            console.log(err);
        }
    }, 100);
}

// ------------------------------- //
// Get settings
// ------------------------------- //
function getSettingsForTree(callbackGetToken) {
    $.ajax({
        type: 'GET',
        url: '/MODELCONNECTOR/GetAccessSettings',
        dataType: 'json',
        success: function (response) {
            if (response) {
                // Init variable
                forgeClientId = response["forgeClientId"];
                forgeSecret = response["forgeSecret"];
                hubName = response["hubName"];
                rootFolderName = response["rootFolderName"];
                civilFolderName = response["civilFolderName"];
                wpFolderName = response["wpFolderName"];

                projectCode = $('#labelProject').text();
                projectCodeID = $('#labelProjectID').text();

                setProgressMessage("Authorize access..");

                // Start reading hubs
                callbackGetToken(getFolderHub);
            }
        },
        error: function (response, error) {
            displayMessage('labelProgressMessage', response.responseText);
        },
    });
}

// ------------------------------- //
// Get Access token
// ------------------------------- //
function getFolderToken(callbackHub) {
    $.ajax({
        method: 'POST',
        url: 'https://developer.api.autodesk.com/authentication/v1/authenticate',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
        },
        data: 'client_id=' + forgeClientId + '&client_secret=' + forgeSecret + '&grant_type=client_credentials&scope=data:write data:read bucket:create bucket:delete',
        success: function (response) {
            access_token = response.access_token;
            if (typeof access_token !== 'undefined') {
                setProgressMessage("Access obtained..");
                callbackHub(getFolderHub);
            } else {
                setProgressMessage("Access denied!!");
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

// ------------------------------- //
// Get BIM360 Hub
// ------------------------------- //
function getFolderHub(callbackProject) {
    if (hub != null) {
        callbackProject(getFolderProject);
    }
    else {
        $.ajax({
            method: 'GET',
            url: 'https://developer.api.autodesk.com/project/v1/hubs',
            headers: {
                Authorization: "Bearer " + access_token
            },
            success: function (response) {
                hubs = response;
                var found = false;
                if ((typeof hubs !== 'undefined') && (typeof hubs.data !== 'undefined')) {
                    setProgressMessage('Reading hubs list..');
                    var data = hubs.data;
                    // Read all hubs
                    data.forEach(function (entry) {
                        var name = entry.attributes.name;
                        if (name == hubName) {
                            hub = entry;
                            found = true;
                        }
                    });
                    if (found) {
                        setProgressMessage('Hub found');
                        callbackProject(getFolderProject);
                    } else {
                        setProgressMessage('Hub not found!!');
                    }
                }
            },
            error: function (error) {
                console.log(error);
            }
        })
    }
}

// ------------------------------- //
// Get BIM360 Projects
// ------------------------------- //
function getFolderProject(callbackTopFolder) {
    if (project != null) {
        callbackTopFolder(getRootFolder);
    }
    {
        $.ajax({
            method: 'GET',
            url: 'https://developer.api.autodesk.com/project/v1/hubs/' + hub.id + '/projects',
            headers: {
                Authorization: "Bearer " + access_token
            },
            success: function (response) {
                projects = response;
                var found = false;
                if ((typeof projects !== 'undefined') && (typeof projects.data !== 'undefined')) {
                    setProgressMessage('Reading projects list..');
                    var data = projects.data;
                    // Read all hubs
                    data.forEach(function (entry) {
                        var name = entry.attributes.name;
                        if (name == projectCode) {
                            project = entry;
                            found = true;
                        }
                    });
                    if (found) {
                        setProgressMessage('Project found');
                        callbackTopFolder(getRootFolder);
                    } else {
                        setProgressMessage('Project not found!!');
                    }
                }
            },
            error: function (error) {
                console.log(error);
            }
        })
    }
}

// ------------------------------- //
// Get BIM360 Root Folder
// ------------------------------- //
function getRootFolder(callbackReadFolders) {
    if (rootFolder != null) {
        callbackReadFolders(getAllFolders(rootFolder));
    }
    else {
        $.ajax({
            method: 'GET',
            url: 'https://developer.api.autodesk.com/project/v1/hubs/' + hub.id + '/projects/' + project.id + '/topFolders',
            headers: {
                Authorization: "Bearer " + access_token
            },
            success: function (response) {
                topfolders = response;
                var found = false;
                if ((typeof topfolders !== 'undefined') && (typeof topfolders.data !== 'undefined')) {
                    setProgressMessage('Reading first level folders..');
                    var data = topfolders.data;
                    // Read all hubs
                    data.forEach(function (entry) {
                        var name = entry.attributes.name;
                        var type = entry.type;
                        if (name == rootFolderName && type == "folders") {
                            rootFolder = entry;
                            found = true;
                        }
                    });
                    if (found) {
                        //setProgressMessage('Root folder found');
                        callbackReadFolders(getAllFolders(rootFolder));
                    } else {
                        setProgressMessage('Root folder not found!!');
                    }
                }
            },
            error: function (error) {
                console.log(error);
            }
        })
    }
}



// ------------------------------- //
// Get All folders
// ------------------------------- //
function getAllFolders(parentFolder) {
    $.ajax({
        method: 'GET',
        url: 'https://developer.api.autodesk.com/data/v1/projects/' + project.id + '/folders/' + parentFolder.id + '/contents',
        headers: {
            Authorization: "Bearer " + access_token
        },
        success: function (response) {
            folders = response;
            if ((typeof folders !== 'undefined') && (typeof folders.data !== 'undefined')) {
                setProgressMessage('Reading folders..');
                var data = folders.data;
                // Read all folders
                data.forEach(function (entry) {
                    var name = entry.attributes.name;
                    var type = entry.type;
                    if (type == "folders") {
                        let newNode = new jsTreeNode(bim360TreeData.length + 1, "#", name);
                        $('#bim360Tree').jstree('create_node', '#', newNode, 'last');
                        bim360TreeData.push(newNode);
                        getAllFolders(entry);
                    }
                });
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}


