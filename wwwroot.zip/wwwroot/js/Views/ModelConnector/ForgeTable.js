﻿var tableItems = null;
var tableItemChecks = null;
var tableDeleteItems = null;
var tableIncorrectFiles = null;
var tableFileRevisions = null;
var tableModelAttributes = null;
var tableFileRevisions = null;
var mainItemToCreate = [];
var mainItemToDelete = [];

$(document).ready(function () {

    // Set Title
    setTitle("3D Model Connector");

    InitTableMainItems();
    InitTableItemsCheck();
    InitTableDeleteItems();
    InitTableIncorrectFiles();
    InitTableRevisions();
    InitTableModelAttributes();

    $("#tabsBIM360").tabs({
        activate: function (e, ui) {
            currentTabIndex = ui.newTab.index().toString();
            if (currentTabIndex == 0) {
                if (tableItems != null) {
                    tableItems.columns.adjust();
                }
            }
            else if (currentTabIndex == 1) {
                if (tableItemChecks != null) {
                    tableItemChecks.columns.adjust();
                }
                if (tableDeleteItems != null) {
                    tableDeleteItems.columns.adjust();
                }
            }
            else if (currentTabIndex == 2) {
                if (tableIncorrectFiles != null) {
                    tableIncorrectFiles.columns.adjust();
                }
            }
            else if (currentTabIndex == 3) {
                if (tableFileRevisions != null) {
                    tableFileRevisions.columns.adjust();
                }
            }
            else if (currentTabIndex == 4) {
                if (tableModelAttributes != null) {
                    tableModelAttributes.columns.adjust();
                }
            }
        }
    });
});

function InitTableMainItems() {
    tableItems = $('#tableItems').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '58vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        columnDefs: [
            {
                "targets": 0,
                "orderable": false,
                "render": function () {
                    return '<input type="checkbox" id="createMain" value="no">';
                }
            },
        ],
        search: {
            "caseInsensitive": true
        }
    });
    tableItems.draw(true);
}

function InitTableItemsCheck() {
    tableItemChecks = $('#tableItemChecks').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '58vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
    tableItemChecks.draw(true);
}

function InitTableDeleteItems() {
    tableDeleteItems = $('#tableDeleteItems').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '58vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
    tableDeleteItems.draw(true);
}

function InitTableIncorrectFiles() {
    tableIncorrectFiles = $('#tableIncorrectFiles').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '58vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
    tableIncorrectFiles.draw(true);
}

function InitTableModelAttributes() {
    tableModelAttributes = $('#tableModelAttributes').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '58vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
    tableModelAttributes.draw(true);
}

function InitTableRevisions() {
    tableFileRevisions = $('#tableFileRevisions').DataTable({
        paging: false,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        scrollY: '58vh',
        scrollCollapse: true,
        bAutoWidth: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
    tableFileRevisions.draw(true);
}


function drawTableItems(data) {
    table3dModelCheck.clear();
    mainItemToCreate = [];

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            if (item.MessageCode == 28) {
                table3dModelCheck.row.add([
                    '',
                    item.FileName,
                    item.MainItemTag,
                    item.TagType,
                    item.Lot,
                    item.Unit,
                    item.CA,
                    item.CWA,
                    item.SubDiscipline,
                    item.WP,
                    item.ObjectCode,
                    item.MaterialWorkGroup
                ]).draw(true);
                mainItemToCreate.push(item);
            }
        });
    }
    table3dModelCheck.draw(true);
}

function drawTableDeletedItems(data) {
    tableDatabaseCheck.clear();
    mainItemToDelete = [];

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            if (item.MessageCode == 113) {
                tableDatabaseCheck.row.add([
                    '',
                    item.MainItemTag,
                    item.TagType,
                    item.Lot
                ]).draw(true);
                mainItemToDelete.push(item);
            }
        });
    }
    tableDatabaseCheck.draw(true);
}

function drawTableLogs(data) {
    tableModelLogs.clear();

    // Add row
    if (data) {
        var logs = data;
        $.each(logs, function (i, item) {
            if (item.MessageCode != 113 && item.MessageCode != 28) {
                tableModelLogs.row.add([
                    item.GetError,
                    item.Description,
                    item.FileName,
                    item.ItemTag,
                ]).draw(true);
            }
        });
    }
    tableModelLogs.draw(true);
}

function SendToDB() {
    loadSpinner();
    start();
    var projectCode = $('#labelProject').text();
    if (!projectCode) {
        hideSpinner();
        alert("Incorrect project!!");
    }

    var url= '/cmd/api/forge/readitems?code=' + projectCode + '&itemStr=""';
    document.getElementById('timeElapsed').innerHTML = '';

    $.ajax({
        url: url,
        type: 'POST',
        dataType: 'json',
        success: function (data) {
            hideSpinner();
            drawTableItems(data);
            drawTableDeletedItems(data);
            drawTableLogs(data);
            $('#tableItems').DataTable().draw();
            $('#tableDeleteItems').DataTable().draw();
            $('#tableLogs').DataTable().draw();
            end();
            document.getElementById('timeElapsed').innerHTML = timeElapsed;
        },
        error: function () {
            hideSpinner();
            alert('error');
            end();
        }
    });
}

function CreateMainItems() {

    setProgressMessage('Creating Main Items..');
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var tagTypes = [];
    var itemTag = [];
    var lots = [];

    tableItems.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        var cell = tableItems.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            itemTag.push(data[2]);
            tagTypes.push(data[3]);
            lots.push(data[4]);
        }
    });

    if (itemTag && itemTag.length == 0) {
        alert("Any items to add!!");
        hideSpinner();
        return;
    }

    // Check folder
    var foldersSelected = [];
    var selectedNodes = $('#bim360Tree').jstree("get_selected", true);
    $.each(selectedNodes, function () {
        foldersSelected.push(this.id);
    });
    if (foldersSelected.length == 0) {
        alert("Any folder selected!!");
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/MODELCONNECTOR/CreateMainItems',
        data: {
            'code': project,
            'itemTagStr': JSON.stringify(itemTag),
            'tagTypesStr': JSON.stringify(tagTypes),
            'lotStr': JSON.stringify(lots)
        },
        dataType: 'text',
        success: function (data) {
            if (data == 'Main Items created') {
                readBIM360Items();
            }
            else {
                alert(data);
                hideSpinner();
            }
        },
        error: function (response, error) {
            displayMessage(response.responseText);
            hideSpinner();
        },
    });
}

function DeleteMainItems() {

    setProgressMessage('Deleting Main Items..');
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var tagTypes = [];
    var itemTag = [];
    var lots = [];

    tableDatabaseCheck.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        var cell = tableDatabaseCheck.cell({ row: rowIdx, column: 0 }).node();
        rowChecked = $('input', cell).prop('checked');
        if (rowChecked) {
            itemTag.push(data[1]);
            tagTypes.push(data[2]);
            lots.push(data[3]);
        }
    });

    if (itemTag && itemTag.length == 0) {
        alert("Any items to delete!!");
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/MODELCONNECTOR/DeleteMainItems',
        data: {
            'code': project,
            'tagTypesStr': JSON.stringify(tagTypes),
            'itemTagStr': JSON.stringify(itemTag),
            'lotStr': JSON.stringify(lots),
        },
        dataType: 'text',
        success: function (data) {
            if (data == '') {
                tableDatabaseCheck.clear();
                window.location = '/cmd/MODELCONNECTOR/Index?code=' + project;
            }
            else {
                alert(data);
            }
        },
        error: function (response, error) {
            displayMessage(response.responseText);
            hideSpinner();
        },
    });
}

function checkAllItemsBim360() {
    var itemsChecked = document.getElementById("CheckAllColumnItems").checked;
    var table = document.getElementById("tableItems");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}

function checkAllDeletedItemsBim360() {
    var itemsChecked = document.getElementById("CheckAllColumnDeletedItems").checked;
    var table = document.getElementById("tableDeleteItems");
    var totalRow = table.rows.length;
    var i;
    for (i = 1; i < totalRow; i++) {
        table.rows[i].cells[0].querySelector('input').checked = itemsChecked;
    }
}
