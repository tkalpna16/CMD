﻿var tableViewHolds = null;

$(document).ready(function () {
    // Setup - add a text input to each footer cell
    $('#tableHolds thead tr').clone(true).appendTo('#tableHolds thead');
    $('#tableHolds thead tr:eq(1) th').each(function (i) {
        var title = $(this).text();
        if ($(this).index() != 0) {
            $(this).html('<input type="text" placeholder="Search" style="width:100%" />');

            $('input[type="text"]', this).on('keyup change', function () {
                if (tableQTY.column(i).search() !== this.value) {
                    tableQTY
                        .column(i)
                        .search(this.value)
                        .draw();
                }
            });
        }
    });

    tableViewHolds = $('#tableHolds').DataTable({
        paging: false,
        scrollY: '36vh',
        scrollX: '100%',
        orderCellsTop: true,
        fixedHeader: true,
        bInfo: false,
        bSort: true,
        bAutoWidth: false,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });

    $('#divHolds').show();
    tableViewHolds.draw();
});