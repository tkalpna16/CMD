﻿var tableViewList = null;

$(document).ready(function () {

    // Main Settings
    setTitle("Data Schedules"); // Set Title
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/Index?code=' + project;
        window.location.href = url;
    });

    //InitTableViewList();
});

function InitTableViewList() {

    tableViewList = $('#tablePBSList').DataTable({
        dom: 'Rrtip',
        paging: false,
        orderCellsTop: false,
        fixedHeader: false,
        searching: false,
        bInfo: false,
        bSort: false,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        search: {
            "caseInsensitive": true
        }
    });
}

function openPBSList() {
    var project = $('#labelProject').text();
    var url= '/cmd/PBS/ViewList?code=' + project;
    window.location.href = url;
}

function openItemsList() {
    var project = $('#labelProject').text();
    var url= '/cmd/ItemListCreation/ItemsView?code=' + project;
    window.location.href = url;
}

function open3DModelList() {
    var project = $('#labelProject').text();
    var url= '/cmd/ModelConnector/ModelView?code=' + project;
    window.location.href = url;
}

function openHoldView() {
    var project = $('#labelProject').text();
    var url= '/cmd/HoldManager/HoldView?code=' + project;
    window.location.href = url;
}

function openPlanningView() {
    var project = $('#labelProject').text();
    var url= '/cmd/Plannings/PlanningView?code=' + project;
    window.location.href = url;
}

function openQuantityView() {
    var project = $('#labelProject').text();
    var url= '/cmd/QuantityManager/QuantityView?code=' + project;
    window.location.href = url;
}

function openDetailedItemsList() {
    var project = $('#labelProject').text();
    var url= '/cmd/ItemListCreation/CivilItemsView?code=' + project;
    window.location.href = url;
}