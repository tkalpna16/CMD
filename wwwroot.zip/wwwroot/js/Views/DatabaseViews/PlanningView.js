﻿var tableViewPlanning = null;
var totalParamterPlanningView = 31;

$(document).ready(function () {
    // Main Settings
    setTitle("Planning List"); // Set Title
    hideElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        createExcel3DModelView();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTablePlanningView();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    
    $('#divPlanning').show();
    tableViewPlanning.draw();
});

function InitTablePlanningView() {

    tableViewPlanning = $('#tablePlanning').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        }
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i <= totalParamterPlanningView; i++) {
            var col1 = document.getElementById("checkBox" + i).checked;
            if (col1) {
                colId.push(i);
            }
        }

        if (colId.length == 0) {
            tableViewPlanning.search(filter).draw();
        }
        else {
            tableViewPlanning.column(colId).search(filter).draw();
        }
    });

    // Hide colums
    for (let i = 1; i <= totalParamterPlanningView; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        tableViewPlanning.column(i - 1).visible(checkbox.checked);
    }

    hideEventsColumnsPlanningView();
}

function hideEventsColumnsPlanningView() {
    for (let i = 1; i <= totalParamterPlanningView; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableHoldsView.column(i - 1).visible(event.currentTarget.checked);
        })
    }
}