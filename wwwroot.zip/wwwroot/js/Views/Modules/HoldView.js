﻿var tableHoldsView = null;
var totalHoldViewColumns = 25;

$(document).ready(function () {
    // Main Settings
    setTitle("Holds"); // Set Title
    hideElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        createExcelHoldView();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTableHoldsView();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('#rowTable').show();
    tableHoldsView.columns.adjust();
});

function InitTableHoldsView() {
    tableHoldsView = $('#tableHoldManager').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        }
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i <= totalHoldViewColumns; i++) {
            var col1 = document.getElementById("checkBox" + i).checked;
            if (col1) {
                colId.push(i - 1);
            }
        }

        if (colId.length == 0) {
            tableHoldsView.search(filter).draw();
        }
        else {
            tableHoldsView.column(colId).search(filter).draw();
        }
    });

    // Hide colums
    for (let i = 1; i <= totalHoldViewColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        tableHoldsView.column(i - 1).visible(checkbox.checked);
    }

    hideEventsColumnsHold();
}

function hideEventsColumnsHold() {
    for (let i = 1; i <= totalHoldViewColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableHoldsView.column(i - 1).visible(event.currentTarget.checked);
        })
    }
}

function createExcelHoldView() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/HoldManager/CreateExcelView';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/Holds.xlsx";
            link.download = project + "-Holds-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}