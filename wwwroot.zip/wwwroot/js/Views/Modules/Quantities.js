﻿$(document).ready(function () {
    // To List
    $('.listbox').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#TagType').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    // Create Button Event
    $("#btnGetExcel").click(function () {

        // Area
        var selectedArea = [];
        $('#Area :selected').each(function () {
            selectedArea.push($(this).text());
        });
        if (selectedArea.length == 0) {
            alert("Any Area selected!!");
            return;
        }

        // TagType
        var selectedTagTypes = [];
        $('#TagType :selected').each(function () {
            selectedTagTypes.push($(this).text());
        });
        if (selectedTagTypes.length == 0) {
            alert("Any TagType selected!!");
            return;
        }

        // projectId
        var projectId = $('#labelProject').text();

        loadSpinner();

        $.ajax({
            type: 'POST',
            url: '/cmd/PriceEvaluator/ExcelQuantities',
            data: {
                'areasstr': JSON.stringify(selectedArea),
                'tagtypestr': JSON.stringify(selectedTagTypes),
                'projectId': projectId},
            dataType: 'text',
            success: function (data) {
                hideSpinner();
                window.location = '/cmd/PriceEvaluator/Download?filename=Quantities.xlsx';
            }
        });
    });
});