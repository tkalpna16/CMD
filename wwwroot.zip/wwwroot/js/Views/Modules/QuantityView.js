﻿var tableQTYView = null;
var tableQTYViewTotalColumns = 38;

$(document).ready(function () {
    // Main Settings
    setTitle("Quantities"); // Set Title
    hideElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar

    $("#btnDownloadExcel").click(function () {
        downloadQuantityManagerViewExcel();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProjectDescription').text();
        var url= '/cmd/VIEWMANAGER/Index?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTableQuantityView();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    document.getElementById("rowTable").style.opacity = "1.0";
});

function InitTableQuantityView() {

    tableQTYView = $('#tableQtyManager').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: false,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        "orderClasses": false,
        bAutoWidth: true,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { width: 100, targets: 5 },
            { width: 100, targets: 7 }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        var filter = $(this).val();

        var colId = [];
        for (let i = 1; i <= tableQTYViewTotalColumns; i++) {
            var col1 = document.getElementById("checkBox" + i).checked;
            if (col1) {
                colId.push(i - 1);
            }
        }

        if (colId.length == 0) {
            tableQTYView.search(filter).draw();
        }
        else {
            tableQTYView.column(colId).search(filter).draw();
        }
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableQTYView.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableQTY.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableQTYView.draw();
    });

    hideEventsColumnsQtyView();

    for (let i = 1; i <= tableQTYViewTotalColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        if (!checkbox.checked) {
            tableQTYView.column(i - 1).visible(checkbox.checked, false);
        }
    }
    tableQTYView.draw();
}


function downloadQuantityManagerViewExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();
    setProgressMessage("Download Excel..");

    var url: '/cmd/QuantityManager/CreateExcelView';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/Quantities.xlsx";
            link.download = project + "-Quantities-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function hideEventsColumnsQtyView() {
    for (let i = 1; i <= tableQTYViewTotalColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableQTYView.column(i - 1).visible(event.currentTarget.checked);
        })
    }
}