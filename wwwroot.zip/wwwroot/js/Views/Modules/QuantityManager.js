﻿var kfactor = true;
var k = 0.0;
var qtyce = 0.0;
var tableQTY = null;
var tableQTYTotalColumns = 36;
var totalParametersQTY = 0;

var editableColumnsQtyManager = [13, 17, 18, 19, 20, 22, 26, 28, 29, 31, 34];

const startingColumnQTY = 37;
const maxParametersQTY = 10;

$(document).ready(function () {
    // Main Settings
    setTitle("Quantity Manager"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    showElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#modelQtyManagerBtn"); // Hide PBS Button

    // Additional buttons
    var role = $("#labelRole").text();
    if (role == 'Admin' || role == 'Discipline Leader' || role == 'Quantity Specialist') {
        InitCommandsQuantityManager();
        showElement("#btnCommand1");
    }
    showElement("#btnCommand2");

    $("#btnDownloadExcel").click(function () {
        downloadQuantityManagerExcel();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        loadSpinner();

        $.ajax({
            type: 'GET',
            url: '/cmd/ItemListCreation/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: {
                'code': project
            },
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Temp/TemplateCIL.xlsx";
                link.download = "TemplateCIL.xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (data) {
                hideSpinner();
                alert(data);
            }
        });
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });

    // Init Parameters
    var labelVal = $('#labelParameters').text();
    totalParametersQTY = parseInt(labelVal);

    InitTableQuantityManager();
    InitFormulaColumnEnabled();

    // Hide Checkbox
    for (let i = totalParametersQTY; i < maxParametersQTY; i++) {
        hideElement("#rowParam" + (i + startingColumnQTY));
        hideElement("#rowParamVis" + (i + startingColumnQTY));
        hideElement("#rowParamVal" + (i + startingColumnQTY));
    }

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $('#rowTable').show();
    tableQTY.columns.adjust();
});

function InitCommandsQuantityManager() {
    $("#btnCommand1").html('CE SUBMISSION');

    $("#btnCommand1").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/QuantityManager/CESubmission?code=' + project;
        window.location.href = url;
    });

    var buttonTitle = $('#labelBalance').text();
    $("#btnCommand2").removeClass("btn-light");
    $("#btnCommand2").removeClass("btn-outline-secondary");
    $("#btnCommand2").addClass("btn-success");
    $("#btnCommand2").html(buttonTitle);
    $("#btnCommand2").click(function () {
        var project = $('#labelProject').text();
        var val = $('#labelBalance').text();
        var showbalance = 0;
        if (val == "SHOW BALANCE") {
            showbalance = 1;
        }
        var url= '/cmd/QuantityManager/Manager?code=' + project + '&&showbalance=' + showbalance;
        window.location.href = url;
    });
}

function InitFormulaColumnEnabled() {

    $('[id="item_ITEM_QUANTITY_QTY_BUDGET"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_QTY_WR"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_QTY_IFR"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_QTY_IFC"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_QTY_ACC"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_QTY_NEXT_CE"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_MANUAL_QTY_HOLD"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_QTY_REBAR"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_CONNECTION_INDICENCE"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });

    $('[id="item_ITEM_QUANTITY_AI_VOLUME_LAST_ISSUE"]').focusout(function () {
        try {
            var oldValue = $(this).val();
            if (oldValue) {
                var newValue = math.evaluate(oldValue);
                if (newValue) {
                    $(this).val(newValue);
                }
            }
        }
        catch (exception_var) {
        }
    });
}

function InitTableQuantityManager() {

    tableQTY = $('#tableQtyManager').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0], "searchable": false },
            {
                "targets": [0], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { "targets": 8, "orderDataType": "dom-text", type: 'string' },
            { width: 30, targets: 0 },
            { width: 110, targets: 3 },
            { width: 50, targets: 7 },
            { width: 60, targets: 10 },
            { "targets": 13, "orderDataType": "dom-text", type: 'string' },
            { "targets": 17, "orderDataType": "dom-text", type: 'string' },
            { "targets": 18, "orderDataType": "dom-text", type: 'string' },
            { "targets": 19, "orderDataType": "dom-text", type: 'string' },
            { "targets": 20, "orderDataType": "dom-text", type: 'string' },
            { "targets": 22, "orderDataType": "dom-text", type: 'string' },
            { "targets": 26, "orderDataType": "dom-text", type: 'string' },
            { "targets": 27, "orderDataType": "dom-text", type: 'string' },
            { "targets": 28, "orderDataType": "dom-text", type: 'string' },
            { "targets": 29, "orderDataType": "dom-text", type: 'string' },
            { "targets": 31, "orderDataType": "dom-text", type: 'string' },
            { "targets": 34, "orderDataType": "dom-text", type: 'string' },
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        createdRow: function (row, data, index) {
            try {
                var dateIFRAct = null;
                var dateIFCAct = null;


                // QTY
                try {

                    // Check IFR Actual
                    cell = row.cells[tableQTYTotalColumns + maxParametersQTY + 3];
                    if (cell.children.length > 0) {
                        var dateIFRActStr = cell.children[0].value;
                        dateIFRAct = moment(dateIFRActStr, 'YYYY-MM-DD');
                        if (dateIFRAct.isValid()) {
                            cell = row.cells[19];
                            if (cell.children.length > 0) {
                                var qtyIFR = parseFloat(cell.children[0].value);
                                if (!qtyIFR) {
                                    row.cells[19].style.backgroundColor = "orange";
                                    settooltiptext(row.cells[19].children[0], 'QTY MISSING, RELATIVE ACTUAL DATE IN PLANNING MANAGER IS AVAILABLE');
                                }
                            }
                        }
                    }

                    // Check IFC Actual
                    cell = row.cells[tableQTYTotalColumns + maxParametersQTY + 4];
                    if (cell.children.length > 0) {
                        var dateIFCActStr = cell.children[0].value;
                        dateIFCAct = moment(dateIFCActStr, 'YYYY-MM-DD');
                        if (dateIFCAct.isValid()) {
                            cell = row.cells[20];
                            if (cell.children.length > 0) {
                                var qtyIFC = parseFloat(cell.children[0].value);
                                if (!qtyIFC) {
                                    row.cells[20].style.backgroundColor = "orange";
                                    settooltiptext(row.cells[20].children[0], 'QTY MISSING, RELATIVE ACTUAL DATE IN PLANNING MANAGER IS AVAILABLE');
                                }
                            }
                        }
                    }
                }
                catch (exception_var) {
                    console.log(exception_var);
                }
                finally {

                }
            }
            catch (error) {
                console.log(error);
            }
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableQuantityManagerSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableQTY.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableQTY.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableQTY.draw();

        colorDatatableAllRow(tableQTY);
    });

    hideEventsColumnsQtyManager();

    for (let i = 1; i <= tableQTYTotalColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        tableQTY.column(i).visible(checkbox.checked);
    }

    // Hide additional columns
    var columnsToHide = [];
    if (totalParametersQTY < maxParametersQTY) {
        var starting = startingColumnQTY + totalParametersQTY;
        var final = startingColumnQTY + maxParametersQTY;
        for (let i = starting; i < final; i++) {
            columnsToHide.push(i);
        }
    }
    if (columnsToHide.length > 0) {
        tableQTY.columns(columnsToHide).visible(false);
    }
}

function updateTableQuantityManagerSearch() {

    var total = tableQTYTotalColumns + totalParametersQTY;
    var filter = $('#tableSearch').val();

    // Reset filter
    tableQTY.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= total; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableQTY.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableQTY.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function getText(cell) {
    return (cell.innerText == undefined) ? cell.textContent : cell.innerText;
}

function downloadQuantityManagerExcel() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();
    setProgressMessage("Download Excel..");

    var url= '/cmd/ItemListCreation/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/MainItemList.xlsx";
            link.download = project + "-QuantityManager-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function SaveQty() {
    loadSpinner();
    setProgressMessage("Saving quantities..");

    var project = $('#labelProject').text();

    // GetData
    var mainItems = [];
    var tagtypes = [];
    var lots = [];

    var drawrevacc = [];
    var budgetqty = [];
    var wrqty = [];
    var ifrqty = [];
    var ifcqty = [];
    var qtyacc = [];
    var qtynextce = [];
    var qtyhold = [];
    var qtyrebar = [];
    var qtyconninc = [];
    var qtyvol = [];
    var param1Values = [];
    var param2Values = [];
    var param3Values = [];
    var param4Values = [];
    var param5Values = [];
    var param6Values = [];
    var param7Values = [];
    var param8Values = [];
    var param9Values = [];
    var param10Values = [];

    var valid = true;

    tableQTY.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        if (!valid)
            return;

        mainItems.push(data[3]);
        tagtypes.push(data[6]);
        lots.push(data[7]);

        // Draw rev acc
        celldrawrev = tableQTY.cell({ row: rowIdx, column: 13 }).node();
        value = $('input', celldrawrev).val();
        drawrevacc.push(value);

        // Qty budget
        cellbudget = tableQTY.cell({ row: rowIdx, column: 17 }).node();
        value = $('input', cellbudget).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid budget value");
                valid = false;
            }
        }
        budgetqty.push(qty);

        // Qty wr
        cellwr = tableQTY.cell({ row: rowIdx, column: 18 }).node();
        value = $('input', cellwr).val();
        if (value == '') {
            qty = 0.0;
        }
        else{
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid Qty wr value");
                valid = false;
            }
        }
        wrqty.push(qty);


        // Qty ifr
        cellifr = tableQTY.cell({ row: rowIdx, column: 19 }).node();
        value = $('input', cellifr).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid Qty ifr value");
                valid = false;
            }
        }
        ifrqty.push(qty);

        // Qty ifc
        cellifc = tableQTY.cell({ row: rowIdx, column: 20 }).node();
        value = $('input', cellifc).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid Qty ifc value");
                valid = false;
            }
        }
        ifcqty.push(qty);

        // Qty acc
        cellacc = tableQTY.cell({ row: rowIdx, column: 22 }).node();
        value = $('input', cellacc).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid Qty acc value");
                valid = false;
            }
        }
        qtyacc.push(qty);

        // Qty next ce
        cellce = tableQTY.cell({ row: rowIdx, column: 26 }).node();
        value = $('input', cellce).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid Qty next ce value");
                valid = false;
            }
        }
        qtynextce.push(qty);

        // Qty hold
        cellhold = tableQTY.cell({ row: rowIdx, column: 28 }).node();
        value = $('input', cellhold).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                alert("Invalid Qty hold value");
                valid = false;
            }
        }
        qtyhold.push(qty);

        // Qty rebar
        cellifb = tableQTY.cell({ row: rowIdx, column: 29 }).node();
        value = $('input', cellifb).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                // Continue
            }
        }
        qtyrebar.push(qty);

        // Qty Conn Inc
        cellconninc = tableQTY.cell({ row: rowIdx, column: 31 }).node();
        value = $('input', cellconninc).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                // Continue
            }
        }
        qtyconninc.push(qty);

        // AI Volume
        cellvolume = tableQTY.cell({ row: rowIdx, column: 34 }).node();
        value = $('input', cellvolume).val();
        if (value == '') {
            qty = 0.0;
        }
        else {
            qty = parseFloat(value);
            if (isNaN(qty)) {
                // Continue
            }
        }
        qtyvol.push(qty);

        // Qty 1
        qty = 0.0;
        if (totalParametersQTY > 0) {
            cell = tableQTY.cell({ row: rowIdx, column: 37 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param1Values.push(qty);

        // Qty 2
        qty = 0.0;
        if (totalParametersQTY > 1) {
            cell = tableQTY.cell({ row: rowIdx, column: 38 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param2Values.push(qty);

        // Qty 3
        qty = 0.0;
        if (totalParametersQTY > 2) {
            cell = tableQTY.cell({ row: rowIdx, column: 38 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param3Values.push(qty);

        // Qty 4
        qty = 0.0;
        if (totalParametersQTY > 3) {
            cell = tableQTY.cell({ row: rowIdx, column: 39 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param9Values.push(qty);

        // Qty 5
        qty = 0.0;
        if (totalParametersQTY > 4) {
            cell = tableQTY.cell({ row: rowIdx, column: 40 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param5Values.push(qty);

        // Qty 6
        qty = 0.0;
        if (totalParametersQTY > 5) {
            cell = tableQTY.cell({ row: rowIdx, column: 41 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param6Values.push(qty);

        // Qty 7
        qty = 0.0;
        if (totalParametersQTY > 6) {
            cell = tableQTY.cell({ row: rowIdx, column: 42 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param7Values.push(qty);

        // Qty 8
        qty = 0.0;
        if (totalParametersQTY > 7) {
            cell = tableQTY.cell({ row: rowIdx, column: 42 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param8Values.push(qty);

        // Qty 9
        qty = 0.0;
        if (totalParametersQTY > 8) {
            cell = tableQTY.cell({ row: rowIdx, column: 43 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param9Values.push(qty);

        // Qty 10
        qty = 0.0;
        if (totalParametersQTY > 8) {
            cell = tableQTY.cell({ row: rowIdx, column: 44 }).node();
            value = $('input', cell).val();
            if (value == '') {
                qty = 0.0;
            }
            else {
                qty = parseFloat(value);
                if (isNaN(qty)) {
                    alert("Invalid Qty");
                    valid = false;
                }
            }
        }
        param10Values.push(qty);
    });

    if (!valid) {
        hideSpinner();
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/QuantityManager/UpdateQty',
        data: {
            'code': project,
            'mainitemsstr': JSON.stringify(mainItems),
            'tagtypesstr': JSON.stringify(tagtypes),
            'lotstr': JSON.stringify(lots),
            'drawrevaccstr': JSON.stringify(drawrevacc),
            'budgetstr': JSON.stringify(budgetqty),
            'wrqtystr': JSON.stringify(wrqty),
            'ifrqtystr': JSON.stringify(ifrqty),
            'ifcqtystr': JSON.stringify(ifcqty),
            'qtyaccstr': JSON.stringify(qtyacc),
            'qtynextcestr': JSON.stringify(qtynextce),
            'qtyholdstr': JSON.stringify(qtyhold),
            'qtyrebarstr': JSON.stringify(qtyrebar),
            'qtyconnincstr': JSON.stringify(qtyconninc),
            'qtyvolstr': JSON.stringify(qtyvol),
            'param1ValuesStr': JSON.stringify(param1Values),
            'param2ValuesStr': JSON.stringify(param2Values),
            'param3ValuesStr': JSON.stringify(param3Values),
            'param4ValuesStr': JSON.stringify(param4Values),
            'param5ValuesStr': JSON.stringify(param5Values),
            'param6ValuesStr': JSON.stringify(param6Values),
            'param7ValuesStr': JSON.stringify(param7Values),
            'param8ValuesStr': JSON.stringify(param8Values),
            'param9ValuesStr': JSON.stringify(param9Values),
            'param10ValuesStr': JSON.stringify(param10Values)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
            window.location = '/cmd/QuantityManager/Manager?code=' + project;
        },
        error: function (response, error) {
            hideSpinner();
            alert(response.responseText);
        },
    });
}

function applyQtyValue() {
    loadSpinner();
    setProgressMessage("Apply quantities");

    // Get selected columns
    var colIds = [];
    for (let i = 0; i < editableColumnsQtyManager.length; i++) {
        var col1 = document.getElementById("checkBoxVal" + editableColumnsQtyManager[i]).checked;
        if (col1) {
            colIds.push(editableColumnsQtyManager[i]);
        }
    }

    if (totalParametersQTY > 0) {
        colParam1 = document.getElementById("checkBoxVal37").checked;
        colIds.push(37);
    }
    if (totalParametersQTY > 1) {
        colParam1 = document.getElementById("checkBoxVal38").checked;
        colIds.push(38);
    }
    if (totalParametersQTY > 2) {
        colParam1 = document.getElementById("checkBoxVal39").checked;
        colIds.push(39);
    }
    if (totalParametersQTY > 3) {
        colParam1 = document.getElementById("checkBoxVal40").checked;
        colIds.push(40);
    }
    if (totalParametersQTY > 4) {
        colParam1 = document.getElementById("checkBoxVal41").checked;
        colIds.push(41);
    }
    if (totalParametersQTY > 5) {
        colParam1 = document.getElementById("checkBoxVal42").checked;
        colIds.push(42);
    }
    if (totalParametersQTY > 6) {
        colParam1 = document.getElementById("checkBoxVal43").checked;
        colIds.push(43);
    }
    if (totalParametersQTY > 7) {
        colParam1 = document.getElementById("checkBoxVal44").checked;
        colIds.push(44);
    }
    if (totalParametersQTY > 8) {
        colParam1 = document.getElementById("checkBoxVal45").checked;
        colIds.push(45);
    }
    if (totalParametersQTY > 9) {
        colParam1 = document.getElementById("checkBoxVal46").checked;
        colIds.push(46);
    }

    // Apply to selected items
    if (colIds.length > 0) {
        tableQTY.rows().every(function (rowIdx, tableLoop, rowLoop) {
            colIds.forEach(colIdx => updateQuantityManagerTableValues(colIdx, rowIdx));
        });
    }

    hideSpinner();
}

function updateQuantityManagerTableValues(colIdx, rowIdx) {
    var valueToApply = $('#inputValue').val();

    var cell = tableQTY.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        if (colIdx == 13) {
            cell = tableQTY.cell({ row: rowIdx, column: colIdx }).node();
            $('input', cell).val(valueToApply);
        }
        else {
            // Parse float
            var val = parseFloat(valueToApply);
            if (val && val > 0.0) {
                cell = tableQTY.cell({ row: rowIdx, column: colIdx }).node();
                $('input', cell).val(val);
            }
        }
    }
}

function checkAllColQtyManager() {
    var colChecked = document.getElementById("checkboxAllColumn").checked;
    document.getElementById("checkboxQTYBudget").checked = colChecked;
    document.getElementById("checkboxQTYWR").checked = colChecked;
    document.getElementById("checkboxQTYCE").checked = colChecked;
    document.getElementById("checkboxQTYREINF").checked = colChecked;
}

function checkAllItemQtyManager() {
    var itemsChecked = document.getElementById("checkboxAllItems").checked;
    var cell = null;
    var input = null;
    tableQTY.rows().every(function (rowIdx, tableLoop, rowLoop) {
        cell = tableQTY.cell({ row: rowIdx, column: 0 }).node();
        input = $('input', cell);
        input.prop("checked", itemsChecked);
    });
    tableQTY.draw();
}

function OnChangeQtyFormulaEvent(element) {
    var element = "";
}

function applyQtyCE() {
    loadSpinner();
    setProgressMessage("Apply QTE CE..");

    var inputValue = document.getElementById('inputQTYCEValue').value;
    if (inputValue) {

        tableQTY.rows().every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableQTY.cell({ row: rowIdx, column: 0 }).node();
            var checked = $('input', cell).prop("checked");
            if (checked) {
                var cell = tableQTY.cell({ row: rowIdx, column: 23 });
                qty = cell.data();

                cell = tableQTY.cell(this, 26).node();
                $('input', cell).val(qty * inputValue);

                if (qty > 0.0) {
                    cell = tableQTY.cell(this, 25).node();
                    $('input', cell).val(inputValue);
                }
            }
        });
    }

    hideSpinner();
}

function hideEventsColumnsQtyManager() {
    for (let i = 1; i <= tableQTYTotalColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableQTY.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableQTY);
        })
    }
}

function importExcelQuantityManagerTemplate() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Import Main Items..");

    $.ajax({
        url: '/cmd/ItemListCreation/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/QuantityManager/Manager?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/QuantityManager/Manager?code=' + project;
        }
    });
}