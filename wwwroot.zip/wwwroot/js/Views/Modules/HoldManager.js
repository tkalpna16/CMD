﻿var tableHoldsManager = null;
var totalHoldColumns = 23;

$(document).ready(function () {
    // Main Settings
    setTitle("Hold Manager"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    showElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#holdManagerBtn"); // Hide Hold Button

    $("#btnDownloadExcel").click(function () {
        createExcelHold();
    });
    $("#btnImportExcel").click(function () {
        $("#modalExcel").modal('show');
    });

    $('.datepicker').datepicker({
        changeMonth: true,
        changeYear: true,
        format: "yyyy/mm/dd",
        language: "en"
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });

    // Create Button Event
    $("#btnGetExcelTemplate").click(function () {
        $.ajax({
            type: 'GET',
            url: '/cmd/HoldManager/GetTemplate',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var link = document.createElement('a');
                link.href = "/cmd/Report/TemplateHold.xlsx";
                link.download = "TemplateHold.xlsx";
                link.click();
            },
            error: function (data) {
                alert(data);
            }
        });
    });



    // Init UI
    InitTableHoldsManager();
    setMultiselectHolds();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('#rowTable').show();
    tableHoldsManager.columns.adjust();
});

var tableHoldsManager = null;

function InitTableHoldsManager() {
    tableHoldsManager = $('#tableHoldManager').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        responsive: true,
        orderCellsTop: true,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        sScrollX: '100%',
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "width": "200px", "targets": 16 },
            { "width": "200px", "targets": 24 },
            { "targets": [0, totalHoldColumns], "searchable": false },
            {
                "targets": [0, totalHoldColumns], //first column / numbering column
                "orderable": false, //set not orderable
            }
        ],
        order: [
            [3, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        }
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableHoldManagerSearch();
    });

    $("#inputSelectAll").on("change", function () {
        var checked = $(this).prop("checked");
        tableHoldsManager.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        tableHoldsManager.draw();

        colorDatatableAllRow(tableHoldsManager);
    });

    // Hide colums
    for (let i = 1; i <= totalHoldColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        tableHoldsManager.column(i).visible(checkbox.checked);
    }

    hideEventsColumnsHold();
}

function updateTableHoldManagerSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableHoldsManager.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalHoldColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableHoldsManager.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableHoldsManager.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function ApplyValueHolds() {
    var value = $('#inputValue').val();

    var holdQtyChecked = document.getElementById("checkBoxVal15").checked;
    var holdDescrChecked = document.getElementById("checkBoxVal16").checked;
    var colDate1 = document.getElementById("checkBoxVal19").checked;
    var colDate2 = document.getElementById("checkBoxVal20").checked;
    var colDate3 = document.getElementById("checkBoxVal21").checked;

    if (holdQtyChecked && (colDate1 || colDate2 || colDate3)) {
        alert("Invalid type of data");
        return;
    }

    var rowChecked;
    var cell;

    tableHoldsManager.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (holdQtyChecked) {
            var valueFloat = parseFloat(value);
            if (valueFloat && valueFloat >= 0.0) {
                cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
                rowChecked = $('input', cell).prop('checked');
                if (rowChecked) {
                    cell = tableHoldsManager.cell({ row: rowIdx, column: 15 }).node();
                    $('input', cell).val(value);
                }
            }
        }
        if (holdDescrChecked) {
            cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
            rowChecked = $('input', cell).prop('checked');
            if (rowChecked) {
                cell = tableHoldsManager.cell({ row: rowIdx, column: 16 }).node();
                $('input', cell).val(value);
            }
        }
        if (colDate1) {
            var inputDate = moment(value);
            if (inputDate.isValid()) {
                var valueDate = inputDate.format('YYYY/MM/DD');
                cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
                rowChecked = $('input', cell).prop('checked');
                if (rowChecked) {
                    cell = tableHoldsManager.cell({ row: rowIdx, column: 19 }).node();
                    $('input', cell).val(valueDate);
                }
            }
        }
        if (colDate2) {
            var inputDate = moment(value);
            if (inputDate.isValid()) {
                var valueDate = inputDate.format('YYYY/MM/DD');
                cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
                rowChecked = $('input', cell).prop('checked');
                if (rowChecked) {
                    cell = tableHoldsManager.cell({ row: rowIdx, column: 20 }).node();
                    $('input', cell).val(valueDate);
                }
            }
        }
        if (colDate3) {
            var inputDate = moment(value);
            if (inputDate.isValid()) {
                var valueDate = inputDate.format('YYYY/MM/DD');
                cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
                rowChecked = $('input', cell).prop('checked');
                if (rowChecked) {
                    cell = tableHoldsManager.cell({ row: rowIdx, column: 21 }).node();
                    $('input', cell).val(valueDate);
                }
            }
        }
    });
    tableHoldsManager.draw();
}

function SaveHolds() {
    loadSpinner();

    var project = $('#labelProject').text();

    // GetData
    var holdIds = [];
    var qty = [];
    var types = [];
    var foredate = [];
    var foreactual = [];
    var actualdate = [];
    var cell;

    tableHoldsManager.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cell = tableHoldsManager.cell({ row: rowIdx, column: 0 }).node();
        value = $('span', cell).text();
        values = parseInt(value);
        holdIds.push(value);

        cell = tableHoldsManager.cell({ row: rowIdx, column: 15 }).node();
        value = $('input', cell).val();
        value = parseFloat(value);
        if (value && value >= 0.0) {
            qty.push(value);
        }
        else {
            qty.push(0.0);
        }

        cell = tableHoldsManager.cell({ row: rowIdx, column: 16 }).node();
        value = $('option:selected', cell).val();
        types.push(value);

        cell = tableHoldsManager.cell({ row: rowIdx, column: 19 }).node();
        value = $('input', cell).val();
        foredate.push(value);

        cell = tableHoldsManager.cell({ row: rowIdx, column: 20 }).node();
        value = $('input', cell).val();
        foreactual.push(value);

        cell = tableHoldsManager.cell({ row: rowIdx, column: 21 }).node();
        value = $('input', cell).val();
        actualdate.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/HoldManager/UpdateHolds',
        data: {
            'code': project,
            'holdIdsstr': JSON.stringify(holdIds),
            'qtystr': JSON.stringify(qty),
            'typesstr': JSON.stringify(types),
            'foredatestr': JSON.stringify(foredate),
            'foreactualstr': JSON.stringify(foreactual),
            'actualdatestr': JSON.stringify(actualdate)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
            hideSpinner();
            var url= '/cmd/HoldManager/Index?code=' + project;
            window.location.href = url;
        },
        error: function (response, error) {
            alert(response.responseText);
            hideSpinner();
            var url= '/cmd/HoldManager/Index?code=' + project;
            window.location.href = url;
        },
    });
}

function hideEventsColumnsHold() {
    for (let i = 1; i <= totalHoldColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableHoldsManager.column(i).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableHoldsManager);
        })
    }
}

function showModalNewHold() {
    $("#modalHoldTypes").modal('show');
}

function setMultiselectHolds() {
    $('#selectMainItemTags').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#selectTagType').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: false,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#selectTagLot').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: false,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });
}

function CreateMultipleHold() {
    // projectId
    var code = $('#labelProject').text();

    // Item Tags
    var selectedItemTags = [];
    $('#selectMainItemTags :selected').each(function () {
        selectedItemTags.push($(this).text());
    });
    if (selectedItemTags.length == 0) {
        alert("Any Item Tag selected!!");
        return;
    }

    var holdQty = $('#inputHoldQty').val();
    holdQty = parseFloat(holdQty);
    if (holdQty <= 0.0) {
        alert("Invalid Hold Qty!!");
        return;
    }

    var holdType = $('#selectHold').val();
    if (holdType == '') {
        alert("Any Hold Description selected!!");
        return;
    }

    loadSpinnerModal();
    setProgressMessageModal("Creating Holds..");

    $.ajax({
        type: 'POST',
        url: '/cmd/HoldManager/CreateHolds',
        data: {
            'code': code,
            'mainitemsstr': JSON.stringify(selectedItemTags),
            'holdQty': holdQty,
            'holdType': holdType
        },
        dataType: 'text',
        success: function (response) {
            hideSpinnerModal();
            alert(response);
            var url= '/cmd/HoldManager/Index?code=' + code;
            window.location.href = url;
        },
        error: function (val) {
            hideSpinnerModal();
            alert(response.responseText);
            var url= '/cmd/HoldManager/Index?code=' + code;
            window.location.href = url;
        }
    });
}


function createExcelHold() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    loadSpinner();

    var url= '/cmd/HoldManager/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/HoldList.xlsx";
            link.download = project + "-Hold-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });
}

function importExcelMainItemsHold() {
    // Add Item List
    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }

    var fileInput = document.getElementById('inputFile');
    if (fileInput.files.length == 0) {
        alert("Select an Excel file!!")
        return;
    }
    var file = fileInput.files[0];
    var formData = new FormData();
    formData.append('postedFile', file);
    formData.append('code', project);

    loadSpinnerModal();
    setProgressMessageModal("Create Main Items..");

    $.ajax({
        url: '/cmd/HoldManager/ImportExcel',
        contentType: false,
        processData: false,
        type: 'post',
        data: formData,
        success: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/HoldManager/Index?code=' + project;
        },
        error: function (val) {
            hideSpinnerModal();
            showExcelLogsAlert(val);
            var project = $('#labelProject').text();
            window.location = '/cmd/HoldManager/Index?code=' + project;
        }
    });
}

function deleteCurrentHold(button) {
    var row = $(button).closest("tr");
    var id = row.find("span").html();
    var url = "/cmd/HOLDMANAGER/DeleteHold?id=" + id;
    $.ajax({
        type: "POST",
        url: url,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            if (response == STATUS_DELETED) {
                var project = $('#labelProject').text();
                window.location = '/cmd/HoldManager/Index?code=' + project;
            }
            else {
                displayMessage(response);
            }
        },
        error: function (response, error) {
            if (response.responseText == STATUS_DELETED) {
                var project = $('#labelProject').text();
                window.location = '/cmd/HoldManager/Index?code=' + project;
            }
            else {
                displayMessage(response.responseText);
            }
        },
    });
}