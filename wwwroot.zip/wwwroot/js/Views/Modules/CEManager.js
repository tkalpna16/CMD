﻿var tableCEQTY;

$(document).ready(function () {
    // Main Settings
    setTitle("CE Submission"); // Set Title
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    disable("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disable("#modelQtyManagerBtn"); // Hide PBS Button

    $("#btnDownloadExcel").click(function () {
        SaveCEQtyExcel();
    });

    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/QuantityManager/Manager?code=' + project;
        window.location.href = url;
    });

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    InitTableQuantityCE();

    $("#selectRevision1").change(function () {
        UpdateTableCEQty();
    });
    $("#selectRevision2").change(function () {
        UpdateTableCEQty();
    });

    // Select Actual and Last
    var hasOptionActual = $("option:contains('Actual')", "#selectRevision1").length == 1;
    if (hasOptionActual) {
        document.getElementById("selectRevision1").value = "Actual";
    }
    var count = $('#selectRevision2 option').length;
    if (count > 0) {
        document.getElementById("selectRevision2").selectedIndex = 0;
    }
    UpdateTableCEQty();
});

function UpdateTableCEQty(){

    var revision1 = $("#selectRevision1").val();
    var revision2 = $("#selectRevision2").val();

    var project = $('#labelProject').text();

    loadSpinner();
    tableCEQTY.clear();

    $.ajax({
        type: 'POST',
        url: '/cmd/QuantityManager/GetQtyCERevision',
        data: {
            'code': project,
            'revision1str': revision1,
            'revision2str': revision2
        },
        dataType: 'text',
        success: function (response) {
            var element = JSON.parse(response);;
            for (var i = 0; i < element.length; i++)
                addRowCEQty(element[i]);

            // Change header
            var text1 = '';
            if (revision1 == 'Actual') {
                text1 = "[Actual]";
            }
            else {
                text1 = "[" + revision1.split('-')[1] + "]";
            }
            var text2 = '';
            if (revision2 == 'Actual') {
                text2 = "[Actual]";
            }
            else {
                text2 = "[" + revision2.split('-')[1] + "]";
            }
            $('#ceDate1').text(text1);
            $('#ceDate2').text(text2);

            tableCEQTY.draw(true);
            hideSpinner();
        },
        error: function (response, error) {
            alert(response);
            hideSpinner();
        },
    });
}

function addRowCEQty(qty) {
    tableCEQTY.row.add([
        qty.mainItemTag,
        qty.tagTypeDescription,
        qty.lot,
        qty.qtyCE1,
        qty.qtyCE2,
        qty.deltaCE
    ]).draw(false);
}

function InitTableQuantityCE() {
    tableCEQTY = $('#tableCEManager').DataTable({
        dom: 'Rrtip',
        responsive: true,
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, 5], "searchable": true },
            {
                "targets": [0, 5], //first column / numbering column
                "orderable": false, //set not orderable
            }
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
        order: [
            [0, 'asc']
        ]
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableCEManagerSearch();
    });
}

function updateTableCEManagerSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableCEQTY.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= 5; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableCEQTY.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableCEQTY.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function SaveQtyCE() {
    var project = $('#labelProject').text();

    $.ajax({
        type: 'POST',
        url: '/cmd/QuantityManager/SaveQtyCE',
        data: {
            'code': project
        },
        dataType: 'text',
        success: function (response) {
            window.location = '/cmd/QuantityManager/CESubmission?code=' + project;
        },
        error: function (response, error) {
            alert(response.responseText);
            window.location = '/cmd/QuantityManager/CESubmission?code=' + project;
        },
    });
}

function DeleteQtyCERevision() {
    var project = $('#labelProject').text();
    var revision1 = $("#selectRevision1").val();
    if (revision1 == '' && revision1 != 'Actual') {
        alert("Invalid revision");
        return;
    }

    loadSpinner();
    $.ajax({
        type: 'POST',
        url: '/cmd/QuantityManager/DeleteCERevision',
        data: {
            'code': project,
            'revisionstr': revision1
        },
        dataType: 'text',
        success: function (response) {
            hideSpinner();
            displayMessage('messageLabel', response);
            window.location = '/cmd/QuantityManager/CESubmission?code=' + project;
        },
        error: function (response, error) {
            hideSpinner();
            displayMessage('messageLabel', response.responseText);
            window.location = '/cmd/QuantityManager/CESubmission?code=' + project;
        },
    });
}

function SaveCEQtyExcel() {

    var revision1 = $("#selectRevision1").val();
    var revision2 = $("#selectRevision2").val();

    var project = $('#labelProject').text();

    loadSpinner();


    var url= '/cmd/QuantityManager/CreateExcelCERev';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project,
            'revision1str': revision1,
            'revision2str': revision2
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/CE.xlsx";
            link.download = project + "-CE-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            hideSpinner();
        }
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/QuantityManager/GetQtyCERevision',
        data: {
            'code': project,
            'revision1str': revision1,
            'revision2str': revision2
        },
        dataType: 'text',
        success: function (response) {
            var element = JSON.parse(response);;
            for (var i = 0; i < element.length; i++)
                addRowCEQty(element[i]);
            tableCEQTY.draw(true);
            hideSpinner();
        },
        error: function (response, error) {
            alert(response);
            hideSpinner();
        },
    });
}

