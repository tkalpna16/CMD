﻿var tableDLDrawings = null;
var totalDLDrawingsColumns = 15;

$(document).ready(function () {
    // Set Title
    setTitle("DL Generator");
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar
    showElement("#btnDownloadExcel"); // Show Navbar
    disable("#btnImportExcel"); // Show Navbar

    // Additional buttons
    var role = $("#labelRole").text();
    if (role == 'Admin' || role == 'Discipline Leader') {
        InitCommandsItemListDLDrawings();
        showElement("#btnCommand1");
        $("#btnCommand1").click(function () {
            editDLSettings();
        });
    }

    showElement("#navTopButton"); // Show Navbar
    disableLink("#dlGeneratorBtn"); // Hide PBS Button

    // Init Buttons
    $("#btnDownloadExcel").click(function () {
        createDLDrawingExcel();
    });
    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        var url= '/cmd/PROJECTS/DataManagement?code=' + project;
        window.location.href = url;
    });

    // Init UI
    InitTableDrawings();
    UpdateCommandVisibility();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    document.getElementById('inputSelectedRevision').onchange = function () {
        updateDLRevision();
    };

    $('#rowTable').show();
    tableDLDrawings.columns.adjust();

    var len = document.getElementById("inputSelectedRevision").length;
    if (len > 0) {
        $("#btnCreateDL").html('Update');
    }

    var currentRev = $("#revisionLabel").text();
    $("#inputSelectedRevision").val(currentRev);
});

function InitTableDrawings() {

    tableDLDrawings = $('#tableDrawings').DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '58vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        order: [
            [4, 'asc']
        ],
        search: {
            "caseInsensitive": true
        },
        initComplete: (settings, json) => {
            $('.dataTables_paginate').insertAfter('div#tablePaginationDiv');
        },
    });

    // Set table search
    $('#tableSearch').on('input', function (e) {
        updateTableDLMainSearch();
    });

    // Hide colums
    for (let i = 1; i <= totalDLDrawingsColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        tableDLDrawings.column(i - 1).visible(checkbox.checked);
    }

    hideEventsColumnsDL();
}

function updateTableDLMainSearch() {
    var filter = $('#tableSearch').val();

    // Reset filter
    tableDLDrawings.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalDLDrawingsColumns; i++) {
        var col1 = document.getElementById("checkBox" + i).checked;
        if (col1) {
            colId.push(i - 1);
            var currentVal = $('#inputAD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        tableDLDrawings.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            tableDLDrawings.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function InitCommandsItemListDLDrawings() {
    $("#btnCommand1").html('Manage DL Settings');
}

function UpdateCommandVisibility() {
    var tableItems = $('#tableDrawings').DataTable();
    var count = tableItems.rows().count();
    if (count < 1) {
        hideElement("#divTableDrawings");
        showElement('#emptyRows');
    }
    else {
        showElement('#divTableDrawings');
        hideElement('#emptyRows');
    }
}

function CreateNewDL() {
    if (confirm("Do you want create a new DL?")) {
        var project = $('#labelProject').text();

        loadSpinner();
        setProgressMessage("Create DL..");

        $.ajax({
            type: 'GET',
            url: '/cmd/DLGENERATOR/CreateDrawingList?code=' + project,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                var url= '/cmd/DLGENERATOR/Index?code=' + project;
                window.location.href = url;
            },
            error: function (response, error) {
                var url= '/cmd/DLGENERATOR/Index?code=' + project;
                window.location.href = url;
            },
        });
    }
}

function updateDLRevision() {
    var project = $('#labelProject').text();
    var revision = $('#inputSelectedRevision').val();

    if (revision == '' && revision == null) {
        return;
    }

    var url= '/cmd/DLGENERATOR/Index?code=' + project + "&revision=" + revision.split("-")[0];
    window.location.href = url;
}

function addRowDL(element) {
    tableDLDrawings.row.add([
        element.tcmDrawingNumber,
        element.drawingDescription
    ]).draw(false);
}

function createDLDrawingExcel() {
    loadSpinner();
    setProgressMessage("Downloading Excel..");

    var project = $('#labelProject').text();
    if (!project || project == '') {
        alert("Any Project selected!!");
        return;
    }
    var revision = $('#inputSelectedRevision').val();

    var url= '/cmd/DLGENERATOR/CreateExcel';
    $.ajax({
        type: "GET",
        url: url,
        contentType: "application/json; charset=utf-8",
        data: {
            'code': project,
            'revision': revision
        },
        dataType: "json",
        success: function (data) {
            var now = new Date();
            var dateString = moment(now).format('YYYYMMDD');
            var link = document.createElement('a');
            link.href = "/cmd/Temp/DL.xlsx";
            link.download = project + "-DL-Rev" + revision + "-" + dateString + ".xlsx";
            link.click();
            hideSpinner();
        },
        error: function (response) {
            alert(response.responseText);
            hideSpinner();
        }
    });
}

function editDLSettings() {
    var project = $('#labelProject').text();
    var url= '/cmd/DLGENERATOR/Edit?code=' + project;
    window.location.href = url;
}

function DeleteDL() {
    var revision = $('#inputSelectedRevision').val();
    if (revision == '' || revision == null) {
        return;
    }

    if (confirm("Do you want delete existing DL?")) {
        var project = $('#labelProject').text();

        loadSpinner();
        setProgressMessage("Delete DL..");

        $.ajax({
            type: 'POST',
            url: '/cmd/DLGENERATOR/DeleteRevision',
            data: {
                'code': project,
                'revisionstr': revision
            },
            dataType: 'text',
            success: function (response) {
                var url= '/cmd/DLGENERATOR/Index?code=' + project;
                window.location.href = url;
            },
            error: function (response, error) {
                var url= '/cmd/DLGENERATOR/Index?code=' + project;
                window.location.href = url;
            },
        });
    }
}

function hideEventsColumnsDL() {
    for (let i = 1; i <= totalDLDrawingsColumns; i++) {
        var checkbox = document.getElementById("checkBoxVis" + i);
        checkbox.addEventListener('change', (event) => {
            tableDLDrawings.column(i - 1).visible(event.currentTarget.checked);
            colorDatatableAllRow(tableDLDrawings);
        })
    }
}