﻿var secondCodes = ['AX', 'AACSSettings', 'AACS', 'AADASettings', 'AADA', 'AADCSettings', 'AADC', 'AAOthers', 'AG', 'AICS', 'AICSSettings', 'AIDU', 'AIDUSettings', 'AIOthers', 'APDASettings', 'APDA', 'APOthers', 'AQDASettings', 'AQDA', 'AQOthers', 'ARDASettings', 'ARDA', 'AROthers'];
var dlCodes = ['AX', 'AA', 'AG', 'AI', 'AP', 'AQ', 'AR']
var tableCodes = ['divTableAX', 'divTableAACSSettings', 'divTableAACS', 'divTableAADASettings', 'divTableAADA', 'divTableAADCSettings', 'divTableAADC', 'divTableAAOthers', 'divTableAG', 'divTableAICSSettings', 'divTableAICS', 'divTableAIDU', 'divTableAIDUSettings', 'divTableAIOthers', 'divTableAPDASettings', 'divTableAPDA', 'divTableAPOthers', 'divTableAQDASettings', 'divTableAQDA', 'divTableAQOthers', 'divTableARDASettings', 'divTableARDA', 'divTableAROthers']
var pressedBntClass = 'btn-success';
var notPressedBntClass = 'btn-light';
var dlSettingsTables = [];

$(document).ready(function () {
    // Set Title
    setTitle("Manage DL Settings");
    showElement("#navbarSupportedContent"); // Show Navbar
    showElement("#labelNavProject"); // Show Navbar
    showElement("#labelNavProjectName"); // Show Navbar

    hideElement("#btnDownloadExcel"); // Show Navbar
    hideElement("#btnImportExcel"); // Show Navbar

    showElement("#navTopButton"); // Show Navbar
    disableLink("#dlGeneratorBtn"); // Hide PBS Button

    // Init Buttons
    $("#btnPrevious").click(function () {
        var project = $('#labelProject').text();
        //var url: '/cmd/DLGenerator/Index?code=' + project;
        var url= '/cmd/DLGenerator/Index?code=' + project;
        window.location.href = url;
    });

    // Hide All
    HideAllColumn();
    HideAllDLTables();

    InitDLTables();

    // Init Dropdowns
    $('.dropdown-toggle').dropdown();

    $('.dropdown-submenu button.btn').on("click", function (e) {
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    SetSettings();
});

function InitDLTables() {
    InitDLTable(secondCodes[0], 3);
    InitDLTable(secondCodes[2], 5);
    InitDLTable(secondCodes[4], 6);
    InitDLTable(secondCodes[6], 9);
    InitDLTable(secondCodes[7], 3);
    InitDLTable(secondCodes[8], 3);
    InitDLTable(secondCodes[9], 4);
    InitDLTable(secondCodes[11], 7);
    InitDLTable(secondCodes[13], 3);
    InitDLTable(secondCodes[15], 6);
    InitDLTable(secondCodes[16], 3);
    InitDLTable(secondCodes[18], 6);
    InitDLTable(secondCodes[19], 3);
    InitDLTable(secondCodes[21], 6);
    InitDLTable(secondCodes[22], 3);

    //secondCodes.forEach(element => InitDLTable('table' + element, '30vh'));
}

function InitDLTable(code, totalColumns) {
    var tableid = '#table' + code;
    var tableidhtml = 'table' + code;
    var table = $(tableid).DataTable({
        dom: 'Rrtip',
        paging: true,
        pageLength: 500,
        orderCellsTop: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        colReorder: {
            'allowReorder': false
        },
        bAutoWidth: true,
        scrollY: '55vh',
        scrollCollapse: true,
        language: {
            "zeroRecords": "",
            "emptyTable": "",
            "paginate": {
                "previous": "<",
                "next": ">"
            },
            search: '<i class="fa fa-search" aria-hidden="true" style="margin-right:20px"></i>',
            searchPlaceholder: 'Search...'
        },
        "columnDefs": [
            { "targets": [0, totalColumns], "searchable": true },
            {
                "targets": [0, totalColumns], //first column / numbering column
                "orderable": false, //set not orderable
            },
            { width: 100, targets: 0 }
        ],
        order: [
            [1, 'asc']
        ],
        search: {
            "caseInsensitive": true
        }
    });

    // Set table search
    $('#tableSearch' + code).on('input', function (e) {
        updateTableDLEditSearch(totalColumns, code, table);
    });

    updateTableDLEditSearch(totalColumns, code, table);

    $("#inputSelectAll" + code).on("change", function () {
        var checked = $(this).prop("checked");
        table.rows({ filter: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
            cell = table.cell({ row: rowIdx, column: 0 }).node();
            input = $('input', cell);
            input.prop("checked", checked);
        });
        table.draw();

        colorDatatableAllRow(table);
    });

    dlSettingsTables.push(table);
}

function updateTableAXSearch() {
    updateTableDLEditSearch(3, 'AX', dlSettingsTables[0]);
}
function updateTableAACSSearch() {
    updateTableDLEditSearch(5, 'AACS', dlSettingsTables[1]);
}
function updateTableAADASearch() {
    updateTableDLEditSearch(5, 'AADA', dlSettingsTables[2]);
}
function updateTableAADCSearch() {
    updateTableDLEditSearch(9, 'AADC', dlSettingsTables[3]);
}
function updateTableAAOthersSearch() {
    updateTableDLEditSearch(2, 'AAOthers', dlSettingsTables[4]);
}
function updateTableAGSearch() {
    updateTableDLEditSearch(2, 'AG', dlSettingsTables[5]);
}
function updateTableAICSSearch() {
    updateTableDLEditSearch(2, 'AICS', dlSettingsTables[6]);
}
function updateTableAIDUSearch() {
    updateTableDLEditSearch(2, 'AIDU', dlSettingsTables[7]);
}
function updateTableAIOthersSearch() {
    updateTableDLEditSearch(2, 'AIOthers', dlSettingsTables[8]);
}
function updateTableAPDASearch() {
    updateTableDLEditSearch(2, 'APDA', dlSettingsTables[9]);
}
function updateTableAPOthersSearch() {
    updateTableDLEditSearch(2, 'APOthers', dlSettingsTables[10]);
}
function updateTableAQDASearch() {
    updateTableDLEditSearch(2, 'AQDA', dlSettingsTables[11]);
}
function updateTableAQOthersSearch() {
    updateTableDLEditSearch(2, 'AQOthers', dlSettingsTables[12]);
}
function updateTableARDASearch() {
    updateTableDLEditSearch(6, 'ARDA', dlSettingsTables[13]);
}
function updateTableAROthersSearch() {
    updateTableDLEditSearch(2, 'AROthers', dlSettingsTables[14]);
}

function updateTableDLEditSearch(totalColumns, code, table) {
    var filter = $('#tableSearch' + code).val();

    // Reset filter
    table.search('')
        .columns().search('')
        .draw();

    var colId = [];
    var colFilterVal = [];
    for (let i = 1; i <= totalColumns; i++) {
        var col1 = document.getElementById("checkBox" + code + + i).checked;
        if (col1) {
            colId.push(i);
            var currentVal = $('#input' + code + 'AD' + i).val();
            if (currentVal != null && currentVal != '') {
                colFilterVal.push(currentVal);
            }
            else {
                colFilterVal.push(filter);
            }
        }
    }

    if (colId.length == 0) {
        table.search(filter).draw(true);
    }
    else {
        for (let i = 0; i < colId.length; i++) {
            table.column(colId[i]).search(colFilterVal[i]).draw(true);
        }
    }
}

function HideDLColumn(code) {
    $("#columnButton" + code).hide();
}
function ShowDLColumn(code) {
    $("#columnButton" + code).show();
}
function HideAllColumn() {
    dlCodes.forEach(element => HideDLColumn(element));
}
function SetDLBtnPressed(id) {
    $("#" + id).removeClass(notPressedBntClass);
    $("#" + id).addClass(pressedBntClass);
}
function SetDLBtnNotPressed(id) {
    $("#" + id).removeClass(pressedBntClass);
    $("#" + id).addClass(notPressedBntClass);
}
function RemoveAllButtonPressed() {
    dlCodes.forEach(element => SetDLBtnNotPressed('btn' + element));
}
function clickDLMainButton(clicked_id) {
    HideAllColumn();
    HideAllDLTables();
    RemoveAllButtonPressed();
    SetDLBtnPressed(clicked_id);
    if (clicked_id != '') {
        var colName = clicked_id.replace('btn', '');
        ShowDLColumn(colName);
        if (colName != 'AX' && colName != 'AG') {
            var divId = 'columnButton' + colName;
            SetDLSecondaryButtonNotPressed(divId);
        }
        else {
            var divTableName = '#divTable' + colName;
            showElement(divTableName);
            var tableName = '#table' + colName;
            var table = $(tableName).DataTable().columns.adjust();
        }
    }
}
function SetDLSecondaryButtonNotPressed(divId) {
    var btns = document.getElementById(divId).querySelectorAll(":scope > .btn");
    btns.forEach(element => SetDLBtnNotPressed(element.id));
}
function clickDLSecondaryButton(clicked_id, div_id) {
    SetDLSecondaryButtonNotPressed(div_id);
    SetDLBtnPressed(clicked_id);
    HideAllDLTables();
    var colName = clicked_id.replace('btn', '');
    showElement('#divTable' + colName);
    var tableName = '#table' + colName;
    var table = $(tableName).DataTable().columns.adjust();
}
function clickDLSecondaryButtonSettings(clicked_id, div_id) {
    HideAllDLTables();
    var colName = clicked_id.replace('btn', '');
    showElement('#divTable' + colName);
}
function HideAllDLTables() {
    tableCodes.forEach(element => hideElement('#' + element));
}
function SaveCommonDocuments() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    var table = $('#tableAX').DataTable();
    var valid = true;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        if (!valid)
            return;
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();

        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        docNumber.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAAOthers() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    var table = $('#tableAAOthers').DataTable();
    var valid = true;
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        docNumber.push(value);

        if (value < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        if (value > maxValue) {
            alert("Bigger than max value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAG() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAG').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();

        var valint = parseInt(value);
        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        docNumber.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',        
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAIOthers() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAIOthers').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        docNumber.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',        
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAPOthers() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAPOthers').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        docNumber.push(valint);
    });


    if (!valid)
        return;

    $.ajax({
        type: 'POST',        
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAQOthers() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAQOthers').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        docNumber.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAROthers() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAROthers').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[1]);
        docDescr.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();

        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        docNumber.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SaveAQDAWBS() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var areas = [];
    var cellnum;

    var table = $('#tableAQDAWBS').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value) || area < 0.0) {
            alert("Not correct value: " + value);
            return;
        }
        areas.push(area);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateAADAPiles',
        data: {
            'code': project,
            'itemstr': JSON.stringify(itemTags),
            'areastr': JSON.stringify(areas)
        },
        dataType: 'text',
        success: function (response) {
            var object = JSON.parse(response);
            alert(object.message);
            if (object.valid) {
                var documents = object.documents;
                if (documents) {
                    var counter = 0;
                    table.rows().every(function (rowIdx) {
                        var cell = table.cell(rowIdx, 1);
                        cell.data(documents[counter]).draw();
                        counter++;
                    });
                    //table.draw(true);
                }
            }
        },
        error: function (response, error) {
            var object = JSON.parse(response.responseText);
            alert(object.message);
        },
    });
}

/*
 * SETTINGS
 */
function SetSettings() {
    SetAACSSettings();
    SetAADASettings();

    SetAADCSettings();
    SetAACSSettings();
    SetAIDUSettings();

    SetAIDASettings();
    SetAICSSettings();
    SetAQDASettings();
    SetAPDASettings();
    SetARDASettings();
}
function SetAADASettings() {
    $("#AADADrawingScale").val(aadaDrawingScale);
    $("#AADADrawingSize").val(aadaDrawingSize);
    $("#inputAADAADrawingNum").val(aadaDrawingNum);
    $("#inputAADAAArea").val(aadaArea);
}
function SaveAADASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var scale = $("#AADADrawingScale").val();
    var size = $("#AADADrawingSize").val();
    var mindocs = $("#inputAADAADrawingNum").val();
    var area = $("#inputAADAAArea").val();

    $.ajax({
        type: 'POST',        
        url: '/cmd/DLGENERATOR/UpdateAADASettings',
        data: {
            'code': project,
            'scale': scale,
            'size': size,
            'numdrw': mindocs,
            'area': area
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAADASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAADASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAADA() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var itemTagTypes = [];
    var drawings = [];
    var cellnum;

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    var table = $('#tableAADA').DataTable();
    var valid = true;

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[1]);
        itemTagTypes.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        drawings.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',        
        url: '/cmd/DLGENERATOR/UpdateAADA',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(itemTagTypes),
            'drawingsStr': JSON.stringify(drawings)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response);
        },
    });
}
function SaveAADC() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var docs = [];
    var cellnum;

    var maxValue = parseInt($('#inputMaxManualDoc').text());
    var valid = true;

    var table = $('#tableAADC').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[1]);
        tagTypes.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 8 }).node();
        value = $('input', cellnum).val();
        docs.push(value);

        if (valid && value < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            return;
        }

        if (valid && value > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADC',
        url: '/cmd/DLGENERATOR/UpdateAADC',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'docsStr': JSON.stringify(docs)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response);
        },
    });
}
function showHelpAADC() {
    $("#modalViewFactor").modal('show');
}
function showHelpAIDU() {
    $("#modalViewSteelFactor").modal('show');
}
function SetAADCSettings() {
    $("#inputAADCFoundationPR_FP").val(aadcFoundationPR_FP);
    $("#inputAADCFoundationST_FP").val(aadcFoundationST_FP);
    $("#inputAADCFoundationEQ_FP").val(aadcFoundationEQ_FP);
    $("#inputAADCFoundationBL_FP").val(aadcFoundationBL_FP);
    $("#inputAADCFoundationBS_FP").val(aadcFoundationBS_FP);
    $("#inputAADCFoundationOther_FP").val(aadcFoundationOther_FP);

    $("#inputAADCFoundationPR_FW").val(aadcFoundationPR_FW);
    $("#inputAADCFoundationST_FW").val(aadcFoundationST_FW);
    $("#inputAADCFoundationEQ_FW").val(aadcFoundationEQ_FW);
    $("#inputAADCFoundationBL_FW").val(aadcFoundationBL_FW);
    $("#inputAADCFoundationBS_FW").val(aadcFoundationBS_FW);
    $("#inputAADCFoundationOther_FW").val(aadcFoundationOther_FW);

    $("#inputAADCFoundationPR_RF").val(aadcFoundationPR_RF);
    $("#inputAADCFoundationST_RF").val(aadcFoundationST_RF);
    $("#inputAADCFoundationEQ_RF").val(aadcFoundationEQ_RF);
    $("#inputAADCFoundationBL_RF").val(aadcFoundationBL_RF);
    $("#inputAADCFoundationBS_RF").val(aadcFoundationBS_RF);
    $("#inputAADCFoundationOther_RF").val(aadcFoundationOther_RF);

    $("#inputAADCFoundationPR_BBS").val(aadcFoundationPR_BBS);
    $("#inputAADCFoundationST_BBS").val(aadcFoundationST_BBS);
    $("#inputAADCFoundationEQ_BBS").val(aadcFoundationEQ_BBS);
    $("#inputAADCFoundationBL_BBS").val(aadcFoundationBL_BBS);
    $("#inputAADCFoundationBS_BBS").val(aadcFoundationBS_BBS);
    $("#inputAADCFoundationOther_BBS").val(aadcFoundationOther_BBS);

    $("#inputAADCElevationPR_EP").val(aadcElevationPR_EP);
    $("#inputAADCElevationST_EP").val(aadcElevationST_EP);
    $("#inputAADCElevationOther_EP").val(aadcElevationOther_EP);

    $("#inputAADCElevationPR_FW").val(aadcElevationPR_FW);
    $("#inputAADCElevationST_FW").val(aadcElevationST_FW);
    $("#inputAADCElevationOther_FW").val(aadcElevationOther_FW);

    $("#inputAADCElevationPR_RF").val(aadcElevationPR_RF);
    $("#inputAADCElevationST_RF").val(aadcElevationST_RF);
    $("#inputAADCElevationOther_RF").val(aadcElevationOther_RF);

    $("#inputAADCElevationPR_BBS").val(aadcElevationPR_BBS);
    $("#inputAADCElevationST_BBS").val(aadcElevationST_BBS);
    $("#inputAADCElevationOther_BBS").val(aadcElevationOther_BBS);

    $("#inputAADCElevationEQ").val(aadcElevationEQ);
    $("#inputAADCElevationBL").val(aadcElevationBL);
}
function SaveAADCSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var foundationPR_FP = $("#inputAADCFoundationPR_FP").val();
    var foundationST_FP = $("#inputAADCFoundationST_FP").val();
    var foundationEQ_FP = $("#inputAADCFoundationEQ_FP").val();
    var foundationBL_FP = $("#inputAADCFoundationBL_FP").val();
    var foundationBS_FP = $("#inputAADCFoundationBS_FP").val();
    var foundationOther_FP = $("#inputAADCFoundationOther_FP").val();

    var foundationPR_FW = $("#inputAADCFoundationPR_FW").val();
    var foundationST_FW = $("#inputAADCFoundationST_FW").val();
    var foundationEQ_FW = $("#inputAADCFoundationEQ_FW").val();
    var foundationBL_FW = $("#inputAADCFoundationBL_FW").val();
    var foundationBS_FW = $("#inputAADCFoundationBS_FW").val();
    var foundationOther_FW = $("#inputAADCFoundationOther_FW").val();

    var foundationPR_RF = $("#inputAADCFoundationPR_RF").val();
    var foundationST_RF = $("#inputAADCFoundationST_RF").val();
    var foundationEQ_RF = $("#inputAADCFoundationEQ_RF").val();
    var foundationBL_RF = $("#inputAADCFoundationBL_RF").val();
    var foundationBS_RF = $("#inputAADCFoundationBS_RF").val();
    var foundationOther_RF = $("#inputAADCFoundationOther_RF").val();

    var foundationPR_BBS = $("#inputAADCFoundationPR_BBS").val();
    var foundationST_BBS = $("#inputAADCFoundationST_BBS").val();
    var foundationEQ_BBS = $("#inputAADCFoundationEQ_BBS").val();
    var foundationBL_BBS = $("#inputAADCFoundationBL_BBS").val();
    var foundationBS_BBS = $("#inputAADCFoundationBS_BBS").val();
    var foundationOther_BBS = $("#inputAADCFoundationOther_BBS").val();

    var elevationPR_EP = $("#inputAADCElevationPR_EP").val();
    var elevationST_EP = $("#inputAADCElevationST_EP").val();
    var elevationOther_EP = $("#inputAADCElevationOther_EP").val();

    var elevationPR_FW = $("#inputAADCElevationPR_FW").val();
    var elevationST_FW = $("#inputAADCElevationST_FW").val();
    var elevationOther_FW = $("#inputAADCElevationOther_FW").val();

    var elevationPR_RF = $("#inputAADCElevationPR_RF").val();
    var elevationST_RF = $("#inputAADCElevationST_RF").val();
    var elevationOther_RF = $("#inputAADCElevationOther_RF").val();

    var elevationPR_BBS = $("#inputAADCElevationPR_BBS").val();
    var elevationST_BBS = $("#inputAADCElevationST_BBS").val();
    var elevationOther_BBS = $("#inputAADCElevationOther_BBS").val();

    var elevationEQ = $("#inputAADCElevationEQ").val();
    var elevationBL = $("#inputAADCElevationBL").val();


    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADCSettings',
        url: '/cmd/DLGENERATOR/UpdateAADCSettings',
        data: {
            'code': project,
            'foundationPR_FP': foundationPR_FP,
            'foundationST_FP': foundationST_FP,
            'foundationEQ_FP': foundationEQ_FP,
            'foundationBL_FP': foundationBL_FP,
            'foundationBS_FP': foundationBS_FP,
            'foundationOther_FP': foundationOther_FP,
            'foundationPR_FW': foundationPR_FW,
            'foundationST_FW': foundationST_FW,
            'foundationEQ_FW': foundationEQ_FW,
            'foundationBL_FW': foundationBL_FW,
            'foundationBS_FW': foundationBS_FW,
            'foundationOther_FW': foundationOther_FW,
            'foundationPR_RF': foundationPR_RF,
            'foundationST_RF': foundationST_RF,
            'foundationEQ_RF': foundationEQ_RF,
            'foundationBL_RF': foundationBL_RF,
            'foundationBS_RF': foundationBS_RF,
            'foundationOther_RF': foundationOther_RF,
            'foundationPR_BBS': foundationPR_BBS,
            'foundationST_BBS': foundationST_BBS,
            'foundationEQ_BBS': foundationEQ_BBS,
            'foundationBL_BBS': foundationBL_BBS,
            'foundationBS_BBS': foundationBS_BBS,
            'foundationOther_BBS': foundationOther_BBS,
            'elevationPR_EP': elevationPR_EP,
            'elevationST_EP': elevationST_EP,
            'elevationOther_EP': elevationOther_EP,
            'elevationPR_FW': elevationPR_FW,
            'elevationST_FW': elevationST_FW,
            'elevationOther_FW': elevationOther_FW,
            'elevationPR_RF': elevationPR_RF,
            'elevationST_RF': elevationST_RF,
            'elevationOther_RF': elevationOther_RF,
            'elevationPR_BBS': elevationPR_BBS,
            'elevationST_BBS': elevationST_BBS,
            'elevationOther_BBS': elevationOther_BBS,
            'elevationEQ': elevationEQ,
            'elevationBL': elevationBL
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAADCSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAADCSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAADCPlans() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var areas = [];
    var cellnum;

    var table = $('#tableAADCPlan').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
            alert("Not correct value: " + value);
            return;
        }
        areas.push(area);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADCFoundationPlan',
        url: '/cmd/DLGENERATOR/UpdateAADCFoundationPlan',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'areasStr': JSON.stringify(areas)
        },
        dataType: 'text',
        success: function (response) {
            var object = JSON.parse(response);
            displayMessage('messageLabelAADCPlan', object.message);
            if (object.valid) {
                var documents = object.documents;
                if (documents) {
                    var counter = 0;

                }
            }
        },
        error: function (response, error) {
            var object = JSON.parse(response.responseText);
            displayMessage('messageLabelAADCPlan', object.message);
        },
    });
}
function SaveAADCPipes() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var elevationFactors = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAADCPipeRacks').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationFactor = parseFloat(value);
        if (isNaN(value)) {
            elevationFactor = '';
        }
        elevationFactors.push(elevationFactor);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(value)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADCFactorsPipesStructures',
        url: '/cmd/DLGENERATOR/UpdateAADCFactorsPipesStructures',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors),
            'elevationFactorsStr': JSON.stringify(elevationFactors),
            'numOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCPipeRacks', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCPipeRacks', response.responseText);
        },
    });
}
function SaveAADCEquipment() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var elevationFactors = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAADCEquipment').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationFactor = parseFloat(value);
        if (isNaN(value)) {
            elevationFactor = '';
        }
        elevationFactors.push(elevationFactor);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(value)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateAADCFactorsEquipment',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors),
            'elevationFactorsStr': JSON.stringify(elevationFactors),
            'numOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCEquipment', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCEquipment', response.responseText);
        },
    });
}
function SaveAADCBuilding() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var elevationFactors = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAADCBuilding').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationFactor = parseFloat(value);
        if (isNaN(value)) {
            elevationFactor = '';
        }
        elevationFactors.push(elevationFactor);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(value)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADCBuilding',
        url: '/cmd/DLGENERATOR/UpdateAADCBuilding',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors),
            'elevationFactorsStr': JSON.stringify(elevationFactors),
            'numOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCBuilding', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCBuilding', response.responseText);
        },
    });
}
function SaveAADCBasin() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var cellnum;

    var table = $('#tableAADCBasin').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADCBasin',
        url: '/cmd/DLGENERATOR/UpdateAADCBasin',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCBasin', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCBasin', response.responseText);
        },
    });
}
function SaveAADCOthers() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationDocs = [];
    var elevationDocs = [];
    var cellnum;

    var table = $('#tableAADCOthers').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationDoc = parseFloat(value);
        if (isNaN(value)) {
            foundationDoc = '';
        }
        foundationDocs.push(foundationDoc);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationDoc = parseFloat(value);
        if (isNaN(value)) {
            elevationDoc = '';
        }
        elevationDocs.push(elevationDoc);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAADCOther',
        url: '/cmd/DLGENERATOR/UpdateAADCOther',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationDocsStr': JSON.stringify(foundationDocs),
            'elevationDocsStr': JSON.stringify(elevationDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCOthers', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCOthers', response.responseText);
        },
    });
}
function SetAACSSettings() {
    $("#inputAACSDrawingNum").val(aacsDrawingNum);
}
function SaveAACSSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var mindocs = $("#inputAACSDrawingNum").val();

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAACSSettings',
        url: '/cmd/DLGENERATOR/UpdateAACSSettings',
        data: {
            'code': project,
            'numdrw': mindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAACSSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAACSSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAACS() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numDocs = [];
    var cellnum;

    var table = $('#tableAACS').DataTable();
    var valid = true;

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        itemTags.push(data[1]);
        tagTypes.push(data[2]);

        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        numDocs.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAACS',
        url: '/cmd/DLGENERATOR/UpdateAACS',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SetAIDUSettings() {
    $("#inputAIDUPipeDrawingNum").val(aiduPipeStructureMinimumDrw);
    $("#inputAIDUArea").val(aiduFoundProcessRefArea);
    $("#inputAIDUBuildingDrawingNum").val(aiduFoundBuildingMinimumDrw);
    $("#inputAIDUOtherDrawingNum").val(aiduFoundOtherMinimumDrw);
}
function SaveAIDUSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var pipemindocs = $("#inputAIDUPipeDrawingNum").val();
    var refarea = $("#inputAIDUArea").val();
    var bldgmindocs = $("#inputAIDUBuildingDrawingNum").val();
    var otherdocs = $("#inputAIDUOtherDrawingNum").val();

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDUSettings',
        url: '/cmd/DLGENERATOR/UpdateAIDUSettings',
        data: {
            'code': project,
            'pipemindocs': pipemindocs,
            'refarea': refarea,
            'bldgmindocs': bldgmindocs,
            'otherdocs': otherdocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAIDUSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAIDUSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAIDUPipes() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var numOfFloors = [];
    var numOfModules = [];
    var cellnum;

    var table = $('#tableAIDUPipeRacks').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfFloors.push(num);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfModules.push(num);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDUFactorsPipesStructures',
        url: '/cmd/DLGENERATOR/UpdateAIDUFactorsPipesStructures',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'pipesFactorsStr': JSON.stringify(foundationFactors),
            'pipesNumOfFloorsStr': JSON.stringify(numOfFloors),
            'pipesNumOfModulesStr': JSON.stringify(numOfModules)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUPipeRacks', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUPipeRacks', response.responseText);
        },
    });
}
function SaveAIDUProcess() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var areas = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAIDUProcess').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
            area = '';
        }
        areas.push(area);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDUProcessStructures',
        url: '/cmd/DLGENERATOR/UpdateAIDUProcessStructures',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'areaStr': JSON.stringify(areas),
            'structureNumOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUProcess', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUProcess', response.responseText);
        },
    });
}
function SaveAIDUShelter() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var shelterFactorStr = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAIDUShelter').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var factor = parseFloat(value);
        if (isNaN(factor)) {
            factor = '';
        }
        shelterFactorStr.push(factor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDUShelter',
        url: '/cmd/DLGENERATOR/UpdateAIDUShelter',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'shelterFactorStr': JSON.stringify(shelterFactorStr),
            'structureNumOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUShelter', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUShelter', response.responseText);
        },
    });
}
function SaveAIDUPipeSupport() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numOfDocs = [];
    var cellnum;

    var table = $('#tableAIDUPipeSupport').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var doc = parseInt(value);
        if (isNaN(doc)) {
            doc = '';
        }
        numOfDocs.push(doc);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDUPipeSupport',
        url: '/cmd/DLGENERATOR/UpdateAIDUPipeSupport',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numOfDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUPipeSupport', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUPipeSupport', response.responseText);
        },
    });
}
function SaveAIDUOthers() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numOfDocs = [];
    var cellnum;

    var table = $('#tableAIDUOthers').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var doc = parseInt(value);
        if (isNaN(doc)) {
            doc = '';
        }
        numOfDocs.push(doc);
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDUOthers',
        url: '/cmd/DLGENERATOR/UpdateAIDUOthers',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numOfDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUOthers', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUOthers', response.responseText);
        },
    });
}
function SetAIDASettings() {
    $("#inputAIDADrawingNum").val(aidaDrawingNum);
}
function SaveAIDASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var mindocs = $("#inputAIDADrawingNum").val();

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDASettings',
        url: '/cmd/DLGENERATOR/UpdateAIDASettings',
        data: {
            'code': project,
            'numdrw': mindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAIDASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAIDASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAIDAFireproofing() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numDocs = [];
    var cellnum;

    var table = $('#tableAIDAFireproofing').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var docs = parseInt(value);
        if (isNaN(docs)) {
        }
        else {
            itemTags.push(data[0]);
            tagTypes.push(data[1]);
            numDocs.push(docs);
        }
    });

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAIDAFireproofing',
        url: '/cmd/DLGENERATOR/UpdateAIDAFireproofing',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDAFireproofing', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDAFireproofing', response.responseText);
        },
    });
}
function SetAICSSettings() {
    $("#inputAICSDrawingNum").val(aicsDrawingNum);
}
function SaveAICSSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var mindocs = $("#inputAICSDrawingNum").val();
    var maxValue = parseInt($('#inputMaxManualDoc').text());
    if (mindocs > maxValue) {
        alert("Bigger value than settings " + maxValue);
        valid = false;
        return;
    }

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateAICSSettings',
        data: {
            'code': project,
            'numdrw': mindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAICSSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAICSSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAICS() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var numDocs = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAICS').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();

        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        numDocs.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateAICS',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}
function SetAQDASettings() {
    $("#AQDADrawingScale").val(aqdaDrawingScale);
    $("#AQDADrawingSize").val(aqdaDrawingSize);
    $("#inputAQDAArea").val(aqdaArea);
}
function SaveAQDASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var scale = $("#AQDADrawingScale").val();
    var size = $("#AQDADrawingSize").val();
    var area = $("#inputAQDAArea").val();

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAQDASettings',
        url: '/cmd/DLGENERATOR/UpdateAQDASettings',
        data: {
            'code': project,
            'scale': scale,
            'size': size,
            'area': area
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAQDASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAQDASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAQDA() {
    var project = $('#labelProject').text();

    // GetData
    var units = [];
    var areas = [];
    var drawings = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAQDA').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        units.push(data[1]);
        areas.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        var value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        drawings.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAQDA',
        url: '/cmd/DLGENERATOR/UpdateAQDA',
        data: {
            'code': project,
            'unitstr': JSON.stringify(units),
            'areastr': JSON.stringify(areas),
            'drawingstr': JSON.stringify(drawings)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response);
        },
    });
}
function SetAPDASettings() {
    $("#APDADrawingScale").val(apdaDrawingScale);
    $("#APDADrawingSize").val(apdaDrawingSize);
    $("#inputAPDAArea").val(apdaArea);
}
function SaveAPDASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var scale = $("#APDADrawingScale").val();
    var size = $("#APDADrawingSize").val();
    var area = $("#inputAPDAArea").val();

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAPDASettings',
        url: '/cmd/DLGENERATOR/UpdateAPDASettings',
        data: {
            'code': project,
            'scale': scale,
            'size': size,
            'area': area
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAPDASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAPDASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAPDA() {
    var project = $('#labelProject').text();

    // GetData
    var units = [];
    var areas = [];
    var drawings = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAPDA').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        units.push(data[1]);
        areas.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        var value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        drawings.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateAPDA',
        url: '/cmd/DLGENERATOR/UpdateAPDA',
        data: {
            'code': project,
            'unitstr': JSON.stringify(units),
            'areastr': JSON.stringify(areas),
            'drawingstr': JSON.stringify(drawings)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response);
        },
    });
}
function SetARDASettings() {
    $("#APRADrawingScale").val(ardaDrawingScale);
    $("#APRADrawingSize").val(ardaDrawingSize);
    $("#inputARDAArea").val(ardaArea);
}
function SaveARDASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var scale = $("#ARDADrawingScale").val();
    var size = $("#ARDADrawingSize").val();
    var area = $("#inputARDAArea").val();

    $.ajax({
        type: 'POST',
        //url: '/cmd/DLGENERATOR/UpdateARDASettings',
        url: '/cmd/DLGENERATOR/UpdateARDASettings',
        data: {
            'code': project,
            'scale': scale,
            'size': size,
            'area': area
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageARDASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageARDASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveARDA() {
    var project = $('#labelProject').text();

    // GetData
    var units = [];
    var areas = [];
    var drawings = [];
    var cellnum;

    var valid = true;
    var table = $('#tableARDA').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();
        units.push(data[1]);
        areas.push(data[2]);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        var value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        drawings.push(valint);
    });

    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateARDA',
        data: {
            'code': project,
            'unitstr': JSON.stringify(units),
            'areastr': JSON.stringify(areas),
            'drawingstr': JSON.stringify(drawings)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response);
        },
    });
}
function SaveAIDU() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var numDocs = [];
    var cellnum;

    var valid = true;
    var table = $('#tableAIDU').DataTable();

    var maxValue = parseInt($('#inputMaxManualDoc').text());

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 6 }).node();
        value = $('input', cellnum).val();
        var valint = parseInt(value);

        if (valid && valint < 0) {
            alert("Invalid value " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }

        if (valid && valint > maxValue) {
            alert("Bigger value than settings " + data[1] + "-" + data[2]);
            valid = false;
            return;
        }
        numDocs.push(valint);
    });


    if (!valid)
        return;

    $.ajax({
        type: 'POST',
        url: '/cmd/DLGENERATOR/UpdateAIDU',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            alert(response);
        },
        error: function (response, error) {
            alert(response.responseText);
        },
    });
}

//Apply values

function axApplyValues() {

    dlSettingsTables[0].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[0], 3, rowIdx, 'AX');
    });
    dlSettingsTables[0].draw();
}

function aacsApplyValues() {

    dlSettingsTables[1].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[1], 4, rowIdx, 'AACS');
    });
    dlSettingsTables[1].draw();
}

function aadaApplyValues() {

    dlSettingsTables[2].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[2], 5, rowIdx, 'AADA');
    });
    dlSettingsTables[2].draw();
}

function aadcApplyValues() {

    dlSettingsTables[3].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[3], 8, rowIdx, 'AADC');
    });
    dlSettingsTables[3].draw();
}

function aaOthersApplyValues() {

    dlSettingsTables[4].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[4], 3, rowIdx, 'AAOthers');
    });
    dlSettingsTables[4].draw();
}

function agApplyValues() {

    dlSettingsTables[5].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[5], 3, rowIdx, 'AG');
    });
    dlSettingsTables[5].draw();
}

function aicsApplyValues() {

    dlSettingsTables[6].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[6], 3, rowIdx, 'AICS');
    });
    dlSettingsTables[6].draw();
}

function aiduApplyValues() {

    dlSettingsTables[7].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[7], 6, rowIdx, 'AIDU');
    });
    dlSettingsTables[7].draw();
}

function aiOthersApplyValues() {

    dlSettingsTables[8].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[8], 3, rowIdx, 'AIOthers');
    });
    dlSettingsTables[8].draw();
}

function apdaApplyValues() {

    dlSettingsTables[9].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[9], 5, rowIdx, 'APDA');
    });
    dlSettingsTables[9].draw();
}

function apOthersApplyValues() {

    dlSettingsTables[10].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[10], 3, rowIdx, 'APOthers');
    });
    dlSettingsTables[10].draw();
}

function aqdaApplyValues() {

    dlSettingsTables[11].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[11], 5, rowIdx, 'AQDA');
    });
    dlSettingsTables[11].draw();
}

function aqOthersApplyValues() {

    dlSettingsTables[12].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[12], 3, rowIdx, 'AQOthers');
    });
    dlSettingsTables[12].draw();
}

function ardaApplyValues() {

    dlSettingsTables[13].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[13], 5, rowIdx, 'ARDA');
    });
    dlSettingsTables[13].draw();
}

function arOthersApplyValues() {

    dlSettingsTables[14].rows().every(function (rowIdx, tableLoop, rowLoop) {
        updateDLSettingsTableValues(dlSettingsTables[14], 3, rowIdx, 'AROthers');
    });
    dlSettingsTables[14].draw();
}

function updateDLSettingsTableValues(table, colIdx, rowIdx, code) {
    var valueToApply = $('#inputValue' + code).val();

    var cell = table.cell({ row: rowIdx, column: 0 }).node();
    rowChecked = $('input', cell).prop('checked');
    if (rowChecked) {
        cell = table.cell({ row: rowIdx, column: colIdx }).node();
        $('input', cell).val(valueToApply);
    }
}