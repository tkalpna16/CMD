﻿$(document).ready(function () {

    // Hide All
    HideAllColumn();
    HideAllDLTables();

    InitDLTables();

    SetSettings();
});

function InitDLTables() {
    InitDLTable('tableCommonDocuments', '42vh');

    InitDLTable('tableAADAPiles', '40vh');
    InitDLTable('tableAADCPlan', '40vh');
    InitDLTable('tableAADCPipeRacks', '26vh');
    InitDLTable('tableAADCEquipment', '26vh');
    InitDLTable('tableAADCBuilding', '26vh');
    InitDLTable('tableAADCBasin', '26vh');
    InitDLTable('tableAADCOthers', '26vh');
    InitDLTable('tableAIDUPipeRacks', '26vh');
    InitDLTable('tableAIDUProcess', '26vh');
    InitDLTable('tableAIDUShelter', '26vh');
    InitDLTable('tableAIDUPipeSupport', '26vh');
    InitDLTable('tableAIDUOthers', '26vh');
    InitDLTable('tableAACSConcrete', '26vh');
    InitDLTable('tableAIDAFireproofing', '36vh');
    InitDLTable('tableAICSSteel', '36vh');
    InitDLTable('tableAQDAWBS', '36vh');
    InitDLTable('tableAPDAWBS', '36vh');
    InitDLTable('tableARDAWBS', '36vh');
}

function InitDLTable(tableId, height) {
    var table = $('#' + tableId).DataTable({
        paging: false,
        orderCellsTop: true,
        scrollY: height,
        scrollCollapse: true,
        fixedHeader: false,
        searching: true,
        bInfo: false,
        bSort: true,
        language: {
            "zeroRecords": "",
            "emptyTable": ""
        },
        dom: 'Bfrtip',
        buttons: [
            'copy', 'excel', 'pdf'
        ],
        search: {
            "caseInsensitive": true
        }
    });
}

var dlCodes = ['CommonDocuments', 'AADA', 'AADC', 'AACS', 'AIDU', 'AIDA', 'AICS', 'AQDA']
var tableCodes = ['divTableCommonDocuments', 'divTableAADASettings', 'divTableAADAPiles', 'divTableAADCSettings', 'divTableAADCPlan', 'divTableAADCPipeRacks', 'divTableAADCEquipment', 'divTableAADCBuilding', 'divTableAADCBasin', 'divTableAADCOthers', 'divTableAACSSettings', 'divTableAACSConcrete', 'divTableAIDUSettings','divTableAIDUPipeRacks', 'divTableAIDUProcess', 'divTableAIDUShelter', 'divTableAIDUPipeSupport','divTableAIDUOthers','divTableAIDASettings', 'divTableAIDAFireproofing', 'divTableAICSSettings', 'divTableAICSSteel', 'divTableAQDASettings', 'divTableAQDAWBS', 'divTableAPDASettings', 'divTableAPDAWBS']
var pressedBntClass = 'btn-primary'
var notPressedBntClass = 'btn-light'

function HideDLColumn(code) {
    $("#columnButton" + code).hide();
}
function ShowDLColumn(code) {
    $("#columnButton" + code).show();
}
function HideAllColumn() {
    dlCodes.forEach(element => HideDLColumn(element));
}
function SetDLBtnPressed(id) {
    $("#" + id).removeClass(notPressedBntClass);
    $("#" + id).addClass(pressedBntClass);
}
function SetDLBtnNotPressed(id) {
    $("#" + id).removeClass(pressedBntClass);
    $("#" + id).addClass(notPressedBntClass);
}
function RemoveAllButtonPressed() {
    dlCodes.forEach(element => SetDLBtnNotPressed('btn' + element));
}

function clickDLMainButton(clicked_id) {
    HideAllColumn();
    HideAllDLTables();
    RemoveAllButtonPressed();
    SetDLBtnPressed(clicked_id);
    if (clicked_id != '') {
        var colName = clicked_id.replace('btn', '');
        ShowDLColumn(colName);
        if (colName != 'CommonDocuments') {
            var divId = 'columnButton' + colName;
            SetDLSecondaryButtonNotPressed(divId);
        }
        else {
            var divTableName = '#divTable' + colName;
            showElement(divTableName);
            var tableName = '#table' + colName;
            var table = $(tableName).DataTable().columns.adjust();
        }
    }
}

function SetDLSecondaryButtonNotPressed(divId) {
    var btns = document.getElementById(divId).querySelectorAll(":scope > .btn");
    btns.forEach(element => SetDLBtnNotPressed(element.id));
}

function clickDLSecondaryButton(clicked_id, div_id) {
    SetDLSecondaryButtonNotPressed(div_id);
    SetDLBtnPressed(clicked_id);
    HideAllDLTables();
    var colName = clicked_id.replace('btn', '');
    showElement('#divTable' + colName);
    var tableName = '#table' + colName;
    var table = $(tableName).DataTable().columns.adjust();
}

function HideAllDLTables() {
    tableCodes.forEach(element => hideElement('#' + element));
}

function SaveCommonDocuments() {
    var project = $('#labelProject').text();

    // GetData
    var docTypes = [];
    var docDescr = [];
    var docNumber = [];
    var cellnum;

    var table = $('#tableCommonDocuments').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        docTypes.push(data[0]);
        docDescr.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 2 }).node();
        value = $('input', cellnum).val();
        docNumber.push(value);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateCommonDocuments',
        data: {
            'code': project,
            'documentstr': JSON.stringify(docTypes),
            'descrstr': JSON.stringify(docDescr),
            'numberstr': JSON.stringify(docNumber)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelCommonDocuments', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelCommonDocuments', response.responseText);
        },
    });
}

function SaveAQDAWBS() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var areas = [];
    var cellnum;

    var table = $('#tableAQDAWBS').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);

        cellnum = table.cell({ row: rowIdx, column: 2 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
            alert("Not correct value: " + value);
            return;
        }
        areas.push(area);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADAPiles',
        data: {
            'code': project,
            'itemstr': JSON.stringify(itemTags),
            'areastr': JSON.stringify(areas)
        },
        dataType: 'text',
        success: function (response) {
            var object = JSON.parse(response);
            displayMessage('messageLabelPiles', object.message);
            if (object.valid) {
                var documents = object.documents;
                if (documents) {
                    var counter = 0;
                    table.rows().every(function (rowIdx) {
                        var cell = table.cell(rowIdx, 1);
                        cell.data(documents[counter]).draw();
                        counter++;
                    });
                    //table.draw(true);
                }
            }
        },
        error: function (response, error) {
            var object = JSON.parse(response.responseText);
            displayMessage('messageLabelPiles', object.message);
        },
    });
}

/*
 * SETTINGS
 */
function SetSettings() {
    //SetAADASettings();
    //SetAADCSettings();
    //SetAACSSettings();

    //SetAIDASettings();
    //SetAICSSettings();
    //SetAQDASettings();
    //SetAPDASettings();
    //SetARDASettings();
}

function SetAADASettings() {
    $("#AADADrawingScale").val(aadaDrawingScale);
    $("#AADADrawingSize").val(aadaDrawingSize);
    $("#inputAADAADrawingNum").val(aadaDrawingNum);
    $("#inputAADAAArea").val(aadaArea);
}
function SaveAADASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var scale = $("#AADADrawingScale").val();
    var size = $("#AADADrawingSize").val();
    var mindocs = $("#inputAADAADrawingNum").val();
    var area = $("#inputAADAAArea").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADASettings',
        data: {
            'code': project,
            'scale': scale,
            'size': size,
            'numdrw': mindocs,
            'area': area
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAADASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAADASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAADAPiles() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var areas = [];
    var cellnum;

    var table = $('#tableAADAPiles').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
            alert("Not correct value: " + value);
            return;
        }
        areas.push(area);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADAPiles',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'areasStr': JSON.stringify(areas)
        },
        dataType: 'text',
        success: function (response) {
            var object = JSON.parse(response);
            displayMessage('messageLabelPiles', object.message);
            if (object.valid) {
                var documents = object.documents;
                if (documents) {
                    var counter = 0;
                    table.rows().every(function (rowIdx) {
                        var cell = table.cell(rowIdx, 3);
                        cell.data(documents[counter]).draw();
                        counter++;
                    });
                    //table.draw(true);
                }
            }
        },
        error: function (response, error) {
            var object = JSON.parse(response.responseText);
            displayMessage('messageLabelPiles', object.message);
        },
    });
}

function SetAADCSettings() {
    $("#inputAADCFoundationPR_FW").val(aadcFoundationPR_FW);
    $("#inputAADCFoundationST_FW").val(aadcFoundationST_FW);
    $("#inputAADCFoundationEQ_FW").val(aadcFoundationEQ_FW);
    $("#inputAADCFoundationBL_FW").val(aadcFoundationBL_FW);
    $("#inputAADCFoundationBS_FW").val(aadcFoundationBS_FW);
    $("#inputAADCElevationPR_FW").val(aadcElevationPR_FW);
    $("#inputAADCElevationST_FW").val(aadcElevationST_FW);
    $("#inputAADCElevationEQ").val(aadcElevationEQ);
    $("#inputAADCElevationBL").val(aadcElevationBL);

    $("#inputAADCFoundationPR_RF").val(aadcFoundationPR_RF);
    $("#inputAADCFoundationST_RF").val(aadcFoundationST_RF);
    $("#inputAADCFoundationEQ_RF").val(aadcFoundationEQ_RF);
    $("#inputAADCFoundationBL_RF").val(aadcFoundationBL_RF);
    $("#inputAADCFoundationBS_RF").val(aadcFoundationBS_RF);
    $("#inputAADCElevationPR_RF").val(aadcElevationPR_RF);
    $("#inputAADCElevationST_RF").val(aadcElevationST_RF);

    $("#inputAADCFoundationPR_BBS").val(aadcFoundationPR_BBS);
    $("#inputAADCFoundationST_BBS").val(aadcFoundationST_BBS);
    $("#inputAADCFoundationEQ_BBS").val(aadcFoundationEQ_BBS);
    $("#inputAADCFoundationBL_BBS").val(aadcFoundationBL_BBS);
    $("#inputAADCFoundationBS_BBS").val(aadcFoundationBS_BBS);
    $("#inputAADCElevationPR_BBS").val(aadcElevationPR_BBS);
    $("#inputAADCElevationST_BBS").val(aadcElevationST_BBS);

    $("#inputAADCPipeRackMultiplerFoundation").val(aadcPipeRackMultiplerFoundation);
    $("#inputAADCProcessStructureMultiplerFoundation").val(aadcProcessStructureMultiplerFoundation);
    $("#inputAADCEquipmentMultiplerFoundation").val(aadcEquipmentMultiplerFoundation);
    $("#inputAADCBuildingMultiplerFoundation").val(aadcBuildingMultiplerFoundation);
    $("#inputAADCBasinMultiplerFoundation").val(aadcBasinMultiplerFoundation);
    $("#inputAADCPipeRackMultiplerElevation").val(aadcPipeRackMultiplerElevation);
    $("#inputAADCProcessStructureMultiplerElevation").val(aadcProcessStructureMultiplerElevation);
    $("#inputAADCEquipmentMultiplerElevation").val(aadcEquipmentMultiplerElevation);
    $("#inputAADCBuildingMultiplerElevation").val(aadcBuildingMultiplerElevation);
}
function SaveAADCSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var foundationPR_FW = $("#inputAADCFoundationPR_FW").val();
    var foundationST_FW = $("#inputAADCFoundationST_FW").val();
    var foundationEQ_FW = $("#inputAADCFoundationEQ_FW").val();
    var foundationBL_FW = $("#inputAADCFoundationBL_FW").val();
    var foundationBS_FW = $("#inputAADCFoundationBS_FW").val();
    var elevationPR_FW = $("#inputAADCElevationPR_FW").val();
    var elevationST_FW = $("#inputAADCElevationST_FW").val();
    var elevationEQ = $("#inputAADCElevationEQ").val();
    var elevationBL = $("#inputAADCElevationBL").val();

    var foundationPR_RF = $("#inputAADCFoundationPR_RF").val();
    var foundationST_RF = $("#inputAADCFoundationST_RF").val();
    var foundationEQ_RF = $("#inputAADCFoundationEQ_RF").val();
    var foundationBL_RF = $("#inputAADCFoundationBL_RF").val();
    var foundationBS_RF = $("#inputAADCFoundationBS_RF").val();
    var elevationPR_RF = $("#inputAADCElevationPR_RF").val();
    var elevationST_RF = $("#inputAADCElevationST_RF").val();

    var foundationPR_BBS = $("#inputAADCFoundationPR_BBS").val();
    var foundationST_BBS = $("#inputAADCFoundationST_BBS").val();
    var foundationEQ_BBS = $("#inputAADCFoundationEQ_BBS").val();
    var foundationBL_BBS = $("#inputAADCFoundationBL_BBS").val();
    var foundationBS_BBS = $("#inputAADCFoundationBS_BBS").val();
    var elevationPR_BBS = $("#inputAADCElevationPR_BBS").val();
    var elevationST_BBS = $("#inputAADCElevationST_BBS").val();

    var multipler1 = $("#inputAADCPipeRackMultiplerFoundation").val();
    var multipler2 = $("#inputAADCProcessStructureMultiplerFoundation").val();
    var multipler3 = $("#inputAADCEquipmentMultiplerFoundation").val();
    var multipler4 = $("#inputAADCBuildingMultiplerFoundation").val();
    var multipler5 = $("#inputAADCBasinMultiplerFoundation").val();
    var multipler6 = $("#inputAADCPipeRackMultiplerElevation").val();
    var multipler7 = $("#inputAADCProcessStructureMultiplerElevation").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCSettings',
        data: {
            'code': project,
            'foundationPR_FW': foundationPR_FW,
            'foundationST_FW': foundationST_FW,
            'foundationEQ_FW': foundationEQ_FW,
            'foundationBL_FW': foundationBL_FW,
            'foundationBS_FW': foundationBS_FW,
            'elevationPR_FW': elevationPR_FW,
            'elevationST_FW': elevationST_FW,
            'elevationEQ': elevationEQ,
            'elevationBL': elevationBL,
            'foundationPR_RF': foundationPR_RF,
            'foundationST_RF': foundationST_RF,
            'foundationEQ_RF': foundationEQ_RF,
            'foundationBL_RF': foundationBL_RF,
            'foundationBS_RF': foundationBS_RF,
            'elevationPR_RF': elevationPR_RF,
            'elevationST_RF': elevationST_RF,
            'foundationPR_BBS': foundationPR_BBS,
            'foundationST_BBS': foundationST_BBS,
            'foundationEQ_BBS': foundationEQ_BBS,
            'foundationBL_BBS': foundationBL_BBS,
            'foundationBS_BBS': foundationBS_BBS,
            'elevationPR_BBS': elevationPR_BBS,
            'elevationST_BBS': elevationST_BBS,
            'multipler1': multipler1,
            'multipler2': multipler2,
            'multipler3': multipler3,
            'multipler4': multipler4,
            'multipler5': multipler5,
            'multipler6': multipler6,
            'multipler7': multipler7
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAADCSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAADCSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAADCPlans() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var areas = [];
    var cellnum;

    var table = $('#tableAADCPlan').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
            alert("Not correct value: " + value);
            return;
        }
        areas.push(area);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCFoundationPlan',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'areasStr': JSON.stringify(areas)
        },
        dataType: 'text',
        success: function (response) {
            var object = JSON.parse(response);
            displayMessage('messageLabelAADCPlan', object.message);
            if (object.valid) {
                var documents = object.documents;
                if (documents) {
                    var counter = 0;
                    table.rows().every(function (rowIdx) {
                        var cell = table.cell(rowIdx, 3);
                        cell.data(documents[counter]).draw();
                        counter++;
                    });
                    //table.draw(true);
                }
            }
        },
        error: function (response, error) {
            var object = JSON.parse(response.responseText);
            displayMessage('messageLabelAADCPlan', object.message);
        },
    });
}
function SaveAADCPipes() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var elevationFactors = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAADCPipeRacks').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationFactor = parseFloat(value);
        if (isNaN(value)) {
            elevationFactor = '';
        }
        elevationFactors.push(elevationFactor);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(value)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCFactorsPipesStructures',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors),
            'elevationFactorsStr': JSON.stringify(elevationFactors),
            'numOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCPipeRacks', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCPipeRacks', response.responseText);
        },
    });
}
function SaveAADCEquipment() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var elevationFactors = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAADCEquipment').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationFactor = parseFloat(value);
        if (isNaN(value)) {
            elevationFactor = '';
        }
        elevationFactors.push(elevationFactor);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(value)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCFactorsEquipment',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors),
            'elevationFactorsStr': JSON.stringify(elevationFactors),
            'numOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCEquipment', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCEquipment', response.responseText);
        },
    });
}
function SaveAADCBuilding() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var elevationFactors = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAADCBuilding').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationFactor = parseFloat(value);
        if (isNaN(value)) {
            elevationFactor = '';
        }
        elevationFactors.push(elevationFactor);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(value)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCBuilding',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors),
            'elevationFactorsStr': JSON.stringify(elevationFactors),
            'numOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCBuilding', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCBuilding', response.responseText);
        },
    });
}
function SaveAADCBasin() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var cellnum;

    var table = $('#tableAADCBasin').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCBasin',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationFactorsStr': JSON.stringify(foundationFactors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCBasin', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCBasin', response.responseText);
        },
    });
}
function SaveAADCOthers() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationDocs = [];
    var elevationDocs = [];
    var cellnum;

    var table = $('#tableAADCOthers').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationDoc = parseFloat(value);
        if (isNaN(value)) {
            foundationDoc = '';
        }
        foundationDocs.push(foundationDoc);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var elevationDoc = parseFloat(value);
        if (isNaN(value)) {
            elevationDoc = '';
        }
        elevationDocs.push(elevationDoc);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAADCOther',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'foundationDocsStr': JSON.stringify(foundationDocs),
            'elevationDocsStr': JSON.stringify(elevationDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAADCOthers', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAADCOthers', response.responseText);
        },
    });
}

function SetAACSSettings() {
    $("#inputAACSDrawingNum").val(aacsDrawingNum);
}
function SaveAACSSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var mindocs = $("#inputAACSDrawingNum").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAACSSettings',
        data: {
            'code': project,
            'numdrw': mindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAACSSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAACSSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAACSConcrete() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numDocs = [];
    var cellnum;

    var table = $('#tableAACSConcrete').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var docs = parseInt(value);
        if (isNaN(docs)) {

        }
        else {
            itemTags.push(data[0]);
            tagTypes.push(data[1]);
            numDocs.push(docs);
        }
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAACSConcrete',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAACSConcrete', response);
        },
        error: function (response, error) {
            displayMessage('messageAACSConcrete', response.responseText);
        },
    });
}

function SetAIDUSettings() {
    $("#inputAIDUPipeDrawingNum").val(aiduPipeStructureMinimumDrw);
    $("#inputAIDUArea").val(aiduFoundProcessRefArea);
    $("#inputAIDUBuildingDrawingNum").val(aiduFoundBuildingMinimumDrw);
}
function SaveAIDUSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var pipemindocs = $("#inputAACSDrawingNum").val();
    var refarea = $("#inputAACSDrawingNum").val();
    var bldgmindocs = $("#inputAACSDrawingNum").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDUSettings',
        data: {
            'code': project,
            'pipemindocs': pipemindocs,
            'refarea': refarea,
            'bldgmindocs': bldgmindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAIDUSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAIDUSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAIDUPipes() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var foundationFactors = [];
    var numOfFloors = [];
    var numOfModules = [];
    var cellnum;

    var table = $('#tableAIDUPipeRacks').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var foundationFactor = parseFloat(value);
        if (isNaN(value)) {
            foundationFactor = '';
        }
        foundationFactors.push(foundationFactor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfFloors.push(num);

        cellnum = table.cell({ row: rowIdx, column: 5 }).node();
        value = $('input', cellnum).val();
        num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfModules.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDUFactorsPipesStructures',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'pipesFactorsStr': JSON.stringify(foundationFactors),
            'pipesNumOfFloorsStr': JSON.stringify(numOfFloors),
            'pipesNumOfModulesStr': JSON.stringify(numOfModules)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUPipeRacks', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUPipeRacks', response.responseText);
        },
    });
}
function SaveAIDUProcess() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var areas = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAIDUProcess').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
            area = '';
        }
        areas.push(area);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDUProcessStructures',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'areaStr': JSON.stringify(areas),
            'structureNumOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUProcess', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUProcess', response.responseText);
        },
    });
}
function SaveAIDUShelter() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var shelterFactorStr = [];
    var numOfFloors = [];
    var cellnum;

    var table = $('#tableAIDUShelter').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var factor = parseFloat(value);
        if (isNaN(factor)) {
            factor = '';
        }
        shelterFactorStr.push(factor);

        cellnum = table.cell({ row: rowIdx, column: 4 }).node();
        value = $('input', cellnum).val();
        var num = parseInt(value);
        if (isNaN(num)) {
            num = '';
        }
        numOfFloors.push(num);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDUShelter',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'shelterFactorStr': JSON.stringify(shelterFactorStr),
            'structureNumOfFloorsStr': JSON.stringify(numOfFloors)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUShelter', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUShelter', response.responseText);
        },
    });
}
function SaveAIDUPipeSupport() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numOfDocs = [];
    var cellnum;

    var table = $('#tableAIDUPipeSupport').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var doc = parseInt(value);
        if (isNaN(doc)) {
            doc = '';
        }
        numOfDocs.push(doc);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDUPipeSupport',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numOfDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUPipeSupport', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUPipeSupport', response.responseText);
        },
    });
}
function SaveAIDUOthers() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numOfDocs = [];
    var cellnum;

    var table = $('#tableAIDUOthers').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        itemTags.push(data[0]);
        tagTypes.push(data[1]);

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var doc = parseInt(value);
        if (isNaN(doc)) {
            doc = '';
        }
        numOfDocs.push(doc);
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDUOthers',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numOfDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDUOthers', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDUOthers', response.responseText);
        },
    });
}

function SetAIDASettings() {
    $("#inputAIDADrawingNum").val(aidaDrawingNum);
}
function SaveAIDASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var mindocs = $("#inputAIDADrawingNum").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDASettings',
        data: {
            'code': project,
            'numdrw': mindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAIDASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAIDASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAIDAFireproofing() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numDocs = [];
    var cellnum;

    var table = $('#tableAIDAFireproofing').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var docs = parseInt(value);
        if (isNaN(docs)) {
        }
        else {
            itemTags.push(data[0]);
            tagTypes.push(data[1]);
            numDocs.push(docs);
        }
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAIDAFireproofing',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAIDAFireproofing', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAIDAFireproofing', response.responseText);
        },
    });
}

function SetAICSSettings() {
    $("#inputAICSDrawingNum").val(aicsDrawingNum);
}
function SaveAICSSettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var mindocs = $("#inputAICSDrawingNum").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAICSSettings',
        data: {
            'code': project,
            'numdrw': mindocs
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAICSSettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAICSSettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAICSSteel() {
    var project = $('#labelProject').text();

    // GetData
    var itemTags = [];
    var tagTypes = [];
    var numDocs = [];
    var cellnum;

    var table = $('#tableAICSSteel').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var docs = parseInt(value);
        if (isNaN(docs)) {
        }
        else {
            itemTags.push(data[0]);
            tagTypes.push(data[1]);
            numDocs.push(docs);
        }
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAICSSteel',
        data: {
            'code': project,
            'itemTagsStr': JSON.stringify(itemTags),
            'tagTypesStr': JSON.stringify(tagTypes),
            'numOfDocsStr': JSON.stringify(numDocs)
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageLabelAICSSteel', response);
        },
        error: function (response, error) {
            displayMessage('messageLabelAICSSteel', response.responseText);
        },
    });
}

function SetAQDASettings() {
    $("#AQDADrawingScale").val(aqdaDrawingScale);
    $("#AQDADrawingSize").val(aqdaDrawingSize);
    $("#inputAQDAArea").val(aqdaArea);
}
function SaveAQDASettings() {
    loadSpinner();
    var project = $('#labelProject').text();

    // GetData
    var scale = $("#AQDADrawingScale").val();
    var size = $("#AQDADrawingSize").val();
    var area = $("#inputAQDAArea").val();

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAQDASettings',
        data: {
            'code': project,
            'scale': scale,
            'size': size,
            'area': area
        },
        dataType: 'text',
        success: function (response) {
            displayMessage('messageAQDASettings', response);
            hideSpinner();
        },
        error: function (response, error) {
            displayMessage('messageAQDASettings', response.responseText);
            hideSpinner();
        },
    });
}
function SaveAQDAWBS() {
    var project = $('#labelProject').text();

    // GetData
    var units = [];
    var caList = [];
    var areas = [];
    var cellnum;

    var table = $('#tableAQDAWBS').DataTable();
    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var data = this.data();

        cellnum = table.cell({ row: rowIdx, column: 3 }).node();
        value = $('input', cellnum).val();
        var area = parseFloat(value);
        if (isNaN(value)) {
        }
        else {
            units.push(data[0]);
            caList.push(data[1]);
            areas.push(area);
        }
    });

    $.ajax({
        type: 'POST',
        url: '/DLGENERATOR/UpdateAQDA',
        data: {
            'code': project,
            'unitstr': JSON.stringify(units),
            'castr': JSON.stringify(caList),
            'areastr': JSON.stringify(areas)
        },
        dataType: 'text',
        success: function (response) {
            var object = JSON.parse(response);
            displayMessage('messageAQDAWBS', object.message);
            if (object.valid) {
                var documents = object.documents;
                if (documents) {
                    var counter = 0;
                    table.rows().every(function (rowIdx) {
                        var cell = table.cell(rowIdx, 2);
                        cell.data(documents[counter]).draw();
                        counter++;
                    });
                }
            }
        },
        error: function (response, error) {
            var object = JSON.parse(response.responseText);
            displayMessage('messageAQDAWBS', object.message);
        },
    });
}