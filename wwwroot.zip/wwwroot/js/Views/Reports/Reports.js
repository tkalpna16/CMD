﻿$(document).ready(function () {

    $('#WPCode').multiselect({
        includeSelectAllOption: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300,
        enableFiltering: true,
        buttonWidth: '100%',
        buttonClass: 'form-select',
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle" data-bs-toggle="dropdown"><span class="multiselect-selected-text"></span></button>',
        }
    });

    $('#downloadLink').click(function () {
        
        // TagType
        var dropdownvaltagtype = $("#TagType").val();
        if (!dropdownvaltagtype) {
            alert("Any TagType selected!!");
            return;
        }

        // Add Item List
        var project = $('#labelProject').text();
        if (!project || project == '') {
            alert("Any Project selected!!");
            return;
        }

        // WP List
        var wp = [];
        $('#WPCode :selected').each(function () {
            wp.push($(this).text());
        });
        if (wp.length == 0) {
            alert("Any WP selected!!");
            return;
        }

        loadSpinner();

        var url= '/cmd/Reports/CreateExcelFeasibilityCurve';
        $.ajax({
            type: "GET",
            url: url,
            contentType: "application/json; charset=utf-8",
            data: {
                'code': project,
                'tagTypeStr': dropdownvaltagtype,
                'wpStr': JSON.stringify(wp)
            },
            dataType: "json",
            success: function (data) {
                var now = new Date();
                var dateString = moment(now).format('YYYY-MM-DD');
                var link = document.createElement('a');
                link.href = "/cmd/Temp/FeasibilityCurve.xlsx";
                link.download = project + "-FeasibilityCurve_" + dateString + ".xlsx";
                link.click();;

                //window.location = '/Reports/Download?filename=FeasibilityCurve.xlsx';
                hideSpinner();
            },
            error: function (response) {
                hideSpinner();
            }
        });
    });
});

