﻿/*--------------------------------------------------
    Const
-------------------------------------------------- */

const STATUS_OK = 'OK';
const STATUS_PBS_DELETED = 'PBS deleted';
const STATUS_DELETED = 'Deleted';
const STATUS_VENDOR_DELETED = 'VENDOR deleted';
const STATUS_PO_DELETED = 'PO deleted';
const STATUS_MR_DELETED = 'MR deleted';
const STATUS_MAIN_ITEM_DELETED = 'Main Item deleted';


/*--------------------------------------------------
    UI
-------------------------------------------------- */
function hideElement(elementId) {
    $(elementId).hide();
}

function showElement(elementId) {
    $(elementId).show();
}

function hideDisplayElement(elementId) {
    document.getElementById(elementId).style.display = "none";
}

function enable(elementId) {
    $(elementId).prop("enabled", true);
}

function disable(elementId) {
    $(elementId).prop("disabled", true);
}

function makeNavlinkActive(link) {
    $('.nav-link').removeClass('active');
    $(link).addClass('active');
}

function disableLink(elementId) {
    $(elementId).addClass('disabled');
    $(elementId).removeAttr('href');
}

function setvisible(elementId) {
    $(elementId).css('visibility', 'visible');
}

function setnotvisible(elementId) {
    $(elementId).css('visibility', 'hidden');
}

function displayMessage(msg) {
    var label = $('#messageLabel');
    if (label) {
        $("#messageLabel").fadeIn(1);
        $("#messageLabel").html(msg);
        $('#messageLabel').fadeOut(10000);
    }
}

function displayMessage(label, msg) {
    var labelId = $('#' + label);
    if (labelId) {
        $(labelId).fadeIn(1);
        $(labelId).html(msg);
        $(labelId).fadeOut(10000);
    }
}

function setTitle(title) {
    $("#labelTitle").text(title);
    if (title != 'New Project') {
        showElement('#labelNavProject');
        showElement('#labelNavProjectName');
    }
}

function backButton(controller) {
    var projectId = $('#labelProject').text();
    var url = controller + "?code=" + projectId;
    window.location.href = url;
}

/*--------------------------------------------------
    Spinner
-------------------------------------------------- */

function loadSpinner() {
    var spinner = $('#loader');
    spinner.show();
}

function hideSpinner() {
    var spinner = $('#loader');
    if (spinner) {
        spinner.hide();
    }
}

function setProgressMessage(msg) {
    document.getElementById('labelProgressMessage').innerHTML = msg;
}

function loadSpinnerModal() {
    $("#loadingoverlay").fadeIn();
}

function hideSpinnerModal() {
    $("#loadingoverlay").fadeOut();
}

function setProgressMessageModal(msg) {
    document.getElementById('labelProgressMessageModal').innerHTML = msg;
}

function loadSpinnerModal2() {
    $("#loadingoverlay2").fadeIn();
}

function hideSpinnerModal2() {
    $("#loadingoverlay2").fadeOut();
}

function setProgressMessageModal2(msg) {
    document.getElementById('labelProgressMessageModal2').innerHTML = msg;
}

/*--------------------------------------------------
    Text
-------------------------------------------------- */
function isEmpty(str) {
    return (!str || 0 === str.length);
}

/*--------------------------------------------------
    Benchmark
-------------------------------------------------- */
var startTime, endTime, timeElapsed;

function start() {
    startTime = new Date();
};

function end() {
    endTime = new Date();
    var timeDiff = endTime - startTime; //in ms
    // strip the ms
    timeDiff /= 1000;

    // get seconds 
    var seconds = Math.round(timeDiff);
    timeElapsed = 'Time elapsed: ' + seconds + " seconds";
}

/*--------------------------------------------------
    Excel logs
-------------------------------------------------- */

function showExcelLogsAlert(logmanager) {
    var str = logmanager.result + "\n\n";
    if (logmanager.logs.length > 0) {
        str += '---------- Errors ----------\n\n';
        for (let i = 0; i < logmanager.logs.length; i++) {
            var log = logmanager.logs[i];
            str += "- Row " + log.rowNumber + " Col" + log.columnName + " " + log.note + "\n";
        }
    }
    alert(str);
}

function showExcelLogsAlertNoColumn(logmanager) {
    var str = logmanager.result + "\n\n";
    if (logmanager.logs.length > 0) {
        str += '---------- Warnings ----------\n\n';
        for (let i = 0; i < logmanager.logs.length; i++) {
            var log = logmanager.logs[i];
            str += log.note + "\n";
        }
    }
    alert(str);
}

/*--------------------------------------------------
    Datatable
-------------------------------------------------- */

function colorDatatableRow(cbid) {
    var clrow = $(cbid).closest("tr");
    var checked = $(cbid).prop("checked");

    if (checked) {
        $(clrow).addClass('selected');
    }
    else {
        $(clrow).removeClass('selected');
    }
}

function colorDatatableAllRow(table) {
    loadSpinner();
    setProgressMessage("Selecting all rows..");

    table.rows().every(function (rowIdx, tableLoop, rowLoop) {
        var cell = table.cell({ row: rowIdx, column: 0 }).node();
        var input = $('input', cell);
        var checked = input.prop("checked");

        if (checked) {
            $(this.node()).addClass('selected');
        }
        else {
            $(this.node()).removeClass('selected');
        }
    });

    hideSpinner();
}

function strEndsWith(str, suffix) {
    return str.match(suffix + "$") == suffix;
}

/*--------------------------------------------------
    UI
-------------------------------------------------- */

function clearDropDown(selectid) {
    var select = document.getElementById(selectid),
        length = select.options.length;
    while (length--) {
        select.remove(length);
    }
}

function settooltiptext(id, text) {
    $(id).attr('data-toggle', 'tooltip');
    $(id).attr('title', text);
}

//Code implemented by kalpna to Prevent right click and F12 on 18-11-2022
//$(document).keydown(function (event) {
//    if (event.keyCode == 123) { // Prevent F12
//        return false;
//    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I
//        return false;
//    }
//});
//$(document).on("contextmenu", function (e) {
//    e.preventDefault();
//});
